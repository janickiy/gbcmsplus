<?php

use console\components\Migration;

class m160305_181405_update_browser_notifications extends Migration
{
  public function up()
  {
    $this->addColumn(
      \mcms\notifications\models\BrowserNotification::tableName(),
      'event_instance',
      'TEXT DEFAULT NULL'
    );
  }

  public function down()
  {
    $this->dropColumn(
      \mcms\notifications\models\BrowserNotification::tableName(),
      'event_instance'
    );
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
