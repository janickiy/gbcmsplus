<?php

use console\components\Migration;
use mcms\notifications\models\Notification;

class m160307_075529_add_notification extends Migration
{

  protected $notifications;
  protected $emailNotification;
  protected $moduleUsersId;

  public function init()
  {
    $this->emailNotification = Notification::NOTIFICATION_TYPE_EMAIL;

    $moduleApiResult = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => 'users'])
      ->getResult();
    $this->moduleUsersId = $moduleApiResult->id;

    $this->notifications = [
      [
        'event' => mcms\user\components\events\EventUserApprovedWithoutReferrals::className(),
        'data' => [
          'header' => [
            'ru' => '{projectName} - Аккаунт активирован',
            'en' => '{projectName} - Account has been actived',
          ],
          'template' => [
            'ru' => "<strong>Здравствуйте, {user.username}!<br>Ваш аккаунт прошел проверку и успешно активирован.</strong><br><br>" .
              "<strong>Данные для авторизации в партнерской программе:</strong><br>E-mail: {user.email}<br><br>" .
              "<strong>Перед началом работы:</strong> рекомендуем прочитать {homeUrl}/partners/faq/index/, в котором мы собрали ответы на основные вопросы, чтобы вы смогли с легкостью разобраться c функционалом партнерской программы.<br><br>".
              "<strong>Желаем успехов в работе и отличного профита!<br>С уважением, команда {projectName}.</strong>",
            'en' => "<strong>Greetings, {user.username}!<br>Your account was approved and successfully activated.</strong><br><br>" .
              "<strong>Information for authorization in partners program:</strong><br>E-mail: {user.email}<br><br>" .
              "<strong>Before you start:</strong> we recommend you to read the {homeUrl}/partners/faq/index/ in which we collected answers to most frequent questions, so you can easily use partners program functional.<br><br>".
              "<strong>We wish you success in you work and good profit!<br>Best regards, command of {projectName}.</strong>",
          ],
        ]
      ],
    ];
  }

  // Use safeUp/safeDown to run migration code within a transaction
  public function up()
  {
    foreach ($this->notifications as $notificationData) {
      $notification = $notificationData['event'] ? Notification::findOne([
        'event' => $notificationData['event'],
        'notification_type' => $this->emailNotification,
      ]) : null;
      if (!$notification) {
        $notification = new Notification();
      }

      $notification->setAttributes($notificationData['data'], false);
      $notification->event = $notificationData['event'];
      $notification->notification_type = $this->emailNotification;
      $notification->from = [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}',
      ];
      $notification->emails_language = 'ru';
      $notification->use_owner = 1;
      $notification->module_id = $this->moduleUsersId;

      $notification->save(false);

    }
  }

}
