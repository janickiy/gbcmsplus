<?php

use console\components\Migration;

class m160406_205420_update_notification_header_size extends Migration
{
  const TABLE = 'browser_notifications';
  public function up()
  {

    $this->alterColumn(self::TABLE, 'header', 'VARCHAR(2000)');
  }

  public function down()
  {
    $this->alterColumn(self::TABLE, 'header', 'VARCHAR(255) NOT NULL');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
