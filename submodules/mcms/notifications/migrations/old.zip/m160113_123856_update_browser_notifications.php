<?php

use console\components\Migration;

class m160113_123856_update_browser_notifications extends Migration
{

}
