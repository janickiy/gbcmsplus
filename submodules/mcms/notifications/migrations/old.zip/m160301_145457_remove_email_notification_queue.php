<?php

use console\components\Migration;

class m160301_145457_remove_email_notification_queue extends Migration
{
  public function up()
  {
    $this->db
      ->createCommand("DELETE FROM " . \mcms\notifications\models\EmailNotification::tableName())
      ->execute()
    ;
  }

  public function down()
  {
    echo "m160301_145457_remove_email_notification_queue cannot be reverted.\n";

  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
