<?php

use mcms\notifications\models\Notification;
use yii\db\Schema;
use console\components\Migration;

class m160207_125854_add_initial_notification extends Migration
{
  public function up()
  {

  }


  public function down()
  {
    echo "m160207_125854_add_initial_notification cannot be reverted.\n";
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
