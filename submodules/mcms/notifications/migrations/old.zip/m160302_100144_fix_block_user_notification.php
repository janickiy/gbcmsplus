<?php

use mcms\notifications\models\Notification;
use console\components\Migration;
use yii\helpers\ArrayHelper;

class m160302_100144_fix_block_user_notification extends Migration
{


}
