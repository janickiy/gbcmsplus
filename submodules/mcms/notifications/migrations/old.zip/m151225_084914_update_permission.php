<?php

use console\components\Migration;

class m151225_084914_update_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();

    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Notifications';
    $this->permissions = [
      'Notifications' => [
        ['image-upload', 'Can upload image', ['admin', 'root', 'reseller']],
        ['images-get', 'Can get images', ['admin', 'root', 'reseller']],
      ],
    ];
  }
}
