<?php

use console\components\Migration;

class m151217_151050_reseller_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration {
    up as traitUp;
    down as traitDown;
  }

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Notifications';
    $this->permissions = [
      'Notifications' => [
        ['create', 'Can create notification', ['admin', 'root', 'reseller']],
      ],
    ];
  }


  public function up()
  {
    $this->traitUp();
  }

  public function down()
  {
    $this->traitDown();
    $this->permissions = [
      'Notifications' => [
        ['create', 'Can create notification', ['admin', 'root']],
      ],
    ];
    $this->traitUp();
  }
}
