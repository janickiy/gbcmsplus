<?php

use console\components\Migration;

class m160329_093145_browser_notifications_message extends Migration
{
  public function up()
  {
    $this->alterColumn('browser_notifications', 'message', 'LONGTEXT');
  }

  public function down()
  {
    $this->alterColumn('browser_notifications', 'message', 'TEXT');
  }

}
