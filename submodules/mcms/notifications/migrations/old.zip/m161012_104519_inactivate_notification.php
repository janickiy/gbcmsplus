<?php

use mcms\notifications\models\Notification;
use console\components\Migration;

class m161012_104519_inactivate_notification extends Migration
{
  const EVENT = 'mcms\\promo\\components\\events\\LinkCreated';

  public function up()
  {
    $this->update('{{%notifications}}', ['is_disabled' => 1], 'event=:event', [':event' => self::EVENT]);
  }

  public function down()
  {
    $this->update('{{%notifications}}', ['is_disabled' => 0], 'event=:event', [':event' => self::EVENT]);
  }

}
