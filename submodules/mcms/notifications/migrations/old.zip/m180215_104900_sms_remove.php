<?php

use rgk\settings\models\Setting;
use console\components\Migration;

/**
 */
class m180215_104900_sms_remove extends Migration
{
  const SETTING = 'settings.notify_sms';

  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
  }

  /**
   */
  public function up()
  {
    $this->settingsBuilder->removeSetting(self::SETTING);
  }

  /**
   */
  public function down()
  {
    $title = ['ru' => 'Уведомления по смс', 'en' => 'Notifications by SMS'];
    $permissions = ['EditModuleSettingsNotifications'];
    $category = 'other';
    $validators = [["required"],["boolean"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTING, $permissions, Setting::TYPE_STRING, $category, '', $validators);
  }
}
