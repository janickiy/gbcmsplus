<?php

use console\components\Migration;

class m151130_125224_notifications_multilang extends Migration
{

  const TABLE = 'notifications';

  public function up()
  {
    $this->addColumn(self::TABLE, 'from', \yii\db\Schema::TYPE_TEXT);
    $this->addColumn(self::TABLE, 'template', \yii\db\Schema::TYPE_TEXT);
    $this->addColumn(self::TABLE, 'header', \yii\db\Schema::TYPE_TEXT);
  }

  public function down()
  {
    $this->addColumn(self::TABLE, 'header', \yii\db\Schema::TYPE_TEXT);
    $this->addColumn(self::TABLE, 'template', \yii\db\Schema::TYPE_TEXT);
    $this->addColumn(self::TABLE, 'from', \yii\db\Schema::TYPE_TEXT);
  }

}
