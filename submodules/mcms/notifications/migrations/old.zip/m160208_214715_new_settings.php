<?php

use admin\migrations\dbfix\SettingsTransferTrait;
use console\components\Migration;

class m160208_214715_new_settings extends Migration
{
  use SettingsTransferTrait;

  const SETTINGS_NOTIFY_SMS = 'settings.notify_sms';
  const SETTINGS_NOTIFY_EMAIL = 'settings.notify_email';
  const SETTINGS_NOTIFY_BROWSER = 'settings.notify_browser';
  const SETTINGS_ADMIN_EMAIL = 'settings.admin_email';
  const SETTINGS_INFO_EMAIL = 'settings.info_email';
  const SETTINGS_NOREPLY_EMAIL = 'settings.noreply_email';
  const SETTINGS_SUPPORT_EMAIL = 'settings.support_email';
  const SETTINGS_TELEGRAM_BOT_NAME = 'settings.telegram_bot_name';
  const SETTINGS_TELEGRAM_BOT_TOKEN = 'settings.telegram_bot_token';
  const SETTINGS_PUSH_ICON = 'settings.push_icon';

  const MODULE_ID = 'notifications';

  const SETTINGS_TABLE = 'rgk_settings';
  const PERMISSIONS_TABLE = 'rgk_settings_permissions';
  const OPTIONS_TABLE = 'rgk_settings_options';
  const VALUES_TABLE = 'rgk_settings_values';

  public function up()
  {
    $this->insertValues();
  }

  public function down()
  {

  }

  private function getRepository()
  {
    return (new admin\migrations\dbfix\Repository())
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('notifications.settings.notifications_by_sms')
          ->setValue(false)
          ->setKey(self::SETTINGS_NOTIFY_SMS)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('notifications.settings.admin_email')
          ->setKey(self::SETTINGS_ADMIN_EMAIL)
          ->setValidators([['email'], ['required']])
          ->setValue('admin@example.com')
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setFormGroup(['name' => 'app.common.form_group_notifications', 'sort' => 3])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('notifications.settings.info_email')
          ->setKey(self::SETTINGS_INFO_EMAIL)
          ->setValidators([['email'], ['required']])
          ->setValue('info@example.com')
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setFormGroup(['name' => 'app.common.form_group_notifications', 'sort' => 3])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('notifications.settings.support_email')
          ->setKey(self::SETTINGS_SUPPORT_EMAIL)
          ->setValidators([['email'], ['required']])
          ->setValue('support@example.com')
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setFormGroup(['name' => 'app.common.form_group_notifications', 'sort' => 3])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('notifications.settings.noreply_email')
          ->setKey(self::SETTINGS_NOREPLY_EMAIL)
          ->setValidators([['email'], ['required']])
          ->setValue('noreply@example.com')
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setFormGroup(['name' => 'app.common.form_group_notifications', 'sort' => 3])
          ->setSort(4)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('notifications.settings.telegram_bot_name')
          ->setKey(self::SETTINGS_TELEGRAM_BOT_NAME)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('notifications.settings.telegram_bot_token')
          ->setKey(self::SETTINGS_TELEGRAM_BOT_TOKEN)
      )->set(
        (new admin\migrations\dbfix\FileUpload('notifications'))
          ->setName('notifications.settings.push_icon')
          ->setKey(self::SETTINGS_PUSH_ICON)
          ->setExtensions(['jpeg', 'jpg', 'png', 'gif'])
          ->setUploadDir('@uploadPath/{moduleId}/{attributeName}')
          ->setUploadUrl('@uploadUrl/{moduleId}/{attributeName}')
          ->setDefaultFile([
            admin\migrations\dbfix\FileUpload::FILE_NAME_PARAM => 'support.png',
            admin\migrations\dbfix\FileUpload::DIR_PARAM => '@rootPath/web/img',
            admin\migrations\dbfix\FileUpload::URL_PARAM => '/img'
          ])
      );
  }
}
