<?php

use console\components\Migration;
use mcms\notifications\models\BrowserNotification;

class m160331_134458_del_browser_notifications extends Migration
{
  public function up()
  {
    BrowserNotification::deleteAll(['event' => [
      'mcms\promo\components\events\LandingListCreated',
      'mcms\promo\components\events\LandingCreated'
    ]]);
  }

  public function down()
  {

  }
}
