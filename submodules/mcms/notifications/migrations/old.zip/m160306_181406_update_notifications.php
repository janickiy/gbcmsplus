<?php

use mcms\notifications\models\Notification;
use console\components\Migration;
use yii\helpers\ArrayHelper;

class m160306_181406_update_notifications extends Migration
{
  public function up()
  {

    /** @var \mcms\user\Module $userModule */
    $userModule = Yii::$app->getModule('users');
    $userModuleId = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => $userModule->id])
      ->getResult()
      ;

    \mcms\notifications\models\Notification::deleteAll([
      'module_id' => $userModuleId->id
    ]);

    //пользователь зарегистрировался (не ручная)
    //отправляем реселлеру и админу в браузер
    $this->createNotification([
      'module_id' => $userModuleId->id,
      'event' => \mcms\user\components\events\EventRegistered::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Зарегистрировался {user.username}',
        'en' => '{user.username} Registered'
      ],
      'template' => [
        'ru' => 'Статус пользователя: {user.status}',
        'en' => 'User status: {user.status}'
      ],
      'use_owner' => false,
      'roles' => ['admin', 'root', 'reseller']
    ]);
    //отправляем парнеру емейл

    //пользователь зарегистрировался (не ручная)
    //отправляем реселлеру и админу в браузер
    $this->createNotification([
      'module_id' => $userModuleId->id,
      'event' => \mcms\user\components\events\EventRegisteredHandActivation::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Зарегистрировался {user.username}',
        'en' => '{user.username} Registered'
      ],
      'template' => [
        'ru' => 'Статус пользователя: {user.status}. Требуется активация партнера!',
        'en' => 'User status: {user.status}. Activation wanted!'
      ],
      'use_owner' => false,
      'roles' => ['admin', 'root', 'reseller']
    ]);

    //реферал
    //партнеру в браузер
    $this->createNotification([
      'module_id' => $userModuleId->id,
      'event' => \mcms\user\components\events\EventReferralRegistered::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Зарегистрировался реферал: {referrer.username}',
        'en' => 'Referral registered: {referrer.username}'
      ],
      'template' => [
        'ru' => 'Поздравляем! По вашей ссылке зарегистрировался новый пользователь. Статистику по рефералам вы можете просматривать в разделе Рефералы',
        'en' => 'Congratulations! A new user registered by your referrer link. Statistics on referrals you can view in the section Referrals'
      ],
      'use_owner' => true,
    ]);

    //регистрация партнера на емейл
    $this->createNotification([
      'module_id' => $userModuleId->id,
      'event' => \mcms\user\components\events\EventRegisteredHandActivation::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ],
      'header' => [
        'ru' => '{projectName} - Регистрация',
        'en' => '{projectName} - Registration'
      ],
      'template' => [
        'ru' => '<strong>Здравствуйте {user.username}!</strong><br/>Благодарим вас за регистрацию в партнерской программе {projectName}.<br/><br/>Наш менеджер свяжется с вами в ближайшее время!<br/>Если вы не хотите ждать - свяжитесь с нами по контактам указанным на сайте.',
        'en' => '<strong>Greetings, {user.username}!</strong><br>We thank you for registration in partners program <strong>{projectName}</strong>.<br><br>Our manager will contact you soon!<br>If you don\'t want to wait, you can use contacts on our site.<br><br><strong>Best regards, command of {projectName}.</strong>'
      ],
      'use_owner' => true,
    ]);

    //отправлена ссылка активации
    //парнетнеру на емейл
    $this->createNotification([
      'module_id' => $userModuleId->id,
      'event' => \mcms\user\components\events\EventActivationCodeSended::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ],
      'header' => [
        'ru' => '{projectName} - Регистрация',
        'en' => '{projectName} - Registration'
      ],
      'template' => [
        'ru' => '<strong>Здравствуйте, {user.username}!</strong><br>Благодарим вас за регистрацию в партнерской программе <strong>{projectName}</strong>.<br><br>Для активации аккаунта перейдите по ссылке: {homeUrl}/users/site/activate/?code={activationCode}<br><br>Если вы не регистрировались в партнерской программе {projectName}, то проигнорируйте это письмо.<br><br><strong>С уважением, команда {projectName}.</strong>',
        'en' => '<strong>Greetings, {user.username}!</strong><br>We thank you for registration in partners program <strong>{projectName}</strong>.<br><br>To active your account visit following link: {homeUrl}/users/site/activate/?code={activationCode}<br><br>If you didn\'t registered in partners program {projectName}, ignore this mail.<br><br><strong>Best regards, command of {projectName}.</strong>'
      ],
      'use_owner' => true,
    ]);

    //пользователь одобрен
    //партнеру на емейл
    $this->createNotification([
      'module_id' => $userModuleId->id,
      'event' => \mcms\user\components\events\EventUserApproved::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ],
      'to' => [],
      'header' => [
        'ru' => '{projectName} - Аккаунт активирован',
        'en' => '{projectName} - Account has been actived'
      ],
      'template' => [
        'ru' => '<strong>Здравствуйте, {user.username}!<br>Ваш аккаунт прошел проверку и успешно активирован.</strong><br><br><strong>Данные для авторизации в партнерской программе:</strong><br>E-mail: {user.email}<br><br><strong>Реферальная система:</strong> Хотите получать стабильный доход от оборота всех привлеченных партнеров? Привлекайте партнеров и зарабатывайте.<br>Ваша ссылка для привлечения партнеров: {referralLink}<br>Вы можете использовать ее в подписи на форумах, блогах и т.д., а так же рекомендовать напрямую друзьям и знакомым.<br><br><strong>Перед началом работы:</strong> рекомендуем прочитать {homeUrl}/partners/faq/index/, в котором мы собрали ответы на основные вопросы, чтобы вы смогли с легкостью разобраться c функционалом партнерской программы.<br><br><strong>Желаем успехов в работе и отличного профита!<br>С уважением, команда {projectName}.</strong>',
        'en' => '<strong>Greetings, {user.username}!<br>Your account was approved and successfully activated.</strong><br><br><strong>Information for authorization in partners program:</strong><br>E-mail: {user.email}<br><br><strong>Referral system:</strong> You want to have stable income from your partners? Attract your partners and have profit.<br>Your link for getting partners: {referralLink}<br>You can use it in signatures at forums, blogs etc. and also recommend directly to your friends.<br><br><strong>Before you start:</strong> we recommend you to read the {homeUrl}/partners/faq/index/ in which we collected answers to most frequent questions, so you can easily use partners program functional.<br><br><strong>We wish you success in you work and good profit!<br>Best regards, command of {projectName}.</strong>'
      ],
      'use_owner' => true,
    ]);

    //реферальная система отключена
    $this->createNotification([
      'module_id' => $userModuleId->id,
      'event' => \mcms\user\components\events\EventUserApprovedWithoutReferrals::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ],
      'to' => [],
      'header' => [
        'ru' => '{projectName} - Аккаунт активирован',
        'en' => '{projectName} - Account has been actived'
      ],
      'template' => [
        'ru' => '<strong>Здравствуйте, {user.username}!<br>Ваш аккаунт прошел проверку и успешно активирован.</strong><br><br><strong>Данные для авторизации в партнерской программе:</strong><br>E-mail: {user.email}<br><br><strong>Перед началом работы:</strong> рекомендуем прочитать {homeUrl}/partners/faq/index/, в котором мы собрали ответы на основные вопросы, чтобы вы смогли с легкостью разобраться c функционалом партнерской программы.<br><br><strong>Желаем успехов в работе и отличного профита!<br>С уважением, команда {projectName}.</strong>',
        'en' => '<strong>Greetings, {user.username}!<br>Your account was approved and successfully activated.</strong><br><br><strong>Information for authorization in partners program:</strong><br>E-mail: {user.email}<br><br><strong>Before you start:</strong> we recommend you to read the {homeUrl}/partners/faq/index/ in which we collected answers to most frequent questions, so you can easily use partners program functional.<br><br><strong>We wish you success in you work and good profit!<br>Best regards, command of {projectName}.</strong>'
      ],
      'use_owner' => true,
    ]);

    //пользователь заблокирован
    //партнеру емейл
    $this->createNotification([
      'module_id' => $userModuleId->id,
      'event' => \mcms\user\components\events\EventUserBlocked::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ],
      'header' => [
        'ru' => '{projectName} - Аккаунт заблокирован',
        'en' => '{projectName} - Account has been blocked'
      ],
      'template' => [
        'ru' => '<strong>Здравствуйте, {user.username}!<br>Ваш аккаунт заблокрован.</strong><br><br>Наш менеджер свяжется с вами в ближайшее время!<br>Если вы не хотите ждать - свяжитесь с нами по контактам указанным на сайте.<br><br><strong>С уважением, команда {projectName}.</strong>',
        'en' => '<strong>Greetings, {user.username}!<br>Your account has been blocked</strong><br><br>Our manager will contact you soon!<br>If you don\'t want to wait, you can use contacts on our site.<br><br><strong>Best regards, command of {projectName}.</strong>'
      ],
      'use_owner' => true,
    ]);

    //новый пароль отпрален
    //партнеру емейл
    $this->createNotification([
      'module_id' => $userModuleId->id,
      'event' => \mcms\user\components\events\EventNewPasswordSent::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ],
      'header' => [
        'ru' => '{projectName} - Напоминание пароля',
        'en' => '{projectName} - Password remind'
      ],
      'template' => [
        'ru' => '<strong>Здравствуйте, {user.username}!<br>С вашего аккаунта поступил запрос на изменение пароля. Пароль был успешно изменен.</strong><br><br><strong>Данные для авторизации в партнерской программе:</strong><br>E-mail: {user.email}<br>Пароль: {password}<br><br><strong>Желаем успехов в работе и отличного профита!<br>С уважением, команда {projectName}.</strong>',
        'en' => '<strong>Greetings, {user.username}!<br>Password remind has been requested from your account.</strong><br><br><strong>Information for authorization in partners program:</strong><br>E-mail: {user.email}<br>Password: {password}<br><br><strong>We wish you success in you work and good profit!<br>Best regards, command of {projectName}.</strong>'
      ],
      'use_owner' => true,
    ]);

    //сменился статус
    //отправляем партнеру емейл
    $this->createNotification([
      'module_id' => $userModuleId->id,
      'event' => \mcms\user\components\events\EventStatusChanged::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ],
      'header' => [
        'ru' => '{projectName} - Аккаунт {user.status}',
        'en' => '{projectName} - Account {user.status}'
      ],
      'template' => [
        'ru' => '<strong>Здравствуйте, {user.username}!<br>Ваш аккаунт {user.status}<br><br><strong>С уважением, команда {projectName}.</strong>',
        'en' => '<strong>Greetings, {user.username}!<br>Your account {user.status}<br><br><strong>Best regards, command of {projectName}.</strong>'
      ],
      'use_owner' => true,
    ]);

    //напоминание пароля (по ссылке)
    $this->createNotification([
      'module_id' => $userModuleId->id,
      'event' => mcms\user\components\events\EventPasswordGenerateLinkSended::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ],
      'header' => [
        'ru' => '{projectName} - Напоминание пароля',
        'en' => '{projectName} - Password remind',
      ],
      'template' => [
        'ru' => "<strong>Здравствуйте, {user.username}!<br>С вашего аккаунта поступил запрос на изменение пароля.</strong><br><br>" .
          "<strong>Для того, чтобы изменить пароль, перейдите по ссылке:</strong><br>{homeUrl}/users/site/reset-password/?token={user.password_reset_token}<br><br>" .
          "<strong>Желаем успехов в работе и отличного профита!<br>С уважением, команда {projectName}.</strong>",
        'en' => "<strong>Greetings, {user.username}!<br>Password remind has been requested from your account.</strong><br><br>" .
          "<strong>To change password open this link:</strong><br>{homeUrl}/users/site/reset-password/?token={user.password_reset_token}<br><br>" .
          "<strong>We wish you success in you work and good profit!<br>Best regards, command of {projectName}.</strong>",
      ],
      'use_owner' => true,
    ]);
    //пароль изменен
    $this->createNotification([
      'event' => mcms\user\components\events\EventPasswordChanged::className(),
      'module_id' => $userModuleId->id,
      'header' => [
        'ru' => '{projectName} - Пароль изменен',
        'en' => '{projectName} - Password has been changed',
      ],
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ],
      'template' => [
        'ru' => "<strong>Здравствуйте, {user.username}!<br>Ваш пароль для входа в партнерскую программу {projectName} успешно изменен!</strong><br><br>" .
          "<strong>Данные для авторизации в партнерской программе:</strong><br>E-mail: {user.email}<br><br>" .
          "<strong>Желаем успехов в работе и отличного профита!<br>С уважением, команда {projectName}.</strong>",
        'en' => "<strong>Greetings, {user.username}!<br>Your password for accessing partners program {projectName} has been successfully changed!</strong><br><br>" .
          "<strong>Information for authorization in partners program:</strong><br>E-mail: {user.email}<br><br>" .
          "<strong>We wish you success in you work and good profit!<br>Best regards, command of {projectName}.</strong>",
      ],
      'use_owner' => true,
    ]);


    /** @var \mcms\pages\Module $pagesModule */
    $pagesModule = Yii::$app->getModule('pages');
    $pagesModuleId = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => $pagesModule->id])
      ->getResult()
    ;
    \mcms\notifications\models\Notification::deleteAll([
      'module_id' => $pagesModuleId->id
    ]);
    //faq
    //обновлен
    //всем партнерам отправляем уведомление
    $this->createNotification([
      'module_id' => $pagesModuleId->id,
      'event' => \mcms\pages\components\events\FaqUpdateEvent::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,

      'header' => [
        'ru' => 'Обновился раздел FAQ',
        'en' => 'Updated FAQ section'
      ],
      'template' => [
        'ru' => 'Пожалуйста ознакомьтесь с новыми правилами партнерской программы {projectName}.',
        'en' => 'Please refer to the new affiliate program policies {projectName}.'
      ],
      'roles' => ['partner']
    ]);

    /** @var \mcms\support\Module $supportModule */
    $supportModule = Yii::$app->getModule('support');
    $supportModuleId = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => $supportModule->id])
      ->getResult()
    ;
    \mcms\notifications\models\Notification::deleteAll([
      'module_id' => $supportModuleId->id
    ]);
    //поддержка
    //партнер создал тикет
    //реселлер и админ получают в браузер
    $this->createNotification([
      'module_id' => $supportModuleId->id,
      'event' => \mcms\support\components\events\EventCreated::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,

      'header' => [
        'ru' => 'Новый тикет',
        'en' => 'New ticket'
      ],
      'template' => [
        'ru' => 'Пользователь {ticket.createdBy.username} создал тикет #{ticket.id} {ticket.name}',
        'en' => 'User {ticket.createdBy.username} created ticket # {ticket.id} {ticket.name}'
      ],
      'roles' => ['reseller', 'admin', 'root']
    ]);

    //реселлер или админ создал тикет партнеру
    //портенеру емейл и в браузер
    $this->createNotification([
      'module_id' => $supportModuleId->id,
      'event' => \mcms\support\components\events\EventAdminCreated::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Новый тикет',
        'en' => 'New ticket'
      ],
      'template' => [
        'ru' => 'Вам добавлен новый тикет: "{ticket.name}"',
        'en' => 'You have a new ticket: "{ticket.name}"'
      ],
      'use_owner' => true
    ]);

    $this->createNotification([
      'module_id' => $supportModuleId->id,
      'event' => \mcms\support\components\events\EventAdminCreated::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{support_email}',
        'en' => '{support_email}',
      ],
      'header' => [
        'ru' => '{projectName} - Вам добавлен новый тикет.',
        'en' => '{projectName} - You have a new ticket.',
      ],
      'template' => [
        'ru' => '<strong>Здравствуйте {ticket.createdBy.username}!</strong><br><strong>Вам добавлен новый тикет: "{ticket.name}".</strong><br/><strong>Сообщение: </strong><br/>{ticket.message.text}',
        'en' => '<strong>Greetings, {ticket.createdBy.username}!</strong><br><strong>You have a new ticket: "{ticket.name}".</strong><br/><strong>Message: </strong><br/>{ticket.message.text}'
      ],
      'use_owner' => true
    ]);
    //новое сообщение от пользователя
    //админ и реселлер получают ув в браузер
    $this->createNotification([
      'module_id' => $supportModuleId->id,
      'event' => \mcms\support\components\events\EventMessageSend::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Новое сообщение',
        'en' => 'New message',
      ],
      'template' => [
        'ru' => 'Пользователь {ticket.createdBy.username} добавил новое сообщение в #{ticket.id} {ticket.name}',
        'en' => 'User {ticket.createdBy.username} added a new message in the #{ticket.id} {ticket.name}'
      ],
      'roles' => ['admin', 'root', 'reseller']
    ]);
    //тикет закрыт из админки
    //партнер получает ув емейл и в браузер
    $this->createNotification([
      'module_id' => $supportModuleId->id,
      'event' => \mcms\support\components\events\EventAdminClosed::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Тикет закрыт',
        'en' => 'Ticket closed',
      ],
      'template' => [
        'ru' => 'Тикет: "{ticket.name}" закрыт, если у вас остались какие то вопросы обратитесь в службу поддержки.',
        'en' => 'Ticket: "{ticket.name}" is closed, if you still have any questions please contact support.'
      ],
      'use_owner' => true
    ]);

    $this->createNotification([
      'module_id' => $supportModuleId->id,
      'event' => \mcms\support\components\events\EventAdminClosed::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{support_email}',
        'en' => '{support_email}',
      ],
      'header' => [
        'ru' => '{projectName} - Тикет закрыт',
        'en' => '{projectName} - Ticket closed',
      ],
      'template' => [
        'ru' => '<strong>Здравствуйте {ticket.createdBy.username}!</strong><br><strong>Тикет: "{ticket.name}" закрыт, если у вас остались какие то вопросы обратитесь в службу поддержки.</strong>',
        'en' => '<strong>Greetings, {ticket.createdBy.username}!</strong><br><strong>Ticket: "{ticket.name}" is closed, if you still have any questions please contact support.</strong>'
      ],
      'use_owner' => true
    ]);
    //новое сообщение из админки
    //партнеру
    $this->createNotification([
      'module_id' => $supportModuleId->id,
      'event' => \mcms\support\components\events\EventMessageReceived::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{support_email}',
        'en' => '{support_email}',
      ],
      'header' => [
        'ru' => '{projectName} - Вам пришло новое сообщение.',
        'en' => '{projectName} - You have a new message.',
      ],
      'template' => [
        'ru' => '<strong>Здравствуйте {ticket.createdBy.username}!</strong><br><strong>В тикет "{ticket.name}" пришло новое сообщение:</strong><br/>{ticket.message.text}',
        'en' => '<strong>Greetings, {ticket.createdBy.username}!</strong><br><strong>You have a new message in the ticket "{ticket.name}":</strong><br/>{ticket.message.text}'
      ],
      'use_owner' => true
    ]);
    $this->createNotification([
      'module_id' => $supportModuleId->id,
      'event' => \mcms\support\components\events\EventMessageReceived::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => '{projectName} - Вам пришло новое сообщение.',
        'en' => '{projectName} - You have a new message.',
      ],
      'template' => [
        'ru' => '<strong>Здравствуйте {ticket.createdBy.username}!</strong><br><strong>В тикет "{ticket.name}" пришло новое сообщение:</strong><br/>{ticket.message.text}',
        'en' => '<strong>Greetings, {ticket.createdBy.username}!</strong><br><strong>You have a new message in the ticket "{ticket.name}":</strong><br/>{ticket.message.text}'
      ],
      'use_owner' => true
    ]);

    //модуль промо
    /** @var \mcms\promo\Module $promoModule */
    $promoModule = Yii::$app->getModule('promo');
    $promoModuleId = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => $promoModule->id])
      ->getResult()
    ;
    \mcms\notifications\models\Notification::deleteAll([
      'module_id' => $promoModuleId->id
    ]);

    //Переведен трафик с отключенного ленда
    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\DisabledLandingsReplace::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Лендинг #{landingFrom.id} {landingFrom.name} был отключен',
        'en' => 'Landing #{landingFrom.id} {landingFrom.name} has been disabled',
      ],
      'template' => [
        'ru' => 'Трафик автоматически переведен на лендинги из той же категории.',
        'en' => 'Traffic is automatically transferred to the Landing of the same category.'
      ],
      'use_owner' => true,
    ]);
    //источник вебмастера создан
    //админ и реселлер в браузер
    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\SourceCreatedModeration::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Добавлен источник.',
        'en' => 'Source added',
      ],
      'template' => [
        'ru' => 'Пользователь {source.user.username} добавил источник #{source.id} {source.name}. Требуется модерация!',
        'en' => 'User {source.user.username} added source #{source.id} {source.name}. Moderation wanted!'
      ],
      'roles' => ['admin', 'root', 'reseller']
    ]);

    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\SourceCreated::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Добавлен источник.',
        'en' => 'Source added',
      ],
      'template' => [
        'ru' => 'Пользователь {source.user.username} добавил источник #{source.id} {source.name}.',
        'en' => 'User {source.user.username} added source #{source.id} {source.name}.'
      ],
      'roles' => ['admin', 'root', 'reseller']
    ]);
    //Источник вебмастера запрещен/отклонен
    //партнеру в емейл и в браузер
    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\SourceRejected::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Источник #{source.id} {source.name} заблокирован.',
        'en' => 'Source #{source.id} {source.name} rejected.',
      ],
      'template' => [
        'ru' => 'Причина: {source.reject_reason}<br/>Для получения дополнительной информации обратитесь в службу поддержки.',
        'en' => 'Reason: {source.reject_reason}<br/>For more information, please contact customer support.'
      ],
      'use_owner' => true,
    ]);

    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\SourceRejected::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ],
      'header' => [
        'ru' => 'Источник #{source.id} {source.name} заблокирован.',
        'en' => 'Source #{source.id} {source.name} rejected.',
      ],
      'template' => [
        'ru' => 'Причина: {source.reject_reason}<br/>Для получения дополнительной информации обратитесь в службу поддержки.',
        'en' => 'Reason: {source.reject_reason}<br/>For more information, please contact customer support.'
      ],
      'use_owner' => true,
    ]);

    //Источник вебмастера активирован/одобрен
    //партнер email browser
    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\SourceActivated::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Источник #{source.id} {source.name} активирован.',
        'en' => 'Source #{source.id} {source.name} activated.',
      ],
      'template' => [
        'ru' => 'Ваш источник успешно активирован!<br/>Желаем успехов в работе и отличного профита!',
        'en' => 'Your source successfully activated!<br/> We wish you success in your work and a great profit!'
      ],
      'use_owner' => true,
    ]);

    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\SourceActivated::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ],
      'header' => [
        'ru' => 'Источник #{source.id} {source.name} активирован.',
        'en' => 'Source #{source.id} {source.name} activated.',
      ],
      'template' => [
        'ru' => 'Ваш источник успешно активирован!<br/>Желаем успехов в работе и отличного профита!',
        'en' => 'Your source successfully activated!<br/> We wish you success in your work and a great profit!'
      ],
      'use_owner' => true,
    ]);
    //ссылка создана
    //reseller и admin - получают уведомление в браузер
    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\LinkCreatedModeration::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Добавлена ссылка.',
        'en' => 'Link created',
      ],
      'template' => [
        'ru' => 'Пользователь {source.user.username} добавил ссылку #{source.id} {source.name}.<br/>Необходима модерация!',
        'en' => 'User {source.user.username} added a link #{source.id} {source.name}.<br/>Moderation wanted!'
      ],
      'roles' => ['admin', 'reseller', 'root'],
    ]);

    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\LinkCreated::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Добавлена ссылка.',
        'en' => 'Link created',
      ],
      'template' => [
        'ru' => 'Пользователь {source.user.username} добавил ссылку #{source.id} {source.name}.',
        'en' => 'User {source.user.username} added a link #{source.id} {source.name}.'
      ],
      'roles' => ['admin', 'reseller', 'root'],
    ]);

    //Ссылка заблокирована/отклонена
    //партнер получает уведомление в браузер и емейл сообщение

    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\LinkRejected::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ],
      'header' => [
        'ru' => 'Ссылка #{source.id} {source.name} заблокирована.',
        'en' => 'Link #{source.id} {source.name} rejected.',
      ],
      'template' => [
        'ru' => 'Причина: {source.reject_reason}<br/>Для получения дополнительной информации обратитесь в службу поддержки.',
        'en' => 'Reason: {source.reject_reason}<br/>For more information, please contact customer support.'
      ],
      'use_owner' => true,
    ]);

    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\LinkRejected::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Ссылка #{source.id} {source.name} заблокирована.',
        'en' => 'Link #{source.id} {source.name} rejected.',
      ],
      'template' => [
        'ru' => 'Причина: {source.reject_reason}<br/>Для получения дополнительной информации обратитесь в службу поддержки.',
        'en' => 'Reason: {source.reject_reason}<br/>For more information, please contact customer support.'
      ],
      'use_owner' => true,
    ]);

    //Ссылка активирована/одобрена
    //партнер получает уведомление в браузер и емейл сообщение
    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\LinkActivated::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Ссылка #{source.id} {source.name} активирована.',
        'en' => 'Link #{source.id} {source.name} activated.',
      ],
      'template' => [
        'ru' => 'Ваша ссылка успешно активирована!<br/>Желаем успехов в работе и отличного профита!',
        'en' => 'Your link successfully activated!<br/>We wish you success in your work and a great profit!'
      ],
      'use_owner' => true,
    ]);

    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\LinkActivated::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ],
      'header' => [
        'ru' => 'Ссылка #{source.id} {source.name} активирована.',
        'en' => 'Link #{source.id} {source.name} activated.',
      ],
      'template' => [
        'ru' => 'Ваша ссылка успешно активирована!<br/>Желаем успехов в работе и отличного профита!',
        'en' => 'Your link successfully activated!<br/>We wish you success in your work and a great profit!'
      ],
      'use_owner' => true,
    ]);

    //Подана заявка на разблокировку лендинга
    //reseller и admin - получают уведомление в браузер

    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\LandingUnblockRequestCreated::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Заявка на разблокировку лендинга.',
        'en' => 'Request for unlocking landing',
      ],
      'template' => [
        'ru' => 'Пользователь {landingUnblockRequest.user.username} добавил заявку на разблокировку лендинга #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name}<br/>Необходима модерация!',
        'en' => 'User {landingUnblockRequest.user.username} added a request for unlocking Landing # {landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name}<br/>Moderation wanted!'
      ],
      'roles' => ['admin', 'reseller', 'root'],
    ]);

    //Лендинг заблокирован/отклонен
    //партнеру в браузер
    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\LandingDisabled::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} заблокирован.',
        'en' => 'Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} blocked.',
      ],
      'template' => [
        'ru' => 'Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} заблокирован.<br/>Для получения дополнительной информации обратитесь в службу поддержки.',
        'en' => 'Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} blocked.<br/>For more information, please contact customer support.'
      ],
      'use_owner' => true,
    ]);
    //email
    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\LandingDisabled::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}',
      ],
      'header' => [
        'ru' => 'Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} заблокирован.',
        'en' => 'Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} blocked.',
      ],
      'template' => [
        'ru' => 'Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} заблокирован.<br/>Для получения дополнительной информации обратитесь в службу поддержки.',
        'en' => 'Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} blocked.<br/>For more information, please contact customer support.'
      ],
      'use_owner' => true,
    ]);

    //Лендинг активирован/одобрен
    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\LandingUnlocked::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} активирован.',
        'en' => 'Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} activated.',
      ],
      'template' => [
        'ru' => 'Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} успешно активирован.<br/>Желаем успехов в работе и отличного профита!',
        'en' => 'Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} successfully activated.<br/>We wish you success in your work and a great profit!'
      ],
      'use_owner' => true,
    ]);

    //email
    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\LandingUnlocked::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}',
      ],
      'header' => [
        'ru' => 'Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} активирован.',
        'en' => 'Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} activated.',
      ],
      'template' => [
        'ru' => 'Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} успешно активирован.<br/>Желаем успехов в работе и отличного профита!',
        'en' => 'Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} successfully activated.<br/>We wish you success in your work and a great profit!'
      ],
      'use_owner' => true,
    ]);

    //Системный домен создан (через админку)
    //партнер получает уведомление в браузер

    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\SystemDomainAdded::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Добавлен новый домен {domain.url}.',
        'en' => 'New domain {domain.url} added.',
      ],
      'template' => [
        'ru' => 'Вы можете использовать его при создании ссылки.<br/>Желаем успехов в работе и отличного профита!',
        'en' => 'You can use it to create links.<br/>We wish you success in your work and a great profit!'
      ],
      'roles' => ['partner'],
    ]);

    //Партнер добавил новый домен
    //reseller и admin - получают уведомление в браузер
    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\DomainAdded::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Добавлен новый домен {domain.url}.',
        'en' => 'New domain {domain.url} added.',
      ],
      'template' => [
        'ru' => 'Партнер: {domain.createdBy.username} добавил новый домен {domain.url}<br/>Тип домена: {domain.type}<br/>Статус: {domain.status}',
        'en' => 'Partner: {domain.createdBy.username} added a new domain {domain.url} <br/> domain type: {domain.type} <br/> Status: {domain.status}'
      ],
      'roles' => ['reseller', 'admin', 'root'],
    ]);

    //Домен заблокирован (заблокирован, или попал под санкции антивирусов)
    //партнер получает уведомление в браузер и на email
    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\SystemDomainBanned::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Статус {domain.url} обновлен.',
        'en' => '{domain.url} status updated.',
      ],
      'template' => [
        'ru' => 'Статус: {domain.status}. Просьба перевести трафик на активные домены!',
        'en' => 'Status: {domain.status}. Please transfer traffic to the active domains!'
      ],
      'roles' => ['partner'],
    ]);
    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\SystemDomainBanned::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}',
      ],
      'header' => [
        'ru' => 'Статус {domain.url} обновлен.',
        'en' => '{domain.url} status updated.',
      ],
      'template' => [
        'ru' => 'Статус: {domain.status}. Просьба перевести трафик на активные домены!',
        'en' => 'Status: {domain.status}. Please transfer traffic to the active domains!'
      ],
      'roles' => ['partner'],
    ]);

    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\DomainBanned::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}',
      ],
      'header' => [
        'ru' => 'Статус {domain.url} обновлен.',
        'en' => '{domain.url} status updated.',
      ],
      'template' => [
        'ru' => 'Статус: {domain.status}. Просьба перевести трафик на активные домены!',
        'en' => 'Status: {domain.status}. Please transfer traffic to the active domains!'
      ],
      'use_owner' => true
    ]);
    $this->createNotification([
      'module_id' => $promoModuleId->id,
      'event' => \mcms\promo\components\events\DomainBanned::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Статус {domain.url} обновлен.',
        'en' => '{domain.url} status updated.',
      ],
      'template' => [
        'ru' => 'Статус: {domain.status}. Просьба перевести трафик на активные домены!',
        'en' => 'Status: {domain.status}. Please transfer traffic to the active domains!'
      ],
      'use_owner' => true
    ]);

    //модуль выплаты
    $paymentsModule = Yii::$app->getModule('payments');
    $paymentsModuleId = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => $paymentsModule->id])
      ->getResult()
    ;
    \mcms\notifications\models\Notification::deleteAll([
      'module_id' => $paymentsModuleId->id
    ]);
    //заказана досрочная выплата
    //админ и ресс ув в браузер
    $this->createNotification([
      'module_id' => $paymentsModuleId->id,
      'event' => \mcms\payments\components\events\EarlyPaymentCreated::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Досрочная выплата',
        'en' => 'Early payment',
      ],
      'template' => [
        'ru' => '{payment.user.username} заказал досрочную выплату на {payment.amount} {payment.currency}. Необходимо произвести выплату!',
        'en' => '{payment.user.username} ordered early payment on {payment.amount} {payment.currency}. It is necessary to make the payment!'
      ],
      'roles' => ['admin', 'root', 'reseller']
    ]);

    //Сформированы штатные выплаты
    //партнер получает уведомление в браузер
    $this->createNotification([
      'module_id' => $paymentsModuleId->id,
      'event' => \mcms\payments\components\events\RegularPaymentCreated::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Выплата за период {payment.date_from} - {payment.date_to}',
        'en' => 'Payment for the period {payment.date_from} - {payment.date_to}',
      ],
      'template' => [
        'ru' => 'Сумма: {payment.amount} {payment.currency}. Статус выплаты: {payment.status}.',
        'en' => 'Sum: {payment.amount} {payment.currency}. Status of payment: {payment.status}.'
      ],
      'use_owner' => true
    ]);
    //админ реселлер получают уведомление в браузер
    $this->createNotification([
      'module_id' => $paymentsModuleId->id,
      'event' => 'mcms\\payments\\components\\events\\RegularPaymentsGenerated',
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Выплата за период {component.dateFrom} - {component.dateTo}',
        'en' => 'Payment for the period {component.dateFrom} - {component.dateTo}',
      ],
      'template' => [
        'ru' => 'Кол-во: {component.count} шт.<br/>Общая сумма выплат: {component.amount.rub} руб, {component.amount.eur} евро, {component.amount.usd} долларов.',
        'en' => 'Qty:. {component.count} items <br/> Total Payments: {component.amount.rub} rubles, {component.amount.eur} euros, {component.amount.usd} dollars.'
      ],
      'roles' => ['admin', 'root', 'reseller'],
    ]);
    //Изменен статус выплаты
    //партнер получает уведомление в браузер
    $this->createNotification([
      'module_id' => $paymentsModuleId->id,
      'event' => \mcms\payments\components\events\PaymentStatusUpdated::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Выплата #{payment.id} обновлена.',
        'en' => 'Payment #{payment.id} updated.',
      ],
      'template' => [
        'ru' => 'Статус выплаты: {payment.status}.',
        'en' => 'Payment status: {payment.status}.'
      ],
      'use_owner' => true
    ]);
    //Добавлен штраф
    //партнер получает уведомление в браузер
    $this->createNotification([
      'module_id' => $paymentsModuleId->id,
      'event' => \mcms\payments\components\events\UserBalanceInvoiceMulct::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Штраф',
        'en' => 'Mulct',
      ],
      'template' => [
        'ru' => 'С вашего баланса списан штраф в размере {userBalanceInvoice.amount} {userBalanceInvoice.currency}. <br/>Для получения дополнительной информации обратитесь в службу поддержки.',
        'en' => 'With your balance charged a penalty of {userBalanceInvoice.amount} {userBalanceInvoice.currency}. <br/> For more information, please contact customer support.'
      ],
      'use_owner' => true
    ]);
    //Добавлена компенсация
    //партнер получает уведомление в браузер
    $this->createNotification([
      'module_id' => $paymentsModuleId->id,
      'event' => \mcms\payments\components\events\UserBalanceInvoiceCompensation::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Компенсация',
        'en' => 'Compensation',
      ],
      'template' => [
        'ru' => 'На ваш баланс добавлена компенсация в размере {userBalanceInvoice.amount} {userBalanceInvoice.currency}.<br>Для получения дополнительной информации обратитесь в службу поддержки.',
        'en' => 'On your balance added to the compensation in the amount of {userBalanceInvoice.amount} {userBalanceInvoice.currency}.<br>For more information, please contact customer support.'
      ],
      'use_owner' => true
    ]);
    //Добавлена выплата (досрочная из админки)
    //партнер получает уведомление в браузер
    $this->createNotification([
      'module_id' => $paymentsModuleId->id,
      'event' => \mcms\payments\components\events\EarlyPaymentAdminCreated::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Досрочная выплата',
        'en' => 'Early payment',
      ],
      'template' => [
        'ru' => 'Сумма выплаты: {payment.amount} {payment.currency}.<br/>Статус выплаты: {payment.status}.<br/>Для получения дополнительной информации обратитесь в службу поддержки.',
        'en' => 'Payment amount: {payment.amount} {payment.currency}.<br/>Payment status: {payment.status} <br/>For more information, please contact customer support..'
      ],
      'use_owner' => true
    ]);
  }

  private function createNotification(array $notification)
  {
    $model = new Notification();
    $model->module_id = ArrayHelper::getValue($notification, 'module_id');
    $model->event = ArrayHelper::getValue($notification, 'event');
    $model->notification_type = ArrayHelper::getValue($notification, 'type');
    $model->header = ArrayHelper::getValue($notification, 'header');
    $model->template = ArrayHelper::getValue($notification, 'template');
    $model->use_owner = ArrayHelper::getValue($notification, 'use_owner', false);

    if ($roles = ArrayHelper::getValue($notification, 'roles', [])) {
      $model->setRoles($roles);
    }

    $model->from = ArrayHelper::getValue($notification, 'from');

    $model->save(false);

  }

  public function down()
  {
    echo "m160305_142007_notifications cannot be reverted.\n";
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
