<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170411_224521_notifications_delivery_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    // Рассылки
    $this->createPermission(
      'NotificationsDeliveryNotOwn',
      'Просмотр истории рассылки любых пользователей',
      'NotificationsDeliveryController',
      ['root', 'admin']
    );

    $this->assignRolesPermission('NotificationsDeliveryIndex', ['admin', 'reseller']);
    $this->assignRolesPermission('NotificationsDeliveryView', ['admin', 'reseller']);

    // Лог браузерных уведомлений
    $this->createPermission(
      'NotificationsNotificationsBrowserNotOwn',
      'Просмотр списка браузерных уведомлений любых пользователей',
      'NotificationsNotificationsController',
      ['root', 'admin']
    );

    $this->assignRolesPermission('NotificationsNotificationsBrowser', ['admin', 'reseller']);
    $this->assignRolesPermission('NotificationsNotificationsBrowserViewModal', ['admin', 'reseller']);

    // Лог email уведомлений
    $this->createPermission(
      'NotificationsNotificationsEmailNotOwn',
      'Просмотр списка email уведомлений любых пользователей',
      'NotificationsNotificationsController',
      ['root', 'admin']
    );

    $this->assignRolesPermission('NotificationsNotificationsEmail', ['admin', 'reseller']);
    $this->assignRolesPermission('NotificationsNotificationsEmailViewModal', ['admin', 'reseller']);
  }

  public function down()
  {
    // Рассылки
    $this->removePermission('NotificationsDeliveryNotOwn');
    $this->revokeRolesPermission('NotificationsDeliveryIndex', ['admin', 'reseller']);
    $this->revokeRolesPermission('NotificationsDeliveryView', ['admin', 'reseller']);

    // Лог браузерных уведомлений
    $this->removePermission('NotificationsNotificationsBrowserNotOwn');
    $this->revokeRolesPermission('NotificationsNotificationsBrowser', ['admin', 'reseller']);
    $this->revokeRolesPermission('NotificationsNotificationsBrowserViewModal', ['admin', 'reseller']);

    // Лог email уведомлений
    $this->removePermission('NotificationsNotificationsEmailNotOwn');
    $this->revokeRolesPermission('NotificationsNotificationsEmail', ['admin', 'reseller']);
    $this->revokeRolesPermission('NotificationsNotificationsEmailViewModal', ['admin', 'reseller']);
  }
}
