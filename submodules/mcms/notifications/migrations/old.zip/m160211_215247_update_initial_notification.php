<?php

use console\components\Migration;
use mcms\common\helpers\ArrayHelper;
use mcms\notifications\models\Notification;

class m160211_215247_update_initial_notification extends Migration
{

  /*public function up()
  {
    foreach($this->notifications as $notify) {
      $notification = Notification::findOne([
        'event' => ArrayHelper::getValue($notify, 'event'),
        'notification_type' => ArrayHelper::getValue($notify, 'type'),
      ]);

      if($notification) {
        $this->updateNotification(
          ArrayHelper::getValue($notify, 'type'),
          ArrayHelper::getValue($notify, 'module_id'),
          ArrayHelper::getValue($notify, 'event'),
          ArrayHelper::getValue($notify, 'header'),
          ArrayHelper::getValue($notify, 'template'),
          ArrayHelper::getValue($notify, 'roles'),
          ArrayHelper::getValue($notify, 'use_owner')
        );
      } else {
        $this->createNotification(
          ArrayHelper::getValue($notify, 'type'),
          ArrayHelper::getValue($notify, 'module_id'),
          ArrayHelper::getValue($notify, 'event'),
          ArrayHelper::getValue($notify, 'header'),
          ArrayHelper::getValue($notify, 'template'),
          ArrayHelper::getValue($notify, 'roles'),
          ArrayHelper::getValue($notify, 'use_owner')
        );
      }
    }
  }*/

  public function up()
  {

  }

  public function down()
  {

  }
}
