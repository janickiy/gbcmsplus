<?php

use console\components\Migration;

class m160317_210023_clear_browser_notifications extends Migration
{
  public function up()
  {
    \mcms\notifications\models\BrowserNotification::deleteAll();
  }

  public function down()
  {
    echo "m160317_210023_clear_browser_notifications cannot be reverted.\n";
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
