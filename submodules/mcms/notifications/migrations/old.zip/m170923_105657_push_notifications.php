<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170923_105657_push_notifications extends Migration
{
  use PermissionTrait;
  public function up()
  {
    $this->removePermission('NotificationsNotificationTypesSubscribePush');
    $this->removePermission('NotificationsNotificationTypesUnsubscribePush');

    $this->createPermission('NotificationsSettingsSubscribePush', 'Подписка на Push уведомления', 'NotificationsSettingsController', ['admin', 'root', 'investor', 'reseller']);
    $this->createPermission('NotificationsSettingsUnsubscribePush', 'Отписка от Push уведомлений', 'NotificationsSettingsController', ['admin', 'root', 'investor', 'reseller']);
  }

  public function down()
  {
    $this->createPermission('NotificationsNotificationTypesSubscribePush', 'Подписка на Push уведомления', 'NotificationsNotificationTypesController', ['admin', 'root', 'investor', 'reseller']);
    $this->createPermission('NotificationsNotificationTypesUnsubscribePush', 'Отписка от Push уведомлений', 'NotificationsNotificationTypesController', ['admin', 'root', 'investor', 'reseller']);

    $this->removePermission('NotificationsSettingsSubscribePush');
    $this->removePermission('NotificationsSettingsUnsubscribePush');
  }
}
