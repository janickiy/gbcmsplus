<?php

use console\components\Migration;

class m151216_174503_update_email_notification extends Migration
{
  public function up()
  {
    $this->addColumn('email_notifications', 'email', \yii\db\Schema::TYPE_STRING . ' NOT NULL');
    $this->addColumn('email_notifications', 'username', \yii\db\Schema::TYPE_STRING);
    $this->dropForeignKey('email_notifications_user_id_fk', 'email_notifications');
    $this->dropColumn('email_notifications', 'user_id');
  }

  public function down()
  {
    $this->truncateTable('email_notifications');
    $this->dropColumn('email_notifications', 'email');
    $this->dropColumn('email_notifications', 'username');
    $this->addColumn('email_notifications', 'user_id', 'MEDIUMINT(5) UNSIGNED NOT NULL');
    $this->addForeignKey(
      'email_notifications_user_id_fk',
      'email_notifications',
      'user_id',
      'users',
      'id',
      'CASCADE',
      'CASCADE'
    );
  }

}
