<?php

use console\components\Migration;

class m160225_075836_bro_not_index extends Migration
{
  public function up()
  {
    $this->createIndex(
      'bro_not_event_user_id_is_viewed_model_id_index',
      'browser_notifications',
      ['event', 'user_id', 'is_viewed', 'model_id']
    );
  }

  public function down()
  {
    $this->dropIndex('bro_not_event_user_id_is_viewed_model_id_index', 'browser_notifications');
  }
}
