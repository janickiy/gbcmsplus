<?php

use console\components\Migration;

class m170124_121746_rename_module extends Migration
{
  public function up()
  {
    $this->update('modules',
      [ 'name' => 'notifications.main.module_breadcrumbs_name', ],
      [ 'module_id' => 'notifications', ]
    );
  }

  public function down()
  {
    $this->update('modules',
      [ 'name' => 'app.common.module_notifications', ],
      [ 'module_id' => 'notifications', ]
    );
  }
}
