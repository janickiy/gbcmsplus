<?php

use console\components\Migration;

class m160226_101502_update_email_notifications extends Migration
{
  public function up()
  {
    $this->addColumn('email_notifications', 'language', \yii\db\Schema::TYPE_STRING . ' NOT NULL');
  }

  public function down()
  {
    $this->dropColumn('email_notifications', 'language');
  }
}