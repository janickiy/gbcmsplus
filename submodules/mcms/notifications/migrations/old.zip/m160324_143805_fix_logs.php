<?php

use console\components\Migration;

class m160324_143805_fix_logs extends Migration
{
  public function up()
  {
    $notExistsClasses = [];
    $allClasses = (new \yii\db\Query())
      ->select('label')
      ->from('logs')
      ->groupBy('label')
      ->all()
    ;

    foreach ($allClasses as $class) {
      $className = \yii\helpers\ArrayHelper::getValue($class, 'label');
      if (empty($className)) continue;

      if (!class_exists($className)) $notExistsClasses[] = $className;
    }

    if (count($notExistsClasses)) {
      $this->db->createCommand('DELETE FROM logs where label in (:notExistsClasses)', [
        ':notExistsClasses' => implode(',', $notExistsClasses)
      ])->execute();
    }
  }

  public function down()
  {
    echo "m160324_143805_fix_logs cannot be reverted.\n";
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
