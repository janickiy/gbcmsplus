<?php

use console\components\Migration;

class m160429_075248_update_browser_notification_table extends Migration
{

  public function up()
  {
    /** @var \mcms\notifications\models\BrowserNotification[] $browserNotifications */
    $browserNotifications = \mcms\notifications\models\BrowserNotification::find()->each();

    foreach ($browserNotifications as $browserNotification) {
      \mcms\common\event\Event::$isOldSerialize = true;

      $eventInstance = @unserialize($browserNotification->event_instance);
      if (!$eventInstance instanceof \mcms\common\event\Event) continue;
      echo sprintf('%s -- %s event migrated', $browserNotification->id, $eventInstance->className()) . PHP_EOL;

      \mcms\common\event\Event::$isOldSerialize = false;
      $browserNotification->event_instance = serialize($eventInstance);
      $browserNotification->save();
    }
  }

  public function down()
  {
    /** @var \mcms\notifications\models\BrowserNotification[] $browserNotifications */
    $browserNotifications = \mcms\notifications\models\BrowserNotification::find()->each();

    foreach ($browserNotifications as $browserNotification) {
      \mcms\common\event\Event::$isOldSerialize = false;

      $eventInstance = @unserialize($browserNotification->event_instance);
      if (!$eventInstance instanceof \mcms\common\event\Event) continue;
      echo sprintf('%s -- %s event migrated', $browserNotification->id, $eventInstance->className()) . PHP_EOL;

      \mcms\common\event\Event::$isOldSerialize = true;
      $browserNotification->event_instance = serialize($eventInstance);
      $browserNotification->save();
    }
  }
}
