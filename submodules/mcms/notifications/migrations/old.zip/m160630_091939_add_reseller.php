<?php

use mcms\notifications\models\Notification;
use console\components\Migration;

class m160630_091939_add_reseller extends Migration
{
  public function up()
  {

    $moduleApiResult = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => 'promo'])
      ->getResult();
    $modulePromoId = $moduleApiResult->id;

    $notifications = [
      [
        'event' => mcms\promo\components\events\DisabledLandingsListReseller::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_BROWSER,
          'header' => [
            'ru' => 'Лендинги были отключены',
            'en' => 'Landings has been disabled',
          ],
          'template' => [
            'ru' => "Лендинги:<br>{landings}<br>были отключены.",
            'en' => "Landings:<br>{landings}<br>has been disabled",
          ],
          'use_owner' => 0,
          'roles' => ['reseller']
        ]
      ],
      [
        'event' => mcms\promo\components\events\DisabledLandingsListReseller::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'header' => [
            'ru' => 'Лендинги были отключены',
            'en' => 'Landings has been disabled',
          ],
          'template' => [
            'ru' => "<strong>Уважаемый {owner.username}!</strong><br/><p>Лендинги:<br>{landings}<br>были отключены.</p><strong>Best regards, command of {projectName}.</strong>",
            'en' => "<strong>Greetings, {owner.username}!</strong><br/><p>Landings:<br>{landings}<br>has been disabled</p><strong>Best regards, command of {projectName}.</strong>",
          ],
          'use_owner' => 0,
          'roles' => ['reseller']
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingListCreated::className(),
        'data' => [
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'header' => [
            'ru' => 'Добавлены новые лендинги',
            'en' => 'New landings',
          ],
          'template' => [
            'ru' => "<strong>Уважаемый {owner.username}!</strong><br/><p>Добавлены новые лендинги:<br>{landings}<br></p><strong>С уважением, команда {projectName}.</strong>",
            'en' => "<strong>Greetings, {owner.username}!</strong><br/><p>New landings:<br>{landings}<br></p><strong>Best regards, command of {projectName}.</strong>",
          ],
          'use_owner' => 0,
          'roles' => ['reseller']
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingListCreated::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_BROWSER,
          'header' => [
            'ru' => 'Добавлены новые лендинги',
            'en' => 'New landings',
          ],
          'template' => [
            'ru' => "Добавлены новые лендинги:<br>{landings}",
            'en' => "New landings:<br>{landings}",
          ],
          'use_owner' => 0,
          'roles' => ['reseller']
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingCreated::className(),
        'data' => [
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'header' => [
            'ru' => 'Добавлен новый лендинг',
            'en' => 'New landing',
          ],
          'template' => [
            'ru' => '<strong>Уважаемый {owner.username}!</strong><br/><p>Добавлен новый лендинг:<br>{landing.id}. {landing.name}<br></p><strong>С уважением, команда {projectName}.</strong>',
            'en' => "<strong>Greetings, {owner.username}!</strong><br/><p>New landing:<br>{landing.id}. {landing.name}<br></p><strong>Best regards, command of {projectName}.</strong>",
          ],
          'use_owner' => 0,
          'roles' => ['reseller']
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingCreated::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_BROWSER,
          'header' => [
            'ru' => 'Добавлен новый лендинг',
            'en' => 'New landing',
          ],
          'template' => [
            'ru' => 'Добавлен новый лендинг:<br>{landing.id}. {landing.name}',
            'en' => "New landing:<br>{landing.id}. {landing.name}",
          ],
          'use_owner' => 0,
          'roles' => ['reseller']
        ]
      ],
      [
        'event' => mcms\promo\components\events\DisabledLandingsReseller::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'header' => [
            'ru' => 'Лендинг отключен',
            'en' => 'Landing has been disabled',
          ],
          'template' => [
            'ru' => '<strong>Уважаемый {owner.username}!</strong><br/><p>Лендинг #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) был отключен.</p><strong>С уважением, команда {projectName}.</strong>',
            'en' => '<strong>Greetings, {owner.username}!</strong><br/><p>Landing #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) has been disabled.</p><strong>Best regards, command of {projectName}.</strong>'
          ],
          'use_owner' => 0,
          'roles' => ['reseller']
        ]
      ],
      [
        'event' => mcms\promo\components\events\DisabledLandingsReseller::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_BROWSER,
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'header' => [
            'ru' => 'Лендинг отключен',
            'en' => 'Landing has been disabled',
          ],
          'template' => [
            'ru' => 'Лендинг #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) был отключен.',
            'en' => 'Landing #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) has been disabled.'
          ],
          'use_owner' => 0,
          'roles' => ['reseller']
        ]
      ],
    ];

    foreach ($notifications as $notification) {

      $notificationData = \yii\helpers\ArrayHelper::getValue($notification, 'data', []);
      $notificationType = \yii\helpers\ArrayHelper::getValue($notificationData, 'type');
      $notificationModel = $notification['event'] ? Notification::findOne([
        'event' => $notification['event'],
        'notification_type' => $notificationType,
      ]) : null;

      if (!$notificationModel) {
        $notificationModel = new Notification();
      }

      $notificationModel->setAttributes($notificationData, false);
      $notificationModel->event = $notification['event'];
      $notificationModel->notification_type = $notificationType;
      $notificationModel->use_owner = \yii\helpers\ArrayHelper::getValue($notificationData, 'use_owner', 0);
      $notificationModel->roles = \yii\helpers\ArrayHelper::getValue($notificationData, 'roles');
      $notificationModel->module_id = $modulePromoId;

      $notificationModel->save(false);
    }
  }

  public function down()
  {
    echo "m160630_091939_add_reseller cannot be reverted.\n";
  }
}
