<?php

use console\components\Migration;


class m151229_135814_initial_notifications extends Migration
{

  public function up()
  {

  }

  public function down()
  {

  }

}
