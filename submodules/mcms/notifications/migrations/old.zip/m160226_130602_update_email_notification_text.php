<?php

use mcms\notifications\models\Notification;
use console\components\Migration;
use yii\helpers\ArrayHelper;

class m160226_130602_update_email_notification_text extends Migration
{


}
