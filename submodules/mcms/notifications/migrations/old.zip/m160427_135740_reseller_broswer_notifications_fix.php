<?php

use console\components\Migration;
use mcms\notifications\models\BrowserNotification;

class m160427_135740_reseller_broswer_notifications_fix extends Migration
{
  public function up()
  {
    BrowserNotification::deleteAll([
      'event' => 'mcms\promo\components\events\LinkCreated',
      'from_user_id' => null,
    ]);
  }

  public function down()
  {


  }
}
