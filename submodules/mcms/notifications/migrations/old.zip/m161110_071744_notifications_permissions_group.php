<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

/**
 * Группировка прав модуля Уведомления
 */
class m161110_071744_notifications_permissions_group extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('NotificationsModule');

    // Разрешения
    $this->createPermission('NotificationsPermissions', '', 'NotificationsModule');
    $this->addChildPermission('NotificationsPermissions', 'NotificationsCanNotifyAdmin');
    $this->addChildPermission('NotificationsPermissions', 'NotificationsCanNotifyInvestor');
    $this->addChildPermission('NotificationsPermissions', 'NotificationsCanNotifyManager');
    $this->addChildPermission('NotificationsPermissions', 'NotificationsCanNotifyPartner');
    $this->addChildPermission('NotificationsPermissions', 'NotificationsCanNotifyReseller');
    $this->addChildPermission('NotificationsPermissions', 'NotificationsCanNotifyRoot');
    $this->addChildPermission('NotificationsPermissions', 'NotificationsSkipIgnoreIdsCheck');

    // Контроллеры
    $this->createPermission('NotificationsDeliveryController', '', 'NotificationsModule');
    $this->addChildPermission('NotificationsDeliveryController', 'NotificationsDeliveryIndex');
    $this->addChildPermission('NotificationsDeliveryController', 'NotificationsDeliveryView');

    $this->createPermission('NotificationsNotificationsController', '', 'NotificationsModule');
    $this->addChildPermission('NotificationsNotificationsController', 'NotificationsNotificationsBrowser');
    $this->addChildPermission('NotificationsNotificationsController', 'NotificationsNotificationsBrowserViewModal');
    $this->addChildPermission('NotificationsNotificationsController', 'NotificationsNotificationsClear');
    $this->addChildPermission('NotificationsNotificationsController', 'NotificationsNotificationsCreate');
    $this->addChildPermission('NotificationsNotificationsController', 'NotificationsNotificationsEmail');
    $this->addChildPermission('NotificationsNotificationsController', 'NotificationsNotificationsEmailViewModal');
    $this->addChildPermission('NotificationsNotificationsController', 'NotificationsNotificationsImagesGet');
    $this->addChildPermission('NotificationsNotificationsController', 'NotificationsNotificationsImageUpload');
    $this->addChildPermission('NotificationsNotificationsController', 'NotificationsNotificationsReadAll');
    $this->addChildPermission('NotificationsNotificationsController', 'NotificationsNotificationsView');

    $this->createPermission('NotificationsSettingsController', '', 'NotificationsModule');
    $this->addChildPermission('NotificationsSettingsController', 'NotificationsSettingsAdd');
    $this->addChildPermission('NotificationsSettingsController', 'NotificationsSettingsDelete');
    $this->addChildPermission('NotificationsSettingsController', 'NotificationsSettingsDisable');
    $this->addChildPermission('NotificationsSettingsController', 'NotificationsSettingsEdit');
    $this->addChildPermission('NotificationsSettingsController', 'NotificationsSettingsEnable');
    $this->addChildPermission('NotificationsSettingsController', 'NotificationsSettingsList');
    $this->addChildPermission('NotificationsSettingsController', 'NotificationsSettingsTemplate');
    $this->addChildPermission('NotificationsSettingsController', 'NotificationsSettingsUpdate');
    $this->addChildPermission('NotificationsSettingsController', 'NotificationsSettingsView');

    // Удаление устаревшего контроллера
    $this->removePermission('NotificationsDefaultIndex');
  }

  public function down()
  {
    $this->removePermission('NotificationsModule');

    // Разрешения
    $this->removePermission('NotificationsPermissions');

    // Контроллеры
    $this->removePermission('NotificationsDeliveryController');
    $this->removePermission('NotificationsNotificationsController');
    $this->removePermission('NotificationsSettingsController');

    // Восстановление устаревшего контроллера
    $this->createPermission('NotificationsDefaultIndex', null, null, ['admin', 'root']);
  }
}