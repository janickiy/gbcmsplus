<?php

use console\components\Migration;

class m161025_135209_add_own_view_notifications extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->moduleName = 'Notifications';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'Notifications' => [
        ['view', 'Can your own view notifications', ['root','admin','investor','reseller','manager']],
      ],
    ];
  }
}
