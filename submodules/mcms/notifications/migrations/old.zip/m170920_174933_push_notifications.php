<?php

use mcms\common\helpers\ArrayHelper;
use mcms\notifications\models\Notification;
use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170920_174933_push_notifications extends Migration
{
  use PermissionTrait;

  const NOTIFICATIONS_TABLE = 'push_notifications';
  const TOKENS_TABLE = 'users_push_tokens';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::NOTIFICATIONS_TABLE, [
      'id' => $this->primaryKey(),
      'header' => $this->string(255),
      'message' => $this->text()->notNull(),
      'is_send' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_important' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_news' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'from_module_id' => 'TINYINT(3) UNSIGNED NOT NULL',
      'created_at' => $this->integer(10)->notNull()->unsigned(),
      'updated_at' => $this->integer(10)->notNull()->unsigned(),
      'language' => $this->string(255)->notNull(),
      'event' => $this->string(255)->notNull(),
      'model_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT NULL',
      'user_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT NULL',
      'notifications_delivery_id' => $this->integer(10)->unsigned(),
      'from_user_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT NULL',
    ], $tableOptions);

    $this->createTable(self::TOKENS_TABLE, [
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'token' => $this->string(255)->notNull(),
    ], $tableOptions);

    $this->addPrimaryKey(self::TOKENS_TABLE . '_user_id_token', self::TOKENS_TABLE, ['user_id', 'token']);

    $this->createPermission('NotificationsNotificationsPushNotOwn', 'Просмотр списка Push уведомлений любых пользователей', 'NotificationsPermissions', ['admin', 'root']);

    $this->createPermission('NotificationsNotificationsPush', 'Просмотр списка Push уведомлений', 'NotificationsNotificationsController', ['admin', 'root', 'reseller']);

    $this->createPermission('NotificationsNotificationTypesSubscribePush', 'Подписка на Push уведомления', 'NotificationsNotificationTypesController', ['admin', 'root', 'investor', 'reseller']);

    $this->createPermission('NotificationsNotificationTypesUnsubscribePush', 'Отписка от Push уведомлений', 'NotificationsNotificationTypesController', ['admin', 'root', 'investor', 'reseller']);

    $notifications = (new \yii\db\Query())
      ->select(
        ['id', 'module_id', 'event', 'is_disabled', 'use_owner', 'is_important', 'is_system', 'header', 'template', 'is_news', 'emails_language']
      )
      ->from(Notification::tableName() . ' n')
      ->leftJoin('notifications_auth_item nai', 'n.id = nai.notification_id')
      ->andWhere(['or', ['!=', 'nai.auth_item_name', 'partner'], ['is', 'nai.auth_item_name', NULL]])
      ->andWhere(['notification_type' => Notification::NOTIFICATION_TYPE_BROWSER])
      ->groupBy('n.event')->all();

    foreach ($notifications as $notification) {

      $data = (new \yii\db\Query())->select('auth_item_name')->from('notifications_auth_item')->andWhere([
        'notification_id' => ArrayHelper::getValue($notification, 'id')
      ])->all();

      $roles = $data
        ? array_map(function ($val) {
          return ArrayHelper::getValue($val, 'auth_item_name');
        }, $data)
        : [];

      $data = [
        'module_id' => ArrayHelper::getValue($notification, 'module_id'),
        'header' => ArrayHelper::getValue($notification, 'header'),
        'template' => unserialize(ArrayHelper::getValue($notification, 'template')),
        'use_owner' => ArrayHelper::getValue($notification, 'use_owner'),
        'is_disabled' => ArrayHelper::getValue($notification, 'is_disabled'),
        'is_important' => ArrayHelper::getValue($notification, 'is_important'),
        'is_system' => ArrayHelper::getValue($notification, 'is_system'),
        'is_news' => ArrayHelper::getValue($notification, 'is_news'),
        'emails_language' => ArrayHelper::getValue($notification, 'emails_language'),
        'roles' => $roles
      ];

      $this->createNotification(array_merge($data, [
        'event' => ArrayHelper::getValue($notification, 'event'),
        'type' => Notification::NOTIFICATION_TYPE_PUSH
      ]));
    }

  }

  public function down()
  {
    $events = Notification::find()->andWhere(['notification_type' => Notification::NOTIFICATION_TYPE_PUSH])->all();
    foreach ($events as $event) {
      $event->delete();
    }

    $this->removePermission('NotificationsNotificationsPushNotOwn');
    $this->removePermission('NotificationsNotificationsPush');
    $this->removePermission('NotificationsNotificationTypesSubscribePush');
    $this->removePermission('NotificationsNotificationTypesUnsubscribePush');
    $this->dropTable(self::NOTIFICATIONS_TABLE);
    $this->dropTable(self::TOKENS_TABLE);
  }

  /**
   * @see \m160306_181406_update_notifications::createNotification()
   * @param array $notification
   */
  private function createNotification(array $notification)
  {
    $model = new Notification;
    $model->module_id = ArrayHelper::getValue($notification, 'module_id');
    $model->event = ArrayHelper::getValue($notification, 'event');
    $model->notification_type = ArrayHelper::getValue($notification, 'type');
    $model->header = ArrayHelper::getValue($notification, 'header');
    $model->template = ArrayHelper::getValue($notification, 'template');
    $model->emails = ArrayHelper::getValue($notification, 'emails');
    $model->use_owner = ArrayHelper::getValue($notification, 'use_owner', false);
    $model->emails_language = ArrayHelper::getValue($notification, 'emails_language', 'ru');
    $model->is_disabled = ArrayHelper::getValue($notification, 'is_disabled', false);
    $model->is_important = ArrayHelper::getValue($notification, 'is_important', false);
    $model->is_system = ArrayHelper::getValue($notification, 'is_system', false);
    $model->is_news = ArrayHelper::getValue($notification, 'is_news', false);
    if ($roles = ArrayHelper::getValue($notification, 'roles', [])) {
      $model->setRoles($roles);
    }
    $model->from = ArrayHelper::getValue($notification, 'from');
    $model->save(false);
  }
}
