<?php

use console\components\Migration;

class m161025_122040_notifications_delivery extends Migration
{
    public function up()
    {
      $tableOptions = null;
      if ($this->db->driverName === 'mysql') {
        // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
        $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
      }

      $this->createTable('notifications_delivery', [
        'id'             => 'int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
        'user_id'        => 'MEDIUMINT(5) UNSIGNED',
        'header'         => \yii\db\Schema::TYPE_STRING,
        'message'        => \yii\db\Schema::TYPE_TEXT . ' NOT NULL',
        'is_important'   => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
        'from_module_id' => 'TINYINT(3) UNSIGNED NOT NULL',
        'created_at'     => 'INT(10) UNSIGNED NOT NULL',
        'updated_at'     => 'INT(10) UNSIGNED NOT NULL',
        'is_manual'      => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
        'notification_type' => 'INT(1) UNSIGNED NOT NULL',
      ], $tableOptions);

      $this->addForeignKey(
        'notifications_delivery_user_id_fk',
        'notifications_delivery',
        'user_id',
        'users',
        'id',
        'CASCADE',
        'CASCADE'
      );

      $this->addColumn('email_notifications', 'notifications_delivery_id', 'int(10) UNSIGNED');
      $this->addColumn('browser_notifications', 'notifications_delivery_id', 'int(10) UNSIGNED');

      $this->addForeignKey(
        'email_notifications_notifications_delivery_id_fk',
        'email_notifications',
        'notifications_delivery_id',
        'notifications_delivery',
        'id'
      );
      $this->addForeignKey(
        'browser_notifications_notifications_delivery_id_fk',
        'browser_notifications',
        'notifications_delivery_id',
        'notifications_delivery',
        'id'
      );
    }

    public function down()
    {
      $this->dropForeignKey('email_notifications_notifications_delivery_id_fk', 'email_notifications');
      $this->dropColumn('email_notifications', 'notifications_delivery_id');
      $this->dropForeignKey('browser_notifications_notifications_delivery_id_fk', 'browser_notifications');
      $this->dropColumn('browser_notifications', 'notifications_delivery_id');
      $this->dropForeignKey('notifications_delivery_user_id_fk', 'notifications_delivery');
      $this->dropTable('notifications_delivery');
    }
}
