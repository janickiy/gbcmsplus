<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170925_144247_notifications_switcher extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('NotificationsSettingsMyNotificationsEnable', 'Включить собственное уведомление', 'NotificationsSettingsController', ['admin', 'reseller', 'investor', 'root']);
    $this->createPermission('NotificationsSettingsMyNotificationsDisable', 'Выключить собственное уведомление', 'NotificationsSettingsController', ['admin', 'reseller', 'investor', 'root']);
  }

  public function down()
  {
    $this->removePermission('NotificationsSettingsMyNotificationsEnable');
    $this->removePermission('NotificationsSettingsMyNotificationsDisable');
  }
}
