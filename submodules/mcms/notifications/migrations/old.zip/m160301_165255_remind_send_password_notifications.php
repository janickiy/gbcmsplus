<?php

use mcms\notifications\models\Notification;
use console\components\Migration;

class m160301_165255_remind_send_password_notifications extends Migration
{



}
