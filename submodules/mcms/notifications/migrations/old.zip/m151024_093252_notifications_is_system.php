<?php

use console\components\Migration;

class m151024_093252_notifications_is_system extends Migration
{
  const TABLE = 'notifications';
  public function up()
  {
    $this->addColumn(self::TABLE, 'is_system', 'tinyint(1) unsigned NOT NULL DEFAULT 0');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'is_system');
  }
}
