<?php

use console\components\Migration;

class m180530_080714_disable_some_email_notify extends Migration
{
  public function up()
  {
    $this->db->createCommand(<<< SQL
      delete ai from notifications_auth_item ai
      inner join notifications n on ai.notification_id = n.id
      where ai.auth_item_name IN ('reseller', 'admin', 'root') AND n.notification_type = 2 AND n.event NOT LIKE '%alert%' 
SQL
      )->execute();
    $this->update('notifications', ['is_disabled' => 1], ['notification_type' => 2, 'event' => [
      'mcms\\promo\\components\\events\\LandingDisabled',
      'mcms\\promo\\components\\events\\LandingUnlocked',
      'mcms\\promo\\components\\events\\LandingCreated',
      'mcms\\promo\\components\\events\\LandingListCreated',
      'mcms\\promo\\components\\events\\DisabledLandingsListReplace',
      'mcms\\promo\\components\\events\\DisabledLandingsListReplaceFail',
      'mcms\\promo\\components\\events\\DisabledLandingsReplace',
      'mcms\\promo\\components\\events\\DisabledLandingsReplaceFail',
      'mcms\\promo\\components\\events\\DisabledLandingsListReseller',
      'mcms\\promo\\components\\events\\DisabledLandingsReseller',
      'mcms\\promo\\components\\events\\landing_sets\\LandingsAddedToSet',
      'mcms\\promo\\components\\events\\landing_sets\\LandingsRemovedFromSet',
      'mcms\\promo\\components\\events\\LandingListCreatedReseller',
      'mcms\\promo\\components\\events\\LandingCreatedReseller',
      'mcms\\promo\\components\\events\\SourceOperatorLandingsChangeProfitType'
    ]]);


  }

  public function down()
  {
    echo "m180530_080714_disable_some_email_notify cannot be reverted.\n";
  }
}