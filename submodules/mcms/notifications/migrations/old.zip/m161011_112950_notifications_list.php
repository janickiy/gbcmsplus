<?php

use console\components\Migration;

class m161011_112950_notifications_list extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->moduleName = 'Notifications';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'Notifications' => [
        ['email', 'Can view sent email notifications', ['root']],
        ['browser', 'Can view sent browser notifications', ['root']],
        ['email-view-modal', 'Can view sent email notification', ['root']],
        ['browser-view-modal', 'Can view sent browser notification', ['root']],
      ],
    ];
  }
}