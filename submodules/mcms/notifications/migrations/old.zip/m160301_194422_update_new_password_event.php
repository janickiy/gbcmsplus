<?php

use console\components\Migration;

class m160301_194422_update_new_password_event extends Migration
{

}
