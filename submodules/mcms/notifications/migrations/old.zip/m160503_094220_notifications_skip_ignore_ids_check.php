<?php

use console\components\Migration;

class m160503_094220_notifications_skip_ignore_ids_check extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->createOrGetPermission('NotificationsSkipIgnoreIdsCheck', 'Can user send notification to other users');
    $this->assignRolesPermission('NotificationsSkipIgnoreIdsCheck', ['investor']);
  }

  public function down()
  {
    $this->revokeRolesPermission('NotificationsSkipIgnoreIdsCheck', ['investor']);
    $this->removePermission('NotificationsSkipIgnoreIdsCheck');
  }
}
