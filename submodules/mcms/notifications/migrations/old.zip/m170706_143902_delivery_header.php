<?php

use console\components\Migration;

class m170706_143902_delivery_header extends Migration
{
  public function up()
  {
    $this->alterColumn('notifications_delivery', 'header', $this->text());
  }

  public function down()
  {
    $this->alterColumn('notifications_delivery', 'header', $this->string(255));
  }

}
