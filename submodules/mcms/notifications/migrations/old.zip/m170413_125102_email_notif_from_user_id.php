<?php

use console\components\Migration;

class m170413_125102_email_notif_from_user_id extends Migration
{
  const TABLE = 'email_notifications';

  public function up()
  {
    $this->addColumn(self::TABLE, 'from_user_id', 'MEDIUMINT(5) UNSIGNED NULL');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'from_user_id');
  }
}
