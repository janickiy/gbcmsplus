<?php

use console\components\Migration;

class m161014_081941_refactor_wallets extends Migration
{
  public function up()
  {
    $this->delete('browser_notifications', ['event' => [
      'mcms\payments\components\events\EarlyPaymentAdminCreated',
      'mcms\payments\components\events\EarlyPaymentCreated',
      'mcms\payments\components\events\EarlyPaymentIndividualPercentChanged',
      'mcms\payments\components\events\PartnerAutoPaymentsEnable',
      'mcms\payments\components\events\PaymentCreated',
      'mcms\payments\components\events\PaymentSettingAutopayDisabled',
      'mcms\payments\components\events\PaymentStatusUpdated',
      'mcms\payments\components\events\PaymentUpdated',
      'mcms\payments\components\events\ReferralIndividualPercentChanged',
      'mcms\payments\components\events\RegularPaymentCreated',
      'mcms\payments\components\events\UserCurrencyChanged'
    ]]);
  }

  public function down()
  {
    echo "m161014_081941_refactor_wallets cannot be reverted.\n";
  }
}
