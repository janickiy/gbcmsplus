<?php

use yii\db\Schema;
use console\components\Migration;

class m160129_100214_notification_add_is_hidden extends Migration
{
  const TABLE = 'browser_notifications';

  public function up()
  {
    $this->addColumn(self::TABLE, 'is_hidden', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
    $this->createIndex(self::TABLE . '_is_hidden_index', self::TABLE, 'is_hidden');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'is_hidden');
  }
}
