<?php

use console\components\Migration;

class m151222_153435_browser_notification_event extends Migration
{
  const TABLE = 'browser_notifications';

  public function up()
  {
    $this->addColumn(self::TABLE, 'event',  \yii\db\Schema::TYPE_STRING . ' NOT NULL');
    $this->addColumn(self::TABLE, 'model_id', 'MEDIUMINT(5) UNSIGNED NULL');
    $this->addColumn(self::TABLE, 'from_user_id', 'MEDIUMINT(5) UNSIGNED NULL');
    $this->createIndex('browser_notifications_event_index', self::TABLE, 'event');
    $this->addForeignKey(
      'browser_notifications_from_user_id_fk',
      'browser_notifications',
      'from_user_id',
      'users',
      'id',
      'CASCADE',
      'CASCADE'
    );

  }

  public function down()
  {
    $this->dropForeignKey('browser_notifications_from_user_id_fk', 'browser_notifications');
    $this->dropColumn(self::TABLE, 'event');
    $this->dropColumn(self::TABLE, 'model_id');
    $this->dropColumn(self::TABLE, 'from_user_id');
  }

}
