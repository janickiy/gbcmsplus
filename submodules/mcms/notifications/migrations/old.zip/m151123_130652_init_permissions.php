<?php

use console\components\Migration;

class m151123_130652_init_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();

    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Notifications';
    $this->permissions = [
      'Settings' => [
        ['list', 'Can view modules', ['admin', 'root']],
        ['view', 'Can view modules event catchers', ['admin', 'root']],
        ['add', 'Can add event catcher', ['admin', 'root']],
        ['edit', 'Can edit event catcher', ['admin', 'root']],
        ['delete', 'Can delete event catcher', ['admin', 'root']],
        ['template', 'Can edit event template', ['admin', 'root']],
        ['disable', 'Can disable event catching', ['admin', 'root']],
        ['enable', 'Can enable event catching', ['admin', 'root']],
      ],
      'Default' => [
        ['index', 'Can view index page', ['admin', 'root']]
      ]
    ];
  }


}
