<?php

use console\components\Migration;

class m151217_154955_update_reseller_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration {
    up as traitUp;
    down as traitDown;
  }

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Notifications';
    $this->permissions = [
      'Settings' => [
        ['list', 'Can view modules', ['admin', 'root', 'reseller']],
        ['view', 'Can view modules event catchers', ['admin', 'root', 'reseller']],
        ['update', 'Can update event catcher', ['admin', 'root', 'reseller']],
        ['disable', 'Can disable event catching', ['admin', 'root', 'reseller']],
        ['enable', 'Can enable event catching', ['admin', 'root', 'reseller']],
      ],
    ];
  }


  public function up()
  {
    $this->traitUp();
  }

  public function down()
  {
    $this->traitDown();
    $this->permissions = [
      'Settings' => [
        ['list', 'Can view modules', ['admin', 'root']],
        ['view', 'Can view modules event catchers', ['admin', 'root']],
        ['update', 'Can update event catcher', ['admin', 'root']],
        ['disable', 'Can disable event catching', ['admin', 'root']],
        ['enable', 'Can enable event catching', ['admin', 'root']],
      ],
    ];
    $this->traitUp();
  }
}
