<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170921_124350_notifications_for_users extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable('notifications_ignore', [
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'notification_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
    ], $tableOptions);

    $this->addPrimaryKey('notifications_ignore_pair', 'notifications_ignore', ['user_id', 'notification_id']);

    $this->createPermission('NotificationsSettingsMyNotifications', 'Редактирование собственных уведомлений', 'NotificationsSettingsController', ['admin', 'reseller', 'investor', 'root']);
    $this->createPermission('NotificationsSettingsUnsubscribeTelegram', 'Отписка от уведомлений Telegram', 'NotificationsSettingsController', ['admin', 'root', 'investor', 'reseller']);

    $this->removePermission('NotificationsNotificationTypesUnsubscribeTelegram');
    $this->removePermission('NotificationsNotificationTypesIndex');
    $this->removePermission('NotificationsNotificationTypesController');
  }

  public function down()
  {
    $this->dropTable('notifications_ignore');

    $this->removePermission('NotificationsSettingsMyNotifications');
    $this->removePermission('NotificationsSettingsUnsubscribeTelegram');

    $this->createPermission('NotificationsNotificationTypesController', 'Контроллер настройки типов уведомлений', 'NotificationsModule');
    $this->createPermission('NotificationsNotificationTypesIndex', 'Настройка типов уведомлений', 'NotificationsNotificationTypesController', ['admin', 'root', 'investor', 'reseller']);
    $this->createPermission('NotificationsNotificationTypesUnsubscribeTelegram', 'Отписка от уведомлений Telegram', 'NotificationsNotificationTypesController', ['admin', 'root', 'investor', 'reseller']);
  }
}
