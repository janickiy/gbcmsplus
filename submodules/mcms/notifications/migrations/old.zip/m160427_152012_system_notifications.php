<?php

use console\components\Migration;
use mcms\notifications\models\Notification;

class m160427_152012_system_notifications extends Migration
{
  private $emailNotifications = [
    'mcms\user\components\events\EventUserBlocked',
    'mcms\user\components\events\EventNewPasswordSent',
    'mcms\user\components\events\EventStatusChanged',
    'mcms\user\components\events\EventPasswordGenerateLinkSended',
    'mcms\user\components\events\EventPasswordChanged',
  ];

  public function up()
  {
    foreach ($this->emailNotifications as $event)
    {
      /** @var Notification $notification */
      $notification = Notification::findOne([
        'event' => $event,
        'notification_type' => Notification::NOTIFICATION_TYPE_EMAIL,
      ]);
      $notification->is_system  = 1;
      $notification->save(false);
    }
  }

  public function down()
  {

  }
}
