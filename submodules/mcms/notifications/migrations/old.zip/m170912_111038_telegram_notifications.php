<?php

use mcms\common\helpers\ArrayHelper;
use mcms\notifications\models\Notification;
use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170912_111038_telegram_notifications extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable('telegram_notifications', [
      'id' => $this->primaryKey(),
      'message' => $this->text()->notNull(),
      'is_send' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_important' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_news' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'from_module_id' => 'TINYINT(3) UNSIGNED NOT NULL',
      'created_at' => $this->integer(10)->notNull()->unsigned(),
      'updated_at' => $this->integer(10)->notNull()->unsigned(),
      'language' => $this->string(255)->notNull(),
      'user_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT NULL',
      'notifications_delivery_id' => $this->integer(10)->unsigned(),
      'from_user_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT NULL',
    ], $tableOptions);


    $this->createPermission('NotificationsNotificationsTelegramNotOwn', 'Просмотр списка Telegram уведомлений любых пользователей', 'NotificationsPermissions', ['admin', 'root']);

    $this->createPermission('NotificationsNotificationsTelegram', 'Просмотр списка уведомлений Telegram', 'NotificationsNotificationsController', ['admin', 'root', 'reseller']);

    $this->createPermission('NotificationsNotificationTypesController', 'Контроллер настройки типов уведомлений', 'NotificationsModule');
    $this->createPermission('NotificationsNotificationTypesIndex', 'Настройка типов уведомлений', 'NotificationsNotificationTypesController', ['admin', 'root', 'investor', 'reseller']);
    $this->createPermission('NotificationsNotificationTypesUnsubscribeTelegram', 'Отписка от уведомлений Telegram', 'NotificationsNotificationTypesController', ['admin', 'root', 'investor', 'reseller']);

    $notifications = (new \yii\db\Query())
      ->select(
        ['id', 'module_id', 'event', 'is_disabled', 'use_owner', 'is_important', 'is_system', 'template', 'is_news', 'emails_language']
      )
      ->from(Notification::tableName() . ' n')
      ->leftJoin('notifications_auth_item nai', 'n.id = nai.notification_id')
      ->andWhere(['or', ['!=', 'nai.auth_item_name', 'partner'], ['is', 'nai.auth_item_name', NULL]])
      ->groupBy('n.event')->all();

    foreach ($notifications as $notification) {

      $data = (new \yii\db\Query())->select('auth_item_name')->from('notifications_auth_item')->andWhere([
        'notification_id' => ArrayHelper::getValue($notification, 'id')
      ])->all();

      $roles = $data
        ? array_map(function ($val) {
          return ArrayHelper::getValue($val, 'auth_item_name');
        }, $data)
        : [];

      $data = [
        'module_id' => ArrayHelper::getValue($notification, 'module_id'),
        'template' => unserialize(ArrayHelper::getValue($notification, 'template')),
        'header' => ArrayHelper::getValue($notification, 'header'),
        'use_owner' => ArrayHelper::getValue($notification, 'use_owner'),
        'is_disabled' => ArrayHelper::getValue($notification, 'is_disabled'),
        'is_important' => ArrayHelper::getValue($notification, 'is_important'),
        'is_system' => ArrayHelper::getValue($notification, 'is_system'),
        'is_news' => ArrayHelper::getValue($notification, 'is_news'),
        'emails_language' => ArrayHelper::getValue($notification, 'emails_language'),
        'roles' => $roles
      ];

      $this->createNotification(array_merge($data, [
        'event' => ArrayHelper::getValue($notification, 'event'),
        'type' => Notification::NOTIFICATION_TYPE_TELEGRAM
      ]));
    }

    $moduleEntity = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => 'notifications'])
      ->getResult();

    // Создаем уведомление об обновлении настроек телеграм бота
    $data = [
      'module_id' => $moduleEntity->id,
      'header' => [
        'ru' => 'Необходимо подписаться на уведомления Telegram',
        'en' => 'You need to subscribe to Telegram notifications',
      ],
      'template' => [
        'ru' => 'Были изменены настройки Telegram - рассылки, в результате чего вам необходимо заново подписаться, если хотите получать уведомления через Telegram',
        'en' => 'The settings of the Telegram have been changed. As a result, you need to re-subscribe if you want to receive notifications via Telegram.'
      ],
      'roles' => [
        'owner'
      ]
    ];

    $this->createNotification(array_merge($data, [
      'event' => \mcms\notifications\components\events\TelegramAutoUnsubscribeEvent::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER
    ]));

  }

  public function down()
  {
    $event = Notification::find()->andWhere(['event' => 'mcms\notifications\components\events\TelegramAutoUnsubscribeEvent'])->one();
    $event->delete();

    $events = Notification::find()->andWhere(['notification_type' => Notification::NOTIFICATION_TYPE_TELEGRAM])->all();
    foreach ($events as $event) {
      $event->delete();
    }

    $this->removePermission('NotificationsNotificationsTelegramNotOwn');
    $this->removePermission('NotificationsNotificationsTelegram');

    $this->removePermission('NotificationsNotificationTypesUnsubscribeTelegram');
    $this->removePermission('NotificationsNotificationTypesIndex');
    $this->removePermission('NotificationsNotificationTypesController');
    $this->dropTable('telegram_notifications');
  }

  /**
   * @see \m160306_181406_update_notifications::createNotification()
   * @param array $notification
   */
  private function createNotification(array $notification)
  {
    $model = new Notification;
    $model->module_id = ArrayHelper::getValue($notification, 'module_id');
    $model->event = ArrayHelper::getValue($notification, 'event');
    $model->notification_type = ArrayHelper::getValue($notification, 'type');
    $model->header = ArrayHelper::getValue($notification, 'header');
    $model->template = ArrayHelper::getValue($notification, 'template');
    $model->emails = ArrayHelper::getValue($notification, 'emails');
    $model->use_owner = ArrayHelper::getValue($notification, 'use_owner', false);
    $model->emails_language = ArrayHelper::getValue($notification, 'emails_language', 'ru');
    $model->is_disabled = ArrayHelper::getValue($notification, 'is_disabled', false);
    $model->is_important = ArrayHelper::getValue($notification, 'is_important', false);
    $model->is_system = ArrayHelper::getValue($notification, 'is_system', false);
    $model->is_news = ArrayHelper::getValue($notification, 'is_news', false);
    if ($roles = ArrayHelper::getValue($notification, 'roles', [])) {
      $model->setRoles($roles);
    }
    $model->from = ArrayHelper::getValue($notification, 'from');
    $model->save(false);
  }
}
