<?php

use mcms\notifications\models\Notification;
use console\components\Migration;

class m160301_082120_change_email_notifications extends Migration
{


}
