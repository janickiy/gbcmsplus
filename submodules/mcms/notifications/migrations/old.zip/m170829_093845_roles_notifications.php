<?php

use console\components\Migration;

class m170829_093845_roles_notifications extends Migration
{
  public function up()
  {

    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable('notifications_for_roles', [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'roles' => $this->string(),
      'module_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'event' => $this->string(),
      'notification_type' => $this->smallInteger()->defaultValue(0)->notNull()->unsigned(),
      'is_important' => $this->smallInteger()->unsigned()->defaultValue(0),
      'created_at' => $this->integer(10)->unsigned()->notNull(),
      'updated_at' => $this->integer(10)->unsigned()->notNull(),
      'is_system' => $this->smallInteger()->unsigned()->defaultValue(0),
      'emails' => $this->text(),
      'from' => $this->text(),
      'template' => $this->text(),
      'header' => $this->text(),
      'is_news' => $this->smallInteger()->unsigned(),
      'emails_language' => $this->string(),
      'is_replace' => $this->smallInteger()->unsigned(),
      'event_instance' => $this->text(),
      'is_send' => $this->smallInteger()->unsigned()->notNull(),
    ], $tableOptions);

    $this->createIndex(
      'notification_for_roles_is_send_index',
      'notifications_for_roles',
      ['is_send']
    );

  }

  public function down()
  {
    $this->dropTable('notifications_for_roles');
  }

}
