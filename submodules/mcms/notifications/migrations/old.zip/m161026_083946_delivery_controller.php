<?php

use console\components\Migration;

class m161026_083946_delivery_controller extends Migration
{
    use \mcms\common\traits\PermissionMigration;

    /**
     * @inheritDoc
     */
    public function init()
    {
        parent::init();
        $this->moduleName = 'Notifications';
        $this->authManager = Yii::$app->getAuthManager();
        $this->permissions = [
            'Delivery' => [
                ['index', 'Can view notification delivery list', ['root']],
                ['view', 'Can view notification delivery detail', ['root']],
            ],
        ];
    }
}
