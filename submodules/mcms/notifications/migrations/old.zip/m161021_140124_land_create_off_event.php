<?php

use console\components\Migration;

class m161021_140124_land_create_off_event extends Migration
{
  public function up()
  {
    $this->update('notifications', ['is_disabled' => 1], [
      'and',
      ['or',
        ['event' => 'mcms\\promo\\components\\events\\LandingCreated'],
        ['event' => 'mcms\\promo\\components\\events\\LandingListCreated'],
      ],
      ['notification_type' => 2]
    ]);
  }

  public function down()
  {
    $this->update('notifications', ['is_disabled' => 0], [
      'and',
      ['or',
        ['event' => 'mcms\\promo\\components\\events\\LandingCreated'],
        ['event' => 'mcms\\promo\\components\\events\\LandingListCreated'],
      ],
      ['notification_type' => 2]
    ]);
  }
}
