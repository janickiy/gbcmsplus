<?php

use mcms\notifications\models\Notification;
use console\components\Migration;

class m161214_122015_update_notifications extends Migration
{
  public function up()
  {
    $notification = Notification::find()->where([
      'event' => \mcms\support\components\events\EventCreated::className(),
      'notification_type' => Notification::NOTIFICATION_TYPE_BROWSER,
    ])->one();
    $notification->template = [
      'ru' => 'Пользователь {ticket.createdBy.username} создал тикет #{ticket.id} {ticket.truncatedName}',
      'en' => 'User {ticket.createdBy.username} created ticket # {ticket.id} {ticket.truncatedName}'
    ];
    $notification->save();

    $notification = Notification::find()->where([
      'event' => \mcms\support\components\events\EventAdminCreated::className(),
      'notification_type' => Notification::NOTIFICATION_TYPE_BROWSER,
    ])->one();
    $notification->template = [
      'ru' => 'Вам добавлен новый тикет: "{ticket.truncatedName}"',
      'en' => 'You have a new ticket: "{ticket.truncatedName}"'
    ];
    $notification->save();
  }

  public function down()
  {
    echo "m161214_122015_update_notifications cannot be reverted.\n";

    return false;
  }
}
