<?php

use console\components\Migration;

class m161025_090118_email_notifications_to_user_id extends Migration
{
    public function up()
    {
      $this->addColumn('email_notifications', 'to_user_id', 'MEDIUMINT(5) UNSIGNED');
      $this->addForeignKey(
        'email_notifications_to_user_id_fk',
        'email_notifications',
        'to_user_id',
        'users',
        'id',
        'CASCADE',
        'CASCADE'
      );
      $this->db->createCommand("
      UPDATE email_notifications
        LEFT JOIN users ON email_notifications.username = users.username
            SET `to_user_id` = users.id
      ")->execute();
    }

    public function down()
    {
      $this->dropForeignKey('email_notifications_to_user_id_fk', 'email_notifications');
      $this->dropColumn('email_notifications', 'to_user_id');
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
