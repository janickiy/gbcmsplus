<?php

use console\components\Migration;

class m151214_110539_email_notifications extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    
    $this->createTable('email_notifications', [
      'id'             => 'int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'user_id'        => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'from'           => \yii\db\Schema::TYPE_STRING . ' NOT NULL',
      'header'         => \yii\db\Schema::TYPE_STRING . ' NOT NULL',
      'message'        => \yii\db\Schema::TYPE_TEXT . ' NOT NULL',
      'is_send'        => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_important'   => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_news'   => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'from_module_id' => 'TINYINT(3) UNSIGNED NOT NULL',
      'created_at'     => 'INT(10) UNSIGNED NOT NULL',
      'updated_at'     => 'INT(10) UNSIGNED NOT NULL',
    ], $tableOptions);

    $this->createIndex(
      'email_notifications_is_send_index',
      'email_notifications',
      ['user_id', 'is_send']
    );

    $this->createIndex('email_notifications_is_important_index', 'email_notifications', 'is_important');
    $this->createIndex('email_notifications_is_news_index', 'email_notifications', 'is_news');

    $this->addForeignKey(
      'email_notifications_from_module_id_fk',
      'email_notifications',
      'from_module_id',
      'modules',
      'id',
      'CASCADE',
      'CASCADE'
    );

    $this->createIndex(
      'email_notifications__is_send_index',
      'email_notifications',
      ['user_id', 'is_send']
    );

    $this->addForeignKey(
      'email_notifications_user_id_fk',
      'email_notifications',
      'user_id',
      'users',
      'id',
      'CASCADE',
      'CASCADE'
    );

  }

  public function down()
  {
    $this->dropForeignKey('email_notifications_user_id_fk', 'email_notifications');
    $this->dropForeignKey('email_notifications_from_module_id_fk', 'email_notifications');
    $this->dropTable('email_notifications');
  }
 
}
