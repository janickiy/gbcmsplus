<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
*/
class m180904_092948_telegram_settings_change extends Migration
{
  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;
  use PermissionTrait;

  const BOT_NAME = 'settings.telegram_bot_name';
  const BOT_TOKEN = 'settings.telegram_bot_token';

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
    $this->authManager = Yii::$app->authManager;
  }
  /**
  */
  public function up()
  {
    $validators = [["string"]];
    $this->settingsBuilder->updateValidators(self::BOT_NAME, $validators);
    $this->settingsBuilder->updateValidators(self::BOT_TOKEN, $validators);
  }

  /**
  */
  public function down()
  {
    $validators = [["required"],["string"]];
    $this->settingsBuilder->updateValidators(self::BOT_NAME, $validators);
    $this->settingsBuilder->updateValidators(self::BOT_TOKEN, $validators);
  }
}
