<?php

use console\components\Migration;
use mcms\notifications\models\Notification;

class m160328_273711_create_notification extends Migration
{
  protected $notifications;
  protected $browserNotification;
  protected $modulePromoId;

  public function init()
  {
    $this->browserNotification = Notification::NOTIFICATION_TYPE_BROWSER;

    $moduleApiResult = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => 'promo'])
      ->getResult();
    $this->modulePromoId = $moduleApiResult->id;

    $this->notifications = [
      [
        'event' => mcms\promo\components\events\LandingCreated::className(),
        'data' => [
          'header' => [
            'ru' => 'Добавлен новый лендинг',
            'en' => 'New landing',
          ],
          'template' => [
            'ru' => "<p>Добавлен новый лендинг:<br>{landing.id}. {landing.name}<br>Спешите снимать сливки!</p>",
            'en' => "<p>New landing:<br>{landing.id}. {landing.name}<br></p>",
          ],
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingListCreated::className(),
        'data' => [
          'header' => [
            'ru' => 'Добавлены новые лендинги',
            'en' => 'New landing',
          ],
          'template' => [
            'ru' => "<p>Добавлены новые лендинги:<br>{landings}<br>Спешите снимать сливки!</p>",
            'en' => "<p>New landings:<br>{landings}<br></p>",
          ],
        ]
      ],
    ];
  }

  // Use safeUp/safeDown to run migration code within a transaction
  public function up()
  {
    foreach ($this->notifications as $notificationData) {
      $notification = $notificationData['event'] ? Notification::findOne([
        'event' => $notificationData['event'],
        'notification_type' => $this->browserNotification,
      ]) : null;
      if (!$notification) {
        $notification = new Notification();
      }

      $notification->setAttributes($notificationData['data'], false);
      $notification->event = $notificationData['event'];
      $notification->notification_type = $this->browserNotification;

      $notification->roles = ['partner'];
      $notification->module_id = $this->modulePromoId;

      $notification->save(false);

    }
  }

  public function down()
  {

  }
}
