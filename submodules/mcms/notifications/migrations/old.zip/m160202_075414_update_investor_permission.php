<?php

use yii\db\Schema;
use console\components\Migration;

class m160202_075414_update_investor_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration {
    up as traitUp;
    down as traitDown;
  }
  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Notifications';
    $this->permissions = [
      'Notifications' => [
        ['clear', 'Can clear notification', ['admin', 'root', 'reseller', 'investor']],
      ],
    ];
  }

  public function up()
  {
    $this->traitUp();
  }

  public function down()
  {
    $this->traitDown();
    $this->permissions = [
      'Notifications' => [
        ['clear', 'Can clear notification', ['admin', 'root', 'reseller']],
      ],
    ];
    $this->traitUp();
  }
}
