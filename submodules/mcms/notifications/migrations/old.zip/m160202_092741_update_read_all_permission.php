<?php

use yii\db\Schema;
use console\components\Migration;

class m160202_092741_update_read_all_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration {
    up as traitUp;
    down as traitDown;
  }

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Notifications';
    $this->permissions = [
      'Notifications' => [
        ['readAll', 'Can read all browser notifications', ['admin', 'root', 'reseller', 'investor']],
      ],
    ];
  }

  public function up()
  {
    $this->traitUp();
  }

  public function down()
  {
    $this->traitDown();
    $this->permissions = [
      'Notifications' => [
        ['readAll', 'Can read all browser notifications', ['admin', 'root', 'partner']],
      ],
    ];
    $this->traitUp();
  }
}
