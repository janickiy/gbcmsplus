<?php

use mcms\notifications\models\Notification;
use console\components\Migration;
use yii\helpers\ArrayHelper;

class m160219_121320_init_notifications extends Migration
{

}
