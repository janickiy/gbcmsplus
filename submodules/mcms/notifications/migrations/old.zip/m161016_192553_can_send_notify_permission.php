<?php

use console\components\Migration;

class m161016_192553_can_send_notify_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Notifications';
    $this->permissions = [
      'CanNotify' => [
        ['root', 'Can notify to root role', ['root']],
        ['admin', 'Can notify to admin role', ['root', 'admin']],
        ['reseller', 'Can notify to reseller role', ['root', 'admin']],
        ['manager', 'Can notify to manager role', ['root', 'admin', 'reseller']],
        ['investor', 'Can notify to investor role', ['root', 'admin']],
        ['partner', 'Can notify to manager role', ['root', 'admin', 'reseller', 'manager']],
      ]
    ];
  }


}
