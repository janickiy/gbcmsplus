<?php

use mcms\notifications\models\Notification;
use console\components\Migration;

class m160301_154715_fix_email_notifications extends Migration
{



}
