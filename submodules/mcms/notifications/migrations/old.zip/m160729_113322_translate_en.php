<?php

use console\components\Migration;

class m160729_113322_translate_en extends Migration
{
  public function up()
  {
    $notifications = array(
      array( // row #0
        'event' => 'mcms\\pages\\components\\events\\FaqUpdateEvent',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:137:"Пожалуйста ознакомьтесь с новыми правилами партнерской программы {projectName}.";s:2:"en";s:65:"Please refer to the new affiliate program policies {projectName}.";}',
        'header' => 'a:2:{s:2:"ru";s:35:"Обновился раздел FAQ";s:2:"en";s:19:"Updated FAQ section";}',
      ),
      array( // row #1
        'event' => 'mcms\\payments\\components\\events\\EarlyPaymentAdminCreated',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:249:"Сумма выплаты: {payment.amount} {payment.currency}.<br>Статус выплаты: {payment.status}.<br>Для получения дополнительной информации обратитесь в службу поддержки.";s:2:"en";s:149:"Payment amount: {payment.amount} {payment.currency}.<br>Payment status: {payment.status} <br>Please contact customer support for additional requires.";}',
        'header' => 'a:2:{s:2:"ru";s:33:"Досрочная выплата";s:2:"en";s:13:"Early payment";}',
      ),
      array( // row #2
        'event' => 'mcms\\payments\\components\\events\\EarlyPaymentCreated',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:172:"{payment.user.username} заказал досрочную выплату на {payment.amount} {payment.currency}. Необходимо произвести выплату!";s:2:"en";s:120:"{payment.user.username} ordered pre-payment of {payment.amount} {payment.currency}. It is necessary to make the payment!";}',
        'header' => 'a:2:{s:2:"ru";s:33:"Досрочная выплата";s:2:"en";s:11:"Pre-payment";}',
      ),
      array( // row #3
        'event' => 'mcms\\payments\\components\\events\\PaymentStatusUpdated',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:46:"Статус выплаты: {payment.status}.";s:2:"en";s:33:"Payment status: {payment.status}.";}',
        'header' => 'a:2:{s:2:"ru";s:48:"Выплата #{payment.id} обновлена.";s:2:"en";s:30:"Payment #{payment.id} updated.";}',
      ),
      array( // row #4
        'event' => 'mcms\\payments\\components\\events\\RegularPaymentCreated',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:95:"Сумма: {payment.amount} {payment.currency}. Статус выплаты: {payment.status}.";s:2:"en";s:75:"Sum: {payment.amount} {payment.currency}. Payment status: {payment.status}.";}',
        'header' => 'a:2:{s:2:"ru";s:72:"Выплата за период {payment.date_from} - {payment.date_to}";s:2:"en";s:62:"Payment for the period {payment.date_from} - {payment.date_to}";}',
      ),
      array( // row #5
        'event' => 'mcms\\payments\\components\\events\\RegularPaymentsGenerated',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:180:"Кол-во: {component.count} шт.<br>Общая сумма выплат: {component.amount.rub} руб, {component.amount.eur} евро, {component.amount.usd} долларов.";s:2:"en";s:138:"Qty:. {component.count} items <br> Total sum: {component.amount.rub} rubles, {component.amount.eur} euros, {component.amount.usd} dollars.";}',
        'header' => 'a:2:{s:2:"ru";s:74:"Выплата за период {component.dateFrom} - {component.dateTo}";s:2:"en";s:64:"Payment for the period {component.dateFrom} - {component.dateTo}";}',
      ),
      array( // row #6
        'event' => 'mcms\\payments\\components\\events\\UserBalanceInvoiceCompensation',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:279:"На ваш баланс добавлена компенсация в размере {userBalanceInvoice.amount} {userBalanceInvoice.currency}.<br>Для получения дополнительной информации обратитесь в службу поддержки.";s:2:"en";s:162:"The compensation of {userBalanceInvoice.amount} {userBalanceInvoice.currency} is added to your balance.<br>Please contact customer support for additional requires";}',
        'header' => 'a:2:{s:2:"ru";s:22:"Компенсация";s:2:"en";s:12:"Compensation";}',
      ),
      array( // row #7
        'event' => 'mcms\\payments\\components\\events\\UserBalanceInvoiceMulct',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:268:"С вашего баланса списан штраф в размере {userBalanceInvoice.amount} {userBalanceInvoice.currency}. <br>Для получения дополнительной информации обратитесь в службу поддержки.";s:2:"en";s:172:"Penalty at the rate {userBalanceInvoice.amount} {userBalanceInvoice.currency} is charged-off from your balance.<br> Please contact customer support for additional requires.";}',
        'header' => 'a:2:{s:2:"ru";s:10:"Штраф";s:2:"en";s:5:"Mulct";}',
      ),
      array( // row #8
        'event' => 'mcms\\promo\\components\\events\\DisabledLandingsListReplace',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:185:"Лендинги:<br>{landings}<br>были отключены.<br/>Трафик автоматически переведен на лендинги из тех же категорий.";s:2:"en";s:122:"Landings:<br>{landings}<br>has been disabled<br/>Traffic is automatically transferred to the Landing of the same category.";}',
        'header' => 'a:2:{s:2:"ru";s:44:"Лендинги были отключены";s:2:"en";s:26:"Landings has been disabled";}',
      ),
      array( // row #9
        'event' => 'mcms\\promo\\components\\events\\DisabledLandingsListReplace',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:319:"<strong>Уважаемый {owner.username}!</strong><br/><p>Лендинги:<br>{landings}<br>были отключены.<br/>Трафик автоматически переведен на лендинги из тех же категорий.</p><strong>С уважением, команда {projectName}.</strong>";s:2:"en";s:235:"<strong>Greetings, {owner.username}!</strong><br/><p>Landings:<br>{landings}<br>has been disabled<br/>Traffic is automatically transferred to the Landing of the same category.</p><strong>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:44:"Лендинги были отключены";s:2:"en";s:26:"Landings has been disabled";}',
      ),
      array( // row #10
        'event' => 'mcms\\promo\\components\\events\\DisabledLandingsListReplaceFail',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:258:"Лендинги:<br>{landings}<br>были отключены.<br/>Лендинги для перевода трафика не найдены. Пожалуйста поменяйте лендинги вручную или остановите трафик!";s:2:"en";s:148:"Landings:<br>{landings}<br>has been disabled<br/>Landings is not found for the transfer of traffic. Please change manually Landings or stop traffic!";}',
        'header' => 'a:2:{s:2:"ru";s:44:"Лендинги были отключены";s:2:"en";s:26:"Landings has been disabled";}',
      ),
      array( // row #11
        'event' => 'mcms\\promo\\components\\events\\DisabledLandingsListReplaceFail',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:392:"<strong>Уважаемый {owner.username}!</strong><br/><p>Лендинги:<br>{landings}<br>были отключены.<br/>Лендинги для перевода трафика не найдены. Пожалуйста поменяйте лендинги вручную или остановите трафик!</p><strong>С уважением, команда {projectName}.</strong>";s:2:"en";s:261:"<strong>Greetings, {owner.username}!</strong><br/><p>Landings:<br>{landings}<br>has been disabled<br/>Landings is not found for the transfer of traffic. Please change manually Landings or stop traffic!</p><strong>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:44:"Лендинги были отключены";s:2:"en";s:26:"Landings has been disabled";}',
      ),
      array( // row #12
        'event' => 'mcms\\promo\\components\\events\\DisabledLandingsListReseller',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:63:"Лендинги:<br>{landings}<br>были отключены.";s:2:"en";s:44:"Landings:<br>{landings}<br>has been disabled";}',
        'header' => 'a:2:{s:2:"ru";s:44:"Лендинги были отключены";s:2:"en";s:26:"Landings has been disabled";}',
      ),
      array( // row #13
        'event' => 'mcms\\promo\\components\\events\\DisabledLandingsListReseller',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:184:"<strong>Уважаемый {owner.username}!</strong><br/><p>Лендинги:<br>{landings}<br>были отключены.</p><strong>Best regards, command of {projectName}.</strong>";s:2:"en";s:157:"<strong>Greetings, {owner.username}!</strong><br/><p>Landings:<br>{landings}<br>has been disabled</p><strong>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:44:"Лендинги были отключены";s:2:"en";s:26:"Landings has been disabled";}',
      ),
      array( // row #14
        'event' => 'mcms\\promo\\components\\events\\DisabledLandingsReplace',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:117:"Трафик автоматически переведен на лендинги из той же категории.";s:2:"en";s:73:"Traffic is automatically transferred to the Landing of the same category.";}',
        'header' => 'a:2:{s:2:"ru";s:135:"Лендинг #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) был отключен.";s:2:"en";s:121:"Landing #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) has been disabled";}',
      ),
      array( // row #15
        'event' => 'mcms\\promo\\components\\events\\DisabledLandingsReplace',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:250:"<strong>Уважаемый {user.username}!</strong><br/><p>Трафик автоматически переведен на лендинги из той же категории.</p><strong>С уважением, команда {projectName}.</strong>";s:2:"en";s:185:"<strong>Greetings, {user.username}!</strong><br/><p>Traffic is automatically transferred to the Landing of the same category.</p><strong>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:135:"Лендинг #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) был отключен.";s:2:"en";s:121:"Landing #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) has been disabled";}',
      ),
      array( // row #16
        'event' => 'mcms\\promo\\components\\events\\DisabledLandingsReseller',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:135:"Лендинг #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) был отключен.";s:2:"en";s:122:"Landing #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) has been disabled.";}',
        'header' => 'a:2:{s:2:"ru";s:31:"Лендинг отключен";s:2:"en";s:25:"Landing has been disabled";}',
      ),
      array( // row #17
        'event' => 'mcms\\promo\\components\\events\\DisabledLandingsReseller',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:269:"<strong>Уважаемый {owner.username}!</strong><br/><p>Лендинг #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) был отключен.</p><strong>С уважением, команда {projectName}.</strong>";s:2:"en";s:235:"<strong>Greetings, {owner.username}!</strong><br/><p>Landing #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) has been disabled.</p><strong>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:31:"Лендинг отключен";s:2:"en";s:25:"Landing has been disabled";}',
      ),
      array( // row #18
        'event' => 'mcms\\promo\\components\\events\\DomainAdded',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:166:"Партнер: {domain.createdBy.username} добавил новый домен {domain.url}<br/>Тип домена: {domain.type}<br/>Статус: {domain.status}";s:2:"en";s:131:"Partner: {domain.createdBy.username} added a new domain {domain.url} <br/> domain type: {domain.type} <br/> Status: {domain.status}";}',
        'header' => 'a:2:{s:2:"ru";s:52:"Добавлен новый домен {domain.url}.";s:2:"en";s:30:"New domain {domain.url} added.";}',
      ),
      array( // row #19
        'event' => 'mcms\\promo\\components\\events\\DomainBanned',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:113:"Статус: {domain.status}. Просьба перевести трафик на активные домены!";s:2:"en";s:71:"Status: {domain.status}. Please transfer traffic to the active domains!";}',
        'header' => 'a:2:{s:2:"ru";s:43:"Статус {domain.url} обновлен.";s:2:"en";s:28:"{domain.url} status updated.";}',
      ),
      array( // row #20
        'event' => 'mcms\\promo\\components\\events\\DomainBanned',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:331:"<strong>Здравствуйте {owner.username}!</strong><p>Домен {domain.url} заблокирован, просьба перевести трафик на активные домены, чтобы избежать потери трафика!</p><p><strong>С уважением, команда {projectName}.</strong></p>";s:2:"en";s:186:"<strong>Greetings {owner.username}!</strong><p>Domain {domain.url} is blocked. Please transfer traffic to the active domains!</p><p><strong>Best regards, {projectName} team.</strong></p>";}',
        'header' => 'a:2:{s:2:"ru";s:65:"{projectName} - Домен {domain.url} заблокирован.";s:2:"en";s:44:"{projectName} - Domain {domain.url} blocked.";}',
      ),
      array( // row #21
        'event' => 'mcms\\promo\\components\\events\\LandingCreated',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:75:"Добавлен новый лендинг:<br>{landing.id}. {landing.name}";s:2:"en";s:44:"New landing:<br>{landing.id}. {landing.name}";}',
        'header' => 'a:2:{s:2:"ru";s:42:"Добавлен новый лендинг";s:2:"en";s:11:"New landing";}',
      ),
      array( // row #22
        'event' => 'mcms\\promo\\components\\events\\LandingCreated',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:213:"<strong>Уважаемый {owner.username}!</strong><br/><p>Добавлен новый лендинг:<br>{landing.id}. {landing.name}<br></p><strong>С уважением, команда {projectName}.</strong>";s:2:"en";s:161:"<strong>Greetings, {owner.username}!</strong><br/><p>New landing:<br>{landing.id}. {landing.name}<br></p><strong>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:42:"Добавлен новый лендинг";s:2:"en";s:11:"New landing";}',
      ),
      array( // row #23
        'event' => 'mcms\\promo\\components\\events\\LandingDisabled',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:249:"Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} заблокирован.<br>Для получения дополнительной информации обратитесь в службу поддержки.";s:2:"en";s:151:"Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name}is blocked.<br>Please contact customer support for further information.";}',
        'header' => 'a:2:{s:2:"ru";s:113:"Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} заблокирован.";s:2:"en";s:89:"Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} blocked.";}',
      ),
      array( // row #24
        'event' => 'mcms\\promo\\components\\events\\LandingDisabled',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:273:"<strong>Здравствуйте {owner.username}!</strong><p>Запрос к лендингу #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} заблокирован.</p><p><strong>С уважением, команда {projectName}.</strong></p>";s:2:"en";s:208:"<strong>Greetings {owner.username}!</strong><p>Landing request #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} is blocked.</p><p><strong>Best regards, {projectName} team.</strong></p>";}',
        'header' => 'a:2:{s:2:"ru";s:129:"{projectName} - Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} заблокирован.";s:2:"en";s:105:"{projectName} - Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} blocked.";}',
      ),
      array( // row #25
        'event' => 'mcms\\promo\\components\\events\\LandingListCreated',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:61:"Добавлены новые лендинги:<br>{landings}";s:2:"en";s:27:"New landings:<br>{landings}";}',
        'header' => 'a:2:{s:2:"ru";s:46:"Добавлены новые лендинги";s:2:"en";s:12:"New landings";}',
      ),
      array( // row #26
        'event' => 'mcms\\promo\\components\\events\\LandingListCreated',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:199:"<strong>Уважаемый {owner.username}!</strong><br/><p>Добавлены новые лендинги:<br>{landings}<br></p><strong>С уважением, команда {projectName}.</strong>";s:2:"en";s:144:"<strong>Greetings, {owner.username}!</strong><br/><p>New landings:<br>{landings}<br></p><strong>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:46:"Добавлены новые лендинги";s:2:"en";s:12:"New landings";}',
      ),
      array( // row #27
        'event' => 'mcms\\promo\\components\\events\\LandingRedirectChanged',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:184:"Лендинг для перевода трафика не найден. Пожалуйста поменяйте лендинг вручную или остановите трафик!";s:2:"en";s:89:"Landing for traffic transfer isn\'t found. Please change manually Landing or stop traffic!";}',
        'header' => 'a:2:{s:2:"ru";s:135:"Лендинг #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) был отключен.";s:2:"en";s:121:"Landing #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) has been disabled";}',
      ),
      array( // row #28
        'event' => 'mcms\\promo\\components\\events\\LandingRedirectChanged',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:316:"<strong>Уважаемый {user.username}!</strong><br><p>Лендинг для перевода трафика не найден. Пожалуйста поменяйте лендинг вручную или остановите трафик!</p><strong>С уважением, команда {projectName}.</strong>";s:2:"en";s:204:"<strong>Greetings, {user.username}!</strong><br><p>Landing for traffic transfer isn\'t found. Please change manually the Landing or stop traffic!</p><strong>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:135:"Лендинг #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) был отключен.";s:2:"en";s:121:"Landing #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) has been disabled";}',
      ),
      array( // row #29
        'event' => 'mcms\\promo\\components\\events\\LandingUnblockRequestCreated',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:256:"Пользователь {landingUnblockRequest.user.username} добавил заявку на разблокировку лендинга #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name}<br>Необходима модерация!";s:2:"en";s:175:"User {landingUnblockRequest.user.username} gave a request for Landing unlocking # {landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name}<br>Moderation wanted!";}',
        'header' => 'a:2:{s:2:"ru";s:62:"Заявка на разблокировку лендинга.";s:2:"en";s:29:"Request for unlocking landing";}',
      ),
      array( // row #30
        'event' => 'mcms\\promo\\components\\events\\LandingUnlocked',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:211:"Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} успешно активирован.<br>Желаем успехов в работе и отличного профита!";s:2:"en";s:153:"Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} is successfully activated.<br><p>Wish you a high profit and success!</p>";}',
        'header' => 'a:2:{s:2:"ru";s:111:"Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} активирован.";s:2:"en";s:91:"Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} activated.";}',
      ),
      array( // row #31
        'event' => 'mcms\\promo\\components\\events\\LandingUnlocked',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:370:"<strong>Здравствуйте {owner.username}!</strong><p>Запрос к лендингу #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} успешно активирован.</p><p>Желаем успехов в работе и отличного профита!<br><strong>С уважением, команда {projectName}</strong></p>";s:2:"en";s:262:"<strong>Greetings {owner.username}!</strong><p>Landing request #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} is successfully activated.</p><p>Wish you a high profit and success!<br><strong>Best regards, {projectName} team.</strong></p>";}',
        'header' => 'a:2:{s:2:"ru";s:127:"{projectName} - Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} активирован.";s:2:"en";s:107:"{projectName} - Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} activated.";}',
      ),
      array( // row #32
        'event' => 'mcms\\promo\\components\\events\\LinkActivated',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:147:"Ваша ссылка успешно активирована!<br>Желаем успехов в работе и отличного профита!";s:2:"en";s:75:"Your link is successfully activated!<br>Wish you a high profit and success!";}',
        'header' => 'a:2:{s:2:"ru";s:65:"Ссылка #{source.id} {source.name} активирована.";s:2:"en";s:42:"Link #{source.id} {source.name} activated.";}',
      ),
      array( // row #33
        'event' => 'mcms\\promo\\components\\events\\LinkActivated',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:334:"<strong>Здравствуйте {owner.username}!</strong><p>Ваша ссылка  #{source.id} {source.name} успешно активирована.</p><p>Желаем успехов в работе и отличного профита!<br><strong>С уважением, команда <strong>{projectName}.</strong></strong></p>";s:2:"en";s:211:"<strong>Greetings {owner.username}!</strong><p>Your link  #{source.id} {source.name} is successfully activated.</p><p>Wish you a high profit and success!<br><strong>Best regards, {projectName} team.</strong></p>";}',
        'header' => 'a:2:{s:2:"ru";s:81:"{projectName} - Ссылка #{source.id} {source.name} активирована.";s:2:"en";s:58:"{projectName} - Link #{source.id} {source.name} activated.";}',
      ),
      array( // row #34
        'event' => 'mcms\\promo\\components\\events\\LinkCreated',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:103:"Пользователь {source.user.username} добавил ссылку #{source.id} {source.name}.";s:2:"en";s:68:"User {source.user.username} added a link #{source.id} {source.name}.";}',
        'header' => 'a:2:{s:2:"ru";s:32:"Добавлена ссылка.";s:2:"en";s:12:"Link created";}',
      ),
      array( // row #35
        'event' => 'mcms\\promo\\components\\events\\LinkCreatedModeration',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:148:"Пользователь {source.user.username} добавил ссылку #{source.id} {source.name}.<br/>Необходима модерация!";s:2:"en";s:91:"User {source.user.username} added a link #{source.id} {source.name}.<br/>Moderation wanted!";}',
        'header' => 'a:2:{s:2:"ru";s:32:"Добавлена ссылка.";s:2:"en";s:12:"Link created";}',
      ),
      array( // row #36
        'event' => 'mcms\\promo\\components\\events\\LinkRejected',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:174:"Причина: {source.reject_reason}<br>Для получения дополнительной информации обратитесь в службу поддержки.";s:2:"en";s:94:"Reason: {source.reject_reason}<br>Please contact customer support for any additional requires.";}',
        'header' => 'a:2:{s:2:"ru";s:67:"Ссылка #{source.id} {source.name} заблокирована.";s:2:"en";s:41:"Link #{source.id} {source.name} rejected.";}',
      ),
      array( // row #37
        'event' => 'mcms\\promo\\components\\events\\LinkRejected',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:264:"<strong>Здравствуйте {owner.username}!</strong><p>Ваша ссылка #{source.id} #{source.name} заблокирована.</p><p>Причина: {source.reject_reason}</p><p><strong>С уважением, команда {projectName}.</strong></p>";s:2:"en";s:195:"<strong>Greetings {owner.username}!</strong><p>Your link #{source.id} #{source.name} is rejected.</p><p>Reason: {source.reject_reason}</p><p><strong>Best regards, {projectName} team.</strong></p>";}',
        'header' => 'a:2:{s:2:"ru";s:83:"{projectName} - Ссылка #{source.id} {source.name} заблокирована.";s:2:"en";s:57:"{projectName} - Link #{source.id} {source.name} rejected.";}',
      ),
      array( // row #38
        'event' => 'mcms\\promo\\components\\events\\SourceActivated',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:147:"Ваш источник успешно активирован!<br>Желаем успехов в работе и отличного профита!";s:2:"en";s:78:"Your source is successfully activated!<br> Wish you a high profit and success!";}',
        'header' => 'a:2:{s:2:"ru";s:67:"Источник #{source.id} {source.name} активирован.";s:2:"en";s:44:"Source #{source.id} {source.name} activated.";}',
      ),
      array( // row #39
        'event' => 'mcms\\promo\\components\\events\\SourceActivated',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:317:"<strong>Здравствуйте {owner.username}!</strong><p>Ваш источник  #{source.id} {source.name} успешно активирован.</p><p>Желаем успехов в работе и отличного профита!<br><strong>С уважением, команда {projectName}.</strong></p>";s:2:"en";s:213:"<strong>Greetings {owner.username}!</strong><p>Your source  #{source.id} {source.name} is successfully activated.</p><p>Wish you a high profit and success!<br><strong>Best regards, {projectName} team.</strong></p>";}',
        'header' => 'a:2:{s:2:"ru";s:83:"{projectName} - Источник #{source.id} {source.name} активирован.";s:2:"en";s:60:"{projectName} - Source #{source.id} {source.name} activated.";}',
      ),
      array( // row #40
        'event' => 'mcms\\promo\\components\\events\\SourceCreated',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:107:"Пользователь {source.user.username} добавил источник #{source.id} {source.name}.";s:2:"en";s:68:"User {source.user.username} added source #{source.id} {source.name}.";}',
        'header' => 'a:2:{s:2:"ru";s:34:"Добавлен источник.";s:2:"en";s:12:"Source added";}',
      ),
      array( // row #41
        'event' => 'mcms\\promo\\components\\events\\SourceCreatedModeration',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:146:"Пользователь {source.user.username} добавил источник #{source.id} {source.name}. Требуется модерация!";s:2:"en";s:87:"User {source.user.username} added source #{source.id} {source.name}. Moderation wanted!";}',
        'header' => 'a:2:{s:2:"ru";s:34:"Добавлен источник.";s:2:"en";s:12:"Source added";}',
      ),
      array( // row #42
        'event' => 'mcms\\promo\\components\\events\\SourceRejected',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:174:"Причина: {source.reject_reason}<br>Для получения дополнительной информации обратитесь в службу поддержки.";s:2:"en";s:94:"Reason: {source.reject_reason}<br>Please contact customer support for any additional requires.";}',
        'header' => 'a:2:{s:2:"ru";s:69:"Источник #{source.id} {source.name} заблокирован.";s:2:"en";s:43:"Source #{source.id} {source.name} rejected.";}',
      ),
      array( // row #43
        'event' => 'mcms\\promo\\components\\events\\SourceRejected',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:258:"<strong>Здравствуйте {owner.username}!</strong><br><p>Ваш источник #{source.id} #{source.name} заблокирован.<br>Причина: {source.reject_reason}</p><strong>С уважением, команда {projectName}.</strong>";s:2:"en";s:198:"<strong>Greetings {owner.username}!</strong><br><p>Your source #{source.id} #{source.name} is rejected.<br>Reason: {source.reject_reason}</p><p><strong>Best regards, {projectName} team.</strong></p>";}',
        'header' => 'a:2:{s:2:"ru";s:85:"{projectName} - Источник #{source.id} {source.name} заблокирован.";s:2:"en";s:59:"{projectName} - Source #{source.id} {source.name} rejected.";}',
      ),
      array( // row #44
        'event' => 'mcms\\promo\\components\\events\\SystemDomainAdded',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:172:"Вы можете использовать его при создании ссылки.<br>Желаем успехов в работе и отличного профита!";s:2:"en";s:77:"You can use it to create links.<br><p>Wish you a high profit and success!</p>";}',
        'header' => 'a:2:{s:2:"ru";s:52:"Добавлен новый домен {domain.url}.";s:2:"en";s:30:"New domain {domain.url} added.";}',
      ),
      array( // row #45
        'event' => 'mcms\\promo\\components\\events\\SystemDomainBanned',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:113:"Статус: {domain.status}. Просьба перевести трафик на активные домены!";s:2:"en";s:71:"Status: {domain.status}. Please transfer traffic to the active domains!";}',
        'header' => 'a:2:{s:2:"ru";s:43:"Статус {domain.url} обновлен.";s:2:"en";s:28:"{domain.url} status updated.";}',
      ),
      array( // row #46
        'event' => 'mcms\\promo\\components\\events\\SystemDomainBanned',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:331:"<strong>Здравствуйте {owner.username}!</strong><p>Домен {domain.url} заблокирован, просьба перевести трафик на активные домены, чтобы избежать потери трафика!</p><p><strong>С уважением, команда {projectName}.</strong></p>";s:2:"en";s:186:"<strong>Greetings {owner.username}!</strong><p>Domain {domain.url} is blocked. Please transfer traffic to the active domains!</p><p><strong>Best regards, {projectName} team.</strong></p>";}',
        'header' => 'a:2:{s:2:"ru";s:65:"{projectName} - Домен {domain.url} заблокирован.";s:2:"en";s:44:"{projectName} - Domain {domain.url} blocked.";}',
      ),
      array( // row #47
        'event' => 'mcms\\support\\components\\events\\EventAdminClosed',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:165:"Тикет: "{ticket.name}" закрыт, если у вас остались какие то вопросы обратитесь в службу поддержки.";s:2:"en";s:84:"Ticket: "{ticket.name}" is closed. If you have any questions please contact support.";}',
        'header' => 'a:2:{s:2:"ru";s:23:"Тикет закрыт";s:2:"en";s:13:"Ticket closed";}',
      ),
      array( // row #48
        'event' => 'mcms\\support\\components\\events\\EventAdminClosed',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{support_email}";s:2:"en";s:15:"{support_email}";}',
        'template' => 'a:2:{s:2:"ru";s:256:"<strong>Здравствуйте {ticket.createdBy.username}!</strong><br><strong>Тикет: "{ticket.name}" закрыт, если у вас остались какие то вопросы обратитесь в службу поддержки.</strong>";s:2:"en";s:161:"<strong>Greetings, {ticket.createdBy.username}!</strong><br><strong>Ticket: "{ticket.name}" is closed. If you have any questions please contact support.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:39:"{projectName} - Тикет закрыт";s:2:"en";s:29:"{projectName} - Ticket closed";}',
      ),
      array( // row #49
        'event' => 'mcms\\support\\components\\events\\EventAdminCreated',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:62:"Вам добавлен новый тикет: "{ticket.name}"";s:2:"en";s:38:"You have a new ticket: "{ticket.name}"";}',
        'header' => 'a:2:{s:2:"ru";s:21:"Новый тикет";s:2:"en";s:10:"New ticket";}',
      ),
      array( // row #50
        'event' => 'mcms\\support\\components\\events\\EventAdminCreated',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{support_email}";s:2:"en";s:15:"{support_email}";}',
        'template' => 'a:2:{s:2:"ru";s:222:"<strong>Здравствуйте {ticket.createdBy.username}!</strong><br><strong>Вам добавлен новый тикет: "{ticket.name}".</strong><br/><strong>Сообщение: </strong><br/>{ticket.message.text}";s:2:"en";s:173:"<strong>Greetings, {ticket.createdBy.username}!</strong><br><strong>You have a new ticket: "{ticket.name}".</strong><br/><strong>Message: </strong><br/>{ticket.message.text}";}',
        'header' => 'a:2:{s:2:"ru";s:62:"{projectName} - Вам добавлен новый тикет.";s:2:"en";s:38:"{projectName} - You have a new ticket.";}',
      ),
      array( // row #51
        'event' => 'mcms\\support\\components\\events\\EventCreated',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:103:"Пользователь {ticket.createdBy.username} создал тикет #{ticket.id} {ticket.name}";s:2:"en";s:79:"User {ticket.createdBy.username} created the ticket # {ticket.id} {ticket.name}";}',
        'header' => 'a:2:{s:2:"ru";s:21:"Новый тикет";s:2:"en";s:10:"New ticket";}',
      ),
      array( // row #52
        'event' => 'mcms\\support\\components\\events\\EventMessageReceived',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:62:"Новое сообщение в тикете: "{ticket.name}"";s:2:"en";s:42:"New message in the ticket: "{ticket.name}"";}',
        'header' => 'a:2:{s:2:"ru";s:50:"Вам пришло новое сообщение.";s:2:"en";s:23:"You have a new message.";}',
      ),
      array( // row #53
        'event' => 'mcms\\support\\components\\events\\EventMessageReceived',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{support_email}";s:2:"en";s:15:"{support_email}";}',
        'template' => 'a:2:{s:2:"ru";s:190:"<strong>Здравствуйте {ticket.createdBy.username}!</strong><br><strong>В тикет "{ticket.name}" пришло новое сообщение:</strong><br/>{ticket.message.text}";s:2:"en";s:156:"<strong>Greetings, {ticket.createdBy.username}!</strong><br><strong>You have a new message in the ticket "{ticket.name}":</strong><br/>{ticket.message.text}";}',
        'header' => 'a:2:{s:2:"ru";s:66:"{projectName} - Вам пришло новое сообщение.";s:2:"en";s:39:"{projectName} - You have a new message.";}',
      ),
      array( // row #54
        'event' => 'mcms\\support\\components\\events\\EventMessageSend',
        'notification_type' => 1,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:127:"Пользователь {ticket.createdBy.username} добавил новое сообщение в #{ticket.id} {ticket.name}";s:2:"en";s:86:"User {ticket.createdBy.username} added a new message to the #{ticket.id} {ticket.name}";}',
        'header' => 'a:2:{s:2:"ru";s:29:"Новое сообщение";s:2:"en";s:11:"New message";}',
      ),
      array( // row #55
        'event' => 'mcms\\user\\components\\events\\EventActivationCodeSended',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:587:"<strong>Здравствуйте, {user.username}!</strong><br>Благодарим вас за регистрацию в партнерской программе <strong>{projectName}</strong>.<br><br>Для активации аккаунта перейдите по ссылке: {homeUrl}/users/site/activate/?code={activationCode}<br><br>Если вы не регистрировались в партнерской программе {projectName}, то проигнорируйте это письмо.<br><br><strong>С уважением, команда {projectName}.</strong>";s:2:"en";s:383:"<strong>Greetings, {user.username}!</strong><br>We thank you for registration in partners program <strong>{projectName}</strong>.<br><br>To active your account visit following link: {homeUrl}/users/site/activate/?code={activationCode}<br><br>If you didn\'t registered in partners program {projectName}, ignore this mail.<br><br><strong>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:38:"{projectName} - Регистрация";s:2:"en";s:28:"{projectName} - Registration";}',
      ),
      array( // row #56
        'event' => 'mcms\\user\\components\\events\\EventPasswordChanged',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:489:"<strong>Здравствуйте, {user.username}!<br>Ваш пароль для входа в партнерскую программу {projectName} успешно изменен!</strong><br><br><strong>Данные для авторизации в партнерской программе:</strong><br>E-mail: {user.email}<br><br><strong>Желаем успехов в работе и отличного профита!<br>С уважением, команда {projectName}.</strong>";s:2:"en";s:339:"<strong>Greetings, {user.username}!<br>Your password for accessing partners program {projectName} has been successfully changed!</strong><br><br><strong>Information for authorization in partners program:</strong><br>E-mail: {user.email}<br><br><strong>Wish you a high profit and success!<br>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:43:"{projectName} - Пароль изменен";s:2:"en";s:41:"{projectName} - Password has been changed";}',
      ),
      array( // row #57
        'event' => 'mcms\\user\\components\\events\\EventPasswordGenerateLinkSended',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:520:"<strong>Здравствуйте, {user.username}!<br>С вашего аккаунта поступил запрос на изменение пароля.</strong><br><br><strong>Для того, чтобы изменить пароль, перейдите по ссылке:</strong><br>{homeUrl}/users/site/reset-password/?token={user.password_reset_token}<br><br><strong>Желаем успехов в работе и отличного профита!<br>С уважением, команда {projectName}.</strong>";s:2:"en";s:337:"<strong>Greetings, {user.username}!<br>Password remind has been requested from your account.</strong><br><br><strong>To change password open this link:</strong><br>{homeUrl}/users/site/reset-password/?token={user.password_reset_token}<br><br><strong>Wish you a high profit and success!<br>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:51:"{projectName} - Напоминание пароля";s:2:"en";s:31:"{projectName} - Password remind";}',
      ),
      array( // row #58
        'event' => 'mcms\\user\\components\\events\\EventPasswordSended',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:541:"<strong>Здравствуйте, {user.username}!<br>С вашего аккаунта поступил запрос на изменение пароля. Пароль был успешно изменен.</strong><br><br><strong>Данные для авторизации в партнерской программе:</strong><br>E-mail: {user.email}<br>Пароль: {password}<br><br><strong>Желаем успехов в работе и отличного профита!<br>С уважением, команда {projectName}.</strong>";s:2:"en";s:327:"<strong>Greetings, {user.username}!<br>Password remind has been requested from your account.</strong><br><br><strong>Information for authorization in partners program:</strong><br>E-mail: {user.email}<br>Password: {password}<br><br><strong>Wish you a high profit and success!<br>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:51:"{projectName} - Напоминание пароля";s:2:"en";s:31:"{projectName} - Password remind";}',
      ),
      array( // row #59
        'event' => 'mcms\\user\\components\\events\\EventReferralRegistered',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:249:"Поздравляем! По вашей ссылке зарегистрировался новый пользователь. Статистику по рефералам вы можете просматривать в разделе Рефералы";s:2:"en";s:123:"Congratulations! A new user registered by your referrer link. Statistics on referrals you can view in the section Referrals";}',
        'header' => 'a:2:{s:2:"ru";s:70:"Зарегистрировался реферал: {referrer.username}";s:2:"en";s:40:"Referral registered: {referrer.username}";}',
      ),
      array( // row #60
        'event' => 'mcms\\user\\components\\events\\EventRegistered',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:52:"Статус пользователя: {user.status}";s:2:"en";s:26:"User status: {user.status}";}',
        'header' => 'a:2:{s:2:"ru";s:50:"Зарегистрировался {user.username}";s:2:"en";s:26:"{user.username} Registered";}',
      ),
      array( // row #61
        'event' => 'mcms\\user\\components\\events\\EventRegisteredHandActivation',
        'notification_type' => 1,
        'from' => 'N;',
        'template' => 'a:2:{s:2:"ru";s:109:"Статус пользователя: {user.status}. Требуется активация партнера!";s:2:"en";s:46:"User status: {user.status}. Activation wanted!";}',
        'header' => 'a:2:{s:2:"ru";s:50:"Зарегистрировался {user.username}";s:2:"en";s:26:"{user.username} Registered";}',
      ),
      array( // row #62
        'event' => 'mcms\\user\\components\\events\\EventRegisteredHandActivation',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:414:"<strong>Здравствуйте {user.username}!</strong><br/>Благодарим вас за регистрацию в партнерской программе {projectName}.<br/><br/>Наш менеджер свяжется с вами в ближайшее время!<br/>Если вы не хотите ждать - свяжитесь с нами по контактам указанным на сайте.";s:2:"en";s:299:"<strong>Greetings, {user.username}!</strong><br>We thank you for registration in partners program <strong>{projectName}</strong>.<br><br>Our manager will contact you soon!<br>If you don\'t want to wait, you can use contacts on our site.<br><br><strong>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:38:"{projectName} - Регистрация";s:2:"en";s:28:"{projectName} - Registration";}',
      ),
      array( // row #63
        'event' => 'mcms\\user\\components\\events\\EventStatusChanged',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:166:"<strong>Здравствуйте, {user.username}!<br>Ваш аккаунт {user.status}<br><br><strong>С уважением, команда {projectName}.</strong>";s:2:"en";s:129:"<strong>Greetings, {user.username}!<br>Your account {user.status}<br><br><strong>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:44:"{projectName} - Аккаунт {user.status}";s:2:"en";s:37:"{projectName} - Account {user.status}";}',
      ),
      array( // row #64
        'event' => 'mcms\\user\\components\\events\\EventUserApproved',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:1396:"<strong>Здравствуйте, {user.username}!<br>Ваш аккаунт прошел проверку и успешно активирован.</strong><br><br><strong>Данные для авторизации в партнерской программе:</strong><br>E-mail: {user.email}<br><br><strong>Реферальная система:</strong> Хотите получать стабильный доход от оборота всех привлеченных партнеров? Привлекайте партнеров и зарабатывайте.<br>Ваша ссылка для привлечения партнеров: {referralLink}<br>Вы можете использовать ее в подписи на форумах, блогах и т.д., а так же рекомендовать напрямую друзьям и знакомым.<br><br><strong>Перед началом работы:</strong> рекомендуем прочитать {homeUrl}/partners/faq/index/, в котором мы собрали ответы на основные вопросы, чтобы вы смогли с легкостью разобраться c функционалом партнерской программы.<br><br><strong>Желаем успехов в работе и отличного профита!<br>С уважением, команда {projectName}.</strong>";s:2:"en";s:793:"<strong>Greetings, {user.username}!<br>Your account was approved and successfully activated.</strong><br><br><strong>Information for authorization in partners program:</strong><br>E-mail: {user.email}<br><br><strong>Referral system:</strong> You want to have stable income from your partners? Attract your partners and have profit.<br>Your link for getting partners: {referralLink}<br>You can use it in signatures at forums, blogs etc. and also recommend directly to your friends.<br><br><strong>Before you start:</strong> we recommend you to read the {homeUrl}/partners/faq/index/ in which we collected answers to most frequent questions, so you can easily use partners program functional.<br><br><strong>Wish you a high profit and success!<br>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:53:"{projectName} - Аккаунт активирован";s:2:"en";s:40:"{projectName} - Account has been actived";}',
      ),
      array( // row #65
        'event' => 'mcms\\user\\components\\events\\EventUserApprovedWithoutReferrals',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:825:"<strong>Здравствуйте, {user.username}!<br>Ваш аккаунт прошел проверку и успешно активирован.</strong><br><br><strong>Данные для авторизации в партнерской программе:</strong><br>E-mail: {user.email}<br><br><strong>Перед началом работы:</strong> рекомендуем прочитать {homeUrl}/partners/faq/index/, в котором мы собрали ответы на основные вопросы, чтобы вы смогли с легкостью разобраться c функционалом партнерской программы.<br><br><strong>Желаем успехов в работе и отличного профита!<br>С уважением, команда {projectName}.</strong>";s:2:"en";s:513:"<strong>Greetings, {user.username}!<br>Your account was approved and successfully activated.</strong><br><br><strong>Information for authorization in partners program:</strong><br>E-mail: {user.email}<br><br><strong>Before you start:</strong> we recommend you to read the {homeUrl}/partners/faq/index/ in which we collected answers to most frequent questions, so you can easily use partners program functional.<br><br><strong>Wish you a high profit and success!<br>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:53:"{projectName} - Аккаунт активирован";s:2:"en";s:40:"{projectName} - Account has been actived";}',
      ),
      array( // row #66
        'event' => 'mcms\\user\\components\\events\\EventUserBlocked',
        'notification_type' => 2,
        'from' => 'a:2:{s:2:"ru";s:15:"{noreply_email}";s:2:"en";s:15:"{noreply_email}";}',
        'template' => 'a:2:{s:2:"ru";s:418:"<strong>Здравствуйте, {user.username}!<br>Ваш аккаунт заблокрован.</strong><br><br>Наш менеджер свяжется с вами в ближайшее время!<br>Если вы не хотите ждать - свяжитесь с нами по контактам указанным на сайте.<br><br><strong>С уважением, команда {projectName}.</strong>";s:2:"en";s:247:"<strong>Greetings, {user.username}!<br>Your account has been blocked</strong><br><br>Our manager will contact you soon!<br>If you don\'t want to wait, you can use contacts on our site.<br><br><strong>Best regards, command of {projectName}.</strong>";}',
        'header' => 'a:2:{s:2:"ru";s:55:"{projectName} - Аккаунт заблокирован";s:2:"en";s:40:"{projectName} - Account has been blocked";}',
      ),
    );

    foreach ($notifications as $notification) {
      $select = (new \yii\db\Query())
        ->select('*')
        ->from('notifications')
        ->where([
          'event' => $notification['event'],
          'notification_type' => $notification['notification_type']
        ])
        ->one();

      if (!$select) {
        echo 'EVENT NOT FOUND' . PHP_EOL;
        continue;
      }

      if (
        $select['template'] == $notification['template']
        && $select['from'] == $notification['from']
        && $select['header'] == $notification['header']
      ) {
        echo 'NO CHANGES' . PHP_EOL;
        continue;
      }

      $this->update('notifications', [
        'template' => $notification['template'],
        'from' => $notification['from'],
        'header' => $notification['header'],
      ], [
        'id' => $select['id']
      ]);
    }
  }

  public function down()
  {
    echo "m160729_113322_translate_en cannot be reverted.\n";
    return true;
  }
}
