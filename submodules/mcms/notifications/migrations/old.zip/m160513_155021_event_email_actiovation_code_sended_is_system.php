<?php

use mcms\user\components\events\EventActivationCodeSended;
use console\components\Migration;

class m160513_155021_event_email_actiovation_code_sended_is_system extends Migration
{
  public function up()
  {
    $this->execute("update notifications set is_system = 1 where event = :event", [':event' => EventActivationCodeSended::className()]);
  }

  public function down()
  {
    echo "m160513_155021_event_email_actiovation_code_sended_is_system cannot be reverted.\n";
  }
}
