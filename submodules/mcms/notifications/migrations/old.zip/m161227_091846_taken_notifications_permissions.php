<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m161227_091846_taken_notifications_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission(
      'NotificationsTakenNotificationsController',
      'Контроллер TakenNotifications',
      'NotificationsModule'
    );

    $this->createPermission(
      'NotificationsTakenNotificationsView',
      'Просмотр списка уведомлений текущему пользователю',
      'NotificationsTakenNotificationsController',
      ['admin', 'investor', 'manager', 'reseller', 'root']
    );

    $this->createPermission(
      'NotificationsTakenNotificationsClear',
      'Пометка всех уведомлений просмотренными и скрытыми',
      'NotificationsTakenNotificationsController',
      ['admin', 'investor', 'manager', 'reseller', 'root']
    );

    $this->removePermission('NotificationsNotificationsView');
    $this->removePermission('NotificationsNotificationsClear');
  }

  public function down()
  {
    $this->removePermission('NotificationsTakenNotificationsView');
    $this->removePermission('NotificationsTakenNotificationsClear');
    $this->removePermission('NotificationsTakenNotificationsController');

    $this->createPermission(
      'NotificationsNotificationsView',
      'Просмотр списка уведомлений текущему пользователю',
      'NotificationsNotificationsController',
      ['admin', 'investor', 'manager', 'reseller', 'root']
    );

    $this->createPermission(
      'NotificationsNotificationsClear',
      'Пометка всех уведомлений просмотренными и скрытыми',
      'NotificationsNotificationsController',
      ['admin', 'investor', 'manager', 'reseller', 'root']
    );
  }
}
