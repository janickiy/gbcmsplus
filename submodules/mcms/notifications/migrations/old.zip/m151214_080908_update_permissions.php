<?php

use console\components\Migration;

class m151214_080908_update_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();

    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Notifications';
    $this->permissions = [
      'Settings' => [
        ['update', 'Can update event catcher', ['admin', 'root']],
      ],
    ];
  }
}
