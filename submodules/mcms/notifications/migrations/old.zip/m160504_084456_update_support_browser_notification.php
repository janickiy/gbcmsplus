<?php

use console\components\Migration;

class m160504_084456_update_support_browser_notification extends Migration
{
  public function up()
  {
    $notification = \mcms\notifications\models\Notification::find()
      ->where([
        'event' => 'mcms\support\components\events\EventMessageReceived',
        'notification_type' => \mcms\notifications\models\Notification::NOTIFICATION_TYPE_BROWSER,
        'use_owner' => 1
      ])
      ->one()
    ;

    if (!$notification) return false;

    $notification->template = [
      'ru' => 'Новое сообщение в тикете: "{ticket.name}"',
      'en' => 'New message in the ticket: "{ticket.name}"'
    ];

    $notification->save();
  }

  public function down()
  {
    echo "m160504_084456_update_support_browser_notification cannot be reverted.\n";
  }
}
