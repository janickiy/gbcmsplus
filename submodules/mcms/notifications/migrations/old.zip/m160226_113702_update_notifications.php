<?php

use console\components\Migration;

class m160226_113702_update_notifications extends Migration
{
  public function up()
  {
    $this->addColumn('notifications', 'emails_language', \yii\db\Schema::TYPE_STRING . ' NOT NULL');
    \mcms\notifications\models\Notification::updateAll(['emails_language' => 'ru']);
  }

  public function down()
  {
    $this->dropColumn('notifications', 'emails_language');
  }
}