<?php

use console\components\Migration;

class m150825_104841_create_notifications extends Migration
{
  const TABLE = 'notifications';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::TABLE, [
      'id'                => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'module_id'         => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'event'             => \yii\db\Schema::TYPE_STRING . ' NOT NULL',
      'notification_type' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_disabled'       => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'use_owner'         => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_important'      => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at'        => 'INT(10) UNSIGNED NOT NULL',
      'updated_at'        => 'INT(10) UNSIGNED NOT NULL',
    ], $tableOptions);

    $this->createIndex('notifications_is_important_index', self::TABLE, 'is_important');

    $this->createTable('notifications_auth_item', [
      'auth_item_name'  => \yii\db\Schema::TYPE_STRING . '(64) NOT NULL',
      'notification_id' => 'MEDIUMINT(10) UNSIGNED NOT NULL'
    ], $tableOptions);

    $this->createIndex(
      'auth_item_name_notification_id',
      'notifications_auth_item',
      ['auth_item_name', 'notification_id'],
      true
    );

    $this->createIndex(
      'auth_item_name',
      'notifications_auth_item',
      ['auth_item_name']
    );

    $this->addForeignKey(
      'notifications_auth_item_name_fk',
      'notifications_auth_item',
      'auth_item_name',
      'auth_item',
      'name',
      'CASCADE',
      'CASCADE'
    );
    $this->addForeignKey(
      'notifications_auth_item_notification_id_fk',
      'notifications_auth_item',
      'notification_id',
      'notifications',
      'id',
      'CASCADE',
      'CASCADE'
    );

    $this->createTable('browser_notifications', [
      'id'             => 'int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'user_id'        => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'from'           => \yii\db\Schema::TYPE_STRING . ' NOT NULL',
      'header'         => \yii\db\Schema::TYPE_STRING . ' NOT NULL',
      'message'        => \yii\db\Schema::TYPE_TEXT . ' NOT NULL',
      'is_viewed'      => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_important'   => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'from_module_id' => 'TINYINT(3) UNSIGNED NOT NULL',
      'created_at'     => 'INT(10) UNSIGNED NOT NULL',
      'updated_at'     => 'INT(10) UNSIGNED NOT NULL',
    ], $tableOptions);

    $this->createIndex(
      'browser_notifications_is_viewed_index',
      'browser_notifications',
      ['user_id', 'is_viewed']
    );

    $this->createIndex('browser_notifications_is_important_index', 'browser_notifications', 'is_important');

    $this->addForeignKey(
      'browser_notifications_from_module_id_fk',
      'browser_notifications',
      'from_module_id',
      'modules',
      'id',
      'CASCADE',
      'CASCADE'
    );

    $this->createIndex(
      'browser_notifications__is_viewed_index',
      'browser_notifications',
      ['user_id', 'is_viewed']
    );

    $this->addForeignKey(
      'browser_notifications_user_id_fk',
      'browser_notifications',
      'user_id',
      'users',
      'id',
      'CASCADE',
      'CASCADE'
    );
  }

  public function down()
  {
    $this->dropForeignKey('browser_notifications_user_id_fk', 'browser_notifications');
    $this->dropForeignKey('browser_notifications_from_module_id_fk', 'browser_notifications');
    $this->dropTable('browser_notifications');

    $this->dropForeignKey('notifications_auth_item_notification_id_fk', 'notifications_auth_item');
    $this->dropForeignKey('notifications_auth_item_name_fk', 'notifications_auth_item');
    $this->dropTable('notifications_auth_item');

    $this->dropTable(self::TABLE);
  }
}
