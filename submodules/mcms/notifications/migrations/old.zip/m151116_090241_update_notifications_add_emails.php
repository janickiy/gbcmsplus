<?php

use console\components\Migration;

class m151116_090241_update_notifications_add_emails extends Migration
{

  const TABLE = 'notifications';

  public function up()
  {
    $this->addColumn(self::TABLE, 'emails', \yii\db\Schema::TYPE_TEXT);
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'emails');
  }
}
