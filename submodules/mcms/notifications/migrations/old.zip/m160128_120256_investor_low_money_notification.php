<?php

use mcms\notifications\models\Notification;
use yii\db\Schema;
use console\components\Migration;

class m160128_120256_investor_low_money_notification extends Migration
{
}
