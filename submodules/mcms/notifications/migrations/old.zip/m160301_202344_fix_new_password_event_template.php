<?php

use console\components\Migration;

class m160301_202344_fix_new_password_event_template extends Migration
{

}
