<?php

use console\components\Migration;

class m170411_081036_delivery_new_fields extends Migration
{
  const TABLE = 'notifications_delivery';

  public function up()
  {
    $this->addColumn(static::TABLE, 'roles', $this->string(255));
    $this->addColumn(static::TABLE, 'emails', $this->text());
    $this->addColumn(static::TABLE, 'event', $this->string(255));
    $this->addColumn(static::TABLE, 'is_news', $this->smallInteger(1)->defaultValue(0));
  }

  public function down()
  {
    $this->dropColumn(static::TABLE, 'roles');
    $this->dropColumn(static::TABLE, 'emails');
    $this->dropColumn(static::TABLE, 'event');
    $this->dropColumn(static::TABLE, 'is_news');
  }
}
