<?php

use console\components\Migration;

class m151214_104907_browser_notification_is_news extends Migration
{

  const TABLE = 'notifications';
  const TABLE_BROWSER = 'browser_notifications';

  public function up()
  {
    $this->addColumn(self::TABLE, 'is_news', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
    $this->createIndex('notifications_is_news_index', self::TABLE, 'is_news');
    $this->addColumn(self::TABLE_BROWSER, 'is_news', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
    $this->createIndex('notifications_is_news_index', self::TABLE_BROWSER, 'is_news');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'is_news');
    $this->dropColumn(self::TABLE_BROWSER, 'is_news');
  }
}
