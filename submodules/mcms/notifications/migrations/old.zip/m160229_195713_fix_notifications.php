<?php

use mcms\notifications\models\Notification;
use console\components\Migration;

class m160229_195713_fix_notifications extends Migration
{


  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
