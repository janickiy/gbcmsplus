<?php

use console\components\Migration;
use mcms\notifications\models\Notification;

class m160325_100729_update_notification_text extends Migration
{
  private $emailNotifications = [
    'mcms\promo\components\events\SourceRejected' => [
      'header' => [
        'ru' => '{projectName} - Источник #{source.id} {source.name} заблокирован.',
        'en' => '{projectName} - Source #{source.id} {source.name} rejected.',
      ],
      'template' => [
        'ru' => '<p><strong>Здравствуйте {owner.username}!<br></strong><strong>Ваш источник #{source.id} #{source.name} заблокирован.</strong></p>' .
                '<p><strong>Причина:</strong> {source.reject_reason}</p>' .
                '<p><strong>С уважением, команда {projectName}.</strong></p>',
        'en' => '<p><strong>Greetings {owner.username}!<br></strong><strong>Your source #{source.id} #{source.name} rejected.</strong></p>' .
                '<p><strong>Reason:</strong> {source.reject_reason}</p>' .
                '<p><strong>Best regards, {projectName} team.</strong></p>',
      ]
    ],
    'mcms\promo\components\events\SourceActivated' => [
      'header' => [
        'ru' => '{projectName} - Источник #{source.id} {source.name} активирован.',
        'en' => '{projectName} - Source #{source.id} {source.name} activated.',
      ],
      'template' => [
        'ru' => '<p><strong>Здравствуйте {owner.username}!</strong><br>' .
                '<strong>Ваш источник  #{source.id} {source.name} </strong>успешно активирован.</p>' .
                '<p><strong>Желаем успехов в работе и отличного профита!<br></strong>' .
                '<strong>С уважением, команда <strong>{projectName}</strong>.</strong></p>',
        'en' => '<p><strong>Greetings {owner.username}!</strong><br>' .
                '<strong>Your source  #{source.id} {source.name}</strong> successfully activated.</p>' .
                '<p><strong>We wish you success in your work and a great profit!<br></strong>' .
                '<strong>Best regards, {projectName} team.</strong></p>',
      ]
    ],
    'mcms\promo\components\events\LinkRejected' => [
      'header' => [
        'ru' => '{projectName} - Ссылка #{source.id} {source.name} заблокирована.',
        'en' => '{projectName} - Link #{source.id} {source.name} rejected.',
      ],
      'template' => [
        'ru' => '<p><strong>Здравствуйте {owner.username}!<br></strong>' .
                '<strong>Ваша ссылка #{source.id} #{source.name} заблокирована.</strong></p>' .
                '<p><strong>Причина:</strong> {source.reject_reason}</p>' .
                '<p><strong>С уважением, команда {projectName}.</strong></p>',
        'en' => '<p><strong>Greetings {owner.username}!<br></strong>' .
                '<strong>Your link #{source.id} #{source.name} rejected.</strong></p>' .
                '<p><strong>Reason:</strong> {source.reject_reason}</p>' .
                '<p><strong>Best regards, {projectName} team.</strong></p>',
      ]
    ],
    'mcms\promo\components\events\LinkActivated' => [
      'header' => [
        'ru' => '{projectName} - Ссылка #{source.id} {source.name} активирована.',
        'en' => '{projectName} - Link #{source.id} {source.name} activated.',
      ],
      'template' => [
        'ru' => '<p><strong>Здравствуйте {owner.username}!</strong><br>' .
                '<strong>Ваша ссылка  #{source.id} {source.name} </strong>успешно активирована.</p>' .
                '<p><strong>Желаем успехов в работе и отличного профита!<br></strong>' .
                '<strong>С уважением, команда <strong>{projectName}.</strong></p>',
        'en' => '<p><strong>Greetings {owner.username}!</strong><br>' .
                '<strong>Your link  #{source.id} {source.name}</strong> successfully activated.</p>' .
                '<p><strong>We wish you success in your work and a great profit!<br></strong>' .
                '<strong>Best regards, {projectName} team.</strong></p>',
      ]
    ],
    'mcms\promo\components\events\LandingDisabled' => [
      'header' => [
        'ru' => '{projectName} - Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} заблокирован.',
        'en' => '{projectName} - Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} blocked.',
      ],
      'template' => [
        'ru' => '<p><strong>Здравствуйте {owner.username}!</strong><br>' .
                '<strong>Запрос к лендингу #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} заблокирован.</strong></p>' .
                '<p><strong>С уважением, команда <strong>{projectName}.</strong></p>',
        'en' => '<p><strong>Greetings {owner.username}!</strong><br>' .
                '<strong>Landing unblock request #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} blocked.</strong></p>' .
                '<p><strong>Best regards, {projectName} team.</strong></p>',
      ]
    ],
    'mcms\promo\components\events\LandingUnlocked' => [
      'header' => [
        'ru' => '{projectName} - Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} активирован.',
        'en' => '{projectName} - Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} activated.',
      ],
      'template' => [
        'ru' => '<p><strong>Здравствуйте {owner.username}!</strong><br>' .
                '<strong>Запрос к лендингу #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} успешно активирован.</strong></p>' .
                '<p><strong>Желаем успехов в работе и отличного профита!<br></strong>' .
                '<strong>С уважением, команда <strong>{projectName}</strong></p>',
        'en' => '<p><strong>Greetings {owner.username}!</strong><br>' .
                '<strong>Landing unblock request #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} successfully activated.</strong></p>' .
                '<p><strong>We wish you success in your work and a great profit!<br></strong>' .
                '<strong>Best regards, {projectName} team.</strong></p>',
      ]
    ],
    'mcms\promo\components\events\SystemDomainBanned' => [
      'header' => [
        'ru' => '{projectName} - Домен {domain.url} заблокирован.',
        'en' => '{projectName} - Domain {domain.url} blocked.',
      ],
      'template' => [
        'ru' => '<p><strong>Здравствуйте {owner.username}!</strong><br>' .
            '<strong>Домен {domain.url} заблокирован, просьба перевести трафик на активные домены, чтобы избежать потери трафика!</strong></p>' .
            '<p><strong>С уважением, команда <strong>{projectName}.</strong></p>',
        'en' => '<p><strong>Greetings {owner.username}!</strong><br>' .
            '<strong>Domain {domain.url} blocked. Please transfer traffic to the active domains!</strong></p>' .
            '<p><strong>Best regards, {projectName} team.</strong></p>',
      ]
    ],
    'mcms\promo\components\events\DomainBanned' => [
      'header' => [
        'ru' => '{projectName} - Домен {domain.url} заблокирован.',
        'en' => '{projectName} - Domain {domain.url} blocked.',
      ],
      'template' => [
        'ru' => '<p><strong>Здравствуйте {owner.username}!</strong><br>' .
            '<strong>Домен {domain.url} заблокирован, просьба перевести трафик на активные домены, чтобы избежать потери трафика!</strong></p>' .
            '<p><strong>С уважением, команда <strong>{projectName}.</strong></p>',
        'en' => '<p><strong>Greetings {owner.username}!</strong><br>' .
            '<strong>Domain {domain.url} blocked. Please transfer traffic to the active domains!</strong></p>' .
            '<p><strong>Best regards, {projectName} team.</strong></p>',
      ]
    ],
  ];


  // Удаление projectName из заголовка браузерного уведомления
  private $browserNotifications = [
    'mcms\support\components\events\EventMessageReceived' => [
      'header' => [
        'ru' => 'Вам пришло новое сообщение.',
        'en' => 'You have a new message.',
      ],
    ],
  ];


  public function up()
  {
    foreach ($this->emailNotifications as $event => $text)
    {
      /** @var Notification $notification */
      $notification = Notification::findOne([
        'event' => $event,
        'notification_type' => Notification::NOTIFICATION_TYPE_EMAIL,
      ]);
      $notification->header  = $text['header'];
      $notification->template = $text['template'];
      $notification->save(false);
    }

    foreach ($this->browserNotifications as $event => $text)
    {
      /** @var Notification $notification */
      $notification = Notification::findOne([
        'event' => $event,
        'notification_type' => Notification::NOTIFICATION_TYPE_BROWSER
      ]);
      $notification->header  = $text['header'];
      $notification->save(false);
    }
  }

  public function down()
  {

  }

}
