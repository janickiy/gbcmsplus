<?php

use mcms\notifications\models\Notification;
use console\components\Migration;

class m160404_140229_update_notifications extends Migration
{
  public function up()
  {
    $moduleApiResult = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => 'promo'])
      ->getResult();
    $modulePromoId = $moduleApiResult->id;

    $notifications = [
      [
        'event' => mcms\promo\components\events\LandingCreated::className(),
        'data' => [
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'header' => [
            'ru' => 'Добавлен новый лендинг',
            'en' => 'New landing',
          ],
          'template' => [
            'ru' => '<strong>Уважаемый {owner.username}!</strong><br>
<p>Добавлен новый лендинг:<br>{landing.id}. {landing.name}<br>Спешите снимать сливки!
</p><strong>С уважением, команда {projectName}.</strong>',
            'en' => "<strong>Greetings, {owner.username}!</strong><br/><p>New landing:<br>{landing.id}. {landing.name}<br></p><strong>Best regards, command of {projectName}.</strong>",
          ],
          'use_owner' => 0,
          'roles' => ['partner']
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingListCreated::className(),
        'data' => [
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'header' => [
            'ru' => 'Добавлены новые лендинги',
            'en' => 'New landings',
          ],
          'template' => [
            'ru' => "<strong>Уважаемый {owner.username}!</strong><br/><p>Добавлены новые лендинги:<br>{landings}<br>Спешите снимать сливки!</p><strong>С уважением, команда {projectName}.</strong>",
            'en' => "<strong>Greetings, {owner.username}!</strong><br/><p>New landings:<br>{landings}<br></p><strong>Best regards, command of {projectName}.</strong>",
          ],
          'use_owner' => 0,
          'roles' => ['partner']
        ]
      ],
      [
        'event' => mcms\promo\components\events\DisabledLandingsListReplace::className(),
        'data' => [
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'header' => [
            'ru' => 'Лендинги были отключены',
            'en' => 'Landings has been disabled',
          ],
          'template' => [
            'ru' => "<strong>Уважаемый {owner.username}!</strong><br/><p>Лендинги:<br>{landings}<br>были отключены.<br/>Трафик автоматически переведен на лендинги из тех же категорий.</p><strong>С уважением, команда {projectName}.</strong>",
            'en' => "<strong>Greetings, {owner.username}!</strong><br/><p>Landings:<br>{landings}<br>has been disabled<br/>Traffic is automatically transferred to the Landing of the same category.</p><strong>Best regards, command of {projectName}.</strong>",
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\DisabledLandingsListReplace::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_BROWSER,
          'header' => [
            'ru' => 'Лендинги были отключены',
            'en' => 'Landings has been disabled',
          ],
          'template' => [
            'ru' => "Лендинги:<br>{landings}<br>были отключены.<br/>Трафик автоматически переведен на лендинги из тех же категорий.",
            'en' => "Landings:<br>{landings}<br>has been disabled<br/>Traffic is automatically transferred to the Landing of the same category.",
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\DisabledLandingsListReplaceFail::className(),
        'data' => [
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'header' => [
            'ru' => 'Лендинги были отключены',
            'en' => 'Landings has been disabled',
          ],
          'template' => [
            'ru' => "<strong>Уважаемый {owner.username}!</strong><br/><p>Лендинги:<br>{landings}<br>были отключены.<br/>Лендинги для перевода трафика не найдены. Пожалуйста поменяйте лендинги вручную или остановите трафик!</p><strong>С уважением, команда {projectName}.</strong>",
            'en' => "<strong>Greetings, {owner.username}!</strong><br/><p>Landings:<br>{landings}<br>has been disabled<br/>Landings is not found for the transfer of traffic. Please change manually Landings or stop traffic!</p><strong>Best regards, command of {projectName}.</strong>",
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\DisabledLandingsListReplaceFail::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_BROWSER,
          'header' => [
            'ru' => 'Лендинги были отключены',
            'en' => 'Landings has been disabled',
          ],
          'template' => [
            'ru' => "Лендинги:<br>{landings}<br>были отключены.<br/>Лендинги для перевода трафика не найдены. Пожалуйста поменяйте лендинги вручную или остановите трафик!",
            'en' => "Landings:<br>{landings}<br>has been disabled<br/>Landings is not found for the transfer of traffic. Please change manually Landings or stop traffic!",
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\DisabledLandingsReplace::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_BROWSER,
          'header' => [
            'ru' => 'Лендинг #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) был отключен.',
            'en' => 'Landing #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) has been disabled',
          ],
          'template' => [
            'ru' => 'Трафик автоматически переведен на лендинги из той же категории.',
            'en' => 'Traffic is automatically transferred to the Landing of the same category.'
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\DisabledLandingsReplace::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'header' => [
            'ru' => 'Лендинг #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) был отключен.',
            'en' => 'Landing #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) has been disabled',
          ],
          'template' => [
            'ru' => '<strong>Уважаемый {user.username}!</strong><br/><p>Трафик автоматически переведен на лендинги из той же категории.</p><strong>С уважением, команда {projectName}.</strong>',
            'en' => '<strong>Greetings, {user.username}!</strong><br/><p>Traffic is automatically transferred to the Landing of the same category.</p><strong>Best regards, command of {projectName}.</strong>'
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\DisabledLandingsReplaceFail::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'header' => [
            'ru' => 'Лендинг #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) был отключен.',
            'en' => 'Landing #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) has been disabled',
          ],
          'template' => [
            'ru' => '<strong>Уважаемый {user.username}!</strong><br/><p>Лендинг для перевода трафика не найден. Пожалуйста поменяйте лендинг вручную или остановите трафик!</p><strong>С уважением, команда {projectName}.</strong>',
            'en' => '<strong>Greetings, {user.username}!</strong><br/><p>Landing is not found for the transfer of traffic. Please change manually Landing or stop traffic!</p><strong>Best regards, command of {projectName}.</strong>'
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\DisabledLandingsReplaceFail::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_BROWSER,
          'header' => [
            'ru' => 'Лендинг #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) был отключен.',
            'en' => 'Landing #{landingFrom.id} {landingFrom.name} - {landingFrom.operatorNames} ({landingFrom.countryCodes}) has been disabled',
          ],
          'template' => [
            'ru' => 'Лендинг для перевода трафика не найден. Пожалуйста поменяйте лендинг вручную или остановите трафик!',
            'en' => 'Landing is not found for the transfer of traffic. Please change manually Landing or stop traffic!'
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\SourceRejected::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'header' => [
            'ru' => '{projectName} - Источник #{source.id} {source.name} заблокирован.',
            'en' => '{projectName} - Source #{source.id} {source.name} rejected.',
          ],
          'template' => [
            'ru' => '<strong>Здравствуйте {owner.username}!</strong><br><p>Ваш источник #{source.id} #{source.name} заблокирован.<br>Причина: {source.reject_reason}</p><strong>С уважением, команда {projectName}.</strong>',
            'en' => '<strong>Greetings {owner.username}!</strong><br><p>Your source #{source.id} #{source.name} rejected.<br>Reason: {source.reject_reason}</p><p><strong>Best regards, {projectName} team.</strong></p>'
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\SourceActivated::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'header' => [
            'ru' => '{projectName} - Источник #{source.id} {source.name} активирован.',
            'en' => '{projectName} - Source #{source.id} {source.name} activated.',
          ],
          'template' => [
            'ru' => '<strong>Здравствуйте {owner.username}!</strong><p>Ваш источник  #{source.id} {source.name} успешно активирован.</p><p>Желаем успехов в работе и отличного профита!<br><strong>С уважением, команда {projectName}.</strong></p>',
            'en' => '<strong>Greetings {owner.username}!</strong><p>Your source  #{source.id} {source.name} successfully activated.</p><p>We wish you success in your work and a great profit!<br><strong>Best regards, {projectName} team.</strong></p>'
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\LinkRejected::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'header' => [
            'ru' => '{projectName} - Ссылка #{source.id} {source.name} заблокирована.',
            'en' => '{projectName} - Link #{source.id} {source.name} rejected.',
          ],
          'template' => [
            'ru' => '<strong>Здравствуйте {owner.username}!</strong><p>Ваша ссылка #{source.id} #{source.name} заблокирована.</p><p>Причина: {source.reject_reason}</p><p><strong>С уважением, команда {projectName}.</strong></p>',
            'en' => '<strong>Greetings {owner.username}!</strong><p>Your link #{source.id} #{source.name} rejected.</p><p>Reason: {source.reject_reason}</p><p><strong>Best regards, {projectName} team.</strong></p>'
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\LinkActivated::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'header' => [
            'ru' => '{projectName} - Ссылка #{source.id} {source.name} активирована.',
            'en' => '{projectName} - Link #{source.id} {source.name} activated.',
          ],
          'template' => [
            'ru' => '<strong>Здравствуйте {owner.username}!</strong><p>Ваша ссылка  #{source.id} {source.name} успешно активирована.</p><p>Желаем успехов в работе и отличного профита!<br><strong>С уважением, команда <strong>{projectName}.</strong></strong></p>',
            'en' => '<strong>Greetings {owner.username}!</strong><p>Your link  #{source.id} {source.name} successfully activated.</p><p>We wish you success in your work and a great profit!<br><strong>Best regards, {projectName} team.</strong></p>'
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingDisabled::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'header' => [
            'ru' => '{projectName} - Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} заблокирован.',
            'en' => '{projectName} - Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} blocked.',
          ],
          'template' => [
            'ru' => '<strong>Здравствуйте {owner.username}!</strong><p>Запрос к лендингу #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} заблокирован.</p><p><strong>С уважением, команда {projectName}.</strong></p>',
            'en' => '<strong>Greetings {owner.username}!</strong><p>Landing unblock request #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} blocked.</p><p><strong>Best regards, {projectName} team.</strong></p>'
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingUnlocked::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'header' => [
            'ru' => '{projectName} - Лендинг #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} активирован.',
            'en' => '{projectName} - Landing #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} activated.',
          ],
          'template' => [
            'ru' => '<strong>Здравствуйте {owner.username}!</strong><p>Запрос к лендингу #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} успешно активирован.</p><p>Желаем успехов в работе и отличного профита!<br><strong>С уважением, команда {projectName}</strong></p>',
            'en' => '<strong>Greetings {owner.username}!</strong><p>Landing unblock request #{landingUnblockRequest.landing.id} {landingUnblockRequest.landing.name} successfully activated.</p><p>We wish you success in your work and a great profit!<br><strong>Best regards, {projectName} team.</strong></p>'
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\SystemDomainBanned::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'header' => [
            'ru' => '{projectName} - Домен {domain.url} заблокирован.',
            'en' => '{projectName} - Domain {domain.url} blocked.',
          ],
          'template' => [
            'ru' => '<strong>Здравствуйте {owner.username}!</strong><p>Домен {domain.url} заблокирован, просьба перевести трафик на активные домены, чтобы избежать потери трафика!</p><p><strong>С уважением, команда {projectName}.</strong></p>',
            'en' => '<strong>Greetings {owner.username}!</strong><p>Domain {domain.url} blocked. Please transfer traffic to the active domains!</p><p><strong>Best regards, {projectName} team.</strong></p>'
          ],
          'roles' => ['partner'],
        ]
      ],
      [
        'event' => mcms\promo\components\events\DomainBanned::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'header' => [
            'ru' => '{projectName} - Домен {domain.url} заблокирован.',
            'en' => '{projectName} - Domain {domain.url} blocked.',
          ],
          'template' => [
            'ru' => '<strong>Здравствуйте {owner.username}!</strong><p>Домен {domain.url} заблокирован, просьба перевести трафик на активные домены, чтобы избежать потери трафика!</p><p><strong>С уважением, команда <strong>{projectName}.</strong></strong></p>',
            'en' => '<strong>Greetings {owner.username}!</strong><p>Domain {domain.url} blocked. Please transfer traffic to the active domains!</p><p><strong>Best regards, {projectName} team.</strong></p>'
          ],
          'use_owner' => 1,
        ]
      ],
      [
        'event' => mcms\promo\components\events\DomainBanned::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'header' => [
            'ru' => '{projectName} - Домен {domain.url} заблокирован.',
            'en' => '{projectName} - Domain {domain.url} blocked.',
          ],
          'template' => [
            'ru' => '<strong>Здравствуйте {owner.username}!</strong><p>Домен {domain.url} заблокирован, просьба перевести трафик на активные домены, чтобы избежать потери трафика!</p><p><strong>С уважением, команда {projectName}.</strong></p>',
            'en' => '<strong>Greetings {owner.username}!</strong><p>Domain {domain.url} blocked. Please transfer traffic to the active domains!</p><p><strong>Best regards, {projectName} team.</strong></p>'
          ],
          'use_owner' => 1,
        ]
      ],
    ];

    foreach ($notifications as $notification) {

      $notificationData = \yii\helpers\ArrayHelper::getValue($notification, 'data', []);
      $notificationType = \yii\helpers\ArrayHelper::getValue($notificationData, 'type');
      $notificationModel = $notification['event'] ? Notification::findOne([
        'event' => $notification['event'],
        'notification_type' => $notificationType,
      ]) : null;

      if (!$notificationModel) {
        $notificationModel = new Notification();
      }

      $notificationModel->setAttributes($notificationData, false);
      $notificationModel->event = $notification['event'];
      $notificationModel->notification_type = $notificationType;
      $notificationModel->use_owner = \yii\helpers\ArrayHelper::getValue($notificationData, 'use_owner', 0);
      $notificationModel->roles = \yii\helpers\ArrayHelper::getValue($notificationData, 'roles');
      $notificationModel->module_id = $modulePromoId;

      $notificationModel->save(false);
    }
  }

  public function down()
  {
    echo "m160404_140229_update_notifications cannot be reverted.\n";
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
