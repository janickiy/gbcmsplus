<?php

use console\components\Migration;

class m170525_054606_delivery_test_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission(
      'NotificationsDeliveryTest',
      'Просмотр истории рассылки любых пользователей',
      'NotificationsDeliveryController',
      ['root', 'admin', 'reseller', 'manager']
    );
  }

  public function down()
  {
    $this->removePermission('NotificationsDeliveryTest');
  }
}
