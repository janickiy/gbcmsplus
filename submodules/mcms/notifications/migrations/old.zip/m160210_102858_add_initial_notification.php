<?php

use console\components\Migration;

class m160210_102858_add_initial_notification extends Migration
{

  public function up()
  {

  }

  public function down()
  {

  }
}
