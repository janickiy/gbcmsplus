<?php

use console\components\Migration;

class m180420_103351_holds_tables extends Migration
{
  const HP_TABLE = 'hold_programs';
  const HPR_TABLE = 'hold_program_rules';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::HP_TABLE, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string()->notNull(),
      'description' => $this->text()->notNull()->defaultValue(''),
      'is_default' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => $this->integer(10)->unsigned()->notNull(),
      'updated_at' => $this->integer(10)->unsigned()->notNull(),

    ], $tableOptions);

    $this->createTable(self::HPR_TABLE, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'hold_program_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'country_id' => 'MEDIUMINT(5) UNSIGNED',

      'unhold_range' => 'MEDIUMINT(5) UNSIGNED NOT NULL COMMENT \'кол-во полных дней|недель|месяцев сколько расхолдиваем\'',
      'unhold_range_type' => 'TINYINT(1) UNSIGNED NOT NULL COMMENT \'тип unhold_range (дней=1|недель=2|месяцев=3)\'',

      'min_hold_range' => 'MEDIUMINT(5) UNSIGNED NOT NULL COMMENT \'через сколько минимум дней|недель|месяцев расхолдиваем\'',
      'min_hold_range_type' => 'TINYINT(1) UNSIGNED NOT NULL COMMENT \'тип min_hold_range (дней=1|недель=2|месяцев=3)\'',

      'at_day' => 'MEDIUMINT(5) UNSIGNED COMMENT \'в какой день (недели|месяца) расхолд\'',
      'at_day_type' => 'TINYINT(1) UNSIGNED COMMENT \'тип at_day (день недели=1|день месяца=2)\'',
      'key_date' => $this->date()->notNull(),
      'created_at' => $this->integer(10)->unsigned()->notNull(),
      'updated_at' => $this->integer(10)->unsigned()->notNull(),
    ], $tableOptions);
    $this->addForeignKey(self::HPR_TABLE . '_hold_program_id_fk', self::HPR_TABLE, 'hold_program_id', self::HP_TABLE, 'id', 'CASCADE', 'CASCADE');

    $this->addColumn('user_payment_settings', 'hold_program_id', 'MEDIUMINT(5) UNSIGNED');
  }

  public function down()
  {
    $this->dropTable(self::HPR_TABLE);
    $this->dropTable(self::HP_TABLE);
    $this->dropColumn('user_payment_settings', 'hold_program_id');
  }
}
