<?php

use console\components\Migration;

class m180428_121853_last_unhold_show_permission extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('CanViewLastUnholdDate', 'Разрешение видеть дату последнего расхолда', 'HoldsModule', ['root']);
  }

  public function down()
  {
    $this->removePermission('CanViewLastUnholdDate');
  }
}
