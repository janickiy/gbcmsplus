<?php

use console\components\Migration;

class m180503_073721_add_fields extends Migration
{
  public function up()
  {
    $this->addColumn('partner_country_unhold', 'last_checked_at', 'int unsigned not null');
    $this->addColumn('partner_country_unhold', 'last_updated_at', 'int unsigned not null');
  }

  public function down()
  {
    $this->dropColumn('partner_country_unhold', 'last_checked_at');
    $this->dropColumn('partner_country_unhold', 'last_updated_at');
  }
}
