<?php

use console\components\Migration;

class m180420_120846_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;
  public function up()
  {
    $this->createPermission('HoldsModule', 'Модуль партнерских холдов');
    $this->createPermission('HoldsPartnerHoldRulesController', 'Контроллер PartnerHoldRules', 'HoldsModule', ['root', 'admin']);
    $this->createPermission('HoldsPartnerHoldRulesIndex', 'Список наборов правил холдов', 'HoldsPartnerHoldRulesController');
    $this->createPermission('HoldsPartnerHoldRulesUpdate', 'Редактирование набора правил холдов', 'HoldsPartnerHoldRulesController');
    $this->createPermission('HoldsPartnerHoldRulesCreateModal', 'Создание набора правил холдов', 'HoldsPartnerHoldRulesController');
    $this->createPermission('HoldsPartnerHoldRulesDelete', 'Удаление набора правил холдов', 'HoldsPartnerHoldRulesController');
    $this->createPermission('HoldsPartnerHoldRulesLinkPartner', 'Добавление партнера к набору правил холдов', 'HoldsPartnerHoldRulesController');
    $this->createPermission('HoldsPartnerHoldRulesUnlinkPartner', 'Удаление партнера из набора правил холдов', 'HoldsPartnerHoldRulesController');

    $this->createPermission('HoldsPartnerHoldRuleItemsController', 'Контроллер PartnerHoldRuleItems', 'HoldsModule', ['root', 'admin']);
    $this->createPermission('HoldsPartnerHoldRuleItemsUpdateModal', 'Редактирование правила холдов', 'HoldsPartnerHoldRulesController');
    $this->createPermission('HoldsPartnerHoldRuleItemsCreateModal', 'Создание правила холдов', 'HoldsPartnerHoldRulesController');
    $this->createPermission('HoldsPartnerHoldRuleItemsDelete', 'Удаление правила холдов', 'HoldsPartnerHoldRulesController');
  }

  public function down()
  {
    $this->removePermission('HoldsPartnerHoldRuleItemsDelete');
    $this->removePermission('HoldsPartnerHoldRuleItemsUpdateModal');
    $this->removePermission('HoldsPartnerHoldRuleItemsCreateModal');
    $this->removePermission('HoldsPartnerHoldRuleItemsController');

    $this->removePermission('HoldsPartnerHoldRulesLinkPartner');
    $this->removePermission('HoldsPartnerHoldRulesUnlinkPartner');
    $this->removePermission('HoldsPartnerHoldRulesDelete');
    $this->removePermission('HoldsPartnerHoldRulesCreateModal');
    $this->removePermission('HoldsPartnerHoldRulesUpdate');
    $this->removePermission('HoldsPartnerHoldRulesIndex');
    $this->removePermission('HoldsPartnerHoldRulesController');
    $this->removePermission('HoldsModule');
  }
}
