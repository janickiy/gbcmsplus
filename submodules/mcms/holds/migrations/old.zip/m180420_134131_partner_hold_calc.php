<?php

use console\components\Migration;

class m180420_134131_partner_hold_calc extends Migration
{
  public function up()
  {
    $this->addColumn('user_balance_invoices', 'country_id', 'MEDIUMINT(5) NOT NULL DEFAULT 0 AFTER user_id');

    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable('rule_unhold_plan', [
      'rule_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'date_from' => 'DATE NOT NULL',
      'date_to' => 'DATE NOT NULL',
      'unhold_date' => 'DATE NOT NULL',
      'meta' => 'TEXT NOT NULL',
    ], $tableOptions);

    $this->addPrimaryKey('rule_unhold_plan_pk', 'rule_unhold_plan', ['rule_id', 'date_from']);

    $this->addForeignKey('rule_unhold_plan_rule_id_fk', 'rule_unhold_plan', 'rule_id', 'hold_program_rules', 'id', 'CASCADE', 'NO ACTION');

    $this->createTable('partner_country_unhold', [
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'last_unhold_date' => 'DATE NOT NULL',
      'meta' => 'TEXT NOT NULL',
    ], $tableOptions);
    $this->addPrimaryKey('partner_country_unhold_pk', 'partner_country_unhold', ['user_id', 'country_id']);

  }

  public function down()
  {
    $this->dropForeignKey('rule_unhold_plan_rule_id_fk', 'rule_unhold_plan');
    $this->dropTable('partner_country_unhold');
    $this->dropTable('rule_unhold_plan');
    $this->dropColumn('user_balance_invoices', 'country_id');
  }
}
