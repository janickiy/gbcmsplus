<?php

use console\components\Migration;

class m180420_080611_holds_module extends Migration
{
  const TABLE = 'modules';
  public function up()
  {
    $time = time();
    $this->insert(self::TABLE, [
      'module_id' => 'holds',
      'name' => 'holds.main.module_name',
      'created_at' => $time,
      'updated_at' => $time,
    ]);
  }

  public function down()
  {
    $this->delete(self::TABLE, ['module_id' => 'holds']);
  }
}
