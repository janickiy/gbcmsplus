<?php

use console\components\Migration;

class m151223_111236_pay_n_sub_types extends Migration
{

  const SUB = 'landing_subscription_types';
  const PAY = 'landing_pay_types';

  public function up()
  {
    $this->delete(self::SUB);
    $this->delete(self::PAY);

    $this->addColumn(self::PAY, 'code', $this->string(100)->notNull() . ' AFTER id');

    $this->insert(self::PAY, ['code' => 'mt', 'name' => 'МТ (Pin Submit)', 'status' => 1, 'created_at' => time()]);
    $this->insert(self::PAY, ['code' => 'mo', 'name' => 'MO (SMS Flow)', 'status' => 1, 'created_at' => time()]);
    $this->insert(self::PAY, ['code' => '3g', 'name' => '3G (1Click, DCB)', 'status' => 1, 'created_at' => time()]);


    $this->insert(self::SUB, ['name' => 'One-Time', 'status' => 1, 'created_at' => time()]);
    $this->insert(self::SUB, ['name' => 'Subscription', 'status' => 1, 'created_at' => time()]);

    $this->dropTable('landing_operator_subscription_types');

    $this->dropForeignKey('landing_operators_pay_type_id_fk', 'landing_operators');
    $this->dropColumn('landing_operators', 'pay_type_id');

    $this->addColumn('landing_operators', 'subscription_type_id', 'tinyint(1) unsigned');
    $this->addForeignKey(
      'landing_operators_subscription_type_id_fk',
      'landing_operators',
      'subscription_type_id',
      'landing_subscription_types',
      'id'
    );

    $this->createTable('landing_operator_pay_types', [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL'
    ]);
    $this->addForeignKey(
      'landing_operator_pay_types' . '_' . 'landing_id' . '_fk',
      'landing_operator_pay_types',
      'landing_id',
      \mcms\promo\models\Landing::tableName(),
      'id'
    );
    $this->addForeignKey(
      'landing_operator_pay_types' . '_' . 'operator_id' . '_fk',
      'landing_operator_pay_types',
      'operator_id',
      \mcms\promo\models\Operator::tableName(),
      'id'
    );
    $this->addForeignKey(
      'landing_operator_pay_types' . '_' . 'landing_pay_type_id' . '_fk',
      'landing_operator_pay_types',
      'landing_pay_type_id',
      self::PAY,
      'id'
    );


  }

  public function down()
  {
    $this->dropColumn(self::PAY, 'code');
  }
}
