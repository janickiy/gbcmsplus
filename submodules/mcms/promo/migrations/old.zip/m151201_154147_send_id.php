<?php

use console\components\Migration;

class m151201_154147_send_id extends Migration
{

  const TABLE = 'landings';

  public function safeUp()
  {
    $this->addColumn(self::TABLE, 'send_id', $this->string(64));
  }

  public function safeDown()
  {
    $this->dropColumn(self::TABLE, 'send_id');
  }
}
