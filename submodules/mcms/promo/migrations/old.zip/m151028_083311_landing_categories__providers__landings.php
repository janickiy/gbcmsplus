<?php

use console\components\Migration;

class m151028_083311_landing_categories__providers__landings extends Migration
{

  protected $landingCategoriesTable = '{{%landing_categories}}';
  protected $providersTable = '{{%providers}}';
  protected $landingsTable = '{{%landings}}';

  public function safeUp()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    /*
     * LANDING CATEGORIES
     */
    $this->createTable($this->landingCategoriesTable, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string(50)->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex('landing_categories_status_index', $this->landingCategoriesTable, 'status');
    $this->addForeignKey('landing_categories_created_by_fk', $this->landingCategoriesTable, 'created_by', '{{%users}}', 'id');


    /*
     * PROVIDERS
     */
    $this->createTable($this->providersTable, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string(100)->notNull(),
      'code' => $this->string(10)->notNull(),
      'url' => $this->string()->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'redirect_to' => 'MEDIUMINT(5) UNSIGNED',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex('providers_status_index', $this->providersTable, 'status');
    $this->createIndex('providers_code_index', $this->providersTable, 'code', true);
    $this->addForeignKey('providers_created_by_fk', $this->providersTable, 'created_by', '{{%users}}', 'id');
    $this->addForeignKey('providers_redirect_to_fk', $this->providersTable, 'redirect_to', $this->providersTable, 'id');


    /*
     * LANDINGS
     */
    $this->createTable($this->landingsTable, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string()->notNull(),
      'category_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'provider_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'image_src' => $this->string(1000)->notNull(),
      'access_type' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'description' => $this->text(),
      'rating' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'auto_rating' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex('landings' . '_' . 'access_type' . '_index', $this->landingsTable, 'access_type');
    $this->createIndex('landings' . '_' . 'status' . '_index', $this->landingsTable, 'status');
    $this->createIndex('landings' . '_' . 'rating' . '_index', $this->landingsTable, 'rating');
    $this->createIndex('landings' . '_' . 'auto_rating' . '_index', $this->landingsTable, 'auto_rating');

    $this->addForeignKey('landings' . '_' . 'category_id' . '_fk', $this->landingsTable, 'category_id', $this->landingCategoriesTable, 'id');
    $this->addForeignKey('landings' . '_' . 'provider_id' . '_fk', $this->landingsTable, 'provider_id', $this->providersTable, 'id');
    $this->addForeignKey('landings' . '_' . 'created_by' . '_fk', $this->landingsTable, 'created_by', '{{%users}}', 'id');

  }

  public function safeDown()
  {
    $this->dropTable($this->landingsTable);
    $this->dropTable($this->providersTable);
    $this->dropTable($this->landingCategoriesTable);
  }

}
