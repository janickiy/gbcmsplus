<?php

use yii\db\Schema;
use console\components\Migration;

class m160218_155327_source_field_ads_network_id extends Migration
{

  protected $sourceTable = 'sources';

  public function up()
  {
    $this->addColumn($this->sourceTable, 'ads_network_id', 'MEDIUMINT(5) UNSIGNED NULL');
  }

  public function down()
  {
    $this->dropColumn($this->sourceTable, 'ads_network_id');
  }

}
