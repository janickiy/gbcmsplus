<?php

use console\components\Migration;

class m160524_143852_category_source_banner_relations extends Migration
{
  public function up()
  {
    $this->addColumn(
      \mcms\promo\models\LandingCategory::tableName(),
      'banner_id',
      'MEDIUMINT(5) UNSIGNED'
    );

    $this->addForeignKey(
      'landing_categories_banner_id_fk',
      \mcms\promo\models\LandingCategory::tableName(),
      'banner_id',
      'banners',
      'id',
      'SET NULL',
      'CASCADE'
    );

    $this->addColumn(
      \mcms\promo\models\Source::tableName(),
      'banner_id',
      'MEDIUMINT(5) UNSIGNED'
    );

    $this->addForeignKey(
      'sources_banner_id_fk',
      \mcms\promo\models\Source::tableName(),
      'banner_id',
      'banners',
      'id',
      'SET NULL',
      'CASCADE'
    );
  }

  public function down()
  {
    $this->dropForeignKey('sources_banner_id_fk', \mcms\promo\models\Source::tableName());
    $this->dropForeignKey('landing_categories_banner_id_fk', \mcms\promo\models\LandingCategory::tableName());

    $this->dropColumn(\mcms\promo\models\LandingCategory::tableName(), 'banner_id');
    $this->dropColumn(\mcms\promo\models\Source::tableName(), 'banner_id');
  }
}
