<?php

use console\components\Migration;

class m180529_145617_percent_precision_2 extends Migration
{
  public function up()
  {
    echo 'partner_program_items...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE partner_program_items
        CHANGE rebill_percent rebill_percent     decimal(5, 2)         null,
        CHANGE buyout_percent buyout_percent     decimal(5, 2)         null,
        CHANGE cpa_profit_rub cpa_profit_rub     decimal(7, 3)         null,
        CHANGE cpa_profit_eur cpa_profit_eur     decimal(7, 3)         null,
        CHANGE cpa_profit_usd cpa_profit_usd     decimal(7, 3)         null
      ')->execute();

    echo 'personal_profit...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE personal_profit
      CHANGE rebill_percent rebill_percent decimal(5, 2)                     null,
      CHANGE buyout_percent buyout_percent decimal(5, 2)                     null,
      CHANGE cpa_profit_rub cpa_profit_rub decimal(7, 3)                     null,
      CHANGE cpa_profit_usd cpa_profit_usd decimal(7, 3)                     null,
      CHANGE cpa_profit_eur cpa_profit_eur decimal(7, 3)                     null
      ')->execute();
  }

  public function down()
  {
    echo 'personal_profit...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE personal_profit
      CHANGE rebill_percent rebill_percent decimal(6, 3)                     null,
      CHANGE buyout_percent buyout_percent decimal(6, 3)                     null,
      CHANGE cpa_profit_rub cpa_profit_rub decimal(6, 3)                     null,
      CHANGE cpa_profit_usd cpa_profit_usd decimal(6, 3)                     null,
      CHANGE cpa_profit_eur cpa_profit_eur decimal(6, 3)                     null
      ')->execute();

    echo 'partner_program_items...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE partner_program_items
      CHANGE rebill_percent rebill_percent     decimal(6, 3)         null,
      CHANGE buyout_percent buyout_percent     decimal(6, 3)         null,
      CHANGE cpa_profit_rub cpa_profit_rub     decimal(6, 3)         null,
      CHANGE cpa_profit_eur cpa_profit_eur     decimal(6, 3)         null,
      CHANGE cpa_profit_usd cpa_profit_usd     decimal(6, 3)         null
      ')->execute();
  }
}
