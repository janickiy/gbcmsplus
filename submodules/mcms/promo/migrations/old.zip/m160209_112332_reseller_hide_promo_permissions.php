<?php

use yii\db\Schema;
use console\components\Migration;

class m160209_112332_reseller_hide_promo_permissions extends Migration
{

  use \mcms\common\traits\PermissionMigration;


  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $resellerCanHidePromoPermissionName = mcms\promo\Module::PERMISSION_CAN_RESELLER_HIDE_PROMO;
    $partnerCanViewPromoPermissionName = mcms\promo\Module::PERMISSION_CAN_PARTNER_VIEW_PROMO;

    $this->createOrGetPermission($resellerCanHidePromoPermissionName, 'Can reseller hide promo');
    $this->createOrGetPermission($partnerCanViewPromoPermissionName, 'Can partner view promo');
  }

  public function down()
  {
    $resellerCanHidePromoPermissionName = mcms\promo\Module::PERMISSION_CAN_RESELLER_HIDE_PROMO;
    $partnerCanViewPromoPermissionName = mcms\promo\Module::PERMISSION_CAN_PARTNER_VIEW_PROMO;

    $this->removePermission($resellerCanHidePromoPermissionName);
    $this->removePermission($partnerCanViewPromoPermissionName);
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
