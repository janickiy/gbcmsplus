<?php

use console\components\Migration;

class m161028_123831_landing_sets_sync_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;
  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->moduleName = 'Promo';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'WebmasterSources' => [
        ['landing-sets-sync', 'Can synchronize the sets of landings in webmaster sources', ['root', 'admin', 'reseller']],
        ['landing-sets-delete', 'Can delete the sets of landings in webmaster sources', ['root', 'admin', 'reseller']],
      ],
    ];
  }
}
