<?php

use console\components\Migration;

class m180629_110820_new_countries_ni_gt extends Migration
{
  public function up()
  {
    $currentValues = [
      ['name' => 'Nicaragua', 'code' => 'ni', 'currency' => 'eur', 'id' => 120],
      ['name' => 'Guatemala', 'code' => 'gt', 'currency' => 'eur', 'id' => 121],
    ];
    foreach ($currentValues as $currentValue) {
      $this->db->createCommand('
          INSERT INTO countries (id, name, status, code, currency, created_at)
          VALUES (:id, :name, :status, :code, :currency, :created_at)
          ON DUPLICATE KEY UPDATE currency=VALUES(currency)', [
        ':id' => $currentValue['id'],
        ':name' => $currentValue['name'],
        ':status' => 0,
        ':code' => $currentValue['code'],
        ':currency' => $currentValue['currency'],
        ':created_at' => time(),
      ])->execute();
    }
  }

  public function down()
  {
    echo "m180629_110820_new_countries_ni_gt cannot be reverted.\n";

    return true;
  }
}
