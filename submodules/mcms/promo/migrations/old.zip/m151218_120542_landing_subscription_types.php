<?php

use console\components\Migration;

class m151218_120542_landing_subscription_types extends Migration
{
  protected $subscriptionTypes = 'landing_subscription_types';
  protected $landingOperatorSubscriptionTypes = 'landing_operator_subscription_types';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable($this->subscriptionTypes, [
      'id' => 'TINYINT(1) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string(100)->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex($this->subscriptionTypes . '_status_index', $this->subscriptionTypes, 'status');

    $this->insert($this->subscriptionTypes, ['name' => 'МТ (Pin Submit)', 'status' => 1, 'created_at' => time()]);
    $this->insert($this->subscriptionTypes, ['name' => 'MO (SMS Flow)', 'status' => 1, 'created_at' => time()]);
    $this->insert($this->subscriptionTypes, ['name' => '3G (1Click, DCB)', 'status' => 1, 'created_at' => time()]);


    $this->createTable($this->landingOperatorSubscriptionTypes, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'landing_subscription_type_id' => 'TINYINT(1) UNSIGNED NOT NULL'
    ]);
    $this->addForeignKey($this->landingOperatorSubscriptionTypes . '_' . 'landing_id' . '_fk', $this->landingOperatorSubscriptionTypes, 'landing_id', \mcms\promo\models\Landing::tableName(), 'id');
    $this->addForeignKey($this->landingOperatorSubscriptionTypes . '_' . 'operator_id' . '_fk', $this->landingOperatorSubscriptionTypes, 'operator_id', \mcms\promo\models\Operator::tableName(), 'id');
    $this->addForeignKey($this->landingOperatorSubscriptionTypes . '_' . 'id' . '_fk', $this->landingOperatorSubscriptionTypes, 'landing_subscription_type_id', $this->subscriptionTypes, 'id');

  }

  public function down()
  {

    $this->dropForeignKey($this->landingOperatorSubscriptionTypes . '_' . 'landing_id' . '_fk', $this->landingOperatorSubscriptionTypes);
    $this->dropForeignKey($this->landingOperatorSubscriptionTypes . '_' . 'operator_id' . '_fk', $this->landingOperatorSubscriptionTypes);
    $this->dropForeignKey($this->landingOperatorSubscriptionTypes . '_' . 'id' . '_fk', $this->landingOperatorSubscriptionTypes);

    $this->dropTable($this->landingOperatorSubscriptionTypes);
    $this->dropTable($this->subscriptionTypes);
  }

}
