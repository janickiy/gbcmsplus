<?php

use console\components\Migration;

class m161024_144659_landings_sets_permissions extends Migration
{
  use \mcms\common\traits\PermissionGroupMigration;

  public function init()
  {
    parent::init();

    $this->groupPermissionName = 'PromoModule';
    $this->groupPermissionDescription = 'Module Promo';
    $this->groupPermissionDefaultRole = ['admin', 'root', 'reseller'];

    $this->groupPermissionControllers = [
      'PromoLandingSetsController' => [
        'description' => 'Promo LandingSets Controller',
        'permissions' => [
          ['PromoLandingSetsIndex', ['admin', 'root', 'reseller']],
          ['PromoLandingSetsCreate', ['admin', 'root', 'reseller']],
          ['PromoLandingSetsCreateModal', ['admin', 'root', 'reseller']],
          ['PromoLandingSetsUpdate', ['admin', 'root', 'reseller']],
          ['PromoLandingSetsDelete', ['admin', 'root', 'reseller']],
        ],
      ],
    ];
  }
}