<?php

use console\components\Migration;

class m171006_093219_default_banner_id extends Migration
{
  public function up()
  {
    $this->addColumn('banners', 'is_default', 'TINYINT(1) NOT NULL DEFAULT 0');
  }

  public function down()
  {
    $this->dropColumn('banners', 'is_default');
  }
}
