<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m171026_133541_source_traffic_filters_off_permission extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PromoManageSourceTrafficFiltersOff', 'Разрешить отключать фильтры трафика для ссылок', 'PromoPermissions', ['root']);
  }

  public function down()
  {
    $this->removePermission('PromoManageSourceTrafficFiltersOff');
  }
}
