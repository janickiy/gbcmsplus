<?php

use console\components\Migration;

class m161031_145737_add_change_autosync_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;
  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->moduleName = 'Promo';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'WebmasterSources' => [
        ['landing-sets-autosync-enable', 'Can change autosynchronize param of the sets of landings in webmaster sources', ['root', 'admin', 'reseller']],
        ['landing-sets-autosync-disable', 'Can change autosynchronize param of the sets of landings in webmaster sources', ['root', 'admin', 'reseller']],

      ],
    ];
  }
}
