<?php

use console\components\Migration;

class m160427_121043_create_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->createOrGetPermission('CanLinkNotificationSend', 'Can link notification send');
    $this->createOrGetPermission('CanStreamNotificationSend', 'Can stream notification send');

    $this->assignRolesPermission('CanLinkNotificationSend', ['partner']);
    $this->assignRolesPermission('CanStreamNotificationSend', ['partner']);
  }

  public function down()
  {
    $this->revokeRolesPermission('CanLinkNotificationSend', ['partner']);
    $this->revokeRolesPermission('CanStreamNotificationSend', ['partner']);
  }
}
