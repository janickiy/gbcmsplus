<?php

use console\components\Migration;

class m170707_064437_reseller_revoke extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->removePermission('PromoIsUserEffectedByRebillConditionModerationFlag');

    $this->revokeRolesPermission('PromoCanViewRebillConditionsWidget', ['reseller']);

    $this->revokeRolesPermission('PromoRebillConditionsCreateModal', ['reseller']);
    $this->revokeRolesPermission('PromoRebillConditionsDelete', ['reseller']);
    $this->revokeRolesPermission('PromoRebillConditionsIndex', ['reseller']);
    $this->revokeRolesPermission('PromoRebillConditionsUpdateModal', ['reseller']);
  }

  public function down()
  {
    $this->assignRolesPermission('PromoRebillConditionsCreateModal', ['reseller']);
    $this->assignRolesPermission('PromoRebillConditionsDelete', ['reseller']);
    $this->assignRolesPermission('PromoRebillConditionsIndex', ['reseller']);
    $this->assignRolesPermission('PromoRebillConditionsUpdateModal', ['reseller']);

    $this->assignRolesPermission('PromoCanViewRebillConditionsWidget', ['reseller']);

    $this->createPermission('PromoIsUserEffectedByRebillConditionModerationFlag', 'Осуществляются условия ребилла', 'PromoPermissions', ['reseller']);
  }
}
