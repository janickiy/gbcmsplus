<?php

use console\components\Migration;

class m180409_094217_sources_count_hits extends Migration
{
  public function up()
  {
    $this->addColumn('sources', 'count_hits', $this->integer(10)->after('is_traffic_filters_off'));

  }

  public function down()
  {
    $this->dropColumn('sources', 'count_hits');
  }

}
