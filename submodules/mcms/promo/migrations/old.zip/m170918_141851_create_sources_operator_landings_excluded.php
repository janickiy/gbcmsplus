<?php

use console\components\Migration;

/**
 * Class m170918_141851_create_sources_operator_landings_excluded
 */
class m170918_141851_create_sources_operator_landings_excluded extends Migration
{
  /**
   * This method contains the logic to be executed when applying this migration.
   * Child classes may override this method to provide actual migration logic.
   * @return boolean return a false value to indicate the migration fails
   * and should not proceed further. All other return values mean the migration succeeds.
   */
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable('sources_operator_landings_excluded', [
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) NOT NULL',
      'rating' => 'DECIMAL(4,4) NOT NULL DEFAULT 0',
    ], $tableOptions);

    $this->addPrimaryKey(
      'sole_pk',
      'sources_operator_landings_excluded',
      ['source_id', 'landing_id', 'operator_id',]
    );
  }

  /**
   * This method contains the logic to be executed when removing this migration.
   * The default implementation throws an exception indicating the migration cannot be removed.
   * Child classes may override this method if the corresponding migrations can be removed.
   * @return boolean return a false value to indicate the migration fails
   * and should not proceed further. All other return values mean the migration succeeds.
   */
  public function down()
  {
    $this->dropTable('sources_operator_landings_excluded');
  }
}
