<?php

use console\components\Migration;

class m160331_163219_init_rebill_conditions_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'Can' => [
        ['view-rebill-conditions-widget', 'Can view rebill conditions widget', ['admin', 'root', 'reseller']],
      ],
      'RebillConditions' => [
        ['index', 'Can view grid rebill conditions', ['admin', 'root', 'reseller']],
        ['create-modal', 'Can create rebill conditions', ['admin', 'root', 'reseller']],
        ['update-modal', 'Can update rebill conditions', ['admin', 'root', 'reseller']],
        ['delete', 'Can delete rebill conditions', ['admin', 'root', 'reseller']],
      ]
    ];
  }
}