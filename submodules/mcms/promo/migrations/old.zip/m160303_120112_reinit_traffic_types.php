<?php

use mcms\promo\models\LandingForbiddenTrafficType;
use console\components\Migration;
use mcms\promo\models\TrafficType;

class m160303_120112_reinit_traffic_types extends Migration
{
  private $id = 1;

  public function init()
  {
    parent::init();
  }


  public function up()
  {
    /*
     1 => Контекстная реклама
     2 => Баннерная реклама
     3 => RichMedia
     4 => Email
     5 => Социальные сети
     6 => Teasers (Content)
     7 => Clickunder/Popunder'
     8 => Дорвеи
     9 => Контентные сайты
     10 => SMS Spam
     11 => Push Ads
    */

    // Удаляем те, которые удалятся.
    LandingForbiddenTrafficType::deleteAll(['forbidden_traffic_type_id' => [6,7,12]]);
    // Меняем старые id на новые.
    LandingForbiddenTrafficType::updateAll(['forbidden_traffic_type_id' => 6], ['forbidden_traffic_type_id' => 8]);
    LandingForbiddenTrafficType::updateAll(['forbidden_traffic_type_id' => 7], ['forbidden_traffic_type_id' => 9]);
    LandingForbiddenTrafficType::updateAll(['forbidden_traffic_type_id' => 8], ['forbidden_traffic_type_id' => 10]);
    LandingForbiddenTrafficType::updateAll(['forbidden_traffic_type_id' => 9], ['forbidden_traffic_type_id' => 11]);
    LandingForbiddenTrafficType::updateAll(['forbidden_traffic_type_id' => 10], ['forbidden_traffic_type_id' => 13]);
    LandingForbiddenTrafficType::updateAll(['forbidden_traffic_type_id' => 11], ['forbidden_traffic_type_id' => 14]);

    // Ставим по новой все.
    $this->createorUpdateTrafficType('Контекстная реклама', 'Paid Search'); // 1 => Контекстная реклама
    $this->createorUpdateTrafficType('Баннерная реклама ', 'Display'); // 2 => Баннерная реклама
    $this->createorUpdateTrafficType('RichMedia', 'RichMedia'); // 3 => RichMedia
    $this->createorUpdateTrafficType('Email', 'Email'); // 4 => Email
    $this->createorUpdateTrafficType('Социальные сети', 'Social Networks'); // 5 => Социальные сети
    $this->createorUpdateTrafficType('Teasers (Content)', 'Teasers (Content)'); // 6 => Teasers (Content)
    $this->createorUpdateTrafficType('Clickunder/Popunder', 'Clickunder/Popunder'); //  7 => Clickunder/Popunder'
    $this->createorUpdateTrafficType('Дорвеи', 'Doorways'); // 8 => Дорвеи
    $this->createorUpdateTrafficType('Контентные сайты', 'Content Sites'); // 9 => Контентные сайты
    $this->createorUpdateTrafficType('SMS спам', 'SMS Spam'); // 10 => SMS Spam
    $this->createorUpdateTrafficType('Push Ads', 'Push Ads'); // 11 => Push Ads

    // Удаляем если что-то еще есть.
    TrafficType::deleteAll(['>=', 'id', $this->id]);
  }

  public function down()
  {
    // Ставим по новой то что есть.
    $this->createorUpdateTrafficType('Контекстная реклама', 'Paid Search'); // 1
    $this->createorUpdateTrafficType('Баннерная реклама ', 'Display'); // 2
    $this->createorUpdateTrafficType('RichMedia', 'RichMedia'); // 3
    $this->createorUpdateTrafficType('Email', 'Email'); // 4
    $this->createorUpdateTrafficType('Социальные сети', 'Social Networks'); // 5
    $this->createorUpdateTrafficType('Price-Comparison', 'Price-Comparison'); // 6 -
    $this->createorUpdateTrafficType('Купоны/Промокоды', 'Coupon/Promo Codes'); // 7 -
    $this->createorUpdateTrafficType('Teasers (Content)', 'Teasers (Content)'); // 8 Новый id при up = 6
    $this->createorUpdateTrafficType('Clickunder/Popunder', 'Clickunder/Popunder'); // 9 Новый id при up = 7
    $this->createorUpdateTrafficType('Дорвеи', 'Doorways'); // 10 Новый id при up = 8
    $this->createorUpdateTrafficType('Контентные сайты', 'Content Sites'); // 11 Новый id при up = 9
    $this->createorUpdateTrafficType('Мотивированный трафик', 'Incentive'); // 12 -
    $this->createorUpdateTrafficType('SMS', 'SMS'); // 13 Новый id при up = 10
    $this->createorUpdateTrafficType('Push Ads', 'Push Ads'); // 14 Новый id при up = 11

    // Меняем старые id на новые.
    LandingForbiddenTrafficType::updateAll(['forbidden_traffic_type_id' => 14], ['forbidden_traffic_type_id' => 11]);
    LandingForbiddenTrafficType::updateAll(['forbidden_traffic_type_id' => 13], ['forbidden_traffic_type_id' => 10]);
    LandingForbiddenTrafficType::updateAll(['forbidden_traffic_type_id' => 11], ['forbidden_traffic_type_id' => 9]);
    LandingForbiddenTrafficType::updateAll(['forbidden_traffic_type_id' => 10], ['forbidden_traffic_type_id' => 8]);
    LandingForbiddenTrafficType::updateAll(['forbidden_traffic_type_id' => 9], ['forbidden_traffic_type_id' => 7]);
    LandingForbiddenTrafficType::updateAll(['forbidden_traffic_type_id' => 8], ['forbidden_traffic_type_id' => 6]);


    TrafficType::deleteAll(['>=', 'id', $this->id]);
  }

  private function createorUpdateTrafficType($ru, $en)
  {
    /** @var TrafficType|null $model */
    $model = TrafficType::findOne($this->id);
    if ($model) {
      $model->status = TrafficType::STATUS_ACTIVE;
      $model->name = ['ru' => $ru, 'en' => $en];
      $model->save();
    } else {
      (new TrafficType([
        'id' => $this->id,
        'status' => TrafficType::STATUS_ACTIVE,
        'name' => ['ru' => $ru, 'en' => $en]
      ]))->save();
    }
    $this->id++;
  }
}
