<?php

use mcms\promo\components\ApiHandlersHelper;
use console\components\Migration;
use mcms\common\helpers\Console;

class m160527_083321_generate_all_banners extends Migration
{
  public function up()
  {
    if (!Console::confirm('Запустить перегенерацию баннеров для микросервиса?')) {
      return true;
    }

    ApiHandlersHelper::generateBannerByTemplate();
  }

  public function down()
  {
    echo "m160527_083321_generate_all_banners cannot be reverted.\n";
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
