<?php

use console\components\Migration;

class m151223_073612_init_platforms extends Migration
{

  const TABLE = 'platforms';

  public function up()
  {
    $this->update(self::TABLE, ['status' => 0]);

    $this->insert(self::TABLE, [
      'name' => 'Android Phone',
      'match_string' => '/Android.*Mobile/',
      'status' => 1,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'name' => 'Android Tablet',
      'match_string' => '/Android(?!.*Mobile)/',
      'status' => 1,
      'created_at' => time(),
      'updated_at' => time()
    ]);


    $this->insert(self::TABLE, [
      'name' => 'BlackBerry',
      'match_string' => '/BlackBerry/',
      'status' => 1,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'name' => 'iPad',
      'match_string' => '/iPad/',
      'status' => 1,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'name' => 'iPhone',
      'match_string' => '/iPhone/',
      'status' => 1,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'name' => 'Java',
      'match_string' => '/J2ME|MIDP/',
      'status' => 1,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'name' => 'MTK/Nucleus',
      'match_string' => '/MTK.*Nucleus/',
      'status' => 1,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'name' => 'Symbian',
      'match_string' => '/SymbianOS/',
      'status' => 1,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'name' => 'Windows Mobile/Phone',
      'match_string' => '/IEMobile/',
      'status' => 1,
      'created_at' => time(),
      'updated_at' => time()
    ]);
  }

  public function down()
  {
    $this->update(self::TABLE, ['status' => 0]);
  }
}
