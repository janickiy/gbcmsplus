<?php

use yii\db\Schema;
use console\components\Migration;
use yii\db\Query;

class m160201_142838_delete_dupl_streams extends Migration
{
  public function up()
  {
    $streams = (new \yii\db\Query())->select([
      'user_id',
      'name',
      'list' => 'GROUP_CONCAT(id)'
    ])->from('streams')
      ->groupBy(['user_id', 'name'])
      ->having('count(id) > 1')
    ->all();

    foreach ($streams as $stream) {

      echo "NAME=" . $stream['name'] . " IDS=" . $stream['list'] . " \n";

      $ids = explode(',', $stream['list']);

      $originalId = current($ids);

      $transaction = $this->db->beginTransaction();

      try {

        foreach ($ids as $toDelete) {
          if ($toDelete == $originalId) continue;

          echo "Stream ID=" . $toDelete . " NAME=" . $stream['name'] . " deleting:\n";

          $this->update('sources', ['stream_id' => $originalId], ['stream_id' => $toDelete]);
          $this->update('subscriptions_day_group', ['stream_id' => $originalId], ['stream_id' => $toDelete]);
          $this->update('subscriptions_day_hour_group', ['stream_id' => $originalId], ['stream_id' => $toDelete]);
          $this->update('sold_subscriptions', ['stream_id' => $originalId], ['stream_id' => $toDelete]);
          $this->update('search_subscriptions', ['stream_id' => $originalId], ['stream_id' => $toDelete]);
          $this->update('hits_day_group', ['stream_id' => $originalId], ['stream_id' => $toDelete]);
          $this->update('hits_day_hour_group', ['stream_id' => $originalId], ['stream_id' => $toDelete]);

          $this->delete('streams', ['id' => $toDelete]);


        }

        $transaction->commit();

      } catch (\Exception $e) {
        $transaction->rollBack();
        throw $e;
      }
    }
  }

  public function down()
  {
    echo "m160201_142838_delete_dupl_streams cannot be reverted.\n";
  }
}
