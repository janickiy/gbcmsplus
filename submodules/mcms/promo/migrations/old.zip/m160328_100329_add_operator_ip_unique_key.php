<?php

use console\components\Migration;

class m160328_100329_add_operator_ip_unique_key extends Migration
{

  const TABLE = 'operator_ips';

  public function up()
  {
    $this->createIndex('operator_ips_operator_id_from_ip_to_ip', self::TABLE,
      ['operator_id', 'from_ip', 'to_ip'], true);
    $this->addColumn(self::TABLE, 'should_delete', 'TINYINT(1) NOT NULL DEFAULT 0');
  }

  public function down()
  {
    $this->dropIndex('operator_ips_operator_id_from_ip_to_ip', self::TABLE);
    $this->dropColumn(self::TABLE, 'should_delete');
  }
}
