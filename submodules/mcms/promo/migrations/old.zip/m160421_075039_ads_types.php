<?php

use console\components\Migration;

class m160421_075039_ads_types extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  const TABLE = 'ads_types';

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->createTable(self::TABLE, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'code' => $this->string(30)->notNull(),
      'name' => $this->string()->notNull(),
      'description' => $this->text()->notNull(),
      'is_default' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'security' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'profit' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED NOT NULL',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'updated_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
    ]);

    $this->batchInsert(self::TABLE, [
      'id',
      'code',
      'name',
      'description',
      'is_default',
      'status',
      'security',
      'profit',
      'created_at',
      'updated_at',
      'created_by',
      'updated_by'
    ], [
      [
        1,
        'redirect',
        serialize(['ru' => 'Redirect', 'en' => 'Redirect']),
        serialize(['ru' => 'При попадании на сайт пользователь сразу перенаправляется на рекламную ссылку. Есть возможность регулировки уникальности пользователя, чтобы показывать рекламу только один раз. Наиболее профитен.', 'en' => 'After entering site user immediatedly redirected to ads link. Regulation of user uniqueness is available to show ads only one time. Most profitable.']),
        1,
        1,
        3,
        5,
        time(),
        time(),
        1,
        1
      ],
      [
        2,
        'clickunder',
        serialize(['ru' => 'ClickUnder', 'en' => 'ClickUnder']),
        serialize(['ru' => 'Второй по профитности. Юзеру будет показана реклама после клика в любом месте сайта, при этом юзер получает контент, находящийся на вашем сайте.', 'en' => 'Second best at profitability. Ads will be shown to user after click in any area of site, in same time user will get content from your site.']),
        0,
        1,
        4,
        4,
        time(),
        time(),
        1,
        1
      ],
      [
        3,
        'dialog',
        serialize(['ru' => 'DialogAds', 'en' => 'DialogAds']),
        serialize(['ru' => 'Уведомление, которое показывается пользователю при попадании на ваш сайт. Выглядит так: http://wap.wiki/img/promo/NewScript Тем самым это не является жестким редиректом, но у пользователя нет выбора, кроме как нажать кнопку Продолжить. Есть возможность задавать текст.', 'en' => 'Notification which is shown to user when he visits your site. Looks like this: http://wap.wiki/img/promo/NewScript This is not hard redirect, but user don\'t have any choice except for clicking button Continue. Text is available for editing.']),
        0,
        0,
        5,
        3,
        time(),
        time(),
        1,
        1
      ],
      [
        4,
        'push',
        serialize(['ru' => 'PushAds', 'en' => 'PushAds']),
        serialize(['ru' => 'Уведомление, которое показывается пользователю при попадании на ваш сайт. Выглядит так: http://wap.wiki/img/promo/NewScript2 У пользователя есть выбор - остаться на сайте или уйти. Наименее профитный способ слива, но наиболее лояльный к пользователю. Есть возможность задавать текст.', 'en' => 'Notification which is shown to user when he visits your site. Looks like this: http://wap.wiki/img/promo/NewScript2 User has choice - to stay on site or to leave. Least profitable ads type, but it\'s most loyal to user. Text is available for editing.']),
        0,
        0,
        5,
        3,
        time(),
        time(),
        1,
        1
      ],
    ]);

    $this->createOrGetPermission('PromoAdsTypesIndex', 'Promo ads types reference');
    $this->createOrGetPermission('PromoAdsTypesCreateModal', 'Promo ads type create');
    $this->createOrGetPermission('PromoAdsTypesUpdateModal', 'Promo ads type update');
    $this->createOrGetPermission('PromoAdsTypesEnable', 'Promo ads type enable');
    $this->createOrGetPermission('PromoAdsTypesDisable', 'Promo ads type disable');

    $this->assignRolesPermission('PromoAdsTypesIndex', ['root', 'admin']);
    $this->assignRolesPermission('PromoAdsTypesCreateModal', ['root', 'admin']);
    $this->assignRolesPermission('PromoAdsTypesUpdateModal', ['root', 'admin']);
    $this->assignRolesPermission('PromoAdsTypesEnable', ['root', 'admin']);
    $this->assignRolesPermission('PromoAdsTypesDisable', ['root', 'admin']);

  }

  public function down()
  {
    $this->removePermission('PromoAdsTypesIndex');
    $this->removePermission('PromoAdsTypesCreateModal');
    $this->removePermission('PromoAdsTypesUpdateModal');
    $this->removePermission('PromoAdsTypesEnable');
    $this->removePermission('PromoAdsTypesDisable');
    $this->dropTable(self::TABLE);
  }
}
