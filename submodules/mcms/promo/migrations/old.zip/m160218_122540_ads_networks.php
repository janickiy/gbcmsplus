<?php

use yii\db\Schema;
use console\components\Migration;
use mcms\promo\models\AdsNetwork;

  class m160218_122540_ads_networks extends Migration
{

  protected $adsNetworksTable = 'ads_networks';
  private $id = 1;

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable($this->adsNetworksTable, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string(50)->notNull(),
      'label1' => $this->string(50)->notNull(),
      'label2' => $this->string(50)->notNull(),
      'description1' => $this->string(300)->notNull(),
      'description2' => $this->string(300)->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
      ], $tableOptions);

    foreach ([
      [
        'name' => 'Kadam.ru',
        'label1' => '[SID]',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '[ID]',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'AdvertLink.ru',
        'label1' => '[SID]',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '[CID]',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'DirectAdvert.ru',
        'label1' => '%SITE_ID%',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '%AD_ID%',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'ActionTeaser.ru',
        'label1' => '[SID]',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '[CID]',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'MarketGid.com',
        'label1' => '{widget_id}',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '{teaser_id}',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
       'name' => 'TeaserNet.com',
       'label1' => '[SITE_ID]',
       'description1' => ['ru' => 'макрос передачи номера источника трафика (id площадки)', 'en' => 'traffic source id (site id)'],
       'label2' => '[TEASER_ID]',
       'description2' => ['ru' => 'макрос передачи номера тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'MediaVenus',
        'label1' => '[TID]',
        'description1' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
        'label2' => '[SID]',
        'description2' => ['ru' => 'передача id площадки', 'en' => 'site id'],
      ],
      [
        'name' => 'ThorMedia',
        'label1' => '[TID]',
        'description1' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
        'label2' => '[SID]',
        'description2' => ['ru' => 'передача id площадки', 'en' => 'site id'],
      ],
      [
        'name' => 'ReCreativ',
        'label1' => '{OfferID}',
        'description1' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
        'label2' => '{SiteID}',
        'description2' => ['ru' => 'передача id площадки', 'en' => 'site id'],
      ],
      [
        'name' => 'MegaTizer',
        'label1' => '[ID]',
        'description1' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
        'label2' => '[SID]',
        'description2' => ['ru' => 'передача id площадки', 'en' => 'site id'],
      ],
      [
        'name' => 'Etarg',
        'label1' => '{{teaser_id}}',
        'description1' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
        'label2' => '{{site_id}}',
        'description2' => ['ru' => 'передача id площадки', 'en' => 'site id'],
      ],
      [
        'name' => 'LuxAds',
        'label1' => '{ad_hash}',
        'description1' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
        'label2' => '{block_hash}',
        'description2' => ['ru' => 'передача id площадки', 'en' => 'site id'],
      ],
      [
        'name' => 'Gnezdo',
        'label1' => '[TID]',
        'description1' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
        'label2' => '[SID]',
        'description2' => ['ru' => 'передача id площадки', 'en' => 'site id'],
      ],
      [
        'name' => 'Oblivochki',
        'label1' => '[TID]',
        'description1' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
        'label2' => '',
        'description2' => ['ru' => '', 'en' => ''],
      ],
      [
        'name' => 'LinkWord',
        'label1' => '[TID]',
        'description1' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
        'label2' => '[SID]',
        'description2' => ['ru' => 'передача id площадки', 'en' => 'site id'],
      ],
      [
        'name' => 'DriveNetwork',
        'label1' => '%AD_ID%',
        'description1' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
        'label2' => '%SITE_ID%',
        'description2' => ['ru' => 'передача id площадки', 'en' => 'site id'],
      ],
      [
        'name' => 'AdMantic',
        'label1' => '{ad_id}',
        'description1' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
        'label2' => '{site_id}',
        'description2' => ['ru' => 'передача id площадки', 'en' => 'site id'],
      ],
      [
        'name' => 'TubeContext.com',
        'label1' => '%site%',
        'description1' => ['ru' => 'передача ID источника', 'en' => 'source ID'],
        'label2' => '%ad%',
        'description2' => ['ru' => 'передача ID тизера', 'en' => 'teaser ID'],
      ],
      [
        'name' => 'VisitWeb.com',
        'label1' => '{USITE}',
        'description1' => ['ru' => 'сайт с которого совершается переход (в кодировке utf-8)', 'en' => 'referrer site (using encoding win1251)'],
        'label2' => '{AD}',
        'description2' => ['ru' => 'ID тизера с которого совершается переход ', 'en' => 'referrer teaser ID (using encoding utf-8)'],
      ],
      [
        'name' => 'BodyClick.net',
        'label1' => '[SID]',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '[ID]',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'TeaserMedia.net',
        'label1' => '{{domain}}',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '{{tid}}',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'PrivatTeaser.ru',
        'label1' => '{REF}',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '{ID}',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'Octobird.com',
        'label1' => '{OB_SITE_ID}',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '',
        'description2' => ['ru' => '', 'en' => ''],
      ],
      [
        'name' => 'AdLabs.ru',
        'label1' => 'ext_meta_id',
        'description1' => ['ru' => 'ID клика, параметр необходим для подсчета достижений целей', 'en' => 'click ID, parameter is required for counting'],
        'label2' => 'source_id',
        'description2' => ['ru' => 'ID площадки (источника трафика)', 'en' => 'site ID (traffic source)'],
      ],
      [
        'name' => 'RedClick.ru',
        'label1' => 'source_id',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => 'tizer_id',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'RedTram.com',
        'label1' => '{SITE_NAME}',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '{GOOD_ID}',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'AdHub.ru',
        'label1' => '{site_id}',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '{ad_id}',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'GlobalTeaser.ru',
        'label1' => '{sid}',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '{tid}',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'AdProfy.com',
        'label1' => '[ab]',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '[at]',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'Yottos.com',
        'label1' => '{source}',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '{content}',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'Novostimira.com.ua',
        'label1' => '{nm_inf_g}',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '{nm_g}',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'Tovarro.com',
        'label1' => '{widget_id}',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '{teaser_id}',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'Mobiads.ru',
        'label1' => '[place_id]',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '[ad_id]',
        'description2' => ['ru' => 'передача id тизера', 'en' => 'teaser id'],
      ],
      [
        'name' => 'CashProm.ru',
        'label1' => '{%CASHPROM_PLACE_ID%}',
        'description1' => ['ru' => 'передача id площадки', 'en' => 'site id'],
        'label2' => '',
        'description2' => ['ru' => '', 'en' => ''],
      ],
    ] as $adsNetworkParams) {
      $this->createAdsNetwork($adsNetworkParams);
    }

    $this->createIndex('ads_networks_status_index', $this->adsNetworksTable, 'status');
  }

  public function down()
  {
    $this->dropTable($this->adsNetworksTable);
  }

  private function createAdsNetwork($adsNetworkParams)
  {
    $adsNetworkParams['id'] = $this->id;
    $adsNetworkParams['status'] = AdsNetwork::STATUS_ACTIVE;
    (new AdsNetwork($adsNetworkParams))->save();

    $this->id++;
  }

}
