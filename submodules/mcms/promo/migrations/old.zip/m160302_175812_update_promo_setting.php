<?php

use mcms\common\module\settings\Repository;
use mcms\modmanager\models\Module;
use console\components\Migration;

class m160302_175812_update_promo_setting extends Migration
{
  public function up()
  {
    /** @var Module $promo */
    $promo = Yii::$app->getModule('promo');
    $promo->settings->offsetSet('settings.arbitrary_link_moderation', false);
  }

  public function down()
  {
  }
}
