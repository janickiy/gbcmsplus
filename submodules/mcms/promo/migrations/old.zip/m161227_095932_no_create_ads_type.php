<?php

use console\components\Migration;

class m161227_095932_no_create_ads_type extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function up()
  {
    $this->removePermission('PromoAdsTypesCreateModal');
  }

  public function down()
  {
    $this->createPermission('PromoAdsTypesCreateModal', 'Создать формат рекламы', 'PromoAdsTypesController', ['admin', 'root']);
  }

}
