<?php

use console\components\Migration;

class m160601_085613_landing_operators_created_at extends Migration
{
  const TABLE = 'landing_operators';

  public function up()
  {
    $this->addColumn(self::TABLE, 'created_at', 'INT(10) NULL DEFAULT \'0\'');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'created_at');
  }
}
