<?php

use yii\db\Schema;
use console\components\Migration;

class m160229_085210_update_reseller_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'Landing' => [
        ['UnblockRequestsCreateModal', 'Can create unblock requests', ['admin', 'root', 'reseller']]
      ]
    ];
  }

}
