<?php

use rgk\settings\models\Setting;
use rgk\settings\models\SettingsCategory;
use console\components\Migration;

class m180607_103020_partner_available_currencies extends Migration
{
  const PARENT_CATEGORY = 'app.common.group_partners';
  const CATEGORY = 'app.common.group_partner_available_currencies';

  const SETTING_RUB = 'settings.partner_available_currencies.rub';
  const SETTING_USD = 'settings.partner_available_currencies.usd';
  const SETTING_EUR = 'settings.partner_available_currencies.eur';

  public function up()
  {
    $title = [
      'ru' => 'Доступные валюты',
      'en' => 'Available currencies',
    ];

    $parentCategoryId = (new \yii\db\Query())
      ->select('id')
      ->from('rgk_settings_category')
      ->where(['key' => self::PARENT_CATEGORY])
      ->scalar();
    Yii::$app->settingsBuilder->createCategory($title, self::CATEGORY, $parentCategoryId);

    Yii::$app->settingsBuilder->createSetting(
      ['en' => 'RUB', 'ru' => 'RUB'],
      [],
      self::SETTING_RUB,
      ['EditModuleSettingsPartners'],
      Setting::TYPE_BOOLEAN,
      self::CATEGORY,
      true,
      [['boolean']],
      1
    );
    Yii::$app->settingsBuilder->createSetting(
      ['en' => 'USD', 'ru' => 'USD'],
      [],
      self::SETTING_USD,
      ['EditModuleSettingsPartners'],
      Setting::TYPE_BOOLEAN,
      self::CATEGORY,
      true,
      [['boolean']],
      2
    );
    Yii::$app->settingsBuilder->createSetting(
      ['en' => 'EUR', 'ru' => 'EUR'],
      [],
      self::SETTING_EUR,
      ['EditModuleSettingsPartners'],
      Setting::TYPE_BOOLEAN,
      self::CATEGORY,
      true,
      [['boolean']],
      3
    );

  }

  public function down()
  {
    Yii::$app->settingsBuilder->removeCategory(self::CATEGORY);
    Yii::$app->settingsBuilder->removeSetting(self::SETTING_RUB);
    Yii::$app->settingsBuilder->removeSetting(self::SETTING_USD);
    Yii::$app->settingsBuilder->removeSetting(self::SETTING_EUR);
  }
}
