<?php

use console\components\Migration;

class m161020_195520_multiple_banners_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  const OLD_PERMISSION = 'CanEditLandingCategoryBannerId';
  const NEW_PERMISSION = 'CanEditLandingCategoryBannersIds';
  const CATEGORY = 'PromoLandingCategoriesController';
  const PERMISSION_ROLES = ['root', 'admin', 'reseller'];

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    // Удаление прав на banner_id
    $this->removePermission(static::OLD_PERMISSION);

    // Добавление прав на bannersIds
    $category = $this->authManager->getPermission(static::CATEGORY);
    $permission = $this->createOrGetPermission(static::NEW_PERMISSION, 'User can edit banners in landing category');
    $this->authManager->addChild($category, $permission);
    $this->assignRolesPermission(static::NEW_PERMISSION, static::PERMISSION_ROLES);
  }

  public function down()
  {
    // Возвращение прав на banner_id
    $category = $this->authManager->getPermission(static::CATEGORY);
    $permission = $this->createOrGetPermission(static::OLD_PERMISSION, 'User can edit banner in landing category');
    $this->authManager->addChild($category, $permission);
    $this->assignRolesPermission(static::OLD_PERMISSION, static::PERMISSION_ROLES);

    // Удаление прав на bannersIds
    $this->removePermission(static::NEW_PERMISSION);
  }
}
