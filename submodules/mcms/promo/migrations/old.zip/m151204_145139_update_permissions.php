<?php

use console\components\Migration;

class m151204_145139_update_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'ArbitrarySources' => [
        ['view-modal', 'View arbitrary source in modal', ['admin', 'root']],
        ['enable', 'Set source status active', ['admin', 'root']],
        ['disable', 'Set source status inactive', ['admin', 'root']],
        ['operators', 'Get list of landing operators', ['admin', 'root']]
      ],
      'WebmasterSources' => [
        ['view-modal', 'View webmaster source in modal', ['admin', 'root']],
        ['enable', 'Set source status active', ['admin', 'root']],
        ['disable', 'Set source status inactive', ['admin', 'root']],
      ]
    ];
  }
}
