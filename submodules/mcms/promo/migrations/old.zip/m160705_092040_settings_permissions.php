<?php

use console\components\Migration;

class m160705_092040_settings_permissions extends Migration
{
  use \mcms\common\traits\PermissionGroupMigration;

  public function init()
  {
    parent::init();

    $this->groupPermissionName = 'PromoModule';
    $this->groupPermissionDescription = 'Module Promo';
    $this->groupPermissionDefaultRole = ['admin', 'root'];

    $this->groupPermissionControllers = [
      'PromoSettings' => [
        'description' => 'Can view settings permissions',
        'permissions' => [
          ['PromoCanEditMainSettings'],
          ['PromoCanEditFakeRevshareSettings'],
          ['PromoCanEditLandingsSettings'],
        ]
      ],
    ];
  }
}
