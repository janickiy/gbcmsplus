<?php

use console\components\Migration;

/**
 * Запросы из этой миграции дать админам на выполнение
 */
class m180522_074231_3digits_admin extends Migration
{
  public function up()
  {
    $approve = \mcms\common\helpers\Console::confirm('Эту миграцию должен выполнить админ. Пропустить миграцию?');
    if ($approve) return true;

    echo 'subscription_rebills...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE subscription_rebills
      CHANGE default_profit default_profit decimal(7, 3) unsigned not null,
      CHANGE real_profit_rub real_profit_rub decimal(7, 3) unsigned not null,
      CHANGE real_profit_usd real_profit_usd decimal(7, 3) unsigned not null,
      CHANGE real_profit_eur real_profit_eur decimal(7, 3) unsigned not null,
      CHANGE reseller_profit_rub reseller_profit_rub decimal(7, 3) unsigned not null,
      CHANGE reseller_profit_usd reseller_profit_usd decimal(7, 3) unsigned not null,
      CHANGE reseller_profit_eur reseller_profit_eur decimal(7, 3) unsigned not null,
      CHANGE profit_rub profit_rub decimal(7, 3) unsigned not null,
      CHANGE profit_usd profit_usd decimal(7, 3) unsigned not null,
      CHANGE profit_eur profit_eur decimal(7, 3) unsigned not null;
      ')->execute();

    echo 'onetime_subscriptions...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE onetime_subscriptions
      CHANGE default_profit default_profit decimal(7, 3) unsigned not null,
      CHANGE real_profit_rub real_profit_rub decimal(7, 3) unsigned not null,
      CHANGE real_profit_usd real_profit_usd decimal(7, 3) unsigned not null,
      CHANGE real_profit_eur real_profit_eur decimal(7, 3) unsigned not null,
      CHANGE reseller_profit_rub reseller_profit_rub decimal(7, 3) unsigned not null,
      CHANGE reseller_profit_usd reseller_profit_usd decimal(7, 3) unsigned not null,
      CHANGE reseller_profit_eur reseller_profit_eur decimal(7, 3) unsigned not null,
      CHANGE profit_rub profit_rub decimal(7, 3) unsigned not null,
      CHANGE profit_usd profit_usd decimal(7, 3) unsigned not null,
      CHANGE profit_eur profit_eur decimal(7, 3) unsigned not null,
      CHANGE calc_profit_rub calc_profit_rub decimal(7, 3) unsigned default \'0.00\' not null
  comment \'расчитанный профит партнера без учета корректировки\',
      CHANGE calc_profit_usd calc_profit_usd decimal(7, 3) unsigned default \'0.00\' not null
  comment \'расчитанный профит партнера без учета корректировки\',
      CHANGE calc_profit_eur calc_profit_eur decimal(7, 3) unsigned default \'0.00\' not null
  comment \'расчитанный профит партнера без учета корректировки\';
      ')->execute();

    echo 'personal_profit...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE personal_profit
      CHANGE rebill_percent rebill_percent decimal(6, 3)                     null,
      CHANGE buyout_percent buyout_percent decimal(6, 3)                     null,
      CHANGE cpa_profit_rub cpa_profit_rub decimal(6, 3)                     null,
      CHANGE cpa_profit_usd cpa_profit_usd decimal(6, 3)                     null,
      CHANGE cpa_profit_eur cpa_profit_eur decimal(6, 3)                     null
      ')->execute();

    echo 'partner_program_items...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE partner_program_items
      CHANGE rebill_percent rebill_percent     decimal(6, 3)         null,
      CHANGE buyout_percent buyout_percent     decimal(6, 3)         null,
      CHANGE cpa_profit_rub cpa_profit_rub     decimal(6, 3)         null,
      CHANGE cpa_profit_eur cpa_profit_eur     decimal(6, 3)         null,
      CHANGE cpa_profit_usd cpa_profit_usd     decimal(6, 3)         null
      ')->execute();

    echo 'user_balance_invoices...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE user_balance_invoices
      CHANGE amount amount          decimal(13, 3)           null
      ')->execute();
  }

  /**
   * */
  public function down()
  {
    $approve = \mcms\common\helpers\Console::confirm('Эту миграцию должен выполнить админ. Пропустить миграцию?');
    if ($approve) return true;

    echo 'partner_program_items...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE partner_program_items
      CHANGE rebill_percent rebill_percent     decimal(5, 2)         null,
      CHANGE buyout_percent buyout_percent     decimal(5, 2)         null,
      CHANGE cpa_profit_rub cpa_profit_rub     decimal(5, 2)         null,
      CHANGE cpa_profit_eur cpa_profit_eur     decimal(5, 2)         null,
      CHANGE cpa_profit_usd cpa_profit_usd     decimal(5, 2)         null
      ')->execute();

    echo 'personal_profit...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE personal_profit
      CHANGE rebill_percent rebill_percent decimal(5, 2)                     null,
      CHANGE buyout_percent buyout_percent decimal(5, 2)                     null,
      CHANGE cpa_profit_rub cpa_profit_rub decimal(5, 2)                     null,
      CHANGE cpa_profit_usd cpa_profit_usd decimal(5, 2)                     null,
      CHANGE cpa_profit_eur cpa_profit_eur decimal(5, 2)                     null
      ')->execute();

    echo 'user_balance_invoices...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE user_balance_invoices
      CHANGE amount amount          decimal(12, 2)           null
      ')->execute();

    echo 'onetime_subscriptions...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE onetime_subscriptions
      CHANGE default_profit default_profit decimal(6, 2) unsigned not null,
      CHANGE real_profit_rub real_profit_rub decimal(6, 2) unsigned not null,
      CHANGE real_profit_usd real_profit_usd decimal(6, 2) unsigned not null,
      CHANGE real_profit_eur real_profit_eur decimal(6, 2) unsigned not null,
      CHANGE reseller_profit_rub reseller_profit_rub decimal(6, 2) unsigned not null,
      CHANGE reseller_profit_usd reseller_profit_usd decimal(6, 2) unsigned not null,
      CHANGE reseller_profit_eur reseller_profit_eur decimal(6, 2) unsigned not null,
      CHANGE profit_rub profit_rub decimal(6, 2) unsigned not null,
      CHANGE profit_usd profit_usd decimal(6, 2) unsigned not null,
      CHANGE profit_eur profit_eur decimal(6, 2) unsigned not null,
      CHANGE calc_profit_rub calc_profit_rub decimal(6, 2) unsigned default \'0.00\' not null
  comment \'расчитанный профит партнера без учета корректировки\',
      CHANGE calc_profit_usd calc_profit_usd decimal(6, 2) unsigned default \'0.00\' not null
  comment \'расчитанный профит партнера без учета корректировки\',
      CHANGE calc_profit_eur calc_profit_eur decimal(6, 2) unsigned default \'0.00\' not null
  comment \'расчитанный профит партнера без учета корректировки\';
      ')->execute();

    echo 'subscription_rebills...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE subscription_rebills
      CHANGE default_profit default_profit decimal(6, 2) unsigned not null,
      CHANGE real_profit_rub real_profit_rub decimal(6, 2) unsigned not null,
      CHANGE real_profit_usd real_profit_usd decimal(6, 2) unsigned not null,
      CHANGE real_profit_eur real_profit_eur decimal(6, 2) unsigned not null,
      CHANGE reseller_profit_rub reseller_profit_rub decimal(6, 2) unsigned not null,
      CHANGE reseller_profit_usd reseller_profit_usd decimal(6, 2) unsigned not null,
      CHANGE reseller_profit_eur reseller_profit_eur decimal(6, 2) unsigned not null,
      CHANGE profit_rub profit_rub decimal(6, 2) unsigned not null,
      CHANGE profit_usd profit_usd decimal(6, 2) unsigned not null,
      CHANGE profit_eur profit_eur decimal(6, 2) unsigned not null;
      ')->execute();
  }
}
