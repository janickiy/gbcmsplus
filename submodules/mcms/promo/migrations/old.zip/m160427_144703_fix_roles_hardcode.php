<?php

use console\components\Migration;

class m160427_144703_fix_roles_hardcode extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->createOrGetPermission('PromoApplyPersonalPercentsAsReseller', 'Apply to current user resellers logic to view personal percents');
    $this->assignRolesPermission('PromoApplyPersonalPercentsAsReseller', ['reseller', 'manager']);

    $this->createOrGetPermission('PromoApplyPersonalPercentsAsInvestor', 'Apply to current user investors logic to view personal percents');
    $this->assignRolesPermission('PromoApplyPersonalPercentsAsInvestor', ['investor']);

    $this->createOrGetPermission('PromoApplyPersonalPercentsAsRoot', 'Apply to current user roots logic to view personal percents');
    $this->assignRolesPermission('PromoApplyPersonalPercentsAsRoot', ['admin', 'root']);

  }

  public function down()
  {
    $this->removePermission('PromoApplyPersonalPercentsAsRoot');
    $this->removePermission('PromoApplyPersonalPercentsAsInvestor');
    $this->removePermission('PromoApplyPersonalPercentsAsReseller');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
