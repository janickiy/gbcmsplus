<?php

use console\components\Migration;

class m160706_100540_update_permissions extends Migration
{

  use \mcms\common\traits\PermissionGroupMigration;

  public function init()
  {
    parent::init();

    $this->groupPermissionName = 'PromoModule';
    $this->groupPermissionDescription = 'Module Promo';
    $this->groupPermissionDefaultRole = ['admin', 'root', 'reseller'];

    $this->groupPermissionControllers = [
      'TraffickbackProvidersController' => [
        'description' => 'Trafficback providers Controller',
        'roles' => ['admin', 'root', 'reseller'],
        'permissions' => [
          ['PromoTrafficbackProvidersCreate'],
          ['PromoTrafficbackProvidersIndex'],
          ['PromoTrafficbackProvidersUpdate'],
        ]
      ],
    ];
  }
}
