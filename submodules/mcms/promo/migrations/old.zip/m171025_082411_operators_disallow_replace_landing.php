<?php

use console\components\Migration;

class m171025_082411_operators_disallow_replace_landing extends Migration
{
  public function up()
  {
    $this->addColumn('operators', 'is_disallow_replace_landing', $this->smallInteger(1)->notNull()->defaultValue(0));
  }

  public function down()
  {
    $this->dropColumn('operators', 'is_disallow_replace_landing');

  }
}
