<?php

use console\components\Migration;

class m171026_133450_source_add_is_traffic_filters_off_column extends Migration
{
  public function up()
  {
    $this->addColumn('sources', 'is_traffic_filters_off', 'TINYINT(1) NOT NULL DEFAULT 0');
  }

  public function down()
  {
    $this->dropColumn('sources', 'is_traffic_filters_off');
  }
}
