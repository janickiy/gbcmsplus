<?php

use yii\db\Schema;
use console\components\Migration;

class m160303_140211_unblock_request_reject_reason extends Migration
{

  const TABLE = 'landing_unblock_requests';

  public function up()
  {
    $this->addColumn(self::TABLE, 'reject_reason', 'TEXT DEFAULT NULL');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'reject_reason');
  }

}
