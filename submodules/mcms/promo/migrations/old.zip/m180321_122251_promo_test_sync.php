<?php

use console\components\Migration;


class m180321_122251_promo_test_sync extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('PromoProvidersTest', 'Тестилка (проверка) провайдеров', 'PromoProvidersController', ['root']);
  }

  public function down()
  {
    $this->removePermission('PromoProvidersTest');
  }
}
