<?php

use console\components\Migration;

class m151028_072606_country_region_city extends Migration
{

  protected $countryTable = '{{%countries}}';
  protected $regionTable = '{{%regions}}';
  protected $cityTable = '{{%cities}}';

  protected $regionsCountryFk = 'regions_country_id_fk';
  protected $citiesCountryFk = 'cities_country_id_fk';
  protected $citiesRegionFk = 'cities_region_id_fk';

  public function safeUp()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    /*
     * COUNTRIES
     */
    $this->createTable($this->countryTable, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string(50)->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'code' => $this->string(10)->notNull(),
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex('countries_status_index', $this->countryTable, 'status');
    $this->createIndex('countries_code_index', $this->countryTable, 'code', true);

    /*
     * REGIONS
     */
    $this->createTable($this->regionTable, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string(50)->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex('regions_status_index', $this->regionTable, 'status');
    $this->addForeignKey($this->regionsCountryFk, $this->regionTable, 'country_id', $this->countryTable, 'id');

    /*
     * CITIES
     */
    $this->createTable($this->cityTable, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string(50)->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'region_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex('cities_status_index', $this->cityTable, 'status');
    $this->addForeignKey($this->citiesCountryFk, $this->cityTable, 'country_id', $this->countryTable, 'id');
    $this->addForeignKey($this->citiesRegionFk, $this->cityTable, 'region_id', $this->regionTable, 'id');

  }

  public function safeDown()
  {
    $this->dropTable($this->cityTable);
    $this->dropTable($this->regionTable);
    $this->dropTable($this->countryTable);
  }

}
