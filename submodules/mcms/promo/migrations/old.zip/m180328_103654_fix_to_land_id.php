<?php

use console\components\Migration;

/**
 */
class m180328_103654_fix_to_land_id extends Migration
{
  /**
   */
  public function up()
  {
    // подменяем из-за бага, описанного в MCMS-2069
    $this->db->createCommand('UPDATE landings l LEFT JOIN landings to_land
    ON to_land.send_id = l.to_landing_id AND l.provider_id = to_land.provider_id
SET l.to_landing_id = to_land.id')->execute();
  }

  /**
   */
  public function down()
  {
    $this->db->createCommand('UPDATE landings l LEFT JOIN landings to_land
    ON to_land.id = l.to_landing_id AND l.provider_id = to_land.provider_id
SET l.to_landing_id = to_land.send_id')->execute();
  }

}
