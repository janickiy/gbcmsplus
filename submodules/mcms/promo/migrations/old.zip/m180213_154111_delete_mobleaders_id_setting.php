<?php

use console\components\Migration;
use rgk\settings\models\Setting;

class m180213_154111_delete_mobleaders_id_setting extends Migration
{
  const SETTING = 'mobleaders_user_id';

  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
  }

  public function up()
  {
    $this->settingsBuilder->removeSetting(self::SETTING);
  }

  public function down()
  {
    $title = ['ru' => 'ID пользователя в Mobleaders, для синхронизации', 'en' => 'Mobleaders user ID, for sync'];
    $permissions = ['PromoCanEditMainSettings'];
    $category = 'app.common.form_group_basic';
    $validators = [["required"],["string"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTING, $permissions, Setting::TYPE_STRING, $category, '', $validators);
  }

}
