<?php

use console\components\Migration;

class m151207_075915_reseller_permissions extends Migration
{

  /** @var \yii\rbac\ManagerInterface */
  public $authManager;

  public $landingUnblockPermission;
  public $userViewPermission;
  public $userFindPermission;
  public $landingViewPermission;
  public $landingSelect2Permission;
  public $landingUnblockViewPermission;
  public $landingUnblockUpdatePermission;
  public $userListPermission;
  public $userEditPermission;
  public $personalProfitCreatePermission;
  public $personalProfitUpdatePermission;
  public $personalProfitDeletePermission;
  public $operatorSelect2Permission;

  public $resellerRole;
  public $rootRole;
  public $adminRole;

  public $viewBlockedLandings;

  public $viewUsersEditForm;
  public $viewPersonalProfitWidget;



  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    $this->landingUnblockPermission = $this->authManager->getPermission('PromoLandingUnblockRequestsIndex');
    $this->userViewPermission = $this->authManager->getPermission('UsersUsersView');
    $this->userFindPermission = $this->authManager->getPermission('PromoLandingUnblockRequestsFindUser');
    $this->landingViewPermission = $this->authManager->getPermission('PromoLandingsView');
    $this->landingSelect2Permission = $this->authManager->getPermission('PromoLandingsSelect2');
    $this->landingUnblockViewPermission = $this->authManager->getPermission('PromoLandingUnblockRequestsView');
    $this->landingUnblockUpdatePermission = $this->authManager->getPermission('PromoLandingUnblockRequestsUpdate');
    $this->userListPermission = $this->authManager->getPermission('UsersUsersList');
    $this->userEditPermission = $this->authManager->getPermission('UsersUsersUpdate');

    $this->personalProfitCreatePermission = $this->authManager->getPermission('PromoPersonalProfitsCreateModal');
    $this->personalProfitUpdatePermission = $this->authManager->getPermission('PromoPersonalProfitsUpdateModal');
    $this->personalProfitDeletePermission = $this->authManager->getPermission('PromoPersonalProfitsDelete');

    $this->operatorSelect2Permission = $this->authManager->getPermission('PromoOperatorsSelect2');


    $this->resellerRole = $this->authManager->getRole('reseller');
    $this->rootRole = $this->authManager->getRole('root');
    $this->adminRole = $this->authManager->getRole('admin');

    $this->viewBlockedLandings = \mcms\promo\Module::PERMISSION_CAN_VIEW_BLOCKED_LANDINGS;
    $this->viewUsersEditForm = \mcms\user\Module::PERMISSION_CAN_VIEW_EDIT_FORM;
    $this->viewPersonalProfitWidget = \mcms\promo\Module::PERMISSION_CAN_VIEW_PERSONAL_PROFITS_WIDGET;



    parent::init();
  }


  public function safeUp()
  {
    $this->authManager->addChild($this->resellerRole, $this->landingUnblockPermission);

    $viewBlockedLandings = $this->authManager->createPermission($this->viewBlockedLandings);
    $viewBlockedLandings->description = 'Can view landings with BLOCKED status';
    $this->authManager->add($viewBlockedLandings);
    $this->authManager->addChild($this->rootRole, $viewBlockedLandings);
    $this->authManager->addChild($this->adminRole, $viewBlockedLandings);


    $this->authManager->addChild($this->resellerRole, $this->userViewPermission);
    $this->authManager->addChild($this->resellerRole, $this->userFindPermission);
    $this->authManager->addChild($this->resellerRole, $this->landingViewPermission);
    $this->authManager->addChild($this->resellerRole, $this->landingSelect2Permission);

    $this->authManager->addChild($this->resellerRole, $this->landingUnblockViewPermission);
    $this->authManager->addChild($this->resellerRole, $this->landingUnblockUpdatePermission);

    $this->authManager->addChild($this->resellerRole, $this->userListPermission);
    $this->authManager->addChild($this->resellerRole, $this->userEditPermission);


    $personalProfitWidget = $this->authManager->createPermission($this->viewPersonalProfitWidget);
    $viewBlockedLandings->description = 'Can view personal profit widget';
    $this->authManager->add($personalProfitWidget);
    $this->authManager->addChild($this->rootRole, $personalProfitWidget);
    $this->authManager->addChild($this->adminRole, $personalProfitWidget);
    $this->authManager->addChild($this->resellerRole, $personalProfitWidget);

    $userFormWidget = $this->authManager->createPermission($this->viewUsersEditForm);
    $viewBlockedLandings->description = 'Can view user edit form widget';
    $this->authManager->add($userFormWidget);
    $this->authManager->addChild($this->rootRole, $userFormWidget);
    $this->authManager->addChild($this->adminRole, $userFormWidget);

    $this->authManager->addChild($this->resellerRole, $this->personalProfitCreatePermission);
    $this->authManager->addChild($this->resellerRole, $this->personalProfitUpdatePermission);
    $this->authManager->addChild($this->resellerRole, $this->personalProfitDeletePermission);

    $this->authManager->addChild($this->resellerRole, $this->operatorSelect2Permission);
  }

  public function safeDown()
  {
    if ($viewBlockedLandings = $this->authManager->getPermission($this->viewBlockedLandings)) {
      $this->authManager->remove($viewBlockedLandings);
    }


    $this->authManager->removeChild($this->resellerRole, $this->landingUnblockPermission);

    $this->authManager->removeChild($this->resellerRole, $this->userViewPermission);
    $this->authManager->removeChild($this->resellerRole, $this->userFindPermission);
    $this->authManager->removeChild($this->resellerRole, $this->landingViewPermission);
    $this->authManager->removeChild($this->resellerRole, $this->landingSelect2Permission);

    $this->authManager->removeChild($this->resellerRole, $this->landingUnblockViewPermission);
    $this->authManager->removeChild($this->resellerRole, $this->landingUnblockUpdatePermission);

    $this->authManager->removeChild($this->resellerRole, $this->userListPermission);
    $this->authManager->removeChild($this->resellerRole, $this->userEditPermission);

    if ($personalProfitWidget = $this->authManager->getPermission($this->viewPersonalProfitWidget)) {
      $this->authManager->remove($personalProfitWidget);
    }

    if ($userFormWidget = $this->authManager->getPermission($this->viewUsersEditForm)) {
      $this->authManager->remove($userFormWidget);
    }

    $this->authManager->removeChild($this->resellerRole, $this->personalProfitCreatePermission);
    $this->authManager->removeChild($this->resellerRole, $this->personalProfitUpdatePermission);
    $this->authManager->removeChild($this->resellerRole, $this->personalProfitDeletePermission);
    $this->authManager->removeChild($this->resellerRole, $this->operatorSelect2Permission);
  }

}
