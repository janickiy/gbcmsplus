<?php

use console\components\Migration;

class m180227_131017_complains_postback_url extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  const TABLE_UPS = 'user_promo_settings';
  const COLUMN_PU = 'complains_postback_url';

  const TABLE_S = 'sources';
  const COLUMN_UCGPU = 'use_complains_global_postback_url';

  const PERMISSION = 'PartnersProfileComplainsPostbackUrlSpread';

  public function up()
  {
    $this->addColumn(self::TABLE_UPS, self::COLUMN_PU, 'VARCHAR(512) AFTER postback_url');
    $this->addColumn(self::TABLE_S, self::COLUMN_UCGPU, 'TINYINT(1) NOT NULL DEFAULT 0 AFTER use_global_postback_url');

    $this->createPermission(self::PERMISSION, 'Использовать глобальный постбек URL для жалоб во всех источниках', 'PartnersProfileController', ['partner']);
  }

  public function down()
  {
    $this->dropColumn(self::TABLE_UPS, self::COLUMN_PU);
    $this->dropColumn(self::TABLE_S, self::COLUMN_UCGPU);

    $this->removePermission(self::PERMISSION);
  }
}
