<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170705_095026_parter_program_copy_permission extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PromoPartnerProgramsCopy', 'Копирование партнерской программы', 'PromoPartnerProgramsController', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('PromoPartnerProgramsCopy');
  }
}
