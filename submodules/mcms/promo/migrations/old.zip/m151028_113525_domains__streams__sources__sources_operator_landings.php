<?php

use console\components\Migration;

class m151028_113525_domains__streams__sources__sources_operator_landings extends Migration
{

  protected $domains = '{{%domains}}';
  protected $streams = '{{%streams}}';
  protected $sources = '{{%sources}}';
  protected $sourcesOperatorLandings = '{{%sources_operator_landings}}';

  public function safeUp()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    /*
     * DOMAINS
     */
    $this->createTable($this->domains, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'url' => $this->string()->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'type' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex('domains' . '_' . 'status' . '_index', $this->domains, 'status');
    $this->createIndex('domains' . '_' . 'type' . '_index', $this->domains, 'type');
    $this->addForeignKey('domains' . '_' . 'user_id' . '_fk', $this->domains, 'user_id', '{{%users}}', 'id');
    $this->addForeignKey('domains' . '_' . 'created_by' . '_fk', $this->domains, 'created_by', '{{%users}}', 'id');


    /*
     * STREAMS
     */
    $this->createTable($this->streams, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string()->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);
    $this->createIndex('streams' . '_' . 'status' . '_index', $this->streams, 'status');
    $this->addForeignKey('streams' . '_' . 'user_id' . '_fk', $this->streams, 'user_id', '{{%users}}', 'id');


    /*
     * SOURCES
     */
    $this->createTable($this->sources, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'hash' => $this->string(10)->notNull(),
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'default_profit_type' => 'TINYINT(1) UNSIGNED DEFAULT 0',
      'url' => $this->string(),
      'ads_type' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'source_type' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'name' => $this->string(),
      'stream_id' => 'MEDIUMINT(5) UNSIGNED',
      'domain_id' => 'MEDIUMINT(5) UNSIGNED',
      'postback_url' => $this->string(),
      'is_notify_subscribe' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_notify_rebill' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_notify_unsubscribe' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'trafficback_type' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'trafficback_url' => $this->string(),
      'label1' => $this->string(),
      'label2' => $this->string(),
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex('sources' . '_' . 'hash' . '_index', $this->sources, 'hash', true);
    $this->createIndex('sources' . '_' . 'default_profit_type' . '_index', $this->sources, 'default_profit_type');
    $this->createIndex('sources' . '_' . 'ads_type' . '_index', $this->sources, 'ads_type');
    $this->createIndex('sources' . '_' . 'status' . '_index', $this->sources, 'status');
    $this->createIndex('sources' . '_' . 'source_type' . '_index', $this->sources, 'source_type');
    $this->createIndex('sources' . '_' . 'is_notify_subscribe' . '_index', $this->sources, 'is_notify_subscribe');
    $this->createIndex('sources' . '_' . 'is_notify_rebill' . '_index', $this->sources, 'is_notify_rebill');
    $this->createIndex('sources' . '_' . 'is_notify_unsubscribe' . '_index', $this->sources, 'is_notify_unsubscribe');
    $this->createIndex('sources' . '_' . 'trafficback_type' . '_index', $this->sources, 'trafficback_type');

    $this->addForeignKey('sources' . '_' . 'user_id' . '_fk', $this->sources, 'user_id', '{{%users}}', 'id');
    $this->addForeignKey('sources' . '_' . 'stream_id' . '_fk', $this->sources, 'stream_id', $this->streams, 'id');
    $this->addForeignKey('sources' . '_' . 'domain_id' . '_fk', $this->sources, 'domain_id', $this->domains, 'id');


    /*
     * SOURCES OPERATOR LANDINGS
     */
    $this->createTable($this->sourcesOperatorLandings, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'profit_type' => 'TINYINT(1) UNSIGNED DEFAULT 0',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED',
      'is_changed' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'change_description' => $this->text(),
      'landing_choose_type' => 'TINYINT(1) UNSIGNED DEFAULT 0'
    ], $tableOptions);

    $this->createIndex('sources_operator_landings' . '_' . 'profit_type' . '_index', $this->sourcesOperatorLandings, 'profit_type');
    $this->createIndex('sources_operator_landings' . '_' . 'is_changed' . '_index', $this->sourcesOperatorLandings, 'is_changed');
    $this->createIndex('sources_operator_landings' . '_' . 'landing_choose_type' . '_index', $this->sourcesOperatorLandings, 'landing_choose_type');
    $this->createIndex('sources_operator_landings' . '_' . 'source_operator_landing' . '_index', $this->sourcesOperatorLandings, ['source_id', 'operator_id', 'landing_id'], true);

    $this->addForeignKey('sources_operator_landings' . '_' . 'source_id' . '_fk', $this->sourcesOperatorLandings, 'source_id', $this->sources, 'id');
    $this->addForeignKey('sources_operator_landings' . '_' . 'operator_id' . '_fk', $this->sourcesOperatorLandings, 'operator_id', '{{%operators}}', 'id');
    $this->addForeignKey('sources_operator_landings' . '_' . 'landing_id' . '_fk', $this->sourcesOperatorLandings, 'landing_id', '{{%landings}}', 'id');


  }

  public function safeDown()
  {
    $this->dropTable($this->sourcesOperatorLandings);
    $this->dropTable($this->sources);
    $this->dropTable($this->streams);
    $this->dropTable($this->domains);
  }
}
