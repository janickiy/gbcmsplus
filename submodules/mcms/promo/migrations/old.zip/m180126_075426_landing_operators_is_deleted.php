<?php

use console\components\Migration;

class m180126_075426_landing_operators_is_deleted extends Migration
{
  const TABLE = 'landing_operators';

  public function up()
  {
    $this->addColumn(self::TABLE,'is_deleted', $this->smallInteger(1)->notNull()->unsigned()->defaultValue(0));

  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'is_deleted');
  }

}
