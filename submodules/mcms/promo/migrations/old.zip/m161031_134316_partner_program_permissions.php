<?php

use console\components\Migration;

class m161031_134316_partner_program_permissions extends Migration
{
  use \mcms\common\traits\PermissionGroupMigration;

  public function init()
  {
    parent::init();

    $this->groupPermissionName = 'PromoModule';
    $this->groupPermissionDescription = 'Module Promo';
    $this->groupPermissionDefaultRole = ['admin', 'root', 'reseller'];

    $this->groupPermissionControllers = [
      'PromoPartnerProgramsController' => [
        'description' => 'Promo PartnerPrograms Controller',
        'permissions' => [
          ['PromoPartnerProgramsIndex'],
          ['PromoPartnerProgramsCreateModal'],
          ['PromoPartnerProgramsUpdate'],
          ['PromoPartnerProgramsDelete'],
          ['PromoPartnerProgramsLinkPartner'],
          ['PromoPartnerProgramsUnlinkPartner'],
          ['PromoPartnerProgramsLinkPartnerEditable'],
          ['PromoPartnerProgramsSyncPartner'],
          ['PromoPartnerProgramsAutosyncEnable'],
          ['PromoPartnerProgramsAutosyncDisable'],
        ],
      ],
      'PromoPartnerProgramItemsController' => [
        'description' => 'Promo PartnerProgramItems Controller',
        'permissions' => [
          ['PromoPartnerProgramItemsCreateModal'],
          ['PromoPartnerProgramItemsUpdateModal'],
          ['PromoPartnerProgramItemsDelete'],
        ],
      ],
    ];
  }
}
