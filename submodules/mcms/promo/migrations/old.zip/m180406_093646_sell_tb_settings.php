<?php

use console\components\Migration;
use rgk\settings\models\Setting;
use rgk\settings\models\SettingsCategory;

class m180406_093646_sell_tb_settings extends Migration
{
  const PARENT_CATEGORY_KEY = 'app.common.group_links';
  const CATEGORY_KEY = 'app.common.tb_sell';
  const SETTINGS_AFTER_N_HITS = 'settings.sell_tb.after_n_hits';
  const SETTINGS_AFTER_N_HOURS_DAYS = 'settings.sell_tb.after_n_hours_days';
  const SETTINGS_HOURS_DAYS = 'settings.sell_tb.hours_days';
  const SETTINGS_AND_OR = 'settings.sell_tb.and_or';

  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
  }

  public function up()
  {
    /* @var $parentCategory SettingsCategory */
    $parentCategory = SettingsCategory::findByKey(self::PARENT_CATEGORY_KEY);
    $title = ['ru' => 'Параметры продажи ТБ', 'en' => 'Sell TB parameters'];
    $this->settingsBuilder->createCategory($title, self::CATEGORY_KEY, $parentCategory->id);

    $this->settingsBuilder->createSetting(
      ['en' => 'After N hits', 'ru' => 'После N хитов'],
      [],
      self::SETTINGS_AFTER_N_HITS,
      ['EditModuleSettingsPromo'],
      Setting::TYPE_INTEGER,
      self::CATEGORY_KEY,
      '',
      [["integer"]]
    );

    $this->settingsBuilder->createSetting(
      ['en' => 'After N hours/days', 'ru' => 'После N часов/дней'],
      [],
      self::SETTINGS_AFTER_N_HOURS_DAYS,
      ['EditModuleSettingsPromo'],
      Setting::TYPE_INTEGER,
      self::CATEGORY_KEY,
      '',
      [["integer"]]
    );

    $this->settingsBuilder->createSetting(
      ['en' => 'Hours/days', 'ru' => 'Часов/дней'],
      [],
      self::SETTINGS_HOURS_DAYS,
      ['EditModuleSettingsPromo'],
      Setting::TYPE_OPTIONS,
      self::CATEGORY_KEY,
      'hours',
      [["required"]]
    );

    $title = ['ru' => 'часов', 'en' => 'hours'];
    $this->settingsBuilder->createOption($title,self::SETTINGS_HOURS_DAYS, 'hours');

    $title = ['ru' => 'дней', 'en' => 'days'];
    $this->settingsBuilder->createOption($title,self::SETTINGS_HOURS_DAYS, 'days');

    $this->settingsBuilder->createSetting(
      ['en' => 'Or/And', 'ru' => 'И/Или'],
      [],
      self::SETTINGS_AND_OR,
      ['EditModuleSettingsPromo'],
      Setting::TYPE_OPTIONS,
      self::CATEGORY_KEY,
      'and',
      [["required"]]
    );

    $title = ['ru' => 'и', 'en' => 'and'];
    $this->settingsBuilder->createOption($title,self::SETTINGS_AND_OR, 'and');

    $title = ['ru' => 'или', 'en' => 'or'];
    $this->settingsBuilder->createOption($title,self::SETTINGS_AND_OR, 'or');
  }

  public function down()
  {
    $this->settingsBuilder->removeSetting(self::SETTINGS_AFTER_N_HOURS_DAYS);
    $this->settingsBuilder->removeSetting(self::SETTINGS_AFTER_N_HITS);
    $this->settingsBuilder->removeSetting(self::SETTINGS_AND_OR);
    $this->settingsBuilder->removeSetting(self::SETTINGS_HOURS_DAYS);
  }


}
