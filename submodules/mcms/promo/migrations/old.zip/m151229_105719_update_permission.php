<?php

use console\components\Migration;

class m151229_105719_update_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'WebmasterSources' => [
        ['enable-modal', 'Set source status active', ['admin', 'root', 'reseller']],
      ]
    ];
  }
}
