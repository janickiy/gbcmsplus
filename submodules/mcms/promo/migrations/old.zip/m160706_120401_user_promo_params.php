<?php

use console\components\Migration;

class m160706_120401_user_promo_params extends Migration
{

  const TABLE = 'user_promo_settings';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(self::TABLE, [
      'user_id' => 'mediumint(5) unsigned NOT NULL PRIMARY KEY',
      'is_reseller_buyout_prices' => 'tinyint(1) unsigned NOT NULL DEFAULT 0',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }


}
