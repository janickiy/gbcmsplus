<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
*/
class m180920_070751_5digits_cron extends Migration
{
  use PermissionTrait;
  /**
  */
  public function up()
  {
    if (!\mcms\common\helpers\Console::confirm('Нужно отключить кроны и синк. Продолжаем?', true)) {
      return false;
    }

    echo 'landing_operators...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE landing_operators
      CHANGE default_currency_rebill_price default_currency_rebill_price decimal(9, 5) not null,
      CHANGE rebill_price_rub rebill_price_rub decimal(9, 5),
      CHANGE rebill_price_usd rebill_price_usd decimal(9, 5),
      CHANGE rebill_price_eur rebill_price_eur decimal(9, 5);
      ')->execute();

    echo 'search_subscriptions...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE search_subscriptions
      CHANGE sum_real_profit_rub sum_real_profit_rub     decimal(9, 5) unsigned default \'0.00\' null,
      CHANGE sum_real_profit_eur sum_real_profit_eur     decimal(9, 5) unsigned default \'0.00\' null,
      CHANGE sum_real_profit_usd sum_real_profit_usd     decimal(9, 5) unsigned default \'0.00\' null,
      CHANGE sum_reseller_profit_rub sum_reseller_profit_rub decimal(9, 5) unsigned default \'0.00\' null,
      CHANGE sum_reseller_profit_eur sum_reseller_profit_eur decimal(9, 5) unsigned default \'0.00\' null,
      CHANGE sum_reseller_profit_usd sum_reseller_profit_usd decimal(9, 5) unsigned default \'0.00\' null,
      CHANGE sum_profit_rub sum_profit_rub          decimal(9, 5) unsigned default \'0.00\' null,
      CHANGE sum_profit_eur sum_profit_eur          decimal(9, 5) unsigned default \'0.00\' null,
      CHANGE sum_profit_usd sum_profit_usd          decimal(9, 5) unsigned default \'0.00\' null;
      ')->execute();

    echo 'statistic...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE statistic
      CHANGE res_revshare_profit_rub res_revshare_profit_rub       decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_revshare_profit_usd res_revshare_profit_usd       decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE res_revshare_profit_eur res_revshare_profit_eur       decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE res_rejected_profit_rub res_rejected_profit_rub       decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_rejected_profit_usd res_rejected_profit_usd       decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE res_rejected_profit_eur res_rejected_profit_eur       decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE res_sold_profit_rub res_sold_profit_rub           decimal(10, 5) unsigned default \'0.00\' not null,
      CHANGE res_sold_profit_usd res_sold_profit_usd           decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE res_sold_profit_eur res_sold_profit_eur           decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit_rub partner_revshare_profit_rub   decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit_usd partner_revshare_profit_usd   decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit_eur partner_revshare_profit_eur   decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit24_rub partner_revshare_profit24_rub decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit24_usd partner_revshare_profit24_usd decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit24_eur partner_revshare_profit24_eur decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE partner_rejected_profit24_rub partner_rejected_profit24_rub decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_rejected_profit24_usd partner_rejected_profit24_usd decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE partner_rejected_profit24_eur partner_rejected_profit24_eur decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE partner_sold_profit24_rub partner_sold_profit24_rub     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_sold_profit24_usd partner_sold_profit24_usd     decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE partner_sold_profit24_eur partner_sold_profit24_eur     decimal(9, 5) unsigned default \'0.00\' not null
      ')->execute();

    echo 'sold_subscriptions...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE sold_subscriptions
      CHANGE real_price_rub real_price_rub        decimal(9, 5) unsigned                not null,
      CHANGE real_price_eur real_price_eur        decimal(9, 5) unsigned                not null,
      CHANGE real_price_usd real_price_usd        decimal(9, 5) unsigned                not null,
      CHANGE reseller_price_rub reseller_price_rub    decimal(9, 5) unsigned                not null,
      CHANGE reseller_price_eur reseller_price_eur    decimal(9, 5) unsigned                not null,
      CHANGE reseller_price_usd reseller_price_usd    decimal(9, 5) unsigned                not null,
      CHANGE price_rub price_rub             decimal(9, 5) unsigned                not null,
      CHANGE price_eur price_eur             decimal(9, 5) unsigned                not null,
      CHANGE price_usd price_usd             decimal(9, 5) unsigned                not null,
      CHANGE profit_rub profit_rub            decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE profit_eur profit_eur            decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE profit_usd profit_usd            decimal(9, 5) unsigned default \'0.00\' not null
      ')->execute();

    echo 'user_balances_grouped_by_day...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE user_balances_grouped_by_day
      CHANGE profit_rub profit_rub    decimal(11, 5)             not null,
      CHANGE profit_eur profit_eur    decimal(11, 5)             not null,
      CHANGE profit_usd profit_usd    decimal(11, 5)             not null
      ')->execute();

    echo 'reseller_profits...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE reseller_profits
      CHANGE profit_rub profit_rub              decimal(13, 5) unsigned default \'0.00\' not null comment \'Сумма профита RUB\',
      CHANGE profit_revshare_rub profit_revshare_rub     decimal(13, 5) unsigned default \'0.00\' null,
      CHANGE profit_cpa_sold_rub profit_cpa_sold_rub     decimal(13, 5) unsigned default \'0.00\' null,
      CHANGE profit_cpa_rejected_rub profit_cpa_rejected_rub decimal(13, 5) unsigned default \'0.00\' null,
      CHANGE profit_onetime_rub profit_onetime_rub      decimal(13, 5) unsigned default \'0.00\' null,
      CHANGE profit_usd profit_usd              decimal(13, 5) unsigned default \'0.00\' not null comment \'Сумма профита USD\',
      CHANGE profit_revshare_usd profit_revshare_usd     decimal(13, 5) unsigned default \'0.00\' null,
      CHANGE profit_cpa_sold_usd profit_cpa_sold_usd     decimal(13, 5) unsigned default \'0.00\' null,
      CHANGE profit_cpa_rejected_usd profit_cpa_rejected_usd decimal(13, 5) unsigned default \'0.00\' null,
      CHANGE profit_onetime_usd profit_onetime_usd      decimal(13, 5) unsigned default \'0.00\' null,
      CHANGE profit_eur profit_eur              decimal(13, 5) unsigned default \'0.00\' not null comment \'Сумма профита EUR\',
      CHANGE profit_revshare_eur profit_revshare_eur     decimal(13, 5) unsigned default \'0.00\' null,
      CHANGE profit_cpa_sold_eur profit_cpa_sold_eur     decimal(13, 5) unsigned default \'0.00\' null,
      CHANGE profit_cpa_rejected_eur profit_cpa_rejected_eur decimal(13, 5) unsigned default \'0.00\' null,
      CHANGE profit_onetime_eur profit_onetime_eur      decimal(13, 5) unsigned default \'0.00\' null
      ')->execute();

    echo 'reseller_profit_statistics...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE reseller_profit_statistics
      CHANGE rebills_reseller_profit rebills_reseller_profit decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE onetime_reseller_profit onetime_reseller_profit decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE rebills_profit rebills_profit          decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE onetime_profit onetime_profit          decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE sold_profit sold_profit             decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE sold_real_profit sold_real_profit        decimal(12, 5) unsigned default \'0.00\' not null
      ')->execute();

    echo 'statistic_data_hour_group...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE statistic_data_hour_group
      CHANGE sum_profit_rub_date_by_date sum_profit_rub_date_by_date decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE sum_profit_eur_date_by_date sum_profit_eur_date_by_date decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE sum_profit_usd_date_by_date sum_profit_usd_date_by_date decimal(12, 5) unsigned default \'0.00\' not null
      ')->execute();

    echo 'subscriptions_day_hour_group...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE subscriptions_day_hour_group
      CHANGE sum_real_profit_rub sum_real_profit_rub     decimal(11, 5) unsigned            not null,
      CHANGE sum_real_profit_eur sum_real_profit_eur     decimal(9, 5) unsigned            not null,
      CHANGE sum_real_profit_usd sum_real_profit_usd     decimal(9, 5) unsigned            not null,
      CHANGE sum_reseller_profit_rub sum_reseller_profit_rub decimal(11, 5) unsigned            not null,
      CHANGE sum_reseller_profit_eur sum_reseller_profit_eur decimal(9, 5) unsigned            not null,
      CHANGE sum_reseller_profit_usd sum_reseller_profit_usd decimal(9, 5) unsigned            not null,
      CHANGE sum_profit_rub sum_profit_rub          decimal(11, 5) unsigned            not null,
      CHANGE sum_profit_eur sum_profit_eur          decimal(9, 5) unsigned            not null,
      CHANGE sum_profit_usd sum_profit_usd          decimal(9, 5) unsigned            not null
      ')->execute();

    echo 'subscriptions_day_group...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE subscriptions_day_group
      CHANGE sum_real_profit_rub sum_real_profit_rub     decimal(12, 5) unsigned            not null,
      CHANGE sum_real_profit_eur sum_real_profit_eur     decimal(10, 5) unsigned            not null,
      CHANGE sum_real_profit_usd sum_real_profit_usd     decimal(10, 5) unsigned            not null,
      CHANGE sum_reseller_profit_rub sum_reseller_profit_rub decimal(12, 5) unsigned            not null,
      CHANGE sum_reseller_profit_eur sum_reseller_profit_eur decimal(10, 5) unsigned            not null,
      CHANGE sum_reseller_profit_usd sum_reseller_profit_usd decimal(10, 5) unsigned            not null,
      CHANGE sum_profit_rub sum_profit_rub          decimal(12, 5) unsigned            not null,
      CHANGE sum_profit_eur sum_profit_eur          decimal(10, 5) unsigned            not null,
      CHANGE sum_profit_usd sum_profit_usd          decimal(10, 5) unsigned            not null
      ')->execute();

    echo 'dashboard_profits_ons...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE dashboard_profits_ons
      CHANGE real_onetime_profit_rub real_onetime_profit_rub     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE real_onetime_profit_usd real_onetime_profit_usd     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE real_onetime_profit_eur real_onetime_profit_eur     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE real_sold_tb_profit_rub real_sold_tb_profit_rub     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE real_sold_tb_profit_usd real_sold_tb_profit_usd     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE real_sold_tb_profit_eur real_sold_tb_profit_eur     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_onetime_profit_rub res_onetime_profit_rub      decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_onetime_profit_usd res_onetime_profit_usd      decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_onetime_profit_eur res_onetime_profit_eur      decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_sold_tb_profit_rub res_sold_tb_profit_rub      decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_sold_tb_profit_usd res_sold_tb_profit_usd      decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_sold_tb_profit_eur res_sold_tb_profit_eur      decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_onetime_profit_rub partner_onetime_profit_rub  decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_onetime_profit_usd partner_onetime_profit_usd  decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_onetime_profit_eur partner_onetime_profit_eur  decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_sold_profit_rub partner_sold_profit_rub     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_sold_profit_usd partner_sold_profit_usd     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_sold_profit_eur partner_sold_profit_eur     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_sold_tb_profit_rub partner_sold_tb_profit_rub  decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_sold_tb_profit_usd partner_sold_tb_profit_usd  decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_sold_tb_profit_eur partner_sold_tb_profit_eur  decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_revshare_profit_rub res_revshare_profit_rub     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_revshare_profit_usd res_revshare_profit_usd     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_revshare_profit_eur res_revshare_profit_eur     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_rejected_profit_rub res_rejected_profit_rub     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_rejected_profit_usd res_rejected_profit_usd     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_rejected_profit_eur res_rejected_profit_eur     decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_sold_profit_rub res_sold_profit_rub         decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_sold_profit_usd res_sold_profit_usd         decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE res_sold_profit_eur res_sold_profit_eur         decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit_rub partner_revshare_profit_rub decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit_usd partner_revshare_profit_usd decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit_eur partner_revshare_profit_eur decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_rejected_profit_rub partner_rejected_profit_rub decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_rejected_profit_usd partner_rejected_profit_usd decimal(12, 5) unsigned default \'0.00\' not null,
      CHANGE partner_rejected_profit_eur partner_rejected_profit_eur decimal(12, 5) unsigned default \'0.00\' not null
      ')->execute();

    echo 'referral_incomes...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE referral_incomes
      CHANGE profit_rub profit_rub       decimal(11, 5)         not null,
      CHANGE profit_eur profit_eur       decimal(11, 5)         not null,
      CHANGE profit_usd profit_usd       decimal(11, 5)         not null
      ')->execute();

    echo 'statistic_day_user_group...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE statistic_day_user_group
      CHANGE sum_rebill_profit_rub sum_rebill_profit_rub  decimal(12, 5) unsigned            not null,
      CHANGE sum_rebill_profit_eur sum_rebill_profit_eur  decimal(12, 5) unsigned            not null,
      CHANGE sum_rebill_profit_usd sum_rebill_profit_usd  decimal(12, 5) unsigned            not null,
      CHANGE sum_onetime_profit_rub sum_onetime_profit_rub decimal(12, 5) unsigned            not null,
      CHANGE sum_onetime_profit_eur sum_onetime_profit_eur decimal(12, 5) unsigned            not null,
      CHANGE sum_onetime_profit_usd sum_onetime_profit_usd decimal(12, 5) unsigned            not null,
      CHANGE sum_sold_profit_rub sum_sold_profit_rub    decimal(12, 5) unsigned            not null,
      CHANGE sum_sold_profit_eur sum_sold_profit_eur    decimal(12, 5) unsigned            not null,
      CHANGE sum_sold_profit_usd sum_sold_profit_usd    decimal(12, 5) unsigned            not null
      ')->execute();

    echo 'statistic_label_group_1...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE statistic_label_group_1
      CHANGE sum_profit_rub sum_profit_rub      decimal(11, 5) unsigned default \'0.00\' not null,
      CHANGE sum_profit_eur sum_profit_eur      decimal(9, 5) unsigned default \'0.00\' not null,
      CHANGE sum_profit_usd sum_profit_usd      decimal(9, 5) unsigned default \'0.00\' not null
      ')->execute();

  }

  /**
  */
  public function down()
  {
    if (!\mcms\common\helpers\Console::confirm('Нужно отключить кроны и синк. Продолжаем?', true)) {
      return false;
    }

    echo 'statistic_day_user_group...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE statistic_day_user_group
      CHANGE sum_rebill_profit_rub sum_rebill_profit_rub  decimal(10, 3) unsigned            not null,
      CHANGE sum_rebill_profit_eur sum_rebill_profit_eur  decimal(10, 3) unsigned            not null,
      CHANGE sum_rebill_profit_usd sum_rebill_profit_usd  decimal(10, 3) unsigned            not null,
      CHANGE sum_onetime_profit_rub sum_onetime_profit_rub decimal(10, 3) unsigned            not null,
      CHANGE sum_onetime_profit_eur sum_onetime_profit_eur decimal(10, 3) unsigned            not null,
      CHANGE sum_onetime_profit_usd sum_onetime_profit_usd decimal(10, 3) unsigned            not null,
      CHANGE sum_sold_profit_rub sum_sold_profit_rub    decimal(10, 3) unsigned            not null,
      CHANGE sum_sold_profit_eur sum_sold_profit_eur    decimal(10, 3) unsigned            not null,
      CHANGE sum_sold_profit_usd sum_sold_profit_usd    decimal(10, 3) unsigned            not null
      ')->execute();

    echo 'referral_incomes...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE referral_incomes
      CHANGE profit_rub profit_rub       decimal(9, 3)         not null,
      CHANGE profit_eur profit_eur       decimal(9, 3)         not null,
      CHANGE profit_usd profit_usd       decimal(9, 3)         not null
      ')->execute();

    echo 'dashboard_profits_ons...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE dashboard_profits_ons
      CHANGE real_onetime_profit_rub real_onetime_profit_rub     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE real_onetime_profit_usd real_onetime_profit_usd     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE real_onetime_profit_eur real_onetime_profit_eur     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE real_sold_tb_profit_rub real_sold_tb_profit_rub     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE real_sold_tb_profit_usd real_sold_tb_profit_usd     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE real_sold_tb_profit_eur real_sold_tb_profit_eur     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_onetime_profit_rub res_onetime_profit_rub      decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_onetime_profit_usd res_onetime_profit_usd      decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_onetime_profit_eur res_onetime_profit_eur      decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_sold_tb_profit_rub res_sold_tb_profit_rub      decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_sold_tb_profit_usd res_sold_tb_profit_usd      decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_sold_tb_profit_eur res_sold_tb_profit_eur      decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_onetime_profit_rub partner_onetime_profit_rub  decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_onetime_profit_usd partner_onetime_profit_usd  decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_onetime_profit_eur partner_onetime_profit_eur  decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_sold_profit_rub partner_sold_profit_rub     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_sold_profit_usd partner_sold_profit_usd     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_sold_profit_eur partner_sold_profit_eur     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_sold_tb_profit_rub partner_sold_tb_profit_rub  decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_sold_tb_profit_usd partner_sold_tb_profit_usd  decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_sold_tb_profit_eur partner_sold_tb_profit_eur  decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_revshare_profit_rub res_revshare_profit_rub     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_revshare_profit_usd res_revshare_profit_usd     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_revshare_profit_eur res_revshare_profit_eur     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_rejected_profit_rub res_rejected_profit_rub     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_rejected_profit_usd res_rejected_profit_usd     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_rejected_profit_eur res_rejected_profit_eur     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_sold_profit_rub res_sold_profit_rub         decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_sold_profit_usd res_sold_profit_usd         decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_sold_profit_eur res_sold_profit_eur         decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit_rub partner_revshare_profit_rub decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit_usd partner_revshare_profit_usd decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit_eur partner_revshare_profit_eur decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_rejected_profit_rub partner_rejected_profit_rub decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_rejected_profit_usd partner_rejected_profit_usd decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_rejected_profit_eur partner_rejected_profit_eur decimal(10, 3) unsigned default \'0.00\' not null
      ')->execute();

    echo 'subscriptions_day_group...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE subscriptions_day_group
      CHANGE sum_real_profit_rub sum_real_profit_rub     decimal(10, 3) unsigned            not null,
      CHANGE sum_real_profit_eur sum_real_profit_eur     decimal(8, 3) unsigned            not null,
      CHANGE sum_real_profit_usd sum_real_profit_usd     decimal(8, 3) unsigned            not null,
      CHANGE sum_reseller_profit_rub sum_reseller_profit_rub decimal(10, 3) unsigned            not null,
      CHANGE sum_reseller_profit_eur sum_reseller_profit_eur decimal(8, 3) unsigned            not null,
      CHANGE sum_reseller_profit_usd sum_reseller_profit_usd decimal(8, 3) unsigned            not null,
      CHANGE sum_profit_rub sum_profit_rub          decimal(10, 3) unsigned            not null,
      CHANGE sum_profit_eur sum_profit_eur          decimal(8, 3) unsigned            not null,
      CHANGE sum_profit_usd sum_profit_usd          decimal(8, 3) unsigned            not null
      ')->execute();

    echo 'subscriptions_day_hour_group...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE subscriptions_day_hour_group
      CHANGE sum_real_profit_rub sum_real_profit_rub     decimal(9, 3) unsigned            not null,
      CHANGE sum_real_profit_eur sum_real_profit_eur     decimal(7, 3) unsigned            not null,
      CHANGE sum_real_profit_usd sum_real_profit_usd     decimal(7, 3) unsigned            not null,
      CHANGE sum_reseller_profit_rub sum_reseller_profit_rub decimal(9, 3) unsigned            not null,
      CHANGE sum_reseller_profit_eur sum_reseller_profit_eur decimal(7, 3) unsigned            not null,
      CHANGE sum_reseller_profit_usd sum_reseller_profit_usd decimal(7, 3) unsigned            not null,
      CHANGE sum_profit_rub sum_profit_rub          decimal(9, 3) unsigned            not null,
      CHANGE sum_profit_eur sum_profit_eur          decimal(7, 3) unsigned            not null,
      CHANGE sum_profit_usd sum_profit_usd          decimal(7, 3) unsigned            not null
      ')->execute();

    echo 'statistic_label_group_1...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE statistic_label_group_1
      CHANGE sum_profit_rub sum_profit_rub      decimal(9, 3) unsigned default \'0.00\' not null,
      CHANGE sum_profit_eur sum_profit_eur      decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE sum_profit_usd sum_profit_usd      decimal(7, 3) unsigned default \'0.00\' not null
      ')->execute();


    echo 'statistic_data_hour_group...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE statistic_data_hour_group
      CHANGE sum_profit_rub_date_by_date sum_profit_rub_date_by_date decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE sum_profit_eur_date_by_date sum_profit_eur_date_by_date decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE sum_profit_usd_date_by_date sum_profit_usd_date_by_date decimal(10, 3) unsigned default \'0.00\' not null
      ')->execute();

    echo 'reseller_profit_statistics...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE reseller_profit_statistics
      CHANGE rebills_reseller_profit rebills_reseller_profit decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE onetime_reseller_profit onetime_reseller_profit decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE rebills_profit rebills_profit          decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE onetime_profit onetime_profit          decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE sold_profit sold_profit             decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE sold_real_profit sold_real_profit        decimal(10, 3) unsigned default \'0.00\' not null
      ')->execute();

    echo 'reseller_profits...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE reseller_profits
      CHANGE profit_rub profit_rub              decimal(11, 3) unsigned default \'0.00\' not null comment \'Сумма профита RUB\',
      CHANGE profit_revshare_rub profit_revshare_rub     decimal(11, 3) unsigned default \'0.00\' null,
      CHANGE profit_cpa_sold_rub profit_cpa_sold_rub     decimal(11, 3) unsigned default \'0.00\' null,
      CHANGE profit_cpa_rejected_rub profit_cpa_rejected_rub decimal(11, 3) unsigned default \'0.00\' null,
      CHANGE profit_onetime_rub profit_onetime_rub      decimal(11, 3) unsigned default \'0.00\' null,
      CHANGE profit_usd profit_usd              decimal(11, 3) unsigned default \'0.00\' not null comment \'Сумма профита USD\',
      CHANGE profit_revshare_usd profit_revshare_usd     decimal(11, 3) unsigned default \'0.00\' null,
      CHANGE profit_cpa_sold_usd profit_cpa_sold_usd     decimal(11, 3) unsigned default \'0.00\' null,
      CHANGE profit_cpa_rejected_usd profit_cpa_rejected_usd decimal(11, 3) unsigned default \'0.00\' null,
      CHANGE profit_onetime_usd profit_onetime_usd      decimal(11, 3) unsigned default \'0.00\' null,
      CHANGE profit_eur profit_eur              decimal(11, 3) unsigned default \'0.00\' not null comment \'Сумма профита EUR\',
      CHANGE profit_revshare_eur profit_revshare_eur     decimal(11, 3) unsigned default \'0.00\' null,
      CHANGE profit_cpa_sold_eur profit_cpa_sold_eur     decimal(11, 3) unsigned default \'0.00\' null,
      CHANGE profit_cpa_rejected_eur profit_cpa_rejected_eur decimal(11, 3) unsigned default \'0.00\' null,
      CHANGE profit_onetime_eur profit_onetime_eur      decimal(11, 3) unsigned default \'0.00\' null
      ')->execute();

    echo 'user_balances_grouped_by_day...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE user_balances_grouped_by_day
      CHANGE profit_rub profit_rub    decimal(9, 3)             not null,
      CHANGE profit_eur profit_eur    decimal(9, 3)             not null,
      CHANGE profit_usd profit_usd    decimal(9, 3)             not null
      ')->execute();

    echo 'sold_subscriptions...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE sold_subscriptions
      CHANGE real_price_rub real_price_rub        decimal(7, 3) unsigned                not null,
      CHANGE real_price_eur real_price_eur        decimal(7, 3) unsigned                not null,
      CHANGE real_price_usd real_price_usd        decimal(7, 3) unsigned                not null,
      CHANGE reseller_price_rub reseller_price_rub    decimal(7, 3) unsigned                not null,
      CHANGE reseller_price_eur reseller_price_eur    decimal(7, 3) unsigned                not null,
      CHANGE reseller_price_usd reseller_price_usd    decimal(7, 3) unsigned                not null,
      CHANGE price_rub price_rub             decimal(7, 3) unsigned                not null,
      CHANGE price_eur price_eur             decimal(7, 3) unsigned                not null,
      CHANGE price_usd price_usd             decimal(7, 3) unsigned                not null,
      CHANGE profit_rub profit_rub            decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE profit_eur profit_eur            decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE profit_usd profit_usd            decimal(7, 3) unsigned default \'0.00\' not null
      ')->execute();

    echo 'statistic...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE statistic
      CHANGE res_revshare_profit_rub res_revshare_profit_rub       decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_revshare_profit_usd res_revshare_profit_usd       decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE res_revshare_profit_eur res_revshare_profit_eur       decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE res_rejected_profit_rub res_rejected_profit_rub       decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_rejected_profit_usd res_rejected_profit_usd       decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE res_rejected_profit_eur res_rejected_profit_eur       decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE res_sold_profit_rub res_sold_profit_rub           decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE res_sold_profit_usd res_sold_profit_usd           decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE res_sold_profit_eur res_sold_profit_eur           decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit_rub partner_revshare_profit_rub   decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit_usd partner_revshare_profit_usd   decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit_eur partner_revshare_profit_eur   decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit24_rub partner_revshare_profit24_rub decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit24_usd partner_revshare_profit24_usd decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE partner_revshare_profit24_eur partner_revshare_profit24_eur decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE partner_rejected_profit24_rub partner_rejected_profit24_rub decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_rejected_profit24_usd partner_rejected_profit24_usd decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE partner_rejected_profit24_eur partner_rejected_profit24_eur decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE partner_sold_profit24_rub partner_sold_profit24_rub     decimal(10, 3) unsigned default \'0.00\' not null,
      CHANGE partner_sold_profit24_usd partner_sold_profit24_usd     decimal(7, 3) unsigned default \'0.00\' not null,
      CHANGE partner_sold_profit24_eur partner_sold_profit24_eur     decimal(7, 3) unsigned default \'0.00\' not null
      ')->execute();

    echo 'search_subscriptions...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE search_subscriptions
      CHANGE sum_real_profit_rub sum_real_profit_rub     decimal(7, 3) unsigned default \'0.00\' null,
      CHANGE sum_real_profit_eur sum_real_profit_eur     decimal(7, 3) unsigned default \'0.00\' null,
      CHANGE sum_real_profit_usd sum_real_profit_usd     decimal(7, 3) unsigned default \'0.00\' null,
      CHANGE sum_reseller_profit_rub sum_reseller_profit_rub decimal(7, 3) unsigned default \'0.00\' null,
      CHANGE sum_reseller_profit_eur sum_reseller_profit_eur decimal(7, 3) unsigned default \'0.00\' null,
      CHANGE sum_reseller_profit_usd sum_reseller_profit_usd decimal(7, 3) unsigned default \'0.00\' null,
      CHANGE sum_profit_rub sum_profit_rub          decimal(7, 3) unsigned default \'0.00\' null,
      CHANGE sum_profit_eur sum_profit_eur          decimal(7, 3) unsigned default \'0.00\' null,
      CHANGE sum_profit_usd sum_profit_usd          decimal(7, 3) unsigned default \'0.00\' null;
      ')->execute();

    echo 'landing_operators...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE landing_operators
      CHANGE default_currency_rebill_price default_currency_rebill_price decimal(10, 3) not null,
      CHANGE rebill_price_rub rebill_price_rub decimal(7, 3),
      CHANGE rebill_price_usd rebill_price_usd decimal(7, 3),
      CHANGE rebill_price_eur rebill_price_eur decimal(7, 3);
      ')->execute();
  }
}
