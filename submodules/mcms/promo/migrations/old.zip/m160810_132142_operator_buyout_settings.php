<?php

use console\components\Migration;

class m160810_132142_operator_buyout_settings extends Migration
{
  const TABLE = 'operators';

  public function up()
  {
    $this->addColumn(self::TABLE, 'buyout_minutes', 'mediumint(5) unsigned AFTER status');
    $this->addColumn(self::TABLE, 'is_buyout_only_after_1st_rebill', 'tinyint(1) unsigned AFTER buyout_minutes');
    $this->addColumn(self::TABLE, 'is_buyout_only_unique_phone', 'tinyint(1) unsigned AFTER is_buyout_only_after_1st_rebill');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'buyout_minutes');
    $this->dropColumn(self::TABLE, 'is_buyout_only_after_1st_rebill');
    $this->dropColumn(self::TABLE, 'is_buyout_only_unique_phone');
  }
}
