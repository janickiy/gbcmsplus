<?php

use console\components\Migration;

class m170720_120101_source_preland_blocked_operators extends Migration
{
  const TABLE_SOURCE_BLOCKED_OPERATORS = 'source_blocked_operators';
  const TABLE_SOURCE_ADD_PRELAND_OPERATORS = 'source_add_preland_operators';
  const TABLE_SOURCE_OFF_PRELAND_OPERATORS = 'source_off_preland_operators';

  public function up()
  {

    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(static::TABLE_SOURCE_BLOCKED_OPERATORS, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
    ], $tableOptions);

    $this->createTable(static::TABLE_SOURCE_ADD_PRELAND_OPERATORS, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
    ], $tableOptions);

    $this->createTable(static::TABLE_SOURCE_OFF_PRELAND_OPERATORS, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
    ], $tableOptions);

    $this->createIndex(static::TABLE_SOURCE_BLOCKED_OPERATORS . '_uq',
      static::TABLE_SOURCE_BLOCKED_OPERATORS,
      ['source_id', 'operator_id'],
      true);
    $this->addForeignKey(static::TABLE_SOURCE_BLOCKED_OPERATORS . 'source_id_fk',
      static::TABLE_SOURCE_BLOCKED_OPERATORS,
      'source_id',
      'sources',
      'id');
    $this->addForeignKey(static::TABLE_SOURCE_BLOCKED_OPERATORS . 'operator_id_fk',
      static::TABLE_SOURCE_BLOCKED_OPERATORS,
      'operator_id',
      'operators',
      'id');

    $this->createIndex(static::TABLE_SOURCE_ADD_PRELAND_OPERATORS . '_uq',
      static::TABLE_SOURCE_ADD_PRELAND_OPERATORS,
      ['source_id', 'operator_id'],
      true);
    $this->addForeignKey(static::TABLE_SOURCE_ADD_PRELAND_OPERATORS . 'source_id_fk',
      static::TABLE_SOURCE_ADD_PRELAND_OPERATORS,
      'source_id',
      'sources',
      'id');
    $this->addForeignKey(static::TABLE_SOURCE_ADD_PRELAND_OPERATORS . 'operator_id_fk',
      static::TABLE_SOURCE_ADD_PRELAND_OPERATORS,
      'operator_id',
      'operators',
      'id');

    $this->createIndex(static::TABLE_SOURCE_OFF_PRELAND_OPERATORS . '_uq',
      static::TABLE_SOURCE_OFF_PRELAND_OPERATORS,
      ['source_id', 'operator_id'],
      true);
    $this->addForeignKey(static::TABLE_SOURCE_OFF_PRELAND_OPERATORS . 'source_id_fk',
      static::TABLE_SOURCE_OFF_PRELAND_OPERATORS,
      'source_id',
      'sources',
      'id');
    $this->addForeignKey(static::TABLE_SOURCE_OFF_PRELAND_OPERATORS . 'operator_id_fk',
      static::TABLE_SOURCE_OFF_PRELAND_OPERATORS,
      'operator_id',
      'operators',
      'id');


    $reader = $this->db->createCommand('SELECT id, operator_blocked, add_operator_preland, off_operator_preland FROM sources')->query();
    foreach ($reader->readAll() as $source) {

      $blockedOperators = unserialize($source['operator_blocked']);
      $addOperatorPreland = unserialize($source['add_operator_preland']);
      $offOperatorPreland = unserialize($source['off_operator_preland']);

      $operatorIds = $this->db->createCommand('SELECT id FROM operators')->queryColumn('id');
      if ($blockedOperators) {
        $blockedSourceOperators = [];
        foreach ($blockedOperators as $operatorId) {
          if (in_array($operatorId, $operatorIds)) $blockedSourceOperators[] = [$source['id'], $operatorId];
        }
        if (!empty($blockedSourceOperators)) {
          $this->batchInsert(static::TABLE_SOURCE_BLOCKED_OPERATORS, ['source_id', 'operator_id'], $blockedSourceOperators);
        }
      }

      if ($addOperatorPreland) {
        $addPrelandSourceOperators = [];
        foreach ($addOperatorPreland as $operatorId) {
          if (in_array($operatorId, $operatorIds)) $addPrelandSourceOperators[] = [$source['id'], $operatorId];
        }
        if (!empty($addPrelandSourceOperators)) {
          $this->batchInsert(static::TABLE_SOURCE_ADD_PRELAND_OPERATORS, ['source_id', 'operator_id'], $addPrelandSourceOperators);
        }
      }

      if ($offOperatorPreland) {
        $offPrelandSourceOperators = [];
        foreach ($offOperatorPreland as $operatorId) {
          if (in_array($operatorId, $operatorIds)) $offPrelandSourceOperators[] = [$source['id'], $operatorId];
        }
        if (!empty($offOperatorPreland)) {
          $this->batchInsert(static::TABLE_SOURCE_OFF_PRELAND_OPERATORS, ['source_id', 'operator_id'], $offPrelandSourceOperators);
        }
      }

    }

    $this->renameColumn('sources', 'operator_blocked', '_operator_blocked');
    $this->renameColumn('sources', 'add_operator_preland', '_add_operator_preland');
    $this->renameColumn('sources', 'off_operator_preland', '_off_operator_preland');

  }

  public function down()
  {
    $this->dropTable(static::TABLE_SOURCE_BLOCKED_OPERATORS);
    $this->dropTable(static::TABLE_SOURCE_ADD_PRELAND_OPERATORS);
    $this->dropTable(static::TABLE_SOURCE_OFF_PRELAND_OPERATORS);

    $this->renameColumn('sources', '_operator_blocked', 'operator_blocked');
    $this->renameColumn('sources', '_add_operator_preland', 'add_operator_preland');
    $this->renameColumn('sources', '_off_operator_preland', 'off_operator_preland');

  }

}
