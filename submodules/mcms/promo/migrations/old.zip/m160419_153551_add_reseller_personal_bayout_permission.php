<?php

use console\components\Migration;

class m160419_153551_add_reseller_personal_bayout_permission extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->assignRolesPermission('PromoCanViewOwnPersonalProfitsWidget', ['reseller', 'admin', 'root']);
  }

  public function down()
  {
    $this->removePermission('PromoCanViewOwnPersonalProfitsWidget', ['admin', 'root']);
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
