<?php

use console\components\Migration;

class m180521_083449_service_url_on extends Migration
{
  public function up()
  {
    $this->update('operators', ['show_service_url' => 1]);
  }

  public function down()
  {
    echo 'can not correctly restore data';
  }
}
