<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170818_090009_remove_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->removePermission('PromoDomainsFindUser');
    $this->removePermission('PromoStreamsFindUser');
  }

  public function down()
  {
    $this->createPermission('PromoDomainsFindUser', 'Поиск пользователя', 'PromoDomainsController', ['root', 'admin', 'reseller']);
    $this->createPermission('PromoStreamsFindUser', 'Поиск пользователя', 'PromoStreamsController', ['root', 'admin', 'reseller']);
  }
}
