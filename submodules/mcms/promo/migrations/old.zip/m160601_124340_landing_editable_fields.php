<?php

use console\components\Migration;

class m160601_124340_landing_editable_fields extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $controllerPermission = $this->authManager->getPermission('PromoLandingsController');

    $updateStatusPermission = $this->createOrGetPermission('PromoLandingsUpdateEditable', 'Update landing editable fields');
    $this->authManager->addChild($controllerPermission, $updateStatusPermission);
    $this->assignRolesPermission('PromoLandingsUpdateEditable', ['root', 'admin', 'reseller', 'manager']);

    $this->addColumn('landings', 'allow_sync_status', 'tinyint(1) unsigned NOT NULL DEFAULT \'1\' after allow_sync_buyout_prices');
    $this->addColumn('landings', 'allow_sync_access_type', 'tinyint(1) unsigned NOT NULL DEFAULT \'1\' after allow_sync_status');
  }

  public function down()
  {
    $this->removePermission('PromoLandingsUpdateEditable');
    $this->dropColumn('landings', 'allow_sync_status');
    $this->dropColumn('landings', 'allow_sync_access_type');
  }
}
