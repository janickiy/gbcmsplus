<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

/**
 * Группировка прав модуля Промо
 */
class m161117_065825_promo_permissions_tb extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('PromoCanManageTbProvidersWithoutCanSellTb', 'Управление ТБ провайдерами без разрешения на продажу ТБ', 'PromoPermissions', ['admin', 'root']);
  }

  public function down()
  {
    $this->removePermission('PromoCanManageTbProvidersWithoutCanSellTb');
  }
}
