<?php

use console\components\Migration;

class m151228_161401_postback_url_length extends Migration
{
  public function up()
  {
    $this->alterColumn('sources', 'postback_url', 'varchar(512)');
    $this->alterColumn('sources', 'is_notify_sell', "tinyint(1) unsigned NOT NULL DEFAULT '0' AFTER is_notify_unsubscribe");
  }

  public function down()
  {
    $this->alterColumn('sources', 'postback_url', 'varchar(255)');
  }
}
