<?php

use console\components\Migration;

class m160923_091637_click_n_confirm extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    parent::init();
  }


  public function up()
  {
    $this->insert('ads_types', [
      'code' => 'click_n_confirm',
      'name' => serialize([
        'ru' => 'Click&Confirm',
        'en' => 'Click&Confirm'
      ]),
      'description' => serialize([
        'ru' => 'ClickUnder с confirm-сообщением',
        'en' => 'ClickUnder with confirm'
      ]),
      'is_default' => 0,
      'status' => 1,
      'security' => 5,
      'profit' => 4,
      'created_at' => time(),
      'updated_at' => time(),
      'created_by' => 1,
      'updated_by' => 1
    ]);

    $this->addColumn('landing_categories', 'click_n_confirm_text', 'text');

    $this->createOrGetPermission('CanEditLandingCategoryClickNConfirmText', 'Can user view can edit landing category click&confirm text');
    $this->assignRolesPermission('CanEditLandingCategoryClickNConfirmText', ['admin', 'root', 'reseller']);
    $this->createOrGetPermission('PromoCanEditDefaultClickNConfirmText', 'Can user edit click&confirm text in module settings');
    $this->assignRolesPermission('PromoCanEditDefaultClickNConfirmText', ['admin', 'root', 'reseller']);
  }

  public function down()
  {
    $this->delete('ads_types', ['code' => 'click_n_confirm']);
    $this->dropColumn('landing_categories', 'click_n_confirm_text');
    $this->removePermission('CanEditLandingCategoryClickNConfirmText');
    $this->removePermission('PromoCanEditDefaultClickNConfirmText');
  }
}
