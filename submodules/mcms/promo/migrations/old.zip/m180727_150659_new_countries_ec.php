<?php

use console\components\Migration;

/**
*/
class m180727_150659_new_countries_ec extends Migration
{

  /**
   */
  public function up()
  {
    $this->db->createCommand('
          INSERT INTO countries (id, name, status, code, currency, created_at)
          VALUES (:id, :name, :status, :code, :currency, :created_at)
          ON DUPLICATE KEY UPDATE currency=VALUES(currency)', [
      ':id' => 122,
      ':name' => 'Ecuador',
      ':status' => 0,
      ':code' => 'EC',
      ':currency' => 'eur',
      ':created_at' => time(),
    ])->execute();
  }

  /**
   */
  public function down()
  {
    echo "m180727_150659_new_countries_ec cannot be reverted.\n";

    return true;
  }
}
