<?php

use yii\db\Schema;
use console\components\Migration;

class m160225_094855_update_source_table_reject_reason extends Migration
{

  protected $sourceTable = 'sources';

  public function up()
  {
    $this->addColumn($this->sourceTable, 'reject_reason', 'TEXT');
  }

  public function down()
  {
    $this->dropColumn($this->sourceTable, 'reject_reason');
  }

}
