<?php

use console\components\Migration;

class m160601_120710_ads_types_description_upd extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->getAuthManager();
  }


  public function up()
  {

    $pushImg = '/img/push_example.png';
    $dialogImg = '/img/dialog_example.png';

    $this->db
      ->createCommand("SET NAMES utf8 COLLATE utf8_unicode_ci;")
      ->execute()
    ;
    $pushDescription = serialize([
      'ru' => "Уведомление, которое показывается пользователю при попадании на ваш сайт. Выглядит так: <a href=\"{$pushImg}\" target=\"_blank\" data-pjax=\"0\">пример</a>. Тем самым это не является жестким редиректом, но у пользователя нет выбора, кроме как нажать кнопку Продолжить. Есть возможность индивидуальной настройки уведомления под ваш сайт.",
      'en' => "Notice is shown to the user in contact with your website. Looks: <a href=\"{$pushImg}\" target=\"_blank\" data-pjax=\"0\">example</a>. Thus, it is not hard redirect, but the user has no choice but to press the Continue button. It is possible to customize the notifications for your site."
    ]);
    $dialogDescription = serialize([
      'ru' => "Уведомление, которое показывается пользователю при попадании на ваш сайт. Выглядит так:  <a href=\"{$dialogImg}\" target=\"_blank\" data-pjax=\"0\">пример</a> У пользователя есть выбор - остаться на сайте или уйти. Наименее профитный способ слива, но наиболее лояльный к пользователю. Есть возможность индивидуальной настройки уведомления под ваш сайт.",
      'en' => "Notice is shown to the user in contact with your website. Looks: <a href=\"{$dialogImg}\" target=\"_blank\" data-pjax=\"0\">example</a> The user has a choice - to stay on the site or go. Least of profitable way to drain, but the most loyal to the user. It is possible to customize the notifications for your site.
"]);

    $update = <<<EOF
UPDATE `ads_types` set `description` = '{$pushDescription}' where `code` = 'push';
UPDATE `ads_types` set `description` = '{$dialogDescription}' where `code` = 'dialog';
EOF;
    $this->db
      ->createCommand($update)
      ->execute()
    ;

    $promoCanViewAdsBlockedTypes = $this->createOrGetPermission('PromoCanViewAdsBlockedTypes', 'Can view ads types');
    $this->assignRolesPermission('PromoCanViewAdsBlockedTypes', ['admin', 'root']);

    $promoPermission = $this->authManager->getPermission('PromoPermissions');
    $this->authManager->addChild($promoPermission, $promoCanViewAdsBlockedTypes);

    $this->assignRolesPermission('PromoAdsTypesIndex', ['reseller', 'manager']);
    $this->assignRolesPermission('PromoAdsTypesUpdateModal', ['reseller', 'manager']);
    $this->assignRolesPermission('PromoAdsTypesEnable', ['reseller', 'manager']);
    $this->assignRolesPermission('PromoAdsTypesDisable', ['reseller', 'manager']);
  }

  public function down()
  {
    $this->revokeRolesPermission('PromoCanViewAdsBlockedTypes', ['admin', 'root']);
    $this->removePermission('PromoCanViewAdsBlockedTypes');

    $this->revokeRolesPermission('PromoAdsTypesIndex', ['reseller', 'manager']);
    $this->revokeRolesPermission('PromoAdsTypesUpdateModal', ['reseller', 'manager']);
    $this->revokeRolesPermission('PromoAdsTypesEnable', ['reseller', 'manager']);
    $this->revokeRolesPermission('PromoAdsTypesDisable', ['reseller', 'manager']);
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
