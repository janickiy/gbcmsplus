<?php

use console\components\Migration;

class m151218_085913_landing_operators_pay_type extends Migration
{
  protected $landingOperatorPayTypes = 'landing_operator_pay_types';
  protected $landingOperators = 'landing_operators';
  protected $landingPayTypes = 'landing_pay_types';


  public function up()
  {
    $this->dropTable($this->landingOperatorPayTypes);

    $this->addColumn($this->landingOperators, 'pay_type_id', 'TINYINT(1) UNSIGNED NULL');
    $this->addForeignKey('landing_operators_pay_type_id_fk', $this->landingOperators, 'pay_type_id', $this->landingPayTypes, 'id');

    $this->insert($this->landingPayTypes, ['name' => 'One-Time', 'status' => 1, 'created_at' => time()]);
    $this->insert($this->landingPayTypes, ['name' => 'Subscribtion', 'status' => 1, 'created_at' => time()]);

  }

  public function down()
  {
    $this->createTable($this->landingOperatorPayTypes, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL'
    ]);
    $this->addForeignKey($this->landingOperatorPayTypes . '_' . 'landing_id' . '_fk', $this->landingOperatorPayTypes, 'landing_id', \mcms\promo\models\Landing::tableName(), 'id');
    $this->addForeignKey($this->landingOperatorPayTypes . '_' . 'operator_id' . '_fk', $this->landingOperatorPayTypes, 'operator_id', \mcms\promo\models\Operator::tableName(), 'id');
    $this->addForeignKey($this->landingOperatorPayTypes . '_' . 'landing_pay_types' . '_fk', $this->landingOperatorPayTypes, 'landing_pay_type_id', $this->landingPayTypes, 'id');

    $this->dropForeignKey($this->landingOperators, 'landing_operators_pay_type_id_fk');
    $this->dropColumn($this->landingOperators, 'pay_type_id');
  }

}
