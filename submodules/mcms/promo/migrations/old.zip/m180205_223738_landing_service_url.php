<?php

use console\components\Migration;

class m180205_223738_landing_service_url extends Migration
{

  public function up()
  {
    $this->addColumn('landings', 'service_url', $this->string(255)->null()->after('name'));
  }

  public function down()
  {
    $this->dropColumn('landings', 'service_url');
  }

}
