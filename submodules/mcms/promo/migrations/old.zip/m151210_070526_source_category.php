<?php

use console\components\Migration;

class m151210_070526_source_category extends Migration
{
  public function up()
  {

    $this->addColumn('sources', 'category_id', 'MEDIUMINT(5) UNSIGNED');

    $this->addForeignKey(
      'sources_category_id_fk',
      'sources',
      'category_id',
      'landing_categories',
      'id',
      'SET NULL',
      'CASCADE'
    );
  }

  public function down()
  {
    $this->dropForeignKey('sources_category_id_fk', 'sources');

    $this->dropColumn('sources', 'category_id');
  }
}
