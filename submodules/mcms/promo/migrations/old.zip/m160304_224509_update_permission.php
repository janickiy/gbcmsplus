<?php

use console\components\Migration;

class m160304_224509_update_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'ArbitrarySources' => [
        ['select2', 'Can search sources', ['admin', 'root', 'reseller']]
      ]
    ];
  }
}
