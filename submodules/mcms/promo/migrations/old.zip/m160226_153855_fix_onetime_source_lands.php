<?php

use console\components\Migration;
use mcms\promo\models\LandingSubscriptionType;
use mcms\promo\models\SourceOperatorLanding;

class m160226_153855_fix_onetime_source_lands extends Migration
{
  public function up()
  {
    $onetimeId = LandingSubscriptionType::find()->where(['code' => 'onetime'])->one()->id;

    $landOps = (new \yii\db\Query())
      ->select(['landing_id', 'operator_id'])
      ->from('landing_operators lo')
      ->where(['subscription_type_id' => $onetimeId])
      ->all();


    foreach($landOps as $landOp){
      $this->update('sources_operator_landings', [
        'profit_type' => SourceOperatorLanding::PROFIT_TYPE_BUYOUT
      ], [
        'landing_id' => $landOp['landing_id'],
        'operator_id' => $landOp['operator_id'],
        'profit_type' => SourceOperatorLanding::PROFIT_TYPE_REBILL
      ]);
    }
  }

  public function down()
  {
    echo "m160226_153855_fix_onetime_source_lands cannot be reverted.\n";

    return true;
  }
}
