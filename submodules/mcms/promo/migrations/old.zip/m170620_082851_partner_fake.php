<?php

use console\components\Migration;

class m170620_082851_partner_fake extends Migration
{
  const TABLE = 'user_promo_settings';
  public function up()
  {
    $this->addColumn(self::TABLE, 'add_fake_after_subscriptions', $this->integer(10)->unsigned());
    $this->addColumn(self::TABLE, 'add_fake_subscription_percent', $this->integer(10)->unsigned());
    $this->addColumn(self::TABLE, 'add_fake_cpa_subscription_percent', $this->integer(10)->unsigned());
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'add_fake_after_subscriptions');
    $this->dropColumn(self::TABLE, 'add_fake_subscription_percent');
    $this->dropColumn(self::TABLE, 'add_fake_cpa_subscription_percent');
  }
}
