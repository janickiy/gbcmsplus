<?php

use console\components\Migration;

class m180118_163648_subscriptions_limit extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  const SUBSCRIPTION_LIMITS = 'subscription_limits';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(self::SUBSCRIPTION_LIMITS, [
      'id' => $this->primaryKey(10)->unsigned(),
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'user_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT NULL',
      'subscriptions_limit' => $this->integer(10)->unsigned()->notNull(),
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'updated_by' => 'MEDIUMINT(5) UNSIGNED',
      'created_at' => $this->integer(10)->unsigned()->notNull(),
      'updated_at' => $this->integer(10)->unsigned(),
    ], $tableOptions);

    $this->createPermission('PromoSubscriptionLimitsController', 'Контроллер SubscriptionLimits', 'PromoModule', ['root', 'admin']);
    $this->createPermission('PromoSubscriptionLimitsIndex', 'Список ограничений', 'PromoSubscriptionLimitsController', ['reseller']);
    $this->createPermission('PromoSubscriptionLimitsCreateModal', 'Создать ограничение', 'PromoSubscriptionLimitsController', ['reseller']);
    $this->createPermission('PromoSubscriptionLimitsUpdateModal', 'Изменить ограничение', 'PromoSubscriptionLimitsController', ['reseller']);
    $this->createPermission('PromoSubscriptionLimitsDelete', 'Удалить ограничение', 'PromoSubscriptionLimitsController', ['reseller']);
  }

  public function down()
  {
    $this->dropTable(self::SUBSCRIPTION_LIMITS);

    $this->removePermission('PromoSubscriptionLimitsController');
    $this->removePermission('PromoSubscriptionLimitsIndex');
    $this->removePermission('PromoSubscriptionLimitsCreateModal');
    $this->removePermission('PromoSubscriptionLimitsUpdateModal');
    $this->removePermission('PromoSubscriptionLimitsDelete');
  }
}
