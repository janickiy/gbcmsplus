<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m161116_091346_add_landing_modal extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission(
      'PromoWebmasterSourcesAddLanding',
      'Добавление лендинга в источник вебмастера. Модалка',
      'PromoWebmasterSourcesController',
      ['root', 'admin', 'reseller']
    );
    $this->createPermission(
      'PromoWebmasterSourcesUpdateLanding',
      'Редактирование лендинга в источнике вебмастера. Модалка',
      'PromoWebmasterSourcesController',
      ['root', 'admin', 'reseller']
    );
  }

  public function down()
  {
    $this->removePermission('PromoWebmasterSourcesUpdateLanding');
    $this->removePermission('PromoWebmasterSourcesAddLanding');
  }
}
