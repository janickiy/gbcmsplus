<?php

use console\components\Migration;

/**
 */
class m180116_073927_investor_priority extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  /**
   * @throws \Exception
   */
  public function up()
  {
    $this->dropTable('investor_priority');
    $this->removePermission('PromoInvestorPriorityUpdate');
    $this->removePermission('PromoInvestorPriorityController');
  }

  /**
   * @throws \yii\base\Exception
   */
  public function down()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    /*
     * INVESTOR PRIORITY
     */
    $this->createTable('investor_priority', [
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL PRIMARY KEY',
      'priority' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->addForeignKey('investor_priority' . '_' . 'user_id' . '_fk', 'investor_priority', 'user_id', '{{%users}}', 'id');
    $this->addForeignKey('investor_priority' . '_' . 'created_by' . '_fk', 'investor_priority', 'created_by', '{{%users}}', 'id');
    $this->createPermission('PromoInvestorPriorityController', 'Контроллер InvestorPriority');
    $this->createPermission('PromoInvestorPriorityUpdate', 'Ajax обработка ответа из виджета [[InvestorPriorityWidget]]', 'PromoInvestorPriorityController', ['root', 'admin']);
  }
}
