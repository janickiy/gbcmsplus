<?php

use console\components\Migration;

class m151218_131607_update_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'LandingSubscriptionTypes' => [
        ['index', 'Lists all LandingSubscriptionType models', ['admin', 'root']],
        ['createModal', 'Create a LandingSubscriptionType model', ['admin', 'root']],
        ['updateModal', 'Updates an existing LandingSubscriptionType model', ['admin', 'root']],
        ['enable', 'Enable an existing LandingSubscriptionType model', ['admin', 'root']],
        ['disable', 'Disable an existing LandingSubscriptionType model', ['admin', 'root']],
      ],
    ];
  }

}
