<?php

use console\components\Migration;
use mcms\promo\models\Source;

class m151214_153431_convert_test extends Migration
{
  const TABLE = 'landing_convert_tests';

  private $tableOptions;

  public function init()
  {
    parent::init();
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $this->tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
  }


  public function up()
  {
    $this->createTable(self::TABLE, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'max_hits' => $this->integer()->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $this->tableOptions);

    $this->createIndex(self::TABLE . '_status_index', self::TABLE, 'status');

    $this->addForeignKey(self::TABLE . '_source_id_fk', self::TABLE, 'source_id', Source::tableName(), 'id');

  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }
}
