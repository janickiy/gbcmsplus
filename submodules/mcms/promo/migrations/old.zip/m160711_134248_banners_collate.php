<?php

use console\components\Migration;

class m160711_134248_banners_collate extends Migration
{

  const TEMPL = 'banner_templates';

  const PROP = 'banner_template_attributes';

  const BANNER = 'banners';

  const BANNER_ATTRS = 'banner_attribute_values';

  public function up()
  {
    $this->alterColumn('banner_templates', 'code', 'varchar(255) COLLATE utf8_unicode_ci NOT NULL');
    $this->alterColumn('banner_templates', 'name', 'varchar(255) COLLATE utf8_unicode_ci NOT NULL');
    $this->alterColumn('banner_templates', 'template', 'text COLLATE utf8_unicode_ci');
    $this->db->createCommand('ALTER TABLE banner_templates
      DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci')->execute();



    $this->alterColumn('banner_template_attributes', 'code', 'varchar(255) COLLATE utf8_unicode_ci NOT NULL');
    $this->alterColumn('banner_template_attributes', 'name', 'varchar(255) COLLATE utf8_unicode_ci NOT NULL');
    $this->db->createCommand('ALTER TABLE banner_template_attributes
      DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci')->execute();


    $this->alterColumn('banners', 'code', 'varchar(255) COLLATE utf8_unicode_ci NOT NULL');
    $this->alterColumn('banners', 'name', 'varchar(255) COLLATE utf8_unicode_ci NOT NULL');
    $this->db->createCommand('ALTER TABLE banners
      DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci')->execute();

    $this->alterColumn('banner_attribute_values', 'multilang_value', 'text COLLATE utf8_unicode_ci');
    $this->alterColumn('banner_attribute_values', 'value', 'text COLLATE utf8_unicode_ci');
    $this->db->createCommand('ALTER TABLE banner_attribute_values
      DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci')->execute();
  }

  public function down()
  {
    echo "m160711_134248_banners_collate cannot be reverted.\n";
    return true;
  }
}
