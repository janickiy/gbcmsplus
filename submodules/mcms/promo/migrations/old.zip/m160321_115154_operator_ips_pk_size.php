<?php

use console\components\Migration;

class m160321_115154_operator_ips_pk_size extends Migration
{
  const TABLE = 'operator_ips';

  public function up()
  {
    $this->alterColumn(self::TABLE, 'id', 'int(10) unsigned NOT NULL AUTO_INCREMENT');
  }

  public function down()
  {
    $this->alterColumn(self::TABLE, 'id', 'mediumint(5) unsigned NOT NULL AUTO_INCREMENT');
  }
}
