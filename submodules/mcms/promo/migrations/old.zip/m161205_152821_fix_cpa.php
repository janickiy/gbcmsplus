<?php

use mcms\promo\Module;
use console\components\Migration;

class m161205_152821_fix_cpa extends Migration
{
  public function up()
  {
    if (Yii::$app->getModule('promo')->settings->getValueByKey('settings.allow_reseller_set_personal_cpa_price')) {
      return true;
    }

    $this->db->createCommand('
      UPDATE partner_program_items 
      SET cpa_profit_rub = NULL, 
        cpa_profit_eur = NULL, 
        cpa_profit_usd = NULL
    ')->execute();

    $this->db->createCommand('
      UPDATE personal_profit p
      INNER JOIN user_promo_settings ups
        ON p.user_id = ups.user_id AND ups.partner_program_id IS NOT NULL
      SET p.cpa_profit = NULL
    ')->execute();

    return true;
  }

  public function down()
  {
    return true;
  }
}
