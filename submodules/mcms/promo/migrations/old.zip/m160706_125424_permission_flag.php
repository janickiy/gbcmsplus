<?php

use console\components\Migration;

class m160706_125424_permission_flag extends Migration
{
  use \mcms\common\traits\PermissionGroupMigration;

  public function init()
  {
    parent::init();

    $this->groupPermissionName = 'PromoModule';
    $this->groupPermissionDescription = 'Module Promo';
    $this->groupPermissionDefaultRole = ['admin', 'root'];

    $this->groupPermissionControllers = [
      'PromoPermissions' => [
        'description' => 'Promo permissions',
        'permissions' => [
          ['PromoCanEditIsResellerBuyoutPricesFlag'],
        ]
      ],
    ];
  }
}
