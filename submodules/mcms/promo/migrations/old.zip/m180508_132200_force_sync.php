<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m180508_132200_force_sync extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PromoProvidersMakeSync', 'Запустить принудительно синхронизацию', 'PromoProvidersController', ['root']);
    $this->createPermission('PromoProvidersMakeFullSync', 'Запустить принудительно синхронизацию без проверки времени', 'PromoProvidersController', ['root']);
  }

  public function down()
  {
    $this->removePermission('PromoProvidersMakeFullSync');
    $this->removePermission('PromoProvidersMakeSync');
  }

}
