<?php

use mcms\common\helpers\Console;
use console\components\Migration;
use yii\db\Query;

class m180412_105951_fix_ik_sol extends Migration
{

  /**
   * @var int кэш, в котором храним айди типа ONETIME.
   * @see DisabledLandingsReplaceController::getSubscriptionTypeId()
   */
  private $onetimeTypeId;

  public function up()
  {
    $this->execute('
      UPDATE sources_operator_landings sol
        INNER JOIN landing_operators lo ON lo.landing_id = sol.landing_id AND lo.operator_id = sol.operator_id
        INNER JOIN landing_subscription_types subtype ON subtype.id = lo.subscription_type_id
      SET sol.profit_type = 2 WHERE subtype.code = \'onetime\' AND sol.profit_type <> 2
  ;');

    if (!Console::confirm("ИК хиты немного подпортились, см. MCMS-2102.\nОчень желательно их обновить вместе со сгруппированными таблицами hits_day_hour_group и hits_day_group.\nБыло выявлено что наибольшая проблема начинается с даты 2018-03-27.\nНа проде желательно не пропускать этот момент. Выполнить?")) {
      return true;
    }

    $dateFrom = '2018-03-27';

    for (
      $date = $dateFrom;
      $date <= Yii::$app->formatter->asDate('today', 'php:Y-m-d');
      $date = Yii::$app->formatter->asDate("$date + 1 day", 'php:Y-m-d'))
    {
      echo "DATE $date...";
      $this->db->createCommand('
      UPDATE hits h
        INNER JOIN landing_operators lo ON lo.operator_id = h.operator_id AND lo.landing_id = h.landing_id
        SET is_cpa = 1
        WHERE lo.subscription_type_id = :onetimeType AND h.date=:date AND h.is_cpa = 0
  ;', [':onetimeType' => $this->getOnetimeTypeId(), ':date' => $date])->execute();
      echo "DONE\n";
    }

    $params = new \mcms\statistic\components\cron\CronParams(['fromTime' => strtotime($dateFrom)]);

    echo 'UPDATE HDHG...';
    (new \mcms\statistic\components\cron\handlers\HitsByHours(['params' => $params]))->run();
    echo "DONE\n";
    echo 'UPDATE HDG...';
    (new \mcms\statistic\components\cron\handlers\HitsByDate(['params' => $params]))->run();
    echo "DONE\n";
  }

  public function down()
  {
    echo "m180412_105951_fix_ik_sol cannot be reverted.\n";
  }

  /**
   * Есть 2 способа списания средств с абонента: это единоразовое списание, либо подписка на услугу.
   * Данный метод вернет ID типа "подписка на услугу"
   * @return int
   */
  private function getOnetimeTypeId()
  {
    if ($this->onetimeTypeId !== null) {
      return $this->onetimeTypeId;
    }

    $this->onetimeTypeId = (int) (new Query())
      ->select('id')
      ->from('landing_subscription_types')
      ->where(['code' => 'onetime'])
      ->scalar();

    return $this->onetimeTypeId;
  }
}
