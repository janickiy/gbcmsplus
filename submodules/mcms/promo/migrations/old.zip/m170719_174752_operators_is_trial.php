<?php

use console\components\Migration;

class m170719_174752_operators_is_trial extends Migration
{
  public function up()
  {
    $this->addColumn('operators','is_trial', $this->smallInteger(1));
    $this->update('operators', ['is_trial' => 1], ['id' => [2, 13]]);
  }

  public function down()
  {
    $this->dropColumn('operators','is_trial');
  }

}
