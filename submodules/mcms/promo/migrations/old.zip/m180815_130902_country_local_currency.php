<?php

use console\components\Migration;
use mcms\promo\models\Country;

/**
 */
class m180815_130902_country_local_currency extends Migration
{
  public $countries = [
    [
      'name' => 'Russia',
      'code' => 'RU',
      'currency' => 'RUB',
    ],
    [
      'name' => 'Azerbaijan',
      'code' => 'AZ',
      'currency' => 'AZN',
    ],
    [
      'name' => 'Ukraine',
      'code' => 'UA',
      'currency' => 'UAH',
    ],
    [
      'name' => 'Belarus',
      'code' => 'by',
      'currency' => 'BYN',
    ],
    [
      'name' => 'Brazil',
      'code' => 'BR',
      'currency' => 'BRL',
    ],
    [
      'name' => 'France',
      'code' => 'FR',
      'currency' => 'EUR',
    ],
    [
      'name' => 'Bulgaria',
      'code' => 'BG',
      'currency' => 'BGN',
    ],
    [
      'name' => 'Romania',
      'code' => 'ro',
      'currency' => 'RON',
    ],
    [
      'name' => 'Poland',
      'code' => 'PL',
      'currency' => 'PLN',
    ],
    [
      'name' => 'Kazakhstan',
      'code' => 'KZ',
      'currency' => 'KZT',
    ],
    [
      'name' => 'Norway',
      'code' => 'no',
      'currency' => 'NOK',
    ],
    [
      'name' => 'Macedonia',
      'code' => 'MK',
      'currency' => 'MKD',
    ],
    [
      'name' => 'Jordan',
      'code' => 'JO',
      'currency' => 'JOD',
    ],
    [
      'name' => 'Serbia',
      'code' => 'RS',
      'currency' => 'RSD',
    ],
    [
      'name' => 'Lithuania-Latvia',
      'code' => 'LTLV',
      'currency' => 'EUR',
    ],
    //TRICKY На разных реселлерках Lithuania-Latvia c разным кодм
    [
      'name' => 'Lithuania-Latvia',
      'code' => 'LT',
      'currency' => 'EUR',
    ],
    [
      'name' => 'Latvia',
      'code' => 'LV',
      'currency' => 'EUR',
    ],
    [
      'name' => 'Estonia',
      'code' => 'EE',
      'currency' => 'EUR',
    ],
    [
      'name' => 'Switzerland',
      'code' => 'CH',
      'currency' => 'CHF',
    ],
    [
      'name' => 'Iraq',
      'code' => 'IQ',
      'currency' => 'IQD',
    ],
    [
      'name' => 'Portugal',
      'code' => 'PT',
      'currency' => 'EUR',
    ],
    [
      'name' => 'Netherlands',
      'code' => 'NL',
      'currency' => 'EUR',
    ],
    [
      'name' => 'Egypt',
      'code' => 'EG',
      'currency' => 'EGP',
    ],
    [
      'name' => 'Czech Republic',
      'code' => 'CZ',
      'currency' => 'CZK',
    ],
    [
      'name' => 'Hungary',
      'code' => 'HU',
      'currency' => 'HUF',
    ],
    [
      'name' => 'Kenya',
      'code' => 'KE',
      'currency' => 'KES',
    ],
    [
      'name' => 'United Kingdom',
      'code' => 'GB',
      'currency' => 'GBP',
    ],
    [
      'name' => 'Pakistan',
      'code' => 'PK',
      'currency' => 'PKR',
    ],
    [
      'name' => 'Belgium',
      'code' => 'BE',
      'currency' => 'EUR',
    ],
    [
      'name' => 'Saudi Arabia',
      'code' => 'SA',
      'currency' => 'SAR',
    ],
    [
      'name' => 'Iran',
      'code' => 'IR',
      'currency' => 'IRR',
    ],
    [
      'name' => 'India',
      'code' => 'IN',
      'currency' => 'INR',
    ],
    [
      'name' => 'Vietnam',
      'code' => 'VN',
      'currency' => 'VND',
    ],
    [
      'name' => 'Italy',
      'code' => 'IT',
      'currency' => 'EUR',
    ],
    [
      'name' => 'Greece',
      'code' => 'GR',
      'currency' => 'EUR',
    ],
    [
      'name' => 'Mexico',
      'code' => 'MX',
      'currency' => 'MXN',
    ],
    [
      'name' => 'Cyprus',
      'code' => 'CY',
      'currency' => 'EUR',
    ],
    [
      'name' => 'United Arab Emirates',
      'code' => 'AE',
      'currency' => 'AED',
    ],
    [
      'name' => 'Indonesia',
      'code' => 'id',
      'currency' => 'IDR',
    ],
    [
      'name' => 'Slovakia',
      'code' => 'SK',
      'currency' => 'EUR',
    ],
    [
      'name' => 'Thailand',
      'code' => 'TH',
      'currency' => 'THB',
    ],
    [
      'name' => 'Austria',
      'code' => 'AT',
      'currency' => 'EUR',
    ],
    [
      'name' => 'Malaysia',
      'code' => 'MY',
      'currency' => 'MYR',
    ],
    [
      'name' => 'South Africa',
      'code' => 'za',
      'currency' => 'ZAR',
    ],
    [
      'name' => 'Qatar',
      'code' => 'QA',
      'currency' => 'QAR',
    ],
    [
      'name' => 'Tunisia',
      'code' => 'TN',
      'currency' => 'TND',
    ],
    [
      'name' => 'Kuwait',
      'code' => 'KW',
      'currency' => 'KWD',
    ],
    [
      'name' => 'Sri Lanka',
      'code' => 'LK',
      'currency' => 'LKR',
    ],
    [
      'name' => 'Honduras',
      'code' => 'hn',
      'currency' => 'HNL',
    ],
    [
      'name' => 'Nicaragua',
      'code' => 'ni',
      'currency' => 'NIO',
    ],
    [
      'name' => 'Guatemala',
      'code' => 'gt',
      'currency' => 'GTQ',
    ],
    [
      'name' => 'Ecuador',
      'code' => 'ec',
      'currency' => 'USD',
    ]
  ];

  /**
   */
  public function up()
  {
    $this->addColumn('countries', 'local_currency', 'VARCHAR(3) NULL DEFAULT NULL AFTER currency');
    echo 'Add local currency to countries...' . PHP_EOL;
    foreach ($this->countries as $country) {
      $this->update('countries', ['local_currency' => strtolower($country['currency'])], ['code' => $country['code']]);
    }
  }

  /**
   */
  public function down()
  {
    $this->dropColumn('countries', 'local_currency');
  }
}
