<?php

use console\components\Migration;

class m170404_073202_html_selector_lenght extends Migration
{
  public function up()
  {
    $this->alterColumn('sources', 'replace_links_css_class', $this->string(255));
  }

  public function down()
  {
    $this->alterColumn('sources', 'replace_links_css_class', $this->string(32));
  }
}
