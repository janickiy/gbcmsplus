<?php

use rgk\settings\models\Setting;
use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m180515_083334_disable_land_merge extends Migration
{

  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;
  use PermissionTrait;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->createPermission(
      'PartnersEditSettingMergeLandings',
      'Разрешение позволяет менять настройку "схлапывания" в админке',
      'PartnersPermissions',
      ['root', 'admin']
    );
    $this->settingsBuilder->createSetting(
      ['en' => 'Merge landings for partners', 'ru' => '"Схлапывать" лендинги в партнерке'],
      [],
      'settings.partners.is_merge_landings',
      ['PartnersEditSettingMergeLandings'],
      Setting::TYPE_BOOLEAN,
      'app.common.group_partners',
      true,
      [['boolean']]
    );
  }

  public function down()
  {
    $this->removePermission('PartnersEditSettingMergeLandings');
    $this->settingsBuilder->removeSetting('settings.partners.is_merge_landings');
  }
}
