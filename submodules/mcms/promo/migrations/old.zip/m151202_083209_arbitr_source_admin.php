<?php

use console\components\Migration;

class m151202_083209_arbitr_source_admin extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'ArbitrarySources' => [
        ['index', 'Lists all Source models', ['admin', 'root']],
        ['view', 'Displays a single Source model', ['admin', 'root']],
        ['update', 'Updates an existing Source model', ['admin', 'root']],
        ['findUser', 'Find user by search string', ['admin', 'root']],
      ]
    ];
  }
}
