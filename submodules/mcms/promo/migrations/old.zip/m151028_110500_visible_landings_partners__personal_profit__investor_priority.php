<?php

use console\components\Migration;

class m151028_110500_visible_landings_partners__personal_profit__investor_priority extends Migration
{

  protected $visibleLandingsPartners = '{{%visible_landings_partners}}';
  protected $personalProfit = '{{%personal_profit}}';
  protected $investorPriority = '{{%investor_priority}}';

  public function safeUp()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    /*
     * VISIBLE LANDINGS PARTNERS
     */
    $this->createTable($this->visibleLandingsPartners, [
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->addPrimaryKey('visible_landings_partners' . '_pk', $this->visibleLandingsPartners, ['user_id', 'landing_id']);
    $this->addForeignKey('visible_landings_partners' . '_' . 'user_id' . '_fk', $this->visibleLandingsPartners, 'user_id', '{{%users}}', 'id');
    $this->addForeignKey('visible_landings_partners' . '_' . 'created_by' . '_fk', $this->visibleLandingsPartners, 'created_by', '{{%users}}', 'id');
    $this->addForeignKey('visible_landings_partners' . '_' . 'landing_id' . '_fk', $this->visibleLandingsPartners, 'landing_id', '{{%landings}}', 'id');


    /*
     * PERSONAL PROFIT
     */
    $this->createTable($this->personalProfit, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED',
      'rebill_percent' => 'DECIMAL(5, 2) NOT NULL',
      'buyout_percent' => 'DECIMAL(5, 2) NOT NULL',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->addForeignKey('personal_profit' . '_' . 'user_id' . '_fk', $this->personalProfit, 'user_id', '{{%users}}', 'id');
    $this->addForeignKey('personal_profit' . '_' . 'created_by' . '_fk', $this->personalProfit, 'created_by', '{{%users}}', 'id');
    $this->addForeignKey('personal_profit' . '_' . 'operator_id' . '_fk', $this->personalProfit, 'operator_id', '{{%operators}}', 'id');
    $this->addForeignKey('personal_profit' . '_' . 'landing_id' . '_fk', $this->personalProfit, 'landing_id', '{{%landings}}', 'id');

    $this->createIndex('personal_profit' . '_' . 'user_operator_landing' . '_index', $this->personalProfit, ['user_id', 'operator_id', 'landing_id'], true);


    /*
     * INVESTOR PRIORITY
     */
    $this->createTable($this->investorPriority, [
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL PRIMARY KEY',
      'priority' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->addForeignKey('investor_priority' . '_' . 'user_id' . '_fk', $this->investorPriority, 'user_id', '{{%users}}', 'id');
    $this->addForeignKey('investor_priority' . '_' . 'created_by' . '_fk', $this->investorPriority, 'created_by', '{{%users}}', 'id');


  }

  public function safeDown()
  {
    $this->dropTable($this->investorPriority);
    $this->dropTable($this->personalProfit);
    $this->dropTable($this->visibleLandingsPartners);
  }

}
