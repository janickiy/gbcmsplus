<?php

use console\components\Migration;

class m161021_123853_banners_rotation extends Migration
{
    public function up()
    {
      $this->addColumn('sources', 'banner_show_limit', $this->smallInteger(5));
    }

    public function down()
    {
      $this->dropColumn('sources', 'banner_show_limit');
    }
}
