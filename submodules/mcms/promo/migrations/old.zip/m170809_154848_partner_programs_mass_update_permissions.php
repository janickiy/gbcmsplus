<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170809_154848_partner_programs_mass_update_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PromoPartnerProgramsMassUpdate', 'Массовое обновление партнерских программ', 'PromoPartnerProgramsController', ['admin', 'reseller', 'root']);
    $this->createPermission('PromoPartnerProgramsMassDelete', 'Массовое удаление партнерских программ', 'PromoPartnerProgramsController', ['admin', 'reseller', 'root']);
    $this->createPermission('PromoPartnerProgramsMassUpdateModal', 'Модальное окно для: массовое обновление партнерских программ', 'PromoPartnerProgramsController', ['admin', 'reseller', 'root']);
  }

  public function down()
  {
    $this->removePermission('PromoPartnerProgramsMassUpdate');
    $this->removePermission('PromoPartnerProgramsMassDelete');
    $this->removePermission('PromoPartnerProgramsMassUpdateModal');
  }
}
