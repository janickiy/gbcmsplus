<?php

use console\components\Migration;

class m160405_162606_update_sources_operator_landings extends Migration
{
  const TABLE = 'sources_operator_landings';
  public function up()
  {
    $this->addColumn(self::TABLE, 'is_disable_handled', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'is_disable_handled');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
