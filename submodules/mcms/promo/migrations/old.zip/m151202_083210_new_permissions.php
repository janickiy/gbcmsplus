<?php

use console\components\Migration;

class m151202_083210_new_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'Countries' => [
        ['createModal', 'Create a Country model', ['admin', 'root']],
        ['updateModal', 'Updates an existing Country model', ['admin', 'root']],
        ['view', 'View an existing Country model', ['admin', 'root']],
        ['viewModal', 'View an existing Country model in modal window', ['admin', 'root']],
        ['enable', 'Enable an existing Country model', ['admin', 'root']],
        ['disable', 'Disable an existing Country model', ['admin', 'root']],
      ],
      'Regions' => [
        ['createModal', 'Create a Region model', ['admin', 'root']],
        ['updateModal', 'Updates an existing Region model', ['admin', 'root']],
        ['view', 'View an existing Region model', ['admin', 'root']],
        ['viewModal', 'View an existing Region model in modal window', ['admin', 'root']],
        ['enable', 'Enable an existing Region model', ['admin', 'root']],
        ['disable', 'Disable an existing Region model', ['admin', 'root']],
      ],
      'Cities' => [
        ['createModal', 'Create a City model', ['admin', 'root']],
        ['updateModal', 'Updates an existing City model', ['admin', 'root']],
        ['view', 'View an existing City model', ['admin', 'root']],
        ['viewModal', 'View an existing City model in modal window', ['admin', 'root']],
        ['enable', 'Enable an existing City model', ['admin', 'root']],
        ['disable', 'Disable an existing City model', ['admin', 'root']],
        ['dependentRegions', 'Get country regions for dependent select', ['admin', 'root']],
      ],
    ];
  }


}
