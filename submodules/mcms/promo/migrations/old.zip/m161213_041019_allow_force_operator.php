<?php

use console\components\Migration;

class m161213_041019_allow_force_operator extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function up()
  {
    $this->addColumn('sources', 'is_allow_force_operator', 'tinyint(1) unsigned NOT NULL DEFAULT 0 COMMENT \'В ссылке арбитражника можно указать GET-парам op=1 и проверка по IP не будет выполняться\'');

    $this->createPermission('PromoManageForceOperatorOption', 'Изменение флага "Разрешить передачу оператора" у ссылки', 'PromoPermissions', ['root', 'admin']);
  }

  public function down()
  {
    $this->dropColumn('sources', 'is_allow_force_operator');
    $this->removePermission('PromoManageForceOperatorOption');
  }
}
