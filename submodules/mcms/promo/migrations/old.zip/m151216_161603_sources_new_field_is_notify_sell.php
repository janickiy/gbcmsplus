<?php

use console\components\Migration;

class m151216_161603_sources_new_field_is_notify_sell extends Migration
{
  protected $sources = '{{%sources}}';

  public function up()
  {
    $this->addColumn($this->sources, 'is_notify_sell', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
    $this->createIndex('sources' . '_' . 'is_notify_sell' . '_index', $this->sources, 'is_notify_sell');
  }

  public function down()
  {
    $this->dropColumn($this->sources, 'is_notify_sell');
  }
}
