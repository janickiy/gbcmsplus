<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m180615_142932_clean_pp extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PromoPartnerProgramsClean', 'Очистка ПП от неактивных лендов', 'PromoPartnerProgramsController', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('PromoPartnerProgramsClean');
  }
}
