<?php

use yii\db\Schema;
use console\components\Migration;
use yii\db\Query;

class m160212_112503_for_sync extends Migration
{

  const TABLE = 'platforms';
  public function up()
  {
    $this->delete('landing_platforms');
    $this->update(self::TABLE, ['status' => 0]);

    $this->addColumn(self::TABLE, 'check_order', 'tinyint(1) NOT NULL DEFAULT 0 AFTER match_string');

    $this->insert(self::TABLE, [
      'id' => 101,
      'name' => 'Android Phone',
      'match_string' => '/Android.*Mobile/',
      'status' => 1,
      'check_order' => 1,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'id' => 102,
      'name' => 'Android Tablet',
      'match_string' => '/Android(?!.*Mobile)/',
      'status' => 1,
      'check_order' => 2,
      'created_at' => time(),
      'updated_at' => time()
    ]);


    $this->insert(self::TABLE, [
      'id' => 103,
      'name' => 'BlackBerry',
      'match_string' => '/BlackBerry/',
      'status' => 1,
      'check_order' => 3,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'id' => 104,
      'name' => 'iPad',
      'match_string' => '/iPad/',
      'status' => 1,
      'check_order' => 4,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'id' => 105,
      'name' => 'iPhone',
      'match_string' => '/iPhone/',
      'status' => 1,
      'check_order' => 5,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'id' => 106,
      'name' => 'Java',
      'match_string' => '/J2ME|MIDP/',
      'status' => 1,
      'check_order' => 6,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'id' => 107,
      'name' => 'MTK/Nucleus',
      'match_string' => '/MTK.*Nucleus/',
      'status' => 1,
      'check_order' => 7,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'id' => 108,
      'name' => 'Symbian',
      'match_string' => '/SymbianOS/',
      'status' => 1,
      'check_order' => 8,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'id' => 109,
      'name' => 'Windows Mobile/Phone',
      'match_string' => '/IEMobile/',
      'status' => 1,
      'check_order' => 9,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->insert(self::TABLE, [
      'id' => 110,
      'name' => 'PC/Web traffic',
      'match_string' => '/.*/',
      'status' => 1,
      'check_order' => 10,
      'created_at' => time(),
      'updated_at' => time()
    ]);

    $this->update('landing_subscription_types', ['status' => 0]);

    $this->addColumn('landing_subscription_types', 'code', 'varchar(50) AFTER id');

    $this->createIndex('landing_subscription_types_code_unique', 'landing_subscription_types', 'code', true);

    $this->addSubCode('One-Time', 'onetime');
    $this->addSubCode('Subscription', 'sub');

    $this->alterColumn('landing_subscription_types', 'code', 'varchar(50) NOT NULL');

    $this->addColumn('landing_operators', 'cost_price', 'decimal(10,2) COMMENT \'цена для абонента в указанной валюте\' AFTER rebill_price_rub ');

    $this->renameColumn('landing_operators', 'is_hold_account', 'days_hold');
    $this->dropIndex('landing_operators_is_hold_account_index', 'landing_operators');

    $this->addColumn('landings', 'allow_sync_buyout_prices', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT \'1\' AFTER auto_rating');
  }

  public function down()
  {
    echo 'There is no way back!' . "\n";
    return false;
  }

  public function addSubCode($name, $code)
  {
    $exists = (new Query())
      ->select('id')
      ->from('landing_subscription_types')
      ->where(['name' => $name])
      ->one();

    if ($exists) {
      $this->update('landing_subscription_types', ['code' => $code, 'status' => 1], ['id' => $exists]);
      return;
    }

    $this->insert('landing_subscription_types', ['name' => $name, 'status' => 1, 'created_at' => time(), 'code' => $code]);
  }

}
