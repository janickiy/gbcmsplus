<?php

use console\components\Migration;

class m161025_080620_source_campaign_is_with_preland extends Migration
{
  public function up()
  {
    $this->addColumn('sources', 'is_duplicate_postback', 'tinyint(1) unsigned not null default 0');
  }

  public function down()
  {
    $this->dropColumn('sources', 'is_duplicate_postback');
  }
}
