<?php

use mcms\notifications\models\Notification;
use console\components\Migration;

class m170906_161341_add_events extends Migration
{
  public function up()
  {

    $moduleApiResult = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => 'promo'])
      ->getResult();
    $modulePromoId = $moduleApiResult->id;

    $notifications = [
      [
        'event' => mcms\promo\components\events\LandingListCreated::className(),
        'data' => [
          'roles' => ['partner'],
          'type' => Notification::NOTIFICATION_TYPE_BROWSER,
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingListCreated::className(),
        'data' => [
          'roles' => ['partner'],
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingCreated::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_BROWSER,
          'roles' => ['partner']
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingCreated::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'roles' => ['partner']
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingListCreatedReseller::className(),
        'data' => [
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'header' => [
            'ru' => 'Добавлены новые лендинги',
            'en' => 'New landings',
          ],
          'template' => [
            'ru' => "<p>лендинги:<br>{landings}<br></p><strong>С уважением, команда {projectName}.</strong>",
            'en' => "<p>landings:<br>{landings}<br></p><strong>Best regards, command of {projectName}.</strong>",
          ],
          'use_owner' => 0,
          'roles' => ['reseller']
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingListCreatedReseller::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_BROWSER,
          'header' => [
            'ru' => 'Добавлены новые лендинги',
            'en' => 'New landings',
          ],
          'template' => [
            'ru' => "лендинги:<br>{landings}",
            'en' => "landings:<br>{landings}",
          ],
          'use_owner' => 0,
          'roles' => ['reseller']
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingCreatedReseller::className(),
        'data' => [
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'type' => Notification::NOTIFICATION_TYPE_EMAIL,
          'header' => [
            'ru' => 'Добавлен новый лендинг',
            'en' => 'New landing',
          ],
          'template' => [
            'ru' => '<p>лендинг:<br>{landing.id}. {landing.name}<br></p><strong>С уважением, команда {projectName}.</strong>',
            'en' => "<p>landing:<br>{landing.id}. {landing.name}<br></p><strong>Best regards, command of {projectName}.</strong>",
          ],
          'use_owner' => 0,
          'roles' => ['reseller']
        ]
      ],
      [
        'event' => mcms\promo\components\events\LandingCreatedReseller::className(),
        'data' => [
          'type' => Notification::NOTIFICATION_TYPE_BROWSER,
          'header' => [
            'ru' => 'Добавлен новый лендинг',
            'en' => 'New landing',
          ],
          'template' => [
            'ru' => 'лендинг:<br>{landing.id}. {landing.name}',
            'en' => "landing:<br>{landing.id}. {landing.name}",
          ],
          'use_owner' => 0,
          'roles' => ['reseller']
        ]
      ],
    ];

    foreach ($notifications as $notification) {

      $notificationData = \yii\helpers\ArrayHelper::getValue($notification, 'data', []);
      $notificationType = \yii\helpers\ArrayHelper::getValue($notificationData, 'type');
      $notificationModel = $notification['event'] ? Notification::findOne([
        'event' => $notification['event'],
        'notification_type' => $notificationType,
      ]) : null;

      if (!$notificationModel) {
        $notificationModel = new Notification();
      }

      $notificationModel->setAttributes($notificationData, false);
      $notificationModel->event = $notification['event'];
      $notificationModel->notification_type = $notificationType;
      $notificationModel->use_owner = \yii\helpers\ArrayHelper::getValue($notificationData, 'use_owner', 0);
      $notificationModel->roles = \yii\helpers\ArrayHelper::getValue($notificationData, 'roles');
      $notificationModel->module_id = $modulePromoId;

      $notificationModel->save(false);
    }
  }

  public function down()
  {
    echo "m160630_091939_add_reseller cannot be reverted.\n";
  }
}
