<?php

use console\components\Migration;

class m170914_083703_add_landing_rating extends Migration
{
  public function up()
  {
    $this->addColumn('sources_operator_landings', 'rating','DECIMAL(4,4) NOT NULL DEFAULT 0');
    $this->createIndex(
      'sources_operator_landings__rating_index',
      'sources_operator_landings',
      'rating'
    );

    $this->addColumn('sources', 'is_auto_rotation_enabled','TINYINT(1) NOT NULL DEFAULT 0');
  }

  public function down()
  {
    $this->dropColumn('sources', 'is_auto_rotation_enabled');

    $this->dropIndex('sources_operator_landings__rating_index','sources_operator_landings');
    $this->dropColumn('sources_operator_landings', 'rating');
  }
}
