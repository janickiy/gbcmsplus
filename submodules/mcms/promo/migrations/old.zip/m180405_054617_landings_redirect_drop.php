<?php

use console\components\Migration;

class m180405_054617_landings_redirect_drop extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->removePermission('PromoLandingRedirectsController');
    $this->removePermission('PromoLandingRedirectsCreateModal');
    $this->removePermission('PromoLandingRedirectsDisable');
    $this->removePermission('PromoLandingRedirectsEnable');
    $this->removePermission('PromoLandingRedirectsIndex');
    $this->removePermission('PromoLandingRedirectsUpdateModal');
    $this->removePermission('PromoLandingRedirectsViewModal');

    $this->execute("DELETE FROM notifications
WHERE
  `event` IN ('mcms\\promo\\components\\events\\LandingRedirectDeleted', 'mcms\\promo\\components\\events\\LandingRedirectChanged')");

    $this->dropTable('landing_redirects');
  }

  public function down()
  {
    $this->createPermission('PromoLandingRedirectsController', 'Контроллер LandingRedirects', 'PromoModule', ['root', 'admin']);
    $this->createPermission('PromoLandingRedirectsCreateModal', 'Создание редиректа', 'PromoLandingRedirectsController');
    $this->createPermission('PromoLandingRedirectsDisable', 'Выключение редиректа', 'PromoLandingRedirectsController');
    $this->createPermission('PromoLandingRedirectsEnable', 'Включение редиректа', 'PromoLandingRedirectsController');
    $this->createPermission('PromoLandingRedirectsIndex', 'Просмотр списка редиректов', 'PromoLandingRedirectsController');
    $this->createPermission('PromoLandingRedirectsUpdateModal', 'Редактирование редиректа - модалка', 'PromoLandingRedirectsController');
    $this->createPermission('PromoLandingRedirectsViewModal', 'Просмотр редиректа - модалка', 'PromoLandingRedirectsController');

    $this->execute('
CREATE TABLE landing_redirects
(
	id MEDIUMINT(5) UNSIGNED AUTO_INCREMENT
		PRIMARY KEY,
	redirect_from TEXT NOT NULL,
	redirect_to TEXT NOT NULL,
	description VARCHAR(512) NOT NULL,
	created_by MEDIUMINT(5) UNSIGNED NOT NULL,
	created_at INT(10) UNSIGNED NOT NULL,
	updated_at INT(10) UNSIGNED NULL,
	status TINYINT(1) UNSIGNED DEFAULT \'0\' NOT NULL,
	CONSTRAINT landing_redirects_created_by_fk
		FOREIGN KEY (created_by) REFERENCES users (id)
);

CREATE INDEX landing_redirects_created_by_fk
	ON landing_redirects (created_by);

CREATE INDEX landing_redirects_status_index
	ON landing_redirects (status);');
  }
}
