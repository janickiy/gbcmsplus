<?php

use console\components\Migration;
use mcms\notifications\models\Notification;

class m161028_100007_set_events extends Migration
{
  public function up()
  {

    $moduleApiResult = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => 'promo'])
      ->getResult();
    $modulePromoId = $moduleApiResult->id;

    $this->insert('notifications', [
      'module_id' => $modulePromoId,
      'event' => 'mcms\\promo\\components\\events\\landing_sets\\LandingsAddedToSet',
      'notification_type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'is_disabled' => 0,
      'use_owner' => 0,
      'is_important' => 0,
      'created_at' => time(),
      'updated_at' => time(),
      'is_system' => 0,
      'emails' => '',
      'from' => serialize([
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ]),
      'template' => serialize([
        'ru' => '<p>{landingSetItems}</p>',
        'en' => '<p>{landingSetItems}</p>'
      ]),
      'header' => serialize([
        'ru' => 'К набору "{landingSet.name}" добавлены новые лендинги',
        'en' => 'New landings added to set "{landingSet.name}"'
      ]),
      'is_news' => 0,
      'emails_language' => 'ru'
    ]);

    $this->authAdd();
    
    $this->insert('notifications', [
      'module_id' => $modulePromoId,
      'event' => 'mcms\\promo\\components\\events\\landing_sets\\LandingsRemovedFromSet',
      'notification_type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'is_disabled' => 0,
      'use_owner' => 0,
      'is_important' => 0,
      'created_at' => time(),
      'updated_at' => time(),
      'is_system' => 0,
      'emails' => '',
      'from' => serialize([
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ]),
      'template' => serialize([
        'ru' => '<p>{landingSetItems}</p>',
        'en' => '<p>{landingSetItems}</p>'
      ]),
      'header' => serialize([
        'ru' => 'Из набора "{landingSet.name}" удалены лендинги',
        'en' => 'Landings removed from set "{landingSet.name}"'
      ]),
      'is_news' => 0,
      'emails_language' => 'ru'
    ]);
    $this->authAdd();

    $this->insert('notifications', [
      'module_id' => $modulePromoId,
      'event' => 'mcms\\promo\\components\\events\\landing_sets\\LandingsAddedToSet',
      'notification_type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'is_disabled' => 0,
      'use_owner' => 0,
      'is_important' => 0,
      'created_at' => time(),
      'updated_at' => time(),
      'is_system' => 0,
      'emails' => '',
      'from' => serialize([
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ]),
      'template' => serialize([
        'ru' => '<strong>Уважаемый {owner.username}!</strong><br>
<p>К набору "{landingSet.name}" добавлены новые лендинги:<br>{landingSetItems}<br>
</p><strong>С уважением, команда {projectName}.</strong>',
        'en' => '<strong>Greetings, {owner.username}!</strong><br>
<p>New landings added to set "{landingSet.name}":<br>{landingSetItems}<br>
</p><strong>Best regards, command of {projectName}.</strong>'
      ]),
      'header' => serialize([
        'ru' => 'К набору "{landingSet.name}" добавлены новые лендинги',
        'en' => 'New landings added to set "{landingSet.name}"'
      ]),
      'is_news' => 0,
      'emails_language' => 'ru'
    ]);
    $this->authAdd();

    $this->insert('notifications', [
      'module_id' => $modulePromoId,
      'event' => 'mcms\\promo\\components\\events\\landing_sets\\LandingsRemovedFromSet',
      'notification_type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'is_disabled' => 0,
      'use_owner' => 0,
      'is_important' => 0,
      'created_at' => time(),
      'updated_at' => time(),
      'is_system' => 0,
      'emails' => '',
      'from' => serialize([
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ]),
      'template' => serialize([
        'ru' => '<strong>Уважаемый {owner.username}!</strong><br>
<p>Из набора "{landingSet.name}" удалены лендинги:<br>{landingSetItems}<br>
</p><strong>С уважением, команда {projectName}.</strong>',
        'en' => '<strong>Greetings, {owner.username}!</strong><br>
<p>Landings removed from set "{landingSet.name}":<br>{landingSetItems}<br>
</p><strong>Best regards, command of {projectName}.</strong>'
      ]),
      'header' => serialize([
        'ru' => 'Из набора "{landingSet.name}" удалены лендинги',
        'en' => 'Landings removed from set "{landingSet.name}"'
      ]),
      'is_news' => 0,
      'emails_language' => 'ru'
    ]);
    $this->authAdd();

  }

  
  public function down()
  {
    $this->delete('notifications', [
      'event' => 'mcms\\promo\\components\\events\\landing_sets\\LandingsAddedToSet',
    ]);
    $this->delete('notifications', [
      'event' => 'mcms\\promo\\components\\events\\landing_sets\\LandingsRemovedFromSet',
    ]);
  }

  private function authAdd()
  {
    $id = $this->db->getLastInsertID();
    $this->insert('notifications_auth_item', [
      'auth_item_name' => 'reseller',
      'notification_id' => $id
    ]);
  }
}
