<?php

use console\components\Migration;

class m180323_082149_investor_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->removePermission('PromoApplyPersonalPercentsAsInvestor');

  }

  public function down()
  {
    $this->createPermission('PromoApplyPersonalPercentsAsInvestor', 'Apply to current user investors logic to view personal percents', 'PromoPermissions', ['investor']);
  }
}
