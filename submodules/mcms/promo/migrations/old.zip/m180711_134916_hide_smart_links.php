<?php

use console\components\Migration;

class m180711_134916_hide_smart_links extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->revokeRolesPermission('PromoSmartLinksIndex', ['reseller']);
  }

  public function down()
  {
    $this->assignRolesPermission('PromoSmartLinksIndex', ['reseller']);
  }
}
