<?php

use console\components\Migration;

class m160712_110134_update_settings_permissions extends Migration
{
  use \mcms\common\traits\PermissionGroupMigration;

  public function init()
  {
    parent::init();

    $this->groupPermissionName = 'PromoModule';
    $this->groupPermissionDescription = 'Module Promo';
    $this->groupPermissionDefaultRole = ['admin', 'root', 'reseller'];

    $this->groupPermissionControllers = [
      'PromoSettings' => [
        'description' => 'Can view settings permissions',
        'permissions' => [
          ['PromoCanEditDefaultTBUrlSettings'],
        ]
      ],
      'PromoLandingCategoriesController' => [
        'description' => 'Promo LandingCategories Controller',
        'permissions' => [
          ['PromoLandingCategoriesIndex', ['admin', 'root', 'reseller']],
          ['PromoLandingCategoriesUpdate', ['admin', 'root', 'reseller']],
          ['PromoLandingCategoriesUpdateModal', ['admin', 'root', 'reseller']],
          ['PromoLandingCategoriesView', ['admin', 'root', 'reseller']],
          ['PromoLandingCategoriesViewModal', ['admin', 'root', 'reseller']],
          ['CanEditLandingCategoryName', ['admin', 'root']],
          ['CanEditLandingCategoryCode', ['admin', 'root']],
          ['CanEditLandingCategoryStatus', ['admin', 'root']],
          ['CanEditLandingCategoryAlterCategories', ['admin', 'root']],
          ['CanEditLandingCategoryBannerId', ['admin', 'root', 'reseller']],
          ['CanEditLandingCategoryTbUrl', ['admin', 'root', 'reseller']],
        ]
      ],
    ];
  }
}
