<?php

use mcms\notifications\models\Notification;
use mcms\promo\models\UserPromoSetting;
use console\components\Migration;

class m171220_113358_enable_buyout_for_partners extends Migration
{
  public function up()
  {
    $this->addColumn(UserPromoSetting::tableName(), 'is_disable_buyout', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT "0"');

    $moduleApiResult = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => 'promo'])
      ->getResult();
    $modulePromoId = $moduleApiResult->id;

    $this->insert('notifications', [
      'module_id' => $modulePromoId,
      'event' => 'mcms\\promo\\components\\events\\SourceOperatorLandingsChangeProfitType',
      'notification_type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'is_disabled' => 0,
      'use_owner' => 1,
      'is_important' => 0,
      'created_at' => time(),
      'updated_at' => time(),
      'is_system' => 0,
      'emails' => '',
      'from' => serialize([
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ]),
      'template' => serialize([
        'ru' => 'В данный момент нет возможности добавлять CPA ссылки',
        'en' => 'At the moment there is no way to add CPA links'
      ]),
      'header' => serialize([
        'ru' => 'Ваши CPA ссылки были изменены на Ребилл',
        'en' => 'Your CPA links was changed to rebill'
      ]),
      'is_news' => 0,
      'emails_language' => 'ru'
    ]);

    $this->insert('notifications', [
      'module_id' => $modulePromoId,
      'event' => 'mcms\\promo\\components\\events\\SourceOperatorLandingsChangeProfitType',
      'notification_type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'is_disabled' => 0,
      'use_owner' => 1,
      'is_important' => 0,
      'created_at' => time(),
      'updated_at' => time(),
      'is_system' => 0,
      'emails' => '',
      'from' => serialize([
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ]),
      'template' => serialize([
        'ru' => '<strong>Уважаемый {owner.username}!</strong><br>
<p>К сожалению, в данный момент нет возможности добавлять CPA ссылки</p>',
        'en' => '<strong>Greetings, {owner.username}!</strong><br>
<p>Unfortunately at the moment there is no way to add CPA links</p>'
      ]),
      'header' => serialize([
        'ru' => 'Ваши CPA ссылки были изменены на Ребилл',
        'en' => 'Your CPA links was changed to rebill'
      ]),
      'is_news' => 0,
      'emails_language' => 'ru'
    ]);
  }

  public function down()
  {
    $this->delete('notifications', [
      'event' => 'mcms\\promo\\components\\events\\SourceOperatorLandingsChangeProfitType',
    ]);

    $this->dropColumn(UserPromoSetting::tableName(), 'is_disable_buyout');
  }
}
