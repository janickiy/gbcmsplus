<?php

use yii\db\Schema;
use console\components\Migration;

class m160128_092122_source_filter_operators extends Migration
{

  const TABLE = 'sources';
  public function up()
  {
    $this->addColumn(self::TABLE, 'filter_operators', 'TEXT DEFAULT NULL COMMENT \'таргетинг по операторам (json массив)\' AFTER label2');

    /** сделаем норм порядок столбцов */
    $this->alterColumn(self::TABLE, 'is_trafficback_sell', "tinyint(1) unsigned NOT NULL DEFAULT '0' AFTER trafficback_url");
    $this->alterColumn(self::TABLE, 'category_id', "mediumint(5) unsigned DEFAULT NULL AFTER name");
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'filter_operators');
  }
}
