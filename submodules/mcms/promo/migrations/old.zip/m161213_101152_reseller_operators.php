<?php

use console\components\Migration;

class m161213_101152_reseller_operators extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function up()
  {
    $this->createPermission('PromoOperatorsDetailList', 'Детальный просмотр списка операторов', 'PromoOperatorsController', ['root', 'admin']);
    $this->createPermission('PromoOperatorsDetailView', 'Детальный просмотр оператора', 'PromoOperatorsController', ['root', 'admin']);
    $this->assignRolesPermission('PromoOperatorsIndex', ['reseller']);
    $this->assignRolesPermission('PromoOperatorsView', ['reseller']);
  }

  public function down()
  {
    $this->removePermission('PromoOperatorsDetailList');
    $this->removePermission('PromoOperatorsDetailView');
    $this->revokeRolesPermission('PromoOperatorsIndex', ['reseller']);
    $this->revokeRolesPermission('PromoOperatorsView', ['reseller']);
  }
}
