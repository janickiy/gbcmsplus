<?php

use console\components\Migration;

class m160422_122404_generate_zip extends Migration
{
  public function up()
  {
    \mcms\promo\commands\WcMakeZipController::selfLaunch();
  }

  public function down()
  {
    echo "m160422_122404_generate_zip cannot be reverted.\n";
  }
}
