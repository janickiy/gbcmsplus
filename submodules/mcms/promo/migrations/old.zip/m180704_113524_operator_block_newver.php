<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m180704_113524_operator_block_newver extends Migration
{

  use PermissionTrait;

  public function up()
  {
    $this->addColumn('traffic_blocks', 'is_blacklist', 'tinyint(1) unsigned not null default 1 comment \'disable this operator\'');
    $this->addColumn('user_promo_settings', 'is_blacklist_traffic_blocks', 'tinyint(1) unsigned not null default 1 comment \'see traffic_blocks table\'');

    // по-умолчанию у ролей включен пермишен PromoTrafficBlockController. Следовательно добавленный ниже пермишен им будет доступен сразу.
    $this->createPermission('PromoTrafficBlockSwitchPartner', 'Виджет аякс-переключателя режима блокировки операторов для партнера', 'PromoTrafficBlockController');
  }

  public function down()
  {
    $this->dropColumn('traffic_blocks', 'is_blacklist');
    $this->dropColumn('user_promo_settings', 'is_blacklist_traffic_blocks');
    $this->removePermission('PromoTrafficBlockSwitchPartner');
  }
}
