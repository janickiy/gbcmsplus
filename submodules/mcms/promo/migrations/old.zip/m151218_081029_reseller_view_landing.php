<?php

use console\components\Migration;

class m151218_081029_reseller_view_landing extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'Landings' => [
        ['viewModal', 'View landing in modal window', ['admin', 'root', 'reseller']],
      ]
    ];
  }
}
