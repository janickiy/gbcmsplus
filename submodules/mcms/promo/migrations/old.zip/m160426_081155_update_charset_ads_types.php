<?php

use console\components\Migration;

class m160426_081155_update_charset_ads_types extends Migration
{
  public function up()
  {
    $this->db
      ->createCommand('ALTER TABLE `ads_types` CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;')
      ->execute();

    $this->db
      ->createCommand("SET NAMES utf8 COLLATE utf8_unicode_ci;")
      ->execute()
      ;

    $update = <<<EOF
UPDATE `ads_types` set `code` = 'redirect', `name` = 'a:2:{s:2:"ru";s:8:"Redirect";s:2:"en";s:8:"Redirect";}', `description` = 'a:2:{s:2:"ru";s:364:"При попадании на сайт пользователь сразу перенаправляется на рекламную ссылку. Есть возможность регулировки уникальности пользователя, чтобы показывать рекламу только один раз. Наиболее профитен.";s:2:"en";s:148:"After entering site user immediatedly redirected to ads link. Regulation of user uniqueness is available to show ads only one time. Most profitable.";}' where `id` = 1;

UPDATE `ads_types` set `code` = 'clickunder', `name` = 'a:2:{s:2:"ru";s:10:"ClickUnder";s:2:"en";s:10:"ClickUnder";}', `description` = 'a:2:{s:2:"ru";s:263:"Второй по профитности. Юзеру будет показана реклама после клика в любом месте сайта, при этом юзер получает контент, находящийся на вашем сайте.";s:2:"en";s:139:"Second best at profitability. Ads will be shown to user after click in any area of site, in same time user will get content from your site.";}' where `id` = 2;

UPDATE `ads_types` set `code` = 'dialog', `name` = 'a:2:{s:2:"ru";s:9:"DialogAds";s:2:"en";s:9:"DialogAds";}', `description` = 'a:2:{s:2:"ru";s:462:"Уведомление, которое показывается пользователю при попадании на ваш сайт. Выглядит так: http://wap.wiki/img/promo/NewScript Тем самым это не является жестким редиректом, но у пользователя нет выбора, кроме как нажать кнопку Продолжить. Есть возможность задавать текст.";s:2:"en";s:240:"Notification which is shown to user when he visits your site. Looks like this: http://wap.wiki/img/promo/NewScript This is not hard redirect, but user don\'t have any choice except for clicking button Continue. Text is available for editing.";}' where `id` = 3;

UPDATE `ads_types` set `code` = 'push', `name` = 'a:2:{s:2:"ru";s:7:"PushAds";s:2:"en";s:7:"PushAds";}', `description` = 'a:2:{s:2:"ru";s:488:"Уведомление, которое показывается пользователю при попадании на ваш сайт. Выглядит так: http://wap.wiki/img/promo/NewScript2 У пользователя есть выбор - остаться на сайте или уйти. Наименее профитный способ слива, но наиболее лояльный к пользователю. Есть возможность задавать текст.";s:2:"en";s:249:"Notification which is shown to user when he visits your site. Looks like this: http://wap.wiki/img/promo/NewScript2 User has choice - to stay on site or to leave. Least profitable ads type, but it\'s most loyal to user. Text is available for editing.";}' where `id` = 4;

EOF;


    $this->db
      ->createCommand($update)
      ->execute()
    ;
  }

  public function down()
  {
    echo "m160426_081155_update_charset_ads_types cannot be reverted.\n";

  }
}
