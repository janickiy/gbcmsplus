<?php

use yii\db\Expression;
use console\components\Migration;

class m170530_143819_any_css_selector extends Migration
{
  /** @var \mcms\promo\Module $promoModule */
  private $promoModule;
  private $settingName;
  private $cssClass;
  const SOURCES = 'sources';

  public function init()
  {
    parent::init();
    $promoModule = Yii::$app->getModule('promo');
    $this->promoModule = $promoModule;
    $this->settingName = $promoModule::SETTINGS_LINKS_REPLACEMENT_CLASS;
  }

  public function up()
  {
    // Заменяем селекторы в настройке модуля
    if ($this->getValue()) {
      if(!$this->saveSetting('a' . $this->getValue())) return false;
    }

    // Заменяем селекторы у источников
    $this->update(self::SOURCES, ['replace_links_css_class' => new Expression('concat("a", `replace_links_css_class`)')], ['!=', 'replace_links_css_class', '']);
  }

  public function down()
  {
    echo "m170530_143819_any_css_selector cannot be reverted.\n";

    return false;
  }

  private function saveSetting($value)
  {
    $this->promoModule->settings->offsetSet($this->settingName, $value);
  }

  private function getValue()
  {
    return $this->cssClass ?:
      $this->cssClass = $this->promoModule->settings->getValueByKey($this->settingName);
  }
}
