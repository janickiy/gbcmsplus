<?php

use console\components\Migration;

class m161102_145618_add_partner_program_autosync extends Migration
{
  const TABLE = 'user_promo_settings';
  const COLUMN = 'partner_program_autosync';

  public function safeUp()
  {
    $this->addColumn(self::TABLE, self::COLUMN, 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
  }

  public function safeDown()
  {
    $this->dropColumn(self::TABLE, self::COLUMN);
  }
}
