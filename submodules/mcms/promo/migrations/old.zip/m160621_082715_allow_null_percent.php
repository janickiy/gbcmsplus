<?php

use console\components\Migration;

class m160621_082715_allow_null_percent extends Migration
{

  const TABLE = 'personal_profit';

  public function up()
  {
    $this->alterColumn(self::TABLE, 'rebill_percent', 'decimal(5,2) DEFAULT NULL');
    $this->alterColumn(self::TABLE, 'buyout_percent', 'decimal(5,2) DEFAULT NULL');
  }

  public function down()
  {
    $this->alterColumn(self::TABLE, 'rebill_percent', 'decimal(5,2) NOT NULL');
    $this->alterColumn(self::TABLE, 'buyout_percent', 'decimal(5,2) NOT NULL');
  }
}
