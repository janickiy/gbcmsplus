<?php

use console\components\Migration;

class m180703_095803_reseller_providers extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  const TABLE = 'providers';

  public function up()
  {
    // Даем ресу необходимые права
    $this->assignRolesPermission('PromoProvidersIndex', ['reseller']);
    $this->assignRolesPermission('PromoProvidersViewModal', ['reseller']);
    $this->assignRolesPermission('PromoProvidersUpdate', ['reseller']);
    $this->assignRolesPermission('PromoLandingsUpdate', ['reseller']);

    $this->createPermission('PromoProvidersCreateExternal', 'Создание внешнего провайдера', 'PromoProvidersController', ['admin', 'root']);
    $this->createPermission('PromoLandingsCreateExternal', 'Создание лендинга для внешнего провайдера', 'PromoLandingsController', ['admin', 'root']);

    $this->createPermission('CanEditAllProviders', 'Возможность редактировать всех провайдеров (RGK и внешних)', 'PromoPermissions', ['admin', 'root']);

    // Добавляем колонку secret_key
    $this->addColumn(self::TABLE, 'secret_key', $this->string(32));
    // Добавляем колонку is_rgk
    $this->addColumn(self::TABLE, 'is_rgk', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
    // Все текущие провайдеры должны иметь флаг is_rgk
    $this->update(self::TABLE, ['is_rgk' => 1]);

  }

  public function down()
  {
    $this->revokeRolesPermission('PromoProvidersIndex', ['reseller']);
    $this->revokeRolesPermission('PromoProvidersViewModal', ['reseller']);
    $this->revokeRolesPermission('PromoProvidersUpdate', ['reseller']);
    $this->revokeRolesPermission('PromoLandingsUpdate', ['reseller']);

    $this->removePermission('PromoProvidersCreateExternal');
    $this->removePermission('PromoLandingsCreateExternal');
    $this->removePermission('CanEditAllProviders');
    $this->dropColumn(self::TABLE, 'is_rgk');
    $this->dropColumn(self::TABLE, 'secret_key');
  }
}
