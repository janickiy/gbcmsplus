<?php

use console\components\Migration;

class m160318_160616_streams_select2_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'Streams' => [
        ['streamSearch', 'Can search streams', ['root', 'admin', 'reseller', 'investor']],
      ],
    ];
  }
}
