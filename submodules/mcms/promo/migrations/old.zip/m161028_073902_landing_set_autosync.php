<?php

use console\components\Migration;

class m161028_073902_landing_set_autosync extends Migration
{
    public function up()
    {
      $this->addColumn('sources', 'landing_set_autosync', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
    }

    public function down()
    {
      $this->dropColumn('sources', 'landing_set_autosync');
    }
}
