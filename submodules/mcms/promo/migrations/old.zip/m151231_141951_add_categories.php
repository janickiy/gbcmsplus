<?php

use console\components\Migration;
use mcms\common\helpers\ArrayHelper;

class m151231_141951_add_categories extends Migration
{

  const TABLE = 'landing_categories';

  public $categories = [
    ['id' => 1, 'name' => 'Музыка'],
    ['id' => 2, 'name' => 'Кино'],
    ['id' => 3, 'name' => 'Эротика'],
    ['id' => 4, 'name' => 'Файлообменники'],
    ['id' => 5, 'name' => 'Знакомства'],
    ['id' => 6, 'name' => 'Игры'],
    ['id' => 7, 'name' => 'Общие'],
    ['id' => 8, 'name' => 'Новости'],
    ['id' => 9, 'name' => 'Рецепты'],
    ['id' => 10, 'name' => 'Мужской журнал'],
    ['id' => 11, 'name' => 'Гороскоп'],
    ['id' => 12, 'name' => 'Сонник'],
    ['id' => 13, 'name' => 'Женский журнал'],
  ];


  public function safeUp()
  {
    foreach ($this->categories as $category) {
      $model = \mcms\promo\models\LandingCategory::findOne($category['id']);

      if ($model) {
        $category = array_merge($category, ['status' => 1]);
        $this->update(self::TABLE, $category, ['id' => $category['id']]);
        continue;
      }

      $category = array_merge($category, ['status' => 1, 'created_by' => 1, 'created_at' => time()]);
      $this->insert(self::TABLE, $category);
    }

    $this->update(self::TABLE,
      ['status' => 0],
      ['not in', 'id', ArrayHelper::getColumn($this->categories, 'id')]
    );
  }

  public function safeDown()
  {

  }
}
