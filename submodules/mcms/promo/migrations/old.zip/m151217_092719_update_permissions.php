<?php

use console\components\Migration;

class m151217_092719_update_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'Landings' => [
        ['enable', 'Enable landing', ['admin', 'root', 'reseller']],
        ['disable', 'Disable landing', ['admin', 'root', 'reseller']],
      ]
    ];
  }
}
