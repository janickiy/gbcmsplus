<?php

use yii\db\Migration;

class m180724_083518_landing_operator_local_currency extends Migration
{
  const TABLE = 'landing_operators';

  public function up()
  {
    $this->addColumn(self::TABLE, 'local_currency_rebill_price', 'DECIMAL(7,3) NOT NULL AFTER default_currency_rebill_price');
    $this->addColumn(self::TABLE, 'local_currency_id', 'MEDIUMINT(5) UNSIGNED NOT NULL AFTER default_currency_rebill_price');
    $this->update(self::TABLE, ['local_currency_id' => new \yii\db\Expression('default_currency_id')]);
    $this->update(self::TABLE, ['local_currency_rebill_price' => new \yii\db\Expression('default_currency_rebill_price')]);
    $this->addForeignKey('landing_operators' . '_' . 'local_currency_id' . '_fk', 'landing_operators', 'local_currency_id', 'currencies', 'id');
  }

  public function down()
  {
    $this->dropForeignKey('landing_operators' . '_' . 'local_currency_id' . '_fk', 'landing_operators');
    $this->dropColumn(self::TABLE, 'local_currency_rebill_price');
    $this->dropColumn(self::TABLE, 'local_currency_id');
  }

}
