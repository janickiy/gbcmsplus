<?php

use console\components\Migration;

class m161101_133745_update_landings_for_set extends Migration
{
  use \mcms\common\traits\PermissionMigration;
  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->moduleName = 'Promo';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'LandingSets' => [
        ['update-landings', 'Can update landings for set', ['root', 'admin', 'reseller']],
      ],
    ];
  }
}
