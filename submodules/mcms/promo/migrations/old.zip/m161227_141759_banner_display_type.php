<?php

use console\components\Migration;

class m161227_141759_banner_display_type extends Migration
{
  public function up()
  {
    $this->addColumn('banner_templates', 'display_type', 'TINYINT(1) NOT NULL DEFAULT 0');
    $this->db->createCommand('UPDATE banner_templates SET display_type = is_iframe')->execute();
    $this->dropColumn('banner_templates', 'is_iframe');
  }

  public function down()
  {
    $this->addColumn('banner_templates', 'is_iframe', 'TINYINT(1) NOT NULL DEFAULT 0');
    $this->db->createCommand('UPDATE banner_templates SET is_iframe = display_type')->execute();
    $this->dropColumn('banner_templates', 'display_type');
  }
}
