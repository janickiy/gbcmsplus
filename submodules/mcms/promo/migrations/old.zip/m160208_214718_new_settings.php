<?php

use admin\migrations\dbfix\SettingsTransferTrait;
use console\components\Migration;

class m160208_214718_new_settings extends Migration
{
  use SettingsTransferTrait;

  const SETTINGS_USE_MAIN_REBILL_PERCENT_AS_PERSONAL_FOR_NEW_USERS = 'settings.use_default_rebill_percent_for_new_users';
  const SETTINGS_USE_MAIN_BUYOUT_PERCENT_AS_PERSONAL_FOR_NEW_USERS = 'settings.use_default_buyout_percent_for_new_users';
  const SETTINGS_MAIN_REBILL_PERCENT_FOR_INVESTOR = 'settings.main_rebill_percent_for_investor';
  const SETTINGS_MAIN_BUYOUT_PERCENT_FOR_INVESTOR = 'settings.main_buyout_percent_for_investor';
  const SETTINGS_MAIN_REBILL_PERCENT_FOR_RESELLER = 'settings.main_rebill_percent_for_reseller';
  const SETTINGS_MAIN_REBILL_PERCENT_FOR_PARTNER = 'settings.main_rebill_percent_for_partner';
  const SETTINGS_MAIN_BUYOUT_PERCENT_FOR_PARTNER = 'settings.main_buyout_percent_for_partner';
  const SETTINGS_LANDING_RATING_FOR_WEBMASTER_SOURCE = 'settings.use_default_landing_rating_for_webmaster_source';
  const SETTINGS_ALLOW_RESELLER_SET_PERSONAL_CPA_PRICE = 'settings.allow_reseller_set_personal_cpa_price';
  const SETTINGS_CAN_MANAGE_PERSONAL_CPA_PRICE = 'settings.can_manage_personal_cpa_price';
  const SETTINGS_ALLOW_SOURCE_REDIRECT = 'settings.is_allowed_source_redirect';
  const SETTINGS_DOMAIN_PRICE_USD = 'settings.domain_price_usd';
  const SETTINGS_DOMAIN_API_CLASS = 'settings.domain_api_class';
  const SETTINGS_DOMAIN_INTERNET_BS_API_KEY = 'settings.domain_internet_bs_api_key';
  const SETTINGS_DOMAIN_INTERNET_BS_API_PASSWORD = 'settings.domain_internet_bs_api_password';
  const SETTINGS_DOMAIN_CLONE = 'settings.domain_clone';
  const SETTINGS_DOMAIN_IP = 'settings.domain_ip';
  const SETTINGS_LAND_CONVERT_TEST_MIN_RATING = 'settings.land_convert_test_min_rating';
  const SETTINGS_LAND_CONVERT_TEST_MAX_HITS = 'settings.land_convert_test_max_hits';
  const SETTINGS_API_HANDLER_CLEAR_CACHE_URL_PATH = 'settings.api_handler_clear_cache_url_path';
  const SETTINGS_API_HANDLER_PATH = 'settings.api_handler_path';
  const SETTINGS_API_HANDLER_CLEAR_CACHE_TYPE = 'settings.api_handler_clear_cache_type';
  const SETTINGS_API_HANDLER_CLEAR_CACHE_TYPE_URL = 'url';
  const SETTINGS_API_HANDLER_CLEAR_CACHE_TYPE_CONSOLE = 'console';
  const SETTINGS_MOBLEADERS_ID = 'mobleaders_user_id';
  const SETTINGS_RESELLER_HIDE_PROMO = 'reseller_hide_promo';
  const SETTINGS_ARBITRARY_LINK_MODERATION = 'settings.arbitrary_link_moderation';
  const SETTINGS_MAX_REBILL_CONDITIONS_PERCENT = 'settings.max_rebill_conditions_percent';
  const SETTINGS_DEFAULT_BANNER = 'settings.default_banner';
  const SETTINGS_DEFAULT_TB_URL = 'settings.default_tb_url';
  const SETTINGS_ENABLE_TB_SELL = 'settings.enable_tb_sell';
  const SETTINGS_DISABLE_CHECK_DOMAIN = 'settings.disable_check_domain';
  const SETTINGS_CLICK_N_CONFIRM_TEXT_RU = 'settings.click_n_conform_text_ru';
  const SETTINGS_CLICK_N_CONFIRM_TEXT_EN = 'settings.click_n_conform_text_en';
  const SETTINGS_LINKS_REPLACEMENT_PERCENT = 'settings.links_replacement_percent';
  const SETTINGS_LINKS_REPLACEMENT_CLASS = 'settings.links_replacement_class';
  const PERMISSION_CAN_VIEW_BLOCKED_LANDINGS = 'PromoCanViewBlockedLandings';
  const PERMISSION_CAN_VIEW_PERSONAL_PROFITS_WIDGET = 'PromoCanViewPersonalProfitsWidget';
  const PERMISSION_CAN_VIEW_OWN_PERSONAL_PROFITS_WIDGET = 'PromoCanViewOwnPersonalProfitsWidget';
  const PERMISSION_CAN_VIEW_PERSONAL_BUYOUT_WIDGET = 'PromoCanViewPersonalBuyoutWidget';
  const PERMISSION_CAN_HAVE_PERSONAL_BUYOUT = 'PromoCanHavePersonalBuyout';
  const PERMISSION_CAN_RESELLER_HIDE_PROMO = 'PromoCanResellerHidePromo';
  const PERMISSION_CAN_PARTNER_VIEW_PROMO = 'PromoPartnerHidePromo';
  const PERMISSION_CAN_VIEW_REBILL_CONDITIONS_WIDGET = 'PromoCanViewRebillConditionsWidget';
  const PERMISSION_USE_NOT_PERSONAL_PERCENT = 'PromoUseNotPersonalPercent';
  const PERMISSION_APPLY_PERSONAL_PERCENT_AS_RESELLER = 'PromoApplyPersonalPercentsAsReseller';
  const PERMISSION_APPLY_PERSONAL_PERCENT_AS_INVESTOR = 'PromoApplyPersonalPercentsAsInvestor';
  const PERMISSION_APPLY_PERSONAL_PERCENT_AS_ROOT = 'PromoApplyPersonalPercentsAsRoot';
  const PERMISSION_PROMO_MANAGE_PERSONAL_CPA_PRICE = 'PromoManagePersonalCPAPrice';
  const PERMISSION_PROMO_MANAGE_PERSONAL_CPA_PRICE_IF_ENABLED = 'PromoManagePersonalCPAPriceIfEnabled';
  const PERMISSION_CAN_EDIT_MAIN_SETTINGS = 'PromoCanEditMainSettings';
  const PERMISSION_CAN_EDIT_FAKE_REVSHARE_SETTINGS = 'PromoCanEditFakeRevshareSettings';
  const PERMISSION_CAN_EDIT_INDIVIDUAL_FAKE_SETTINGS = 'PromoCanEditIndividualFakeSettings';
  const PERMISSION_CAN_EDIT_LANDINGS_SETTINGS = 'PromoCanEditLandingsSettings';
  const PERMISSION_CAN_EDIT_DEFAULT_TB_URL = 'PromoCanEditDefaultTBUrlSettings';
  const PERMISSION_CAN_EDIT_IS_RESELLER_BUYOUT_PRICES_FLAG = 'PromoCanEditIsResellerBuyoutPricesFlag';
  const PERMISSION_CAN_EDIT_DEFAULT_CLICK_N_CONFIRM_TEXT = 'PromoCanEditDefaultClickNConfirmText';
  const PERMISSION_CAN_EDIT_LINKS_REPLACEMENT_PERCENT = 'PromoCanEditLinksReplacementPercent';
  const PERMISSION_CAN_EDIT_LINKS_REPLACEMENT_CLASS = 'PromoCanEditLinksReplacementClass';
  const SETTINGS_FAKE_ADD_AFTER_SUBSCRIPTIONS = 'promo.settings.fake.add_after_subscriptions';
  const SETTINGS_FAKE_ADD_SUBSCRIPTION_PERCENT = 'promo.settings.fake.add_subscription_percent';
  const SETTINGS_FAKE_OFF_SUBSCRIPTION_DAYS = 'promo.settings.fake.off_subscription_days';
  const SETTINGS_FAKE_OFF_SUBSCRIPTION_PERCENT_BEFORE_DAYS = 'promo.settings.fake_off_subscriptions_percent_before_days';
  const SETTINGS_FAKE_ADD_CPA_SUBSCRIPTION_PERCENT = 'promo.settings.fake.add_cpa_subscription_percent';
  const SETTINGS_FAKE_OFF_SUBSCRIPTION_MAX_REJECTION = 'promo.settings.fake.fake_off_subscriptions_max_rejection';
  const SETTINGS_GLOBAL_ENABLE_FAKE_TO_USERS = 'promo.settings.global_enable_fake_to_users';
  const SETTINGS_INDIVIDUAL_FAKE_SETTINGS_ENABLE = 'promo.settings.individual_fake_settings_enable';
  const PERMISSION_CAN_EDIT_USER_FAKE_REVSHARE_FLAG = 'PromoCanEditUserFakeRevshareFlag';
  const PERMISSION_CAN_EDIT_STATIC_PAGES_CONFIG = 'PromoCanEditStaticPagesConfig';
  const SETTINGS_STATIC_PAGES_CONFIG = 'settings.static_pages_config';
  const SETTINGS_ENABLE_EDIT_OWN_BUYOUT_PERCENT = 'enable_edit_own_buyout_percent';
  const SETTINGS_ALLOW_PARTNER_BUYOUT_PERCENT_MORE_THAN_100 = 'allow_partner_buyout_percent_more_than_100';
  const SETTINGS_LANDING_POWERED_BY = 'landing_powered_by';
  const SETTINGS_GLOBAL_ALLOW_FORCE_OPERATOR = 'settings.global_allow_force_operator';
  const SETTINGS_IS_LANDINGS_AUTO_ROTATION_GLOBAL_ENABLED = 'settings.is_landings_auto_rotation_global_enabled';
  const SETTINGS_MIN_COUNT_HITS_ON_LANDING = 'settings.min_count_landings_in_source';
  const SETTINGS_NEW_LANDINGS_CHANCE = 'settings.new_landings_chance';

  const MODULE_ID = 'promo';

  const SETTINGS_TABLE = 'rgk_settings';
  const PERMISSIONS_TABLE = 'rgk_settings_permissions';
  const OPTIONS_TABLE = 'rgk_settings_options';
  const VALUES_TABLE = 'rgk_settings_values';

  public function up()
  {
    $this->insertValues();
  }

  public function down()
  {

  }

  private function getRepository()
  {
    return (new admin\migrations\dbfix\Repository())
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('promo.settings.on/off_use_main_rebill_percent_as_personal_for_new_users')
          ->setKey(self::SETTINGS_USE_MAIN_REBILL_PERCENT_AS_PERSONAL_FOR_NEW_USERS)
          ->setValue(true)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_buyouts_rebills', 'sort' => 2])
          ->setSort(12)
      )
      ->set(
        (new admin\migrations\dbfix\Integer())
          ->setName('promo.settings.landing_rating_for_webmaster_source')
          ->setKey(self::SETTINGS_LANDING_RATING_FOR_WEBMASTER_SOURCE)
          ->setValue(5)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_sources', 'sort' => 6])
          ->setFormGroup(['name' => 'app.common.form_group_landing_test', 'sort' => 1])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\Integer())
          ->setName('promo.settings.land_convert_test_min_rating')
          ->setKey(self::SETTINGS_LAND_CONVERT_TEST_MIN_RATING)
          ->setValue(7)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_sources', 'sort' => 6])
          ->setFormGroup(['name' => 'app.common.form_group_landing_test', 'sort' => 1])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\Integer())
          ->setName('promo.settings.land_convert_test_max_hits')
          ->setKey(self::SETTINGS_LAND_CONVERT_TEST_MAX_HITS)
          ->setHint('promo.settings.land_convert_test_max_hits_hint')
          ->setValue(1000)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_sources', 'sort' => 6])
          ->setFormGroup(['name' => 'app.common.form_group_landing_test', 'sort' => 1])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('promo.settings.on/off_use_main_buyout_percent_as_personal_for_new_users')
          ->setKey(self::SETTINGS_USE_MAIN_BUYOUT_PERCENT_AS_PERSONAL_FOR_NEW_USERS)
          ->setValue(true)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_buyouts_rebills', 'sort' => 2])
          ->setSort(11)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('promo.settings.arbitrary_link_moderation')
          ->setKey(self::SETTINGS_ARBITRARY_LINK_MODERATION)
          ->setValue(false)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_links', 'sort' => 7])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('promo.settings.disable_check_domain')
          ->setKey(self::SETTINGS_DISABLE_CHECK_DOMAIN)
          ->setValue(false)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_sources', 'sort' => 6])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\Float())
          ->setName('promo.settings.main_rebill_percent_for_investor')
          ->setKey(self::SETTINGS_MAIN_REBILL_PERCENT_FOR_INVESTOR)
          ->setValue(100)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_buyouts_rebills', 'sort' => 2])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\Float())
          ->setName('promo.settings.main_buyout_percent_for_investor')
          ->setKey(self::SETTINGS_MAIN_BUYOUT_PERCENT_FOR_INVESTOR)
          ->setValue(10)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_buyouts_rebills', 'sort' => 2])
          ->setSort(4)
      )
      ->set(
        (new admin\migrations\dbfix\Float())
          ->setName('promo.settings.main_rebill_percent_for_reseller')
          ->setKey(self::SETTINGS_MAIN_REBILL_PERCENT_FOR_RESELLER)
          ->setValue(90)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_buyouts_rebills', 'sort' => 2])
          ->setSort(5)
      )
      ->set(
        (new admin\migrations\dbfix\Float())
          ->setName('promo.settings.main_rebill_percent_for_partner')
          ->setKey(self::SETTINGS_MAIN_REBILL_PERCENT_FOR_PARTNER)
          ->setValue(100)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_buyouts_rebills', 'sort' => 2])
          ->setSort(6)
      )
      ->set(
        (new admin\migrations\dbfix\Float())
          ->setName('promo.settings.main_buyout_percent_for_partner')
          ->setKey(self::SETTINGS_MAIN_BUYOUT_PERCENT_FOR_PARTNER)
          ->setValue(100)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_buyouts_rebills', 'sort' => 2])
          ->setSort(7)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('promo.settings.allow_reseller_set_personal_cpa_price')
          ->setKey(self::SETTINGS_ALLOW_RESELLER_SET_PERSONAL_CPA_PRICE)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_buyouts_rebills', 'sort' => 2])
          ->setSort(8)
      )
      ->set(
        (new admin\migrations\dbfix\Integer())
          ->setName('promo.settings.max_rebill_correct_conditions_percent')
          ->setKey(self::SETTINGS_MAX_REBILL_CONDITIONS_PERCENT)
          ->setValue(15)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_buyouts_rebills', 'sort' => 2])
          ->setSort(13)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('promo.settings.enable_edit_own_buyout_percent')
          ->setKey(self::SETTINGS_ENABLE_EDIT_OWN_BUYOUT_PERCENT)
          ->setValue(false)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_buyouts_rebills', 'sort' => 2])
          ->setSort(9)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('promo.settings.allow_partner_buyout_percent_more_than_100')
          ->setKey(self::SETTINGS_ALLOW_PARTNER_BUYOUT_PERCENT_MORE_THAN_100)
          ->setValue(false)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_buyouts_rebills', 'sort' => 2])
          ->setSort(10)
      )
      ->set(
        (new admin\migrations\dbfix\Float())
          ->setName('promo.settings.domain_price_usd')
          ->setKey(self::SETTINGS_DOMAIN_PRICE_USD)
          ->setValue('8')
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setFormGroup(['name' => 'app.common.form_group_domain_registration', 'sort' => 4])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\Lists())
          ->setName('promo.settings.domain_api_class')
          ->setKey(self::SETTINGS_DOMAIN_API_CLASS)
          ->setOptions(['InternetBs' => 'promo.settings.InternetBs'])
          ->setValue('InternetBs')
          ->setHint('promo.settings.domain_api_class-hint')
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setFormGroup(['name' => 'app.common.form_group_domain_registration', 'sort' => 4])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('promo.settings.domain_internet_bs_api_key')
          ->setKey(self::SETTINGS_DOMAIN_INTERNET_BS_API_KEY)
          ->setValue('Q1O7H2M8T5S8Z6K4N1D5')
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setFormGroup(['name' => 'app.common.form_group_domain_registration', 'sort' => 4])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('promo.settings.domain_internet_bs_api_password')
          ->setKey(self::SETTINGS_DOMAIN_INTERNET_BS_API_PASSWORD)
          ->setValue('4g6pF9HCfDPb67XG')
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setFormGroup(['name' => 'app.common.form_group_domain_registration', 'sort' => 4])
          ->setSort(4)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('promo.settings.domain_clone')
          ->setKey(self::SETTINGS_DOMAIN_CLONE)
          ->setValue('forapi.com')
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setFormGroup(['name' => 'app.common.form_group_domain_registration', 'sort' => 4])
          ->setSort(5)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('promo.settings.domain_ip')
          ->setKey(self::SETTINGS_DOMAIN_IP)
          ->setValue('0.0.0.0')
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setFormGroup(['name' => 'app.common.form_group_domain_registration', 'sort' => 4])
          ->setSort(6)
      )
      ->set(
        (new admin\migrations\dbfix\Lists())
          ->setName('promo.settings.api_handler_clear_cache_type')
          ->setKey(self::SETTINGS_API_HANDLER_CLEAR_CACHE_TYPE)
          ->setOptions([
            self::SETTINGS_API_HANDLER_CLEAR_CACHE_TYPE_CONSOLE => 'promo.settings.api_handler_clear_cache_type_console',
            self::SETTINGS_API_HANDLER_CLEAR_CACHE_TYPE_URL => 'promo.settings.api_handler_clear_cache_type_url'
          ])
          ->setValue(self::SETTINGS_API_HANDLER_CLEAR_CACHE_TYPE_URL)
          ->setHint('promo.settings.api_handler_clear_cache_type_hint')
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setSort(5)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('promo.settings.api_handler_clear_cache_url_path')
          ->setKey(self::SETTINGS_API_HANDLER_CLEAR_CACHE_URL_PATH)
          ->setHint('promo.settings.api_handler_clear_cache_url_path_hint')
          ->setValue('/clear-cache')
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setSort(6)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('promo.settings.api_handler_path')
          ->setKey(self::SETTINGS_API_HANDLER_PATH)
          ->setValue('/var/www/clients/client1/web3/web')
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setSort(7)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('promo.settings.mobleaders_sync_id')
          ->setKey(self::SETTINGS_MOBLEADERS_ID)
          ->setValue('')
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setSort(8)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('promo.settings.allow_reseller_hide_promo')
          ->setKey(self::SETTINGS_RESELLER_HIDE_PROMO)
          ->setValue(false)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('promo.settings.default_tb_url')
          ->setKey(self::SETTINGS_DEFAULT_TB_URL)
          ->setValidators([['url']])
          ->setPermissions([self::PERMISSION_CAN_EDIT_DEFAULT_TB_URL])
          ->setGroup(['name' => 'app.common.group_links', 'sort' => 7])
          ->setFormGroup(['name' => 'app.common.form_group_tb', 'sort' => 2])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('promo.settings.enable_tb_sell')
          ->setKey(self::SETTINGS_ENABLE_TB_SELL)
          ->setValue(false)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_links', 'sort' => 7])
          ->setFormGroup(['name' => 'app.common.form_group_tb', 'sort' => 2])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('promo.settings.global_allow_force_operator')
          ->setHint('promo.settings.global_allow_force_operator-hint')
          ->setKey(self::SETTINGS_GLOBAL_ALLOW_FORCE_OPERATOR)
          ->setValue(false)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_links', 'sort' => 7])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('promo.settings.is_allowed_source_redirect')
          ->setKey(self::SETTINGS_ALLOW_SOURCE_REDIRECT)
          ->setValue(false)
          ->setPermissions([self::PERMISSION_CAN_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_sources', 'sort' => 6])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\Text())
          ->setName('promo.settings.static_pages_config')
          ->setKey(self::SETTINGS_STATIC_PAGES_CONFIG)
          ->setPermissions([self::PERMISSION_CAN_EDIT_STATIC_PAGES_CONFIG])
          ->setValidators([['string']])
          ->setValue('')
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setFormGroup(['name' => 'app.common.form_group_lp_parameters', 'sort' => 1])
          ->setSort(6)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setKey(self::SETTINGS_FAKE_ADD_AFTER_SUBSCRIPTIONS)
          ->setName('promo.settings.add_after_subscriptions')
          ->setValidators([
            ['number'],
            ['compare', ['compareValue' => 0, 'operator' => '>=']]
          ])
          ->setValue(0)
          ->setPermissions([self::PERMISSION_CAN_EDIT_FAKE_REVSHARE_SETTINGS])
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_fake_subs', 'sort' => 3])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setKey(self::SETTINGS_FAKE_ADD_SUBSCRIPTION_PERCENT)
          ->setName('promo.settings.add_subscription_percent')
          ->setValidators([
            ['number'],
            ['compare', ['compareValue' => 0, 'operator' => '>=']],
            ['compare', ['compareValue' => 100, 'operator' => '<=']]
          ])
          ->setValue(0)
          ->setPermissions([self::PERMISSION_CAN_EDIT_FAKE_REVSHARE_SETTINGS])
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_fake_subs', 'sort' => 3])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setKey(self::SETTINGS_FAKE_OFF_SUBSCRIPTION_DAYS)
          ->setName('promo.settings.off_subscription_time')
          ->setValidators([
            ['number'],
            ['compare', ['compareValue' => 0, 'operator' => '>=']],
          ])
          ->setValue(0)
          ->setPermissions([self::PERMISSION_CAN_EDIT_FAKE_REVSHARE_SETTINGS])
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_fake_subs', 'sort' => 3])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setKey(self::SETTINGS_FAKE_OFF_SUBSCRIPTION_PERCENT_BEFORE_DAYS)
          ->setName('promo.settings.fake_off_subscriptions_percent_time')
          ->setValidators([
            ['number'],
            ['compare', ['compareValue' => 0, 'operator' => '>=']],
            ['compare', ['compareValue' => 100, 'operator' => '<=']]
          ])
          ->setValue(0)
          ->setPermissions([self::PERMISSION_CAN_EDIT_FAKE_REVSHARE_SETTINGS])
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_fake_subs', 'sort' => 3])
          ->setSort(4)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setKey(self::SETTINGS_FAKE_ADD_CPA_SUBSCRIPTION_PERCENT)
          ->setName('promo.settings.add_cpa_subscription_percent')
          ->setValidators([
            ['number'],
            ['compare', ['compareValue' => 0, 'operator' => '>=']],
            ['compare', ['compareValue' => 100, 'operator' => '<=']]
          ])
          ->setValue(0)
          ->setPermissions([self::PERMISSION_CAN_EDIT_FAKE_REVSHARE_SETTINGS])
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_fake_subs', 'sort' => 3])
          ->setSort(5)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setKey(self::SETTINGS_FAKE_OFF_SUBSCRIPTION_MAX_REJECTION)
          ->setName('promo.settings.fake_off_subscriptions_max_rejection')
          ->setValidators([
            ['number'],
            ['compare', ['compareValue' => 0, 'operator' => '>=']],
          ])
          ->setValue(100)
          ->setPermissions([self::PERMISSION_CAN_EDIT_FAKE_REVSHARE_SETTINGS])
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_fake_subs', 'sort' => 3])
          ->setSort(6)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('promo.settings.global_enable_fake_to_users')
          ->setKey(self::SETTINGS_GLOBAL_ENABLE_FAKE_TO_USERS)
          ->setValue(true)
          ->setHint('promo.settings.global_enable_fake_to_users-hint')
          ->setPermissions([self::PERMISSION_CAN_EDIT_FAKE_REVSHARE_SETTINGS])
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_fake_subs', 'sort' => 3])
          ->setSort(7)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('promo.settings.individual_fake_settings_enable')
          ->setKey(self::SETTINGS_INDIVIDUAL_FAKE_SETTINGS_ENABLE)
          ->setHint('promo.settings.individual_fake_settings_enable-hint')
          ->setPermissions([self::PERMISSION_CAN_EDIT_FAKE_REVSHARE_SETTINGS])
          ->setValue(false)
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_fake_subs', 'sort' => 3])
          ->setSort(8)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('promo.settings.landing_powered_by')
          ->setKey(self::SETTINGS_LANDING_POWERED_BY)
          ->setPermissions([self::PERMISSION_CAN_EDIT_LANDINGS_SETTINGS])
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_links', 'sort' => 7])
          ->setFormGroup(['name' => 'app.common.form_group_landings', 'sort' => 3])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('promo.settings.is_landings_auto_rotation_global_enabled')
          ->setKey(self::SETTINGS_IS_LANDINGS_AUTO_ROTATION_GLOBAL_ENABLED)
          ->setPermissions([self::PERMISSION_CAN_EDIT_LANDINGS_SETTINGS])
          ->setValue(false)
          ->setGroup(['name' => 'app.common.group_sources', 'sort' => 6])
          ->setFormGroup(['name' => 'app.common.autorotation', 'sort' => 5])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setKey(self::SETTINGS_MIN_COUNT_HITS_ON_LANDING)
          ->setName('promo.settings.min_count_hits_on_landing_at_source')
          ->setValidators([
            ['number', ['min' => 0]],
          ])
          ->setValue(1000)
          ->setPermissions([self::PERMISSION_CAN_EDIT_LANDINGS_SETTINGS])
          ->setGroup(['name' => 'app.common.group_sources', 'sort' => 6])
          ->setFormGroup(['name' => 'app.common.autorotation', 'sort' => 5])
          ->setSort(2)
          ->setDependency(['id' => 'is_landings_auto_rotation_global_enabled', 'attribute' => self::SETTINGS_IS_LANDINGS_AUTO_ROTATION_GLOBAL_ENABLED, 'value' => true])
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setKey(self::SETTINGS_NEW_LANDINGS_CHANCE)
          ->setName('promo.settings.new_landings_chance')
          ->setValidators([
            ['number', ['min' => 0, 'max' => 100]],
          ])
          ->setValue(30)
          ->setPermissions([self::PERMISSION_CAN_EDIT_LANDINGS_SETTINGS])
          ->setGroup(['name' => 'app.common.group_sources', 'sort' => 6])
          ->setFormGroup(['name' => 'app.common.autorotation', 'sort' => 5])
          ->setSort(3)
          ->setDependency(['id' => 'is_landings_auto_rotation_global_enabled', 'attribute' => self::SETTINGS_IS_LANDINGS_AUTO_ROTATION_GLOBAL_ENABLED, 'value' => true])
      )
      ->set(
        (new admin\migrations\dbfix\Text())
          ->setName('promo.settings.default_click_n_confirm_text_ru')
          ->setKey(self::SETTINGS_CLICK_N_CONFIRM_TEXT_RU)
          ->setPermissions([self::PERMISSION_CAN_EDIT_DEFAULT_CLICK_N_CONFIRM_TEXT])
          ->setValidators([['string']])
          ->setValue('Чтобы перейти в мобильную версию сайта нажмите Далее.')
          ->setGroup(['name' => 'app.common.group_sources', 'sort' => 6])
          ->setFormGroup(['name' => 'app.common.form_group_click_confirm', 'sort' => 3])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\Text())
          ->setName('promo.settings.default_click_n_confirm_text_en')
          ->setKey(self::SETTINGS_CLICK_N_CONFIRM_TEXT_EN)
          ->setPermissions([self::PERMISSION_CAN_EDIT_DEFAULT_CLICK_N_CONFIRM_TEXT])
          ->setValidators([['string']])
          ->setValue('Click please')
          ->setGroup(['name' => 'app.common.group_sources', 'sort' => 6])
          ->setFormGroup(['name' => 'app.common.form_group_click_confirm', 'sort' => 3])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('promo.settings.links_replacement_percent')
          ->setValidators([
            ['number'],
            ['compare', ['compareValue' => 0, 'operator' => '>=']],
            ['compare', ['compareValue' => 100, 'operator' => '<=']]
          ])
          ->setKey(self::SETTINGS_LINKS_REPLACEMENT_PERCENT)
          ->setPermissions([self::PERMISSION_CAN_EDIT_LINKS_REPLACEMENT_PERCENT])
          ->setValue(100)
          ->setGroup(['name' => 'app.common.group_sources', 'sort' => 6])
          ->setFormGroup(['name' => 'app.common.form_group_link_change', 'sort' => 4])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('promo.settings.links_replacement_class')
          ->setKey(self::SETTINGS_LINKS_REPLACEMENT_CLASS)
          ->setPermissions([self::PERMISSION_CAN_EDIT_LINKS_REPLACEMENT_CLASS])
          ->setValidators([['string']])
          ->setValue('')
          ->setGroup(['name' => 'app.common.group_sources', 'sort' => 6])
          ->setFormGroup(['name' => 'app.common.form_group_link_change', 'sort' => 4])
          ->setSort(2)
      );
  }
}
