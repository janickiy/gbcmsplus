<?php

use console\components\Migration;

class m160309_140642_landing_category_code_n_alter extends Migration
{

  const TABLE = 'landing_categories';

  public function safeUp()
  {
    $this->addColumn(self::TABLE, 'code', $this->string(50) . ' after id');
    $this->addColumn(self::TABLE, 'alter_categories', $this->string() . ' after status');

    $this->updateCategory(1, 'music', ['common', 'fileshare']);
    $this->updateCategory(2, 'movies', ['common', 'fileshare']);
    $this->updateCategory(3, 'erotic');
    $this->updateCategory(4, 'fileshare', ['common']);
    $this->updateCategory(5, 'dating', ['common', 'fileshare']);
    $this->updateCategory(6, 'games', ['common', 'fileshare']);
    $this->updateCategory(7, 'common', ['fileshare']);
    $this->updateCategory(8, 'news', ['common', 'fileshare']);
    $this->updateCategory(9, 'receipts', ['common', 'fileshare']);
    $this->updateCategory(10, 'mens_magazine', ['common', 'fileshare']);
    $this->updateCategory(11, 'horoscope', ['common', 'fileshare']);
    $this->updateCategory(12, 'dream_book', ['common', 'fileshare']);
    $this->updateCategory(13, 'womens_magazine', ['common', 'fileshare']);
    $this->updateCategory(14, 'homework', ['common', 'fileshare']);

    $this->alterColumn(self::TABLE, 'code', $this->string(50)->notNull());
    $this->createIndex(self::TABLE . 'code_uq', self::TABLE, 'code', true);
  }

  public function safeDown()
  {
    $this->dropColumn(self::TABLE, 'code');
    $this->dropColumn(self::TABLE, 'alter_categories');
  }

  public function updateCategory($pk, $code, $alter = [])
  {
    $this->update(self::TABLE,
      ['code' => $code, 'alter_categories' => serialize($alter)],
      ['id' => $pk]
    );
  }
}
