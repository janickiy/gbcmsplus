<?php

use console\components\Migration;

class m161021_094004_banner_settings extends Migration
{
    public function up()
    {
      $this->addColumn('banners', 'opacity', $this->integer(3)->unsigned());
      $this->addColumn('banners', 'cross_position', 'tinyint unsigned');
      $this->addColumn('banners', 'timeout', $this->integer(3)->unsigned());
      $this->update('banners', ['opacity' => 60, 'cross_position' => 1, 'timeout' => 0]);
    }

    public function down()
    {
      $this->dropColumn('banners', 'opacity');
      $this->dropColumn('banners', 'cross_position');
      $this->dropColumn('banners', 'timeout');
    }
}
