<?php

use console\components\Migration;

class m160316_074201_buyout_price extends Migration
{

  const TABLE = 'personal_profit';
  const BUY_PROFIT = 'buyout_profit';

  public function up()
  {
    $this->addColumn(self::TABLE, self::BUY_PROFIT, 'decimal(5,2) AFTER buyout_percent');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, self::BUY_PROFIT);
  }

}
