<?php

use console\components\Migration;

class m151129_114534_is_trafficback_sell extends Migration
{
  public function up()
  {
    $this->addColumn('sources', 'is_trafficback_sell', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
    $this->createIndex('sources' . '_' . 'is_trafficback_sell' . '_index', 'sources', 'is_trafficback_sell');
  }

  public function down()
  {
    $this->dropColumn('sources', 'is_trafficback_sell');
  }
}
