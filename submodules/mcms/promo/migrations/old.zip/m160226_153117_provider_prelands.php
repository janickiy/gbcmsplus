<?php

use console\components\Migration;

class m160226_153117_provider_prelands extends Migration
{
  public function up()
  {
    $this->addColumn('providers', 'preland_add_param', 'VARCHAR(32) DEFAULT NULL');
    $this->addColumn('providers', 'preland_off_param', 'VARCHAR(32) DEFAULT NULL');
  }

  public function down()
  {
    $this->dropColumn('providers', 'preland_add_param');
    $this->dropColumn('providers', 'preland_off_param');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
