<?php

use console\components\Migration;

class m180424_131822_rebill_conditions_permission extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->revokeRolesPermission('PromoCanViewRebillConditionsWidget', ['admin','reseller']);
    $this->revokeRolesPermission('PromoRebillConditionsCreateModal', ['admin','reseller']);
    $this->revokeRolesPermission('PromoRebillConditionsDelete', ['admin','reseller']);
    $this->revokeRolesPermission('PromoRebillConditionsIndex', ['admin','reseller']);
    $this->revokeRolesPermission('PromoRebillConditionsUpdateModal', ['admin','reseller']);

  }

  public function down()
  {
    $this->assignRolesPermission('PromoCanViewRebillConditionsWidget', ['admin']);
    $this->assignRolesPermission('PromoRebillConditionsCreateModal', ['admin']);
    $this->assignRolesPermission('PromoRebillConditionsDelete', ['admin']);
    $this->assignRolesPermission('PromoRebillConditionsIndex', ['admin']);
    $this->assignRolesPermission('PromoRebillConditionsUpdateModal', ['admin']);
  }

}
