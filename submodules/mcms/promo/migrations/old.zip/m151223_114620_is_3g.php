<?php

use console\components\Migration;

class m151223_114620_is_3g extends Migration
{

  const TABLE = 'operators';

  public function up()
  {
    $this->addColumn(self::TABLE, 'is_3g', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0 AFTER name');
    $this->createIndex('operators_is_3g_index', self::TABLE, 'is_3g');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'is_3g');
  }
}
