<?php

use console\components\Migration;

class m151026_111316_currencies extends Migration
{

  protected $tableName = '{{%currencies}}';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable($this->tableName, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string()->notNull(),
      'code' => $this->string(30)->notNull(),
      'symbol' => $this->string(30)->notNull(),
      'created_by' => 'MEDIUMINT(5) UNSIGNED',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

  }

  public function down()
  {
    $this->dropTable($this->tableName);
  }
}
