<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
*/
class m180920_070521_5digits_admin extends Migration
{
  use PermissionTrait;
  /**
  */
  public function up()
  {
    $approve = \mcms\common\helpers\Console::confirm('Эту миграцию должен выполнить админ. Пропустить миграцию?');
    if ($approve) return true;

    echo 'subscription_rebills...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE subscription_rebills
      CHANGE default_profit default_profit decimal(9, 5) unsigned not null,
      CHANGE real_profit_rub real_profit_rub decimal(9, 5) unsigned not null,
      CHANGE real_profit_usd real_profit_usd decimal(9, 5) unsigned not null,
      CHANGE real_profit_eur real_profit_eur decimal(9, 5) unsigned not null,
      CHANGE reseller_profit_rub reseller_profit_rub decimal(9, 5) unsigned not null,
      CHANGE reseller_profit_usd reseller_profit_usd decimal(9, 5) unsigned not null,
      CHANGE reseller_profit_eur reseller_profit_eur decimal(9, 5) unsigned not null,
      CHANGE profit_rub profit_rub decimal(9, 5) unsigned not null,
      CHANGE profit_usd profit_usd decimal(9, 5) unsigned not null,
      CHANGE profit_eur profit_eur decimal(9, 5) unsigned not null;
      ')->execute();

    echo 'onetime_subscriptions...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE onetime_subscriptions
      CHANGE default_profit default_profit decimal(9, 5) unsigned not null,
      CHANGE real_profit_rub real_profit_rub decimal(9, 5) unsigned not null,
      CHANGE real_profit_usd real_profit_usd decimal(9, 5) unsigned not null,
      CHANGE real_profit_eur real_profit_eur decimal(9, 5) unsigned not null,
      CHANGE reseller_profit_rub reseller_profit_rub decimal(9, 5) unsigned not null,
      CHANGE reseller_profit_usd reseller_profit_usd decimal(9, 5) unsigned not null,
      CHANGE reseller_profit_eur reseller_profit_eur decimal(9, 5) unsigned not null,
      CHANGE profit_rub profit_rub decimal(9, 5) unsigned not null,
      CHANGE profit_usd profit_usd decimal(9, 5) unsigned not null,
      CHANGE profit_eur profit_eur decimal(9, 5) unsigned not null,
      CHANGE calc_profit_rub calc_profit_rub decimal(9, 5) unsigned default \'0.00\' not null
  comment \'расчитанный профит партнера без учета корректировки\',
      CHANGE calc_profit_usd calc_profit_usd decimal(9, 5) unsigned default \'0.00\' not null
  comment \'расчитанный профит партнера без учета корректировки\',
      CHANGE calc_profit_eur calc_profit_eur decimal(9, 5) unsigned default \'0.00\' not null
  comment \'расчитанный профит партнера без учета корректировки\';
      ')->execute();

    echo 'user_balance_invoices...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE user_balance_invoices
      CHANGE amount amount          decimal(15, 5)           null
      ')->execute();

  }

  /**
  */
  public function down()
  {
    $approve = \mcms\common\helpers\Console::confirm('Эту миграцию должен выполнить админ. Пропустить миграцию?');
    if ($approve) return true;

    echo 'user_balance_invoices...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE user_balance_invoices
      CHANGE amount amount          decimal(13, 3)           null
      ')->execute();

    echo 'onetime_subscriptions...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE onetime_subscriptions
      CHANGE default_profit default_profit decimal(7, 3) unsigned not null,
      CHANGE real_profit_rub real_profit_rub decimal(7, 3) unsigned not null,
      CHANGE real_profit_usd real_profit_usd decimal(7, 3) unsigned not null,
      CHANGE real_profit_eur real_profit_eur decimal(7, 3) unsigned not null,
      CHANGE reseller_profit_rub reseller_profit_rub decimal(7, 3) unsigned not null,
      CHANGE reseller_profit_usd reseller_profit_usd decimal(7, 3) unsigned not null,
      CHANGE reseller_profit_eur reseller_profit_eur decimal(7, 3) unsigned not null,
      CHANGE profit_rub profit_rub decimal(7, 3) unsigned not null,
      CHANGE profit_usd profit_usd decimal(7, 3) unsigned not null,
      CHANGE profit_eur profit_eur decimal(7, 3) unsigned not null,
      CHANGE calc_profit_rub calc_profit_rub decimal(7, 3) unsigned default \'0.00\' not null
  comment \'расчитанный профит партнера без учета корректировки\',
      CHANGE calc_profit_usd calc_profit_usd decimal(7, 3) unsigned default \'0.00\' not null
  comment \'расчитанный профит партнера без учета корректировки\',
      CHANGE calc_profit_eur calc_profit_eur decimal(7, 3) unsigned default \'0.00\' not null
  comment \'расчитанный профит партнера без учета корректировки\';
      ')->execute();

    echo 'subscription_rebills...' . PHP_EOL;
    $this->db->createCommand('ALTER TABLE subscription_rebills
      CHANGE default_profit default_profit decimal(7, 3) unsigned not null,
      CHANGE real_profit_rub real_profit_rub decimal(7, 3) unsigned not null,
      CHANGE real_profit_usd real_profit_usd decimal(7, 3) unsigned not null,
      CHANGE real_profit_eur real_profit_eur decimal(7, 3) unsigned not null,
      CHANGE reseller_profit_rub reseller_profit_rub decimal(7, 3) unsigned not null,
      CHANGE reseller_profit_usd reseller_profit_usd decimal(7, 3) unsigned not null,
      CHANGE reseller_profit_eur reseller_profit_eur decimal(7, 3) unsigned not null,
      CHANGE profit_rub profit_rub decimal(7, 3) unsigned not null,
      CHANGE profit_usd profit_usd decimal(7, 3) unsigned not null,
      CHANGE profit_eur profit_eur decimal(7, 3) unsigned not null;
      ')->execute();
  }
}
