<?php

use console\components\Migration;

class m170607_132416_add_is_allow_source_redirect_to_users extends Migration
{
  public function up()
  {
    $this->addColumn('user_promo_settings', 'is_allowed_source_redirect', 'TINYINT(1) NOT NULL DEFAULT 0');
  }

  public function down()
  {
    $this->dropColumn('user_promo_settings', 'is_allowed_source_redirect');
  }
}
