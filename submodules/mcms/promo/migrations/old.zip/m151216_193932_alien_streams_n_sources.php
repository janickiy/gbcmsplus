<?php

use console\components\Migration;

class m151216_193932_alien_streams_n_sources extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'ViewOtherPeople' => [
        ['streams', 'Can view other users streams', ['admin', 'root', 'reseller']],
        ['sources', 'Can view other users sources', ['admin', 'root', 'reseller']],
      ]
    ];
  }
}
