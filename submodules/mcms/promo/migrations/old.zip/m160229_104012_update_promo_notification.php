<?php

use console\components\Migration;

class m160229_104012_update_promo_notification extends Migration
{
  public function up()
  {
    $notifications = (new \yii\db\Query())
      ->from(\mcms\notifications\models\Notification::tableName())
      ->select("id")
      ->where([
        'event' => \mcms\promo\components\events\SourceStatusChanged::className(),
        'notification_type' => \mcms\notifications\models\Notification::NOTIFICATION_TYPE_BROWSER
      ])
      ->indexBy("id")
      ->all()
      ;

    foreach ($notifications as $notificationId => $notification) {
      $this->db->createCommand(
        'DELETE from notifications_auth_item WHERE notification_id = :notificationId',
        [':notificationId' => $notificationId]
      )->execute();

      $this->db->createCommand(
        'UPDATE notifications set use_owner = 1 where id = :notificationId',
        [':notificationId' => $notificationId]
      )->execute();
    }
  }

  public function down()
  {
    echo "m160229_104012_update_promo_notification cannot be reverted.\n";
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
