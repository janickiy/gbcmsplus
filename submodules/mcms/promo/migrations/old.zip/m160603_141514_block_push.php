<?php

use console\components\Migration;

class m160603_141514_block_push extends Migration
{
  public function up()
  {
    $this->update('ads_types', ['status' => 2], ['code' => 'push']);
    $this->update('ads_types', ['profit' => 4, 'name' => serialize(['ru' => 'FullScreen Ads', 'en' => 'FullScreen Ads'])], ['code' => 'dialog']);
  }

  public function down()
  {
    $this->update('ads_types', ['status' => 1], ['code' => 'push']);
    $this->update('ads_types', ['profit' => 3, 'name' => serialize(['ru' => 'DialogAds', 'en' => 'DialogAds'])], ['code' => 'dialog']);
  }
}
