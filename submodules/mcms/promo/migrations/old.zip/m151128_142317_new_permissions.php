<?php

use console\components\Migration;

class m151128_142317_new_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'Platforms' => [
        ['index', 'Lists all Platform models', ['admin', 'root']],
        ['createModal', 'Create a Platform model', ['admin', 'root']],
        ['updateModal', 'Updates an existing Platform model', ['admin', 'root']],
        ['enable', 'Enable an existing Platform model', ['admin', 'root']],
        ['disable', 'Disable an existing Platform model', ['admin', 'root']],
      ],
      'ForbiddenTrafficTypes' => [
        ['index', 'Lists all ForbiddenTrafficType models', ['admin', 'root']],
        ['createModal', 'Create a ForbiddenTrafficType model', ['admin', 'root']],
        ['updateModal', 'Updates an existing ForbiddenTrafficType model', ['admin', 'root']],
        ['enable', 'Enable an existing ForbiddenTrafficType model', ['admin', 'root']],
        ['disable', 'Disable an existing ForbiddenTrafficType model', ['admin', 'root']],
      ],
      'LandingPayTypes' => [
        ['index', 'Lists all LandingPayType models', ['admin', 'root']],
        ['createModal', 'Create a LandingPayType model', ['admin', 'root']],
        ['updateModal', 'Updates an existing LandingPayType model', ['admin', 'root']],
        ['enable', 'Enable an existing LandingPayType model', ['admin', 'root']],
        ['disable', 'Disable an existing LandingPayType model', ['admin', 'root']],
      ],
    ];
  }


}
