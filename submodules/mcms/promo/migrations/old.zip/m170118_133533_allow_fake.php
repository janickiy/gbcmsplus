<?php

use console\components\Migration;

class m170118_133533_allow_fake extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function up()
  {
    $this->addColumn('user_promo_settings', 'is_fake_revshare_enabled', 'tinyint(1) unsigned NOT NULL DEFAULT 0');
    $this->createPermission('PromoCanEditUserFakeRevshareFlag', 'Разрешить включать фейки индивидуально', 'PromoPermissions', ['root', 'admin']);
  }

  public function down()
  {
    $this->removePermission('PromoCanEditUserFakeRevshareFlag');
    $this->dropColumn('user_promo_settings', 'is_fake_revshare_enabled');
  }
}
