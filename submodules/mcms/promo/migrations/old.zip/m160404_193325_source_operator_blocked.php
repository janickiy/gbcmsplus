<?php

use console\components\Migration;

class m160404_193325_source_operator_blocked extends Migration
{
  const TABLE = 'sources';

  public function up()
  {
    $this->addColumn(self::TABLE, 'operator_blocked', 'TEXT DEFAULT NULL');
    $this->addColumn(self::TABLE, 'operator_blocked_reason', 'TEXT DEFAULT NULL');

  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'operator_blocked');
    $this->dropColumn(self::TABLE, 'operator_blocked_reason');
  }
}
