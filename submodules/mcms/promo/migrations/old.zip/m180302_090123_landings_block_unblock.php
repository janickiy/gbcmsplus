<?php

use console\components\Migration;

class m180302_090123_landings_block_unblock extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('PromoWebmasterSourcesLockLanding', 'Отклонить заявку на разблокировку лендинга', 'PromoWebmasterSourcesController', ['admin', 'reseller', 'root']);
    $this->createPermission('PromoWebmasterSourcesUnlockLanding', 'Одобрить заявку на разблокировку лендинга', 'PromoWebmasterSourcesController', ['admin', 'reseller', 'root']);
  }

  public function down()
  {
    $this->removePermission('PromoWebmasterSourcesLockLanding');
    $this->removePermission('PromoWebmasterSourcesUnlockLanding');
  }
}
