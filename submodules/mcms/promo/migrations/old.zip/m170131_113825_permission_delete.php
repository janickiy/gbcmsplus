<?php

use console\components\Migration;

class m170131_113825_permission_delete extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function up()
  {
    $this->removePermission('PromoLandingsCreate');
  }

  public function down()
  {
    $this->createPermission('PromoLandingsCreate', 'Создание лендинга', 'PromoLandingsController', ['admin', 'root']);
  }
}
