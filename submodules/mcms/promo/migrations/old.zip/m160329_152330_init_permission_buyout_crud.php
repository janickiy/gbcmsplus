<?php

use console\components\Migration;

class m160329_152330_init_permission_buyout_crud extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'PersonalBuyouts' => [
        ['index', 'Can view grid personal buyout', ['admin', 'root']],
        ['create-modal', 'Can create personal buyout', ['admin', 'root']],
        ['update-modal', 'Can update personal buyout', ['admin', 'root']],
        ['delete', 'Can delete personal buyout', ['admin', 'root']]
      ]
    ];
  }
}
