<?php

use console\components\Migration;
use mcms\promo\Module;

class m170117_202449_provider_settings extends Migration
{
  public function up()
  {
    $this->addColumn('providers', 'handler_class_name', 'VARCHAR(255)');
    $this->addColumn('providers', 'settings', 'TEXT');

    $providers = Yii::$app->db->createCommand('SELECT id, preland_add_param, preland_off_param FROM providers')->queryAll();
    foreach ($providers as $provider) {
      $settings = json_encode([
        'preland_add_param' => $provider['preland_add_param'],
        'preland_off_param' => $provider['preland_off_param'],
        'mobleaders_user_id' => Yii::$app->getModule('promo')->settings->getValueByKey(Module::SETTINGS_MOBLEADERS_ID),
        'api_url' => 'https://mobleaders.com',
      ]);
      Yii::$app->db->createCommand('UPDATE providers SET settings=:settings WHERE id=:id')
        ->bindParam(':id', $provider['id'])
        ->bindParam(':settings', $settings)
        ->execute();
    }

//    $this->insert('providers', ['handler_class_name' => 'Mobleaders']);

    $this->dropColumn('providers', 'preland_add_param');
    $this->dropColumn('providers', 'preland_off_param');
  }

  public function down()
  {
    $providers = Yii::$app->db->createCommand('SELECT id, settings FROM providers')->queryAll();

    $this->dropColumn('providers', 'handler_class_name');
    $this->dropColumn('providers', 'settings');

    $this->addColumn('providers', 'preland_add_param', 'VARCHAR(32) DEFAULT NULL');
    $this->addColumn('providers', 'preland_off_param', 'VARCHAR(32) DEFAULT NULL');

    foreach ($providers as $provider) {
      $settings = json_decode($provider['settings'], true);
      Yii::$app->db->createCommand('UPDATE providers SET preland_add_param=:preland_add_param, 
          preland_off_param=:preland_off_param  WHERE id=:id')
        ->bindParam(':preland_add_param', $settings['preland_add_param'])
        ->bindParam(':preland_off_param', $settings['preland_off_param'])
        ->bindParam(':id', $provider['id'])
        ->execute();
    }
  }
}
