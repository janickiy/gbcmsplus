<?php

use console\components\Migration;

class m180503_122400_remove_is_reseller_buyout_prices extends Migration
{
  const TABLE = 'user_promo_settings';
  const COLUMN = 'is_reseller_buyout_prices';

  public function up()
  {
    $this->dropColumn(self::TABLE, self::COLUMN);
  }

  public function down()
  {
    $this->addColumn(self::TABLE, self::COLUMN, 'TINYINT(1) UNSIGNED DEFAULT \'0\' NOT NULL unsigned after user_id');
  }
}
