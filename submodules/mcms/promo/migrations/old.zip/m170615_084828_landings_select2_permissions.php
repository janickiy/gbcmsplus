<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170615_084828_landings_select2_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PromoLandingsStatFiltersSelect2', 'Ленды из стат фильтров', 'PromoLandingsController', ['investor', 'root', 'admin', 'reseller', 'manager']);
  }

  public function down()
  {
    $this->removePermission('PromoLandingsStatFiltersSelect2');
  }
}
