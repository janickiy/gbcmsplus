<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m180507_112816_country_currency extends Migration
{

  use PermissionTrait;

  public function up()
  {
    $this->addColumn('countries', 'currency', 'varchar(3) after code');
    $currentValues = [
      ['name' => 'Russia', 'code' => 'RU', 'currency' => 'rub', 'id' => 1],
      ['name' => 'Azerbaijan', 'code' => 'AZ', 'currency' => 'rub', 'id' => 2],
      ['name' => 'Ukraine', 'code' => 'UA', 'currency' => 'eur', 'id' => 3],
      ['name' => 'Belarus', 'code' => 'BY', 'currency' => 'rub', 'id' => 4],
      ['name' => 'Brazil', 'code' => 'BR', 'currency' => 'usd', 'id' => 5],
      ['name' => 'France', 'code' => 'FR', 'currency' => 'eur', 'id' => 6],
      ['name' => 'Bulgaria', 'code' => 'BG', 'currency' => 'eur', 'id' => 7],
      ['name' => 'Romania', 'code' => 'RO', 'currency' => 'eur', 'id' => 8],
      ['name' => 'Poland', 'code' => 'PL', 'currency' => 'eur', 'id' => 9],
      ['name' => 'Kazakhstan', 'code' => 'KZ', 'currency' => 'rub', 'id' => 10],
      ['name' => 'Norway', 'code' => 'NO', 'currency' => 'eur', 'id' => 13],
      ['name' => 'Macedonia', 'code' => 'MK', 'currency' => 'eur', 'id' => 15],
      ['name' => 'Jordan', 'code' => 'JO', 'currency' => 'usd', 'id' => 19],
      ['name' => 'Serbia', 'code' => 'RS', 'currency' => 'eur', 'id' => 21],
      ['name' => 'Lithuania-Latvia', 'code' => 'LT', 'currency' => 'eur', 'id' => 23],
      ['name' => 'Latvia', 'code' => 'LV', 'currency' => 'eur', 'id' => 25],
      ['name' => 'Estonia', 'code' => 'EE', 'currency' => 'eur', 'id' => 27],
      ['name' => 'Switzerland', 'code' => 'CH', 'currency' => 'eur', 'id' => 30],
      ['name' => 'Iraq', 'code' => 'IQ', 'currency' => 'usd', 'id' => 34],
      ['name' => 'Portugal', 'code' => 'PT', 'currency' => 'eur', 'id' => 36],
      ['name' => 'Netherlands', 'code' => 'NL', 'currency' => 'eur', 'id' => 38],
      ['name' => 'Egypt', 'code' => 'EG', 'currency' => 'usd', 'id' => 40],
      ['name' => 'Czech Republic', 'code' => 'CZ', 'currency' => 'eur', 'id' => 44],
      ['name' => 'Hungary', 'code' => 'HU', 'currency' => 'eur', 'id' => 48],
      ['name' => 'Kenya', 'code' => 'KE', 'currency' => 'usd', 'id' => 52],
      ['name' => 'United Kingdom', 'code' => 'GB', 'currency' => 'eur', 'id' => 56],
      ['name' => 'Pakistan', 'code' => 'PK', 'currency' => 'usd', 'id' => 59],
      ['name' => 'Belgium', 'code' => 'BE', 'currency' => 'eur', 'id' => 63],
      ['name' => 'Saudi Arabia', 'code' => 'SA', 'currency' => 'usd', 'id' => 66],
      ['name' => 'Iran', 'code' => 'IR', 'currency' => 'usd', 'id' => 70],
      ['name' => 'India', 'code' => 'IN', 'currency' => 'usd', 'id' => 74],
      ['name' => 'Vietnam', 'code' => 'VN', 'currency' => 'usd', 'id' => 78],
      ['name' => 'Italy', 'code' => 'IT', 'currency' => 'eur', 'id' => 82],
      ['name' => 'Greece', 'code' => 'GR', 'currency' => 'eur', 'id' => 86],
      ['name' => 'Mexico', 'code' => 'MX', 'currency' => 'usd', 'id' => 92],
      ['name' => 'Cyprus', 'code' => 'CY', 'currency' => 'eur', 'id' => 96],
      ['name' => 'United Arab Emirates', 'code' => 'AE', 'currency' => 'usd', 'id' => 102],
      ['name' => 'Indonesia', 'code' => 'ID', 'currency' => 'usd', 'id' => 104],
      ['name' => 'Slovakia', 'code' => 'SK', 'currency' => 'eur', 'id' => 108],
      ['name' => 'Thailand', 'code' => 'TH', 'currency' => 'usd', 'id' => 111],
      ['name' => 'Austria', 'code' => 'AT', 'currency' => 'eur', 'id' => 112],
      ['name' => 'Malaysia', 'code' => 'MY', 'currency' => 'usd', 'id' => 113],
      ['name' => 'South Africa', 'code' => 'ZA', 'currency' => 'usd', 'id' => 114],
      ['name' => 'Qatar', 'code' => 'QA', 'currency' => 'usd', 'id' => 115],
      ['name' => 'Tunisia', 'code' => 'TN', 'currency' => 'usd', 'id' => 116],
      ['name' => 'Kuwait', 'code' => 'KW', 'currency' => 'usd', 'id' => 117],
      ['name' => 'Sri Lanka', 'code' => 'LK', 'currency' => 'usd', 'id' => 118],
      ['name' => 'Honduras', 'code' => 'HN', 'currency' => 'usd', 'id' => 119],
    ];
    foreach ($currentValues as $currentValue) {
      $this->db->createCommand('
          INSERT INTO countries (id, name, status, code, currency, created_at)
          VALUES (:id, :name, :status, :code, :currency, :created_at)
          ON DUPLICATE KEY UPDATE currency=VALUES(currency)', [
        ':id' => $currentValue['id'],
        ':name' => $currentValue['name'],
        ':status' => 0,
        ':code' => $currentValue['code'],
        ':currency' => $currentValue['currency'],
        ':created_at' => time(),
      ])->execute();
    }

    $this->createPermission('PromoPersonalProfitsActualizeCourses', 'Актуализировать суммы по курсам валют', 'PromoPersonalProfitsController', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->dropColumn('countries', 'currency');
    $this->removePermission('PromoPersonalProfitsActualizeCourses');
  }
}
