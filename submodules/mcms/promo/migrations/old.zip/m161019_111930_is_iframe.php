<?php

use console\components\Migration;

class m161019_111930_is_iframe extends Migration
{
    public function up()
    {
      $this->addColumn('banner_templates', 'is_iframe', $this->boolean());
      $this->update('banner_templates', ['is_iframe' => 1]);
    }

    public function down()
    {
      $this->dropColumn('banner_templates', 'is_iframe');
    }

}
