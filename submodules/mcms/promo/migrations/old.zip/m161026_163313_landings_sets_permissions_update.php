<?php

use console\components\Migration;

class m161026_163313_landings_sets_permissions_update extends Migration
{
  use \mcms\common\traits\PermissionGroupMigration;

  public function init()
  {
    parent::init();

    $this->groupPermissionName = 'PromoModule';
    $this->groupPermissionDescription = 'Module Promo';
    $this->groupPermissionDefaultRole = ['admin', 'root', 'reseller'];

    $this->groupPermissionControllers = [
      'PromoLandingSetsController' => [
        'description' => 'Promo LandingSets Controller',
        'permissions' => [
          ['PromoLandingSetsIndex', ['admin', 'root', 'reseller']],
          ['PromoLandingSetsCreateModal', ['admin', 'root', 'reseller']],
          ['PromoLandingSetsUpdate', ['admin', 'root', 'reseller']],
          ['PromoLandingSetsUpdateParams', ['admin', 'root', 'reseller']],
          ['PromoLandingSetsDelete', ['admin', 'root', 'reseller']],
        ],
      ],
      'PromoLandingSetItemsController' => [
        'description' => 'Promo LandingSetItems Controller',
        'permissions' => [
          ['PromoLandingSetItemsCreateModal', ['admin', 'root', 'reseller']],
          ['PromoLandingSetItemsUpdateModal', ['admin', 'root', 'reseller']],
          ['PromoLandingSetItemsEnable', ['admin', 'root', 'reseller']],
          ['PromoLandingSetItemsDisable', ['admin', 'root', 'reseller']],
          ['PromoLandingSetItemsDelete', ['admin', 'root', 'reseller']],
        ],
      ],
    ];
  }
}
