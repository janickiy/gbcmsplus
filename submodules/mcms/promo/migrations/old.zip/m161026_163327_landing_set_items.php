<?php

use console\components\Migration;

class m161026_163327_landing_set_items extends Migration
{
  const SET_ITEMS_TABLE = 'landing_set_items';
  const SET_TABLE = 'landing_sets';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(static::SET_ITEMS_TABLE, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'set_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'is_disabled' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    $this->addForeignKey(static::SET_ITEMS_TABLE . '_set_id_fk', static::SET_ITEMS_TABLE, 'set_id', 'landing_sets', 'id', 'CASCADE');
    $this->addForeignKey(static::SET_ITEMS_TABLE . '_operator_id_fk', static::SET_ITEMS_TABLE, 'operator_id', 'operators', 'id', 'CASCADE');
    $this->addForeignKey(static::SET_ITEMS_TABLE . '_landing_id_fk', static::SET_ITEMS_TABLE, 'landing_id', 'landings', 'id', 'CASCADE');

    $this->createIndex(static::SET_ITEMS_TABLE . '_uq', static::SET_ITEMS_TABLE, ['set_id', 'operator_id', 'landing_id'], true);

    $this->renameColumn(static::SET_TABLE, 'landings_autoupdate', 'autoupdate');
  }

  public function down()
  {
    $this->dropTable(static::SET_ITEMS_TABLE);
    $this->renameColumn(static::SET_TABLE, 'autoupdate', 'landings_autoupdate');
  }
}
