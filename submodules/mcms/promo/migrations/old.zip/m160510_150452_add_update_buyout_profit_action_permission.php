<?php

use console\components\Migration;

class m160510_150452_add_update_buyout_profit_action_permission extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Promo';
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'Landings' => [
        ['update-buyout-profit', 'Update buyout profit', ['admin', 'root']]
      ]
    ];
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
