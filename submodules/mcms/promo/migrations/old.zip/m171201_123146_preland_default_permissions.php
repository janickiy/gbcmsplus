<?php

use console\components\Migration;

/**
 * Class m171201_123146_preland_default_permissions
 */
class m171201_123146_preland_default_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  /**
   * @return bool|void
   * @throws \yii\base\Exception
   */
  public function up()
  {
    $this->createPermission('PromoPrelandDefaultsEnable', 'Включение дефолтных прелендов', 'PromoPrelandDefaultsController', ['root', 'reseller', 'manager']);
    $this->createPermission('PromoPrelandDefaultsDisable', 'Отключение дефолтных прелендов', 'PromoPrelandDefaultsController', ['root', 'reseller', 'manager']);
  }

  /**
   * @return bool|void
   * @throws Exception
   */
  public function down()
  {
    $this->removePermission('PromoPrelandDefaultsEnable');
    $this->removePermission('PromoPrelandDefaultsDisable');
  }
}
