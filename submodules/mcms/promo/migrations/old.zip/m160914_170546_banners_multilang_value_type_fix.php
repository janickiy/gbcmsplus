<?php

use console\components\Migration;

class m160914_170546_banners_multilang_value_type_fix extends Migration
{
  const TABLE = 'banner_attribute_values';
  const COLUMN = 'multilang_value';

  public function up()
  {
    $this->alterColumn(self::TABLE, self::COLUMN, 'MEDIUMTEXT');
  }

  public function down()
  {
    $this->alterColumn(self::TABLE, self::COLUMN, 'TEXT');
  }
}
