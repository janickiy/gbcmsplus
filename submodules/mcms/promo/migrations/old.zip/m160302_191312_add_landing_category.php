<?php

use mcms\promo\models\LandingCategory;
use console\components\Migration;

class m160302_191312_add_landing_category extends Migration
{
  const TABLE = 'landing_categories';

  public function safeUp()
  {
    $this->db->createCommand('
        INSERT INTO landing_categories (`id`, `name`, `created_by`, `status`, `created_at`, `updated_at`)
        VALUES (:id, :name, 1, 1, :now, :now) ON DUPLICATE KEY UPDATE `name` = VALUES(`name`)
      ')
      ->bindValue(':id', 14)
      ->bindValue(':name', serialize(['ru' => 'Готовые домашние задания', 'en' => 'Complete homework']))
      ->bindValue(':now', time())
      ->execute();
  }

  public function safeDown(){
    /** @var LandingCategory $model */
    $model = LandingCategory::findOne(14);
    if ($model) {
      $model->delete();
    }
  }
}
