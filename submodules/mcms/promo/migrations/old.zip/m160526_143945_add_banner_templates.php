<?php

use console\components\Migration;

class m160526_143945_add_banner_templates extends Migration
{
  const BANNERS = 'banners';
  const BANNER_TEMPLATES = 'banner_templates';
  const BANNER_TEMPLATES_ATTRIBUTES = 'banner_template_attributes';
  const BANNER_ATTRIBUTE_VALUES = 'banner_attribute_values';

  const TYPE_TEXT = 1;

  const TEMPLATE_FILES = 1;
  const TEMPLATE_MUSIC = 2;
  const TEMPLATE_MOVIES = 3;

  public $banner_templates_attributes = [
    [
      'id' => 1,
      'type' => self::TYPE_TEXT,
      'code' => 'button_text',
      'name' => [
        'ru' => 'Текст кнопки',
        'en' => 'Button text',
      ],
      'template_id' => self::TEMPLATE_FILES,
    ],
    [
      'id' => 2,
      'type' => self::TYPE_TEXT,
      'code' => 'header_text',
      'name' => [
        'ru' => 'Текст заголовка',
        'en' => 'Header text',
      ],
      'template_id' => self::TEMPLATE_FILES,
    ],
    [
      'id' => 3,
      'type' => self::TYPE_TEXT,
      'code' => 'file_ready',
      'name' => [
        'ru' => 'Текст "Файл готов"',
        'en' => 'Text "File ready"',
      ],
      'template_id' => self::TEMPLATE_FILES,
    ],
    [
      'id' => 4,
      'type' => self::TYPE_TEXT,
      'code' => 'for_download',
      'name' => [
        'ru' => 'Текст "к загрузке"',
        'en' => 'Text "for download"',
      ],
      'template_id' => self::TEMPLATE_FILES,
    ],
    [
      'id' => 5,
      'type' => self::TYPE_TEXT,
      'code' => 'other_files',
      'name' => [
        'ru' => 'Текст "Другие файлы"',
        'en' => 'Text "Other files"',
      ],
      'template_id' => self::TEMPLATE_FILES,
    ],
    [
      'id' => 6,
      'type' => self::TYPE_TEXT,
      'code' => 'likes',
      'name' => [
        'ru' => 'Лайки',
        'en' => 'Likes',
      ],
      'template_id' => self::TEMPLATE_FILES,
    ],
    [
      'id' => 7,
      'type' => self::TYPE_TEXT,
      'code' => 'dislikes',
      'name' => [
        'ru' => 'Дислайки',
        'en' => 'Dislikes',
      ],
      'template_id' => self::TEMPLATE_FILES,
    ],
    [
      'id' => 8,
      'type' => self::TYPE_TEXT,
      'code' => 'downloads',
      'name' => [
        'ru' => 'Загрузки',
        'en' => 'Downloads',
      ],
      'template_id' => self::TEMPLATE_FILES,
    ],

    /* музыка */


    [
      'id' => 9,
      'type' => self::TYPE_TEXT,
      'code' => 'listen_text',
      'name' => [
        'ru' => 'Текст кнопки',
        'en' => 'Button text',
      ],
      'template_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'id' => 11,
      'type' => self::TYPE_TEXT,
      'code' => 'music_header_text',
      'name' => [
        'ru' => 'Проигрыватель',
        'en' => 'Player',
      ],
      'template_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'id' => 12,
      'type' => self::TYPE_TEXT,
      'code' => 'music_is_ready_text',
      'name' => [
        'ru' => 'Текст "Музыка готова"',
        'en' => 'Text "Music is ready"',
      ],
      'template_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'id' => 10,
      'type' => self::TYPE_TEXT,
      'code' => 'for_listen_text',
      'name' => [
        'ru' => 'Текст "к прослушиванию"',
        'en' => 'Text "for listening"',
      ],
      'template_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'id' => 13,
      'type' => self::TYPE_TEXT,
      'code' => 'other_compositions_text',
      'name' => [
        'ru' => 'Текст "Другие композиции"',
        'en' => 'Text "Other compositions"',
      ],
      'template_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'id' => 14,
      'type' => self::TYPE_TEXT,
      'code' => 'music_likes',
      'name' => [
        'ru' => 'Лайки',
        'en' => 'Likes',
      ],
      'template_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'id' => 15,
      'type' => self::TYPE_TEXT,
      'code' => 'music_dislikes',
      'name' => [
        'ru' => 'Дислайки',
        'en' => 'Dislikes',
      ],
      'template_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'id' => 16,
      'type' => self::TYPE_TEXT,
      'code' => 'music_downloads',
      'name' => [
        'ru' => 'Загрузки',
        'en' => 'Downloads',
      ],
      'template_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'id' => 17,
      'type' => self::TYPE_TEXT,
      'code' => 'watch_text',
      'name' => [
        'ru' => 'Текст кнопки',
        'en' => 'Button text',
      ],
      'template_id' => self::TEMPLATE_MOVIES,
    ],
    [
      'id' => 18,
      'type' => self::TYPE_TEXT,
      'code' => 'movie_header_text',
      'name' => [
        'ru' => 'Видеоплеер',
        'en' => 'Player',
      ],
      'template_id' => self::TEMPLATE_MOVIES,
    ],
    [
      'id' => 19,
      'type' => self::TYPE_TEXT,
      'code' => 'movie_is_ready_text',
      'name' => [
        'ru' => 'Текст "Видео готово"',
        'en' => 'Text "Movie is ready"',
      ],
      'template_id' => self::TEMPLATE_MOVIES,
    ],
    [
      'id' => 20,
      'type' => self::TYPE_TEXT,
      'code' => 'for_watching_text',
      'name' => [
        'ru' => 'Текст "к просмотру"',
        'en' => 'Text "for watching"',
      ],
      'template_id' => self::TEMPLATE_MOVIES,
    ],
    [
      'id' => 21,
      'type' => self::TYPE_TEXT,
      'code' => 'other_movies_text',
      'name' => [
        'ru' => 'Текст "Другое видео"',
        'en' => 'Text "Other movies"',
      ],
      'template_id' => self::TEMPLATE_MOVIES,
    ],
    [
      'id' => 22,
      'type' => self::TYPE_TEXT,
      'code' => 'movies_likes',
      'name' => [
        'ru' => 'Лайки',
        'en' => 'Likes',
      ],
      'template_id' => self::TEMPLATE_MOVIES,
    ],
    [
      'id' => 23,
      'type' => self::TYPE_TEXT,
      'code' => 'movies_dislikes',
      'name' => [
        'ru' => 'Дислайки',
        'en' => 'Dislikes',
      ],
      'template_id' => self::TEMPLATE_MOVIES,
    ],
    [
      'id' => 24,
      'type' => self::TYPE_TEXT,
      'code' => 'movies_downloads',
      'name' => [
        'ru' => 'Загрузки',
        'en' => 'Downloads',
      ],
      'template_id' => self::TEMPLATE_MOVIES,
    ],

  ];


  public $banners_attribute_values = [
    [
      'banner_id' => self::TEMPLATE_FILES,
      'attribute_id' => 1,
      'multilang_value' => [
        'ru' => 'Скачать',
        'en' => 'Download',
      ]
    ],
    [
      'banner_id' => self::TEMPLATE_FILES,
      'attribute_id' => 2,
      'multilang_value' => [
        'ru' => 'Файлообменник',
        'en' => 'File sharing',
      ]
    ],
    [
      'banner_id' => self::TEMPLATE_FILES,
      'attribute_id' => 3,
      'multilang_value' => [
        'ru' => 'Файл готов',
        'en' => 'File ready',
      ]
    ],
    [
      'banner_id' => self::TEMPLATE_FILES,
      'attribute_id' => 4,
      'multilang_value' => [
        'ru' => 'к загрузке',
        'en' => 'for download',
      ]
    ],
    [
      'banner_id' => self::TEMPLATE_FILES,
      'attribute_id' => 5,
      'multilang_value' => [
        'ru' => 'Другие файлы',
        'en' => 'Other files',
      ]
    ],
    [
      'banner_id' => self::TEMPLATE_FILES,
      'attribute_id' => 6,
      'multilang_value' => [
        'ru' => '2.3 тыс',
        'en' => '2.3',
      ]
    ],
    [
      'banner_id' => self::TEMPLATE_FILES,
      'attribute_id' => 7,
      'multilang_value' => [
        'ru' => '52',
        'en' => '52',
      ]
    ],
    [
      'banner_id' => self::TEMPLATE_FILES,
      'attribute_id' => 8,
      'multilang_value' => [
        'ru' => '37 тыс',
        'en' => '37',
      ]
    ],


    [
      'attribute_id' => 9,
      'multilang_value' => [
        'ru' => 'Слушать',
        'en' => 'Listen',
      ],
      'banner_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'attribute_id' => 11,
      'multilang_value' => [
        'ru' => 'Проигрыватель',
        'en' => 'Player',
      ],
      'banner_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'attribute_id' => 12,
      'multilang_value' => [
        'ru' => 'Музыка готова',
        'en' => 'Music is ready',
      ],
      'banner_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'attribute_id' => 10,
      'multilang_value' => [
        'ru' => 'к прослушиванию',
        'en' => 'for listening',
      ],
      'banner_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'attribute_id' => 13,
      'multilang_value' => [
        'ru' => 'Другие композиции',
        'en' => 'Other compositions',
      ],
      'banner_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'attribute_id' => 14,
      'multilang_value' => [
        'ru' => '2.3 тыс',
        'en' => '2.3',
      ],
      'banner_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'attribute_id' => 15,
      'multilang_value' => [
        'ru' => '52',
        'en' => '52',
      ],
      'banner_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'attribute_id' => 16,
      'multilang_value' => [
        'ru' => '37 тыс',
        'en' => '37',
      ],
      'banner_id' => self::TEMPLATE_MUSIC,
    ],


    [
      'attribute_id' => 17,
      'multilang_value' => [
        'ru' => 'Смотреть',
        'en' => 'Watch',
      ],
      'banner_id' => self::TEMPLATE_MOVIES,
    ],
    [
      'attribute_id' => 18,
      'multilang_value' => [
        'ru' => 'Видеоплеер',
        'en' => 'Player',
      ],
      'banner_id' => self::TEMPLATE_MOVIES,
    ],
    [
      'attribute_id' => 19,
      'multilang_value' => [
        'ru' => 'Видео готово',
        'en' => 'Movie is ready',
      ],
      'banner_id' => self::TEMPLATE_MOVIES,
    ],
    [
      'attribute_id' => 20,
      'multilang_value' => [
        'ru' => 'к просмотру',
        'en' => 'for watching',
      ],
      'banner_id' => self::TEMPLATE_MOVIES,
    ],
    [
      'attribute_id' => 21,
      'multilang_value' => [
        'ru' => 'Другое видео',
        'en' => 'Other movies',
      ],
      'banner_id' => self::TEMPLATE_MOVIES,
    ],
    [
      'attribute_id' => 22,
      'multilang_value' => [
        'ru' => '2.3 тыс',
        'en' => '2.3',
      ],
      'banner_id' => self::TEMPLATE_MOVIES,
    ],
    [
      'attribute_id' => 23,
      'multilang_value' => [
        'ru' => '52',
        'en' => '52',
      ],
      'banner_id' => self::TEMPLATE_MOVIES,
    ],
    [
      'attribute_id' => 24,
      'multilang_value' => [
        'ru' => '37 тыс',
        'en' => '37',
      ],
      'banner_id' => self::TEMPLATE_MOVIES,
    ],


  ];


  public $banners = [
    [
      'id' => self::TEMPLATE_FILES,
      'code' => 'default',
      'name' => [
        'ru' => 'По умолчанию',
        'en' => 'Default',
      ],
      'template_id' => self::TEMPLATE_FILES,
    ],
    [
      'id' => self::TEMPLATE_MUSIC,
      'code' => 'default',
      'name' => [
        'ru' => 'По умолчанию',
        'en' => 'Default',
      ],
      'template_id' => self::TEMPLATE_MUSIC,
    ],
    [
      'id' => self::TEMPLATE_MOVIES,
      'code' => 'default',
      'name' => [
        'ru' => 'По умолчанию',
        'en' => 'Default',
      ],
      'template_id' => self::TEMPLATE_MOVIES,
    ],
  ];

  public $banner_templates = [
    [
      'id' => self::TEMPLATE_FILES,
      'code' => 'files',
      'name' => [
        'ru' => 'Файлообменники',
        'en' => 'Files',
      ],
      'template' => '<!DOCTYPE html>
<html class="xuz-block_html">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="keywords" content="">
		<title>xuz-block</title>
		<link href="https://fonts.googleapis.com/css?family=Roboto:400,300&subset=latin,cyrillic" rel="stylesheet" type="text/css">
		<!-- <link media="all" rel="stylesheet" href="style.css"> -->
		<style>.xuz-block_body{margin:0;color:#828282;font:400 12px "Roboto", sans-serif;width:100%;height:100%;min-width:100%;min-height:100%;overflow:auto;padding:40px 15px 0;-webkit-text-size-adjust:100%;-ms-text-size-adjust:none}.xuz-block_html{box-sizing:border-box;-moz-box-sizing:border-box;height:100%;width:100%;overflow:hidden}*,*:before,*:after{box-sizing:inherit;-moz-box-sizing:inherit}*{max-height:1000000px}article,aside,details,figcaption,figure,footer,header,main,nav,section,summary{display:block}img{border-style:none}svg{width:auto;height:auto;display:inline-block;vertical-align:middle}.xuz-block{display:block;margin:0 auto 30px;width:100%;max-width:290px;min-width:284px;text-align:center}.xuz-block_top{background:#20af74;padding:10px 15px;margin:0 -5px;color:#fff}.xuz-block_top span{display:inline-block;vertical-align:middle;font-size:18px;line-height:1}.xuz-block_top svg{fill:#e6e6e6;width:38px;height:26px;margin-right:10px}.xuz-block_main{background:#fff;padding-top:15px}.file{display:block;margin:0 auto -30px;background:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALkAAACGBAMAAABzrzYXAAAAIVBMVEUAAABMaXEHBwcsLCyWlpRqamlDQ0KgoJ5DQ0MXFxdsbGvF6+abAAAAC3RSTlMaABUZChUZBRQZDpIwUZoAAAOySURBVHhe7drBittWFIfxL7E8lrTyreWRRqskTyCTQrY2dVtmZ9OGtjsbmhayktpC8U6mXQxd2ZAytCuZwrSPWcW5jBxLQ+LROdBC/g/wMxh/nLsw5mCffn119fxof5v7r3+o/0XTXsron9C8tYQe0Dw6mYC+Av6obQM8a6+HCfz6c3034LfXY3hlmlZA1lofwMQ0LYZ5az3FNc3LGbXWC3qmeSm91vqM7Z26o6j3/3v6Bz2cHi07Wfeevv9eTE7VT9rvmabOs5P0C06bl52ih/9cvf9+AR436xILwdfTTQrZHXrwvN1KN4bdHXpBu42MCTcsm/Uwod0elFLOVlGf3a3jPbn/Hr1TH5n776N36ktT7YMeTKfT3OofT++/S3rl2zDn1XT6+a0efrFBet5v2Rs9zNHYn2/0S3T2/Ws9BngivEfA2Wv9Etydkd4NMO8TLuypkuedPgE4RmHBArfPEOZGY5d4Ked4ExV9CGNWnBmVhVAwpqukb8gZ4yvpCQtSnP+x7it+7xd01fQZA1wdPYAZEZ6OHsOYGDIVPcJLCWCiog/o9Ak37FT0FW4fk7BW0cf4feyTVX4FTqkX9FT0nOtSH+Oo6AmjUk/xlVJdl7pSrAHsSl0p1hgmpa4Ua4SXlbqNVSFVU+pGJ9YV7l5fsNZJda/rxFrg7PWCnk6qez3F10l1r19o6CGs9/o5Zzqp7vWhRqyx1XVijSDb6yHsVFLd62ajkFNK1+o5jxVi8q1e8EAhJsfqY4VYE7ZW14h1w8jqF7gKMa2tHtHRuHtWj0FaH0JmdYXbd45nrK4Q64ozqxuFh+oY91bPGcmnanWN2zcrRasrPFQXbK1uY5V+ot7qA1z5u3erR3jyqVpd4fZFkFndxip996yuEOsK1+oasY7xK138oVrgWF0j1pxrq2vEmjA60Ff40qla3cYqnmqlR3jSqVpdIdYILzvQA9mcBpyZSpd+qKZ039IXLMVTrfSZaKwznEoXj3XBttLFb9+GZaVLP1QDmL+ln/NQPKZKH4LsE9Xq1ccJP1GtLn777N2rdANr8Zgq/REjybt3pOf0JJ+oR/oYRzzVSl/hS969I33AQ8m7d6RHeOKpVnoMmWCqdX0n+EQ90kOYS6dqdft8kku1pudcy929ml7gC+kJ1zU9pSP2c1/W9EjqR/MDzGu61P8KgoTOpKabHF62v08/fQNdU9d/BLynbbcBvmrQwwSZdbMG3XyGyLy5adLDGxH8W9Oom3B6813bvfhycqD/C/Jq3mb26izWAAAAAElFTkSuQmCC") 50% 0 no-repeat;background-size:100% 100%;width:185px;height:134px;padding-top:60px}.file svg{width:22px;height:31px;display:inline-block;vertical-align:middle;fill:#1e1f1d;margin-right:10px;margin-left:6px}.file span{display:inline-block;vertical-align:middle;color:#2b2b2b;font-weight:300;font-size:18px;line-height:1.22;text-align:left}.xuz-block_bg-wrap{background:#fdfdfd;background:linear-gradient(to bottom, #fdfdfd 0%, #d2d2d2 100%);filter:progid:DXImageTransform.Microsoft.gradient( startColorstr="#fdfdfd", endColorstr="#d2d2d2",GradientType=0 );width:100%;margin-bottom:60px}.xuz-block_button{display:block;margin:0 auto;width:81.68%;background:#20af74;color:#fff;font-weight:300;text-align:center;padding:0 10px;text-decoration:none;border-radius:44px;position:relative;top:44px;transition:all 0.3s linear 0s}.xuz-block_button:hover{background:#198458}.xuz-block_button svg{width:24px;height:27px;display:inline-block;vertical-align:middle;fill:#fff;margin-right:20px}.xuz-block_button span{display:inline-block;vertical-align:middle;font-size:24px;line-height:88px}.xuz-block_info{display:block;margin:0 0 20px;padding:5px 20px;overflow:hidden;font-weight:300}.xuz-block_info .xuz-block_info-item{display:inline-block;vertical-align:middle;margin-right:20px;width:auto}.xuz-block_info .xuz-block_info-item.__left{float:left}.xuz-block_info .xuz-block_info-item.__right{float:right;margin-left:20px;margin-right:0}.xuz-block_info .xuz-block_info-item span{display:inline-block;vertical-align:middle}.xuz-block_info .xuz-block_info-item svg{fill:#828282;display:inline-block;vertical-align:middle;margin-right:5px;width:16px;height:15px;position:relative;top:-2px}.xuz-block_info .xuz-block_info-item svg.xuz-block_like{-webkit-transform:rotate(10deg);-ms-transform:rotate(10deg);transform:rotate(10deg)}.xuz-block_info .xuz-block_info-item svg.xuz-block_no-like{-webkit-transform:rotate(170deg);-ms-transform:rotate(170deg);transform:rotate(170deg);top:2px}.xuz-block_info .xuz-block_info-item svg.xuz-block_download{top:0;height:18px}.xuz-block_other-file{padding:10px 10px 14px;border-top:1px solid #e5e5e5;font-weight:300}.xuz-block_other-file a{color:#828282;display:inline-block;text-decoration:none;vertical-align:middle;border-bottom:1px dotted #828282;margin-right:5px}.xuz-block_other-file a:hover{padding-bottom:1px;border-bottom:0}.xuz-block_other-file svg{fill:#828282;width:8px;height:11px;display:inline-block;vertical-align:middle;-webkit-transform:rotate(-90deg);-ms-transform:rotate(-90deg);transform:rotate(-90deg)}@media only screen and (min-width: 414px) and (min-height: 565px){.xuz-block_body{font-size:16px;padding:50px 25px 0}.xuz-block{max-width:500px}.xuz-block_top{padding:15px 20px;margin:0 -10px}.xuz-block_top span{font-size:22px}.xuz-block_top svg{width:50px;height:33px}.xuz-block_main{padding-top:20px}.file{margin-bottom:-30px;width:215px;height:156px;padding-top:75px}.file svg{width:30px;height:42px}.file span{font-size:20px}.xuz-block_bg-wrap{margin-bottom:75px}.xuz-block_button{border-radius:50px;top:50px}.xuz-block_button svg{width:30px;height:33px}.xuz-block_button span{font-size:28px;line-height:100px}.xuz-block_info .xuz-block_info-item svg{width:20px;height:18px}.xuz-block_info .xuz-block_info-item svg.xuz-block_download{height:22px}.xuz-block_other-file{padding:15px}.xuz-block_other-file svg{width:12px;height:17px}}@media only screen and (min-width: 520px) and (min-height: 680px){.xuz-block_body{font-size:18px;padding:60px 25px 0}.xuz-block{max-width:640px}.xuz-block_top{padding:20px 25px;margin:0 -15px}.xuz-block_top span{font-size:28px}.xuz-block_top svg{width:60px;height:40px}.xuz-block_main{padding-top:25px}.file{margin-bottom:-40px;width:270px;height:196px;padding-top:90px}.file svg{width:35px;margin-left:10px;height:50px}.file span{font-size:25px}.xuz-block_bg-wrap{margin-bottom:85px}.xuz-block_button{border-radius:60px;top:60px}.xuz-block_button svg{width:35px;height:39px}.xuz-block_button span{font-size:34px;line-height:120px}.xuz-block_info .xuz-block_info-item svg{width:20px;height:18px;top:-3px}.xuz-block_info .xuz-block_info-item svg.xuz-block_no-like{top:3px}.xuz-block_info .xuz-block_info-item svg.xuz-block_download{height:22px}.xuz-block_other-file{padding:15px 15px 19px}.xuz-block_other-file svg{width:12px;height:17px}}</style>
	</head>
	<body class="xuz-block_body">
		<div class="xuz-block">
			<div class="xuz-block_top">
				<svg version="1.2" baseProfile="tiny" class="xuz-block_ico01" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
					 x="0px" y="0px" viewBox="0 96.5 612 413.5" xml:space="preserve"><g>
					<g id="cloud-download">
						<path d="M494.7,255c-17.9-86.7-94.4-153-188.7-153c-73.9,0-137.7,40.8-168.3,102C58.7,214.2,0,278,0,357c0,84.1,68.8,153,153,153
							h331.5c71.4,0,127.5-56.1,127.5-127.5C612,316.2,558.5,260.1,494.7,255z M433.5,331.5L306,459L178.5,331.5H255v-102h102v102H433.5
							z"/>
					</g></g></svg>
				<span>{header_text}</span>
			</div>
			<div class="xuz-block_main">
				<div class="xuz-block_bg-wrap">
					<div class="file">
						<svg version="1.2" baseProfile="tiny" class="xuz-block_ico-arrow_file" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="211.7 0 418.6 595.3" xml:space="preserve"><path d="M624.1,401c8.1-8.4,8.1-21.6,0-30c-8.4-8.1-21.9-8.1-30,0L442,523.2V21c0-11.7-9.3-21-21-21 s-21.3,9.3-21.3,21v502.2L247.8,371c-8.4-8.1-21.6-8.1-30,0c-8.1,8.4-8.1,21.6,0,30L406,589.2c8.1,8.1,21.6,8.1,30,0L624.1,401z"/></svg>
						<span>{file_ready} <br>{for_download}</span>
					</div>
					<a href="{returnUrl}" class="xuz-block_button" target="_top">
						<svg version="1.2" baseProfile="tiny" class="xuz-block_download" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="153.1 0 535.8 595.3" xml:space="preserve"><g><path d="M639.8,496.1H202.1c-27.1,0-49,22.2-49,49.6s22,49.6,49,49.6h437.7c27.1,0,49-22.2,49-49.6S666.9,496.1,639.8,496.1z
							 M384.7,441.5c8.9,9,20.4,13.6,32.1,14.4c1.4,0.1,2.7,0.4,4.1,0.4c1.4,0,2.7-0.3,4.1-0.4c11.7-0.8,23.2-5.5,32.2-14.4l156.9-157.4
							c19.6-19.7,19.6-51.6,0-71.3c-19.6-19.7-51.5-19.7-71.1,0l-72.4,72.6V49.6c0-27.4-22.2-49.6-49.6-49.6c-27.4,0-49.6,22.2-49.6,49.6
							v235.9l-72.4-72.6c-19.6-19.7-51.5-19.7-71.1,0c-19.6,19.7-19.6,51.6,0,71.3L384.7,441.5z"/></g></svg>
						<span>{button_text}</span>
					</a>
				</div>
				<div class="xuz-block_info">
					<div class="xuz-block_info-item __left">
						<svg version="1.2" baseProfile="tiny" class="xuz-block_like" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 21 561 514.5" xml:space="preserve"><g><path d="M0,535.5h102v-306H0V535.5z M561,255c0-28.1-23-51-51-51H349.4l25.5-117.3c0-2.6,0-5.1,0-7.7c0-10.2-5.1-20.4-10.2-28	l-28.1-25.5L168.3,193.8c-10.2,7.6-15.3,20.4-15.3,35.7v255c0,28,22.9,51,51,51h229.5c20.4,0,38.3-12.8,45.9-30.6l76.5-181.1
			c2.5-5.1,2.5-12.8,2.5-17.9v-51L561,255C561,257.5,561,255,561,255z"/></g></svg>
						<span>{likes}</span>
					</div>
					<div class="xuz-block_info-item __left">
						<svg version="1.2" baseProfile="tiny" class="xuz-block_no-like" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 21 561 514.5" xml:space="preserve"><g>
		<path d="M0,535.5h102v-306H0V535.5z M561,255c0-28.1-23-51-51-51H349.4l25.5-117.3c0-2.6,0-5.1,0-7.7c0-10.2-5.1-20.4-10.2-28
			l-28.1-25.5L168.3,193.8c-10.2,7.6-15.3,20.4-15.3,35.7v255c0,28,22.9,51,51,51h229.5c20.4,0,38.3-12.8,45.9-30.6l76.5-181.1
			c2.5-5.1,2.5-12.8,2.5-17.9v-51L561,255C561,257.5,561,255,561,255z"/></g></svg>
						<span>{dislikes}</span>
					</div>
					<div class="xuz-block_info-item __right">
						<svg version="1.2" baseProfile="tiny" class="xuz-block_download" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="153.1 0 535.8 595.3" xml:space="preserve"><g><path d="M639.8,496.1H202.1c-27.1,0-49,22.2-49,49.6s22,49.6,49,49.6h437.7c27.1,0,49-22.2,49-49.6S666.9,496.1,639.8,496.1z
		 M384.7,441.5c8.9,9,20.4,13.6,32.1,14.4c1.4,0.1,2.7,0.4,4.1,0.4c1.4,0,2.7-0.3,4.1-0.4c11.7-0.8,23.2-5.5,32.2-14.4l156.9-157.4
		c19.6-19.7,19.6-51.6,0-71.3c-19.6-19.7-51.5-19.7-71.1,0l-72.4,72.6V49.6c0-27.4-22.2-49.6-49.6-49.6c-27.4,0-49.6,22.2-49.6,49.6
		v235.9l-72.4-72.6c-19.6-19.7-51.5-19.7-71.1,0c-19.6,19.7-19.6,51.6,0,71.3L384.7,441.5z"/></g></svg>
						<span>{downloads}</span>
					</div>
				</div>
				<div class="xuz-block_other-file">
					<a href="{returnUrl}" target="_top">{other_files}</a>
					<svg version="1.2" baseProfile="tiny" class="xuz-block_ico-arrow_file" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="211.7 0 418.6 595.3" xml:space="preserve"><path d="M624.1,401c8.1-8.4,8.1-21.6,0-30c-8.4-8.1-21.9-8.1-30,0L442,523.2V21c0-11.7-9.3-21-21-21 s-21.3,9.3-21.3,21v502.2L247.8,371c-8.4-8.1-21.6-8.1-30,0c-8.1,8.4-8.1,21.6,0,30L406,589.2c8.1,8.1,21.6,8.1,30,0L624.1,401z"/></svg>
				</div>
			</div>
		</div>
	</body>
</html>',
    ],
    [
      'id' => self::TEMPLATE_MUSIC,
      'code' => 'music',
      'name' => [
        'ru' => 'Музыка',
        'en' => 'Music',
      ],

      'template' => '<!DOCTYPE html>
<html class="xuz-block_html">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="keywords" content="">
		<title>xuz-block</title>
		<link href="https://fonts.googleapis.com/css?family=Roboto:400,300&subset=latin,cyrillic" rel="stylesheet" type="text/css">
		<!-- <link media="all" rel="stylesheet" href="style.css"> -->
		<style>.xuz-block_body{margin:0;color:#828282;font:400 12px "Roboto", sans-serif;width:100%;height:100%;min-width:100%;min-height:100%;overflow:auto;padding:40px 15px 0;-webkit-text-size-adjust:100%;-ms-text-size-adjust:none}.xuz-block_html{box-sizing:border-box;-moz-box-sizing:border-box;height:100%;width:100%;overflow:hidden}*,*:before,*:after{box-sizing:inherit;-moz-box-sizing:inherit}*{max-height:1000000px}article,aside,details,figcaption,figure,footer,header,main,nav,section,summary{display:block}img{border-style:none}svg{width:auto;height:auto;display:inline-block;vertical-align:middle}.xuz-block{display:block;margin:0 auto 30px;width:100%;max-width:290px;min-width:284px;text-align:center}.xuz-block_top{background:#2e58a2;padding:10px 15px;margin:0 -5px;color:#fff}.xuz-block_top span{display:inline-block;vertical-align:middle;font-size:18px;line-height:1}.xuz-block_top svg{fill:#e6e6e6;width:38px;height:25px;margin-right:10px}.xuz-block_main{background:#fff}.file{display:block;position:absolute;top:25%;left:50%;width:100%;-webkit-transform:translate(-50%, 0);-ms-transform:translate(-50%, 0);transform:translate(-50%, 0);color:#fff;text-align:center}.file svg{width:25px;height:36px;display:inline-block;vertical-align:middle;fill:#fff;margin-right:10px}.file span{display:inline-block;vertical-align:middle;color:#fff;font-weight:300;font-size:18px;line-height:1.22;text-align:left}.xuz-block_bg-wrap{width:100%;position:relative}.xuz-block_bg-wrap .image{width:100%;height:auto}.xuz-block_bg-wrap .image img{width:100%;height:auto;vertical-align:top}.xuz-block_button{display:block;margin:-44px auto 20px;width:81.68%;background:#2e58a2;color:#fff;font-weight:300;text-align:center;padding:0 10px;text-decoration:none;border-radius:44px;transition:all 0.3s linear 0s;position:relative;z-index:10}.xuz-block_button:hover{background:#1f3f78}.xuz-block_button svg{width:30px;height:35px;display:inline-block;vertical-align:middle;fill:#fff;margin-right:20px}.xuz-block_button span{display:inline-block;vertical-align:middle;font-size:24px;line-height:88px}.xuz-block_info{display:block;margin:0 0 20px;padding:5px 20px;overflow:hidden;font-weight:300}.xuz-block_info .xuz-block_info-item{display:inline-block;vertical-align:middle;margin-right:20px;width:auto}.xuz-block_info .xuz-block_info-item.__left{float:left}.xuz-block_info .xuz-block_info-item.__right{float:right;margin-left:20px;margin-right:0}.xuz-block_info .xuz-block_info-item span{display:inline-block;vertical-align:middle}.xuz-block_info .xuz-block_info-item svg{fill:#828282;display:inline-block;vertical-align:middle;margin-right:5px;width:16px;height:15px;position:relative;top:-2px}.xuz-block_info .xuz-block_info-item svg.xuz-block_like{-webkit-transform:rotate(10deg);-ms-transform:rotate(10deg);transform:rotate(10deg)}.xuz-block_info .xuz-block_info-item svg.xuz-block_no-like{-webkit-transform:rotate(170deg);-ms-transform:rotate(170deg);transform:rotate(170deg);top:2px}.xuz-block_info .xuz-block_info-item .xuz-block_ico-visits{width:20px;height:12px;top:0}.xuz-block_other-file{padding:8px 10px 14px;border-top:1px solid #e5e5e5;font-weight:300}.xuz-block_other-file a{color:#828282;display:inline-block;text-decoration:none;vertical-align:middle;border-bottom:1px dotted #828282;margin-right:5px}.xuz-block_other-file a:hover{padding-bottom:1px;border-bottom:0}.xuz-block_other-file svg{fill:#828282;width:8px;height:11px;display:inline-block;vertical-align:middle;-webkit-transform:rotate(-90deg);-ms-transform:rotate(-90deg);transform:rotate(-90deg)}@media only screen and (min-width: 414px) and (min-height: 625px){.xuz-block_body{font-size:16px;padding:50px 25px 0}.xuz-block{max-width:414px}.xuz-block_top{padding:15px 20px;margin:0 -10px}.xuz-block_top span{font-size:22px}.xuz-block_top svg{width:50px;height:33px}.file svg{width:35px;height:50px}.file span{font-size:25px}.xuz-block_button{border-radius:50px;margin-top:-50px}.xuz-block_button svg{width:35px;height:41px}.xuz-block_button span{font-size:28px;line-height:100px}.xuz-block_info .xuz-block_info-item svg{width:20px;height:18px}.xuz-block_info .xuz-block_info-item .xuz-block_ico-visits{width:25px;height:15px}.xuz-block_other-file{padding:11px 15px 15px}.xuz-block_other-file svg{width:12px;height:17px}}@media only screen and (min-width: 520px) and (min-height: 810px){.xuz-block_body{font-size:18px;padding:60px 25px 0}.xuz-block{max-width:600px}.xuz-block_top{padding:20px 25px;margin:0 -15px}.xuz-block_top span{font-size:28px}.xuz-block_top svg{width:60px;height:40px}.file svg{width:45px;height:64px}.file span{font-size:35px}.xuz-block_button{border-radius:60px;margin-top:-60px}.xuz-block_button svg{width:40px;height:47px}.xuz-block_button span{font-size:34px;line-height:120px}.xuz-block_info .xuz-block_info-item svg{width:20px;height:18px;top:-3px}.xuz-block_info .xuz-block_info-item svg.xuz-block_no-like{top:3px}.xuz-block_info .xuz-block_info-item .xuz-block_ico-visits{width:25px;height:15px}.xuz-block_other-file{padding:11px 15px 19px}.xuz-block_other-file svg{width:12px;height:17px}}</style>
	</head>
	<body class="xuz-block_body">
		<div class="xuz-block">
			<div class="xuz-block_top">
				<svg version="1.2" baseProfile="tiny" class="xuz-block_ico01" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="123.3 100.4 595.3 394.4" xml:space="preserve"><path d="M601.5,260.7c-10.7-90.3-87.4-160.3-180.6-160.3s-169.9,70-180.6,160.3c-64.7,0-117.1,52.4-117.1,117.1	s52.4,117.1,117.1,117.1h361.2c64.7,0,117.1-52.4,117.1-117.1S666.2,260.7,601.5,260.7z M506.3,392.5c0,22.6-18.4,40.9-40.9,40.9	s-40.9-18.4-40.9-40.9s18.4-40.9,40.9-40.9v-81.9h-88.7c0,0,0,120.5,0,122.8c0,22.6-18.4,40.9-40.9,40.9s-40.9-18.4-40.9-40.9	s18.4-40.9,40.9-40.9V228.7h170.6C506.3,228.7,506.3,390.1,506.3,392.5z"/></svg>
				<span>{music_header_text}</span>
			</div>
			<div class="xuz-block_main">
				<div class="xuz-block_bg-wrap">
					<div class="image"><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAMDAwMDAwQEBAQFBQUFBQcHBgYHBwsICQgJCAsRCwwLCwwLEQ8SDw4PEg8bFRMTFRsfGhkaHyYiIiYwLTA+PlQBAwMDAwMDBAQEBAUFBQUFBwcGBgcHCwgJCAkICxELDAsLDAsRDxIPDg8SDxsVExMVGx8aGRofJiIiJjAtMD4+VP/CABEIAdcCgAMBIgACEQEDEQH/xAAbAAEBAAIDAQAAAAAAAAAAAAAAAQIFBAYHA//aAAgBAQAAAADuBUBYAAAAAKgAAAAsKAhYFlioWWVBUqWWKRYUJUsVLFCwBSLFkygXGgLABZYsLFgWLJSxYoFhYAAABYAACkAsCoEqnI5o4/CAABKACAApFACU5nDhQbjfDX9ZAAAAAAAAAAz7ryfPgC7rsI1vVQFQFlEAAAAAWDPuuw2Gp8+EpceVslnE14LABYWABKBYEsoB9fUjU+fBQ33ZRquoUAACUAAEoJQAXfbTsep8/EoqAWAABRAACoAAWB2Hd9DUJlAAASgAAAACUAAAZSUCFILKlCFAIUlEqVLKigILMiWUlSkACoVAAAAVFQAURQAAAAAAAAAAAACkUiywqKJQQUBLFQssWVBYpLAopKSwUgAWFICwABYLFhYAUAAAAAAACUCUACUBSUShKAABFlAJQJQEoAApAWFhYABUsFhYKllllgAAqFCkLKQFlSxSLAAABZYTKASlSgAAAAAAAAAAAAKEUgssKiyiBULALCwAAKEFpBRLFILLFgBYAolRYqLLFgAZEpKQWKgKSyxUAKlhSVBQgCwUAAAAAAAAAAAAAACwLFgoQLAsWLFIABYsqAZXEUAsqWRbLjYtkyhLCgXFYyQlQWApQAJQllEoAlAIpFEUCUgWFAAAAAAAAAAAAAZRcQyiUSi41LLGWNIWFS3GwWMsbLZFBFBQAAASgAAAAAAlAAAABYCwWBRAsLAUSkAAFIqUSglEySUAEKABKABKBQBFAlCwAsLAALjUUAADHKgAAASgABKSkoAAAAALAAHJ2WlgFgUgAAAdk62AArZ6wAHcOngbjuHm4AAAdw6eAAPYPH5QAV3nr+s+O406UPX/ACADb9w84Dn73qYAA9e8hPtPkAHr/kAl750Kgrv967ovXfIWfaeN1uvXvIRy++ecbfuHnAbf1/qXStWAPUvLT17yE7fyNj5uPtPjT1/x+h7tpeh6HGWZT0Cul+o+Q317b6XzLgPX/IN92vby+P7jt/nBZuPXk675YB3vonuHQ+lvX/IDt/o+Phk7h0/t7qA9f8hQvu3y+nE8UFd/Xg9s8h9e3B5BqL675n6lsGpeQ+vafXd78PXb+upqfIeZ3rb+dab195D7rw/Oe9vIXM9F7JPC/Rtxztd1PqB6/Oiej+Wag92+X0eFczhVe/jf8Lm7c6J0V69y+WamcPsfyfbwpO997k1XkPru4w887FzL0/0ecb76vheW7j16Tr3Lbe6TzTgeo83afDleQ6h2L1P5fS+FeteSjv435tx4U9e26NSbceFHupNT5D69t8cmoTcSZaeeR7f16TVG2svhXrzbnkWnevbf5fS+FeteSq78rfG3Hhb17bI1Mu3HRXRfdCanrfZNvjk1CbhLqMfJPUOyJqTbjonZLtjrmo6L67t/l9b0Tf8Akyu+1N+bcvhXo242yNSu3GmvRvUKx1Jt8c2nTcMctRPO/XCak25dNbthqfOfRdx8fq0+Hk6u+k3pthqTbI1RthqK2xNVLtscmpTbsctTjltbJqza1dNk2y46rHLbfP6NRh5SXvlNsbQas2rFrDajU1tCayXaStWm1TLVRtSaw2hdRk2g1Uy2vzzarDzAd9HONkNauxuLXGzJrK2cTXS7KVrU2kl1uOWyJrjZF1WTZw1suz+ebWY+bq74PqbAa82LG682A11bAnAl2ErXpsUuvl2BOAbAutrYE4Bsfnm12PQad7q/E5o4RzRwpebTgVzVx4cvNlcJOcOFLzVx4ZzRwa5o4UvNxycGdLld7HBOYOIctHFl5Y4dcsnEOZK4kcxLxJeWTiHMHDs5g4kvLxycPHqg71TVHKHFXko4xyhxTlE4xypXFOVF4pyicY5Q4q8knGOVjk4s60s7ONfH2Hyj7D5J9h8T7D4n2lfE+yX4n2Hyj60+K/UfE+0r4tSrnD5GcMTIYmSsFoxMlmK0SM0uBkMTOGJkMXHlcpWNmYxTMYGYwszGBmMDOLgZjFMxgZkxM5Zi4tPuLWQxMhiZDEyGJksxMhiZDGXIYmQxMhi4w+lMirIUQoxqiRkMbMhitEKMaoxMhi+IzFjJGFyAKY3HIAXGrAwzEUrFaiS0RhcsVBUuFylIC4lsJVQKRKBRjSsS0ksv/8QAGgEBAQEBAQEBAAAAAAAAAAAAAAECAwcGBf/aAAgBAhAAAAD6sAAAAAAQCwAAAABlObegABYABlpE5OmgAsFlSpYOXDv2Zkw3QLAAACc70QAALAAABAIAFllCKlELgCkCpQQsWLAQACUAAABkAAAAAAZAAAAACwZCwLAALFhZYGSgAQoBKJQYAALLFgFgAZFgFihACwCxAAAAAJQS4oAAAAABkBAoBLKCKSmfkPrNjOiTSUBm0i42SmfCfRPsLjpjec7mnNujG86w2lzo472z4V29sy6SZtXWM7lMab5ajbDd5zpc+GT3KLcrF1hrILrAWNMtaz4ZPckVAsmoCpYWKi6z4a9xQLAWWCwFgLZ4a9wFixUVACxUC3Ph73AAAAAACfGvsgLAAsAFQJ+a/SIWWWCykALKlJxncAAAAACZWpbI1JpAAWLLJT//xAAbAQEBAQEBAQEBAAAAAAAAAAAAAQIEAwcFBv/aAAgBAxAAAAD5ZCpYABUVFioFqUASgAAANNdDx8wAAAAel8mm+lz+YAAAAdXbw8zTXQ8MAWAAAG+nHM1UsBQixQBFIXQAAAAAA0ALAsWLAqADYAAASgADYAAAigADQCwCkAWBYVNgAAAAADYAAAAAA2EqUAlAAANxSWFQFSykqKErQAAAAAA2AAAAAANgAsEoACwDX9N/OZS+/hG/XnusVCvfwJU6uY1izf13+K/A8+ni6PD29eX08Hdrj81108fTzdmPCzPTzH6vNxt/XPL5n77/ADfX39fPGvLl7vbj9Yz1eWOX9Hx16cWO6cM/Tfn+e/rT5pd8uet5614c36M5vfeJt58vdmbc3vrjvW5uXX1p801fK+sxq58/Zi6zNsT0mdsXWfP2Y4dfWHzO2TczbM7Ztmds2zO2bZnbPHr6u+Y25VLZNM2yaZty0zbJpnm19VfMKTUlslSo1JSakqNSeOv6Z/NrFgAsUlSosVJrscYAAAAAJr0eYAAAAAFtksUliwUlzRKRR//EADkQAAAEAwMJBQgDAQEBAAAAAAIFBhEBAwQAEDYSICIjJiczNTcVITBBRAcUJTEyNEBHFlBgFxMk/9oACAEBAAEFAPDj/hWzY/hN+J5eNGGa2dDxGs10bRzY5jWj4TXvc3dZrNZrQhc0b43NdHM8ro28rQzGfNhf8reXitntntDwPPwO/wDOb8empKisH2GaW7ENLdhmluwzS1QW1tID+/ml9bIk5zZhQZALh/ySht/JKC38kobfyShsZncispf70Esc0ZWSgpbHnK/BaxKXSa8f8fLrfx8ut/Hy638fLrGpNS0tJ+F3f07xulhiMcE5QQhRltLQ3HnK7N4NLNqpU3309t76e299Pbe+n1quoMZoWtCF/wAr/Lyzmv8ALOjC0LNZrvKEL2zo3+V3nc0bQzmvkce885XZvBIq2lo5nbBbbtgtt2wWW7YLbHJnQ1FF/QN4/nnNmwjGEYKSuhAuPw1A7HfK/Ch/hCw7HTWOZ0kZV/SR8Bvy+60fBjby+dmzmze+0fD+Wa1m8KFm8JrQs2Z87mzmz43xh33Rf8COY1m8Vs/v8Fsz5fmt4beG347XN4rfgtnt+Q3gtm9/gN4rfjx8CGY1mzI+F3+I1vKz5sM9roZsc6EM2F7eA1zf1zeF8rQzG/q2vb+t8vCbOhDw2s3gwz/ne1zZ0WzoZjeE2bC5rmhZszus3hRv78/5eG1zwzmjnv43f+LD8SPjN/ZQ/v8Azs2c1vK3ldCFme0M9vxIZ/c1zXd9zWa/55jf2cMxoXNnt+FGH+naNmzY+F87NHwfnntmN4jZ0L4XN4bXRh3/ACs0LmvaFzQ8CELNmQhc2c17Qt5/PM+Vmujc0Lmhe1oZzQs1o2a5rNc1u+F7Xws17Q8ZvyG/3ndZrmjZo+D52azRzGuaNvlZr2jZrNGzRuaNmu77NG5o3NG/zs0bNC5o5jRs0bmjZo3NG5o391oWaNzZzRu772bMaGe0Lo5rQvaH4UYZkYWbMaF0IeA0L4wt33tDMje0LND+ib/GRh/StZo3Nnt4sYWa5oWazWhbvjmNntCzXtnws1mzGt52jC+MLma5r2hm+WY3gd9zQua0bN/raOlm11YfENYnazxm/KUKXME3+CYlNSV+A1mt3XfOxulOyiBs2Nye5/7UOf5jWa5o2a/vhntf5xjYoScDYgz2jfG+EO672rW7r4Xwzu63lcppPvFTWks6mr6imnUk61GQm1fQXtc0L1fgHPT3P/ahz+GZCxVSy64zWJDRp4ztHwIQz0hgC+npqirm1FPUUk3N+d7X+1b5Wa+ELlsli9NhhmeeYe8yqsUHcifUHQgCAJI4Buly5k6YnCT/ANlKrqCkK1Der8A5kkvMKingQFMfZ/ZPc/8Aafz/ADU9z8z6ln5DVqFcCJDSNZ4XtLLqCgzEjgG9BYsWVHWVyvQadLTabmU9NUVc6op6iknZntW+WctefLAr7bWxonayhOpkuZJHnHvMarFFJigy5ikcA2hZQEJSSH5n1LqyGjUK/NKWXQmlyuwDZMldOcndGjiyoVyJJSyJokcAh6U2T/Pvafz/ADU9z8z6llvUtGc9SxdQVCJs2d/F6D+E2XtPKqjddlNATG9yRwDeg8WFnUpF4huN0p2UQWQWLF7izM9q2etOfmnUot6lpUuoK8/zjzmVViilxQXF9HXmKRwFZXYBWnPzLqUWdSlDz+5XYBJ6eTVG8CkvJvaEV9SUXiBI4ChHdTZQEJSSH/tP5+hCgvOTdBU8qlN709z8z6lFnUpGc9SOAbTi+vp6epSkUwfLEqgdrQ+KexDayRwF+qLLXn6hoKQz9oCtoKQrUPsqskcBXF9J7/XlKfinF0WdSkXiG3YJT/z5XYC9oNLLrTOkIqNPL9eYrvVuAfarZJUFIZqBO0FIWe0BQ8/u81pz406lFvUpFc/t2fX+6Zh5zGqxRS4oI+YpHAXZ9B/zNXYCWnPzLqUW9SopivUh9crcBKovoKA/M+pRX1JReIEjgL9UqguoKdFLXnx1T09X7RCWnkUvtERfP7RugmK9Nn5l1KLOpSM56kcBWV2AVpz816krzFfs1L6CvskcBfqk3SnZRAtOfmXUqRR0lb7R0PLlyTtI4CiX0H/NLJ7n5l1KLOpKLxCly+gqEV+qFdgJbc9MupVYRUagXxrSyqEzt2dQf8zV2AVxLlzjupoqOh9oxZ1KUHP7jFMGBaUrTnxp1JLepSK5/YPSpsw85jVYopcUEfMEjgL9Uq7AS058ZdSi3qUi+f3K3Aa058ZdSivqSi8QJLAX6pV2Alrz4y6lFvUpF8/vWnPzLqUW9Skbz1I4CsrsBLTnxr1JLepSL58kcBfqlW4CWnPzLqUXdS0Xz9I4Cj0psnufGXUos6kovEKRwF+qVdgJa89MupRd1JRjRPrfqlW4BWnPjPqSW9SlBz+5XYCWnPjTqSW9SkXz+wOleYecxqsT0uKCPmKSwF+qVdgJac+MupJb1JRfP/ncrcBrTnxl1KK+pKLxAksBfqpXYCWnPzLqSW9SkXz4iTNAZpr+MUH8JstOfGXUkt6lI3nqRwFBMF/8KV2Alnz416kFvUlF8+SWAv1SrMBLTnxl1KLupSL58kcBR6VWNExQJw+MupJZ1JReIUjgL9Uq7AS156ZdSS7qSi+fkSZoDNNfqlW4BWnPzPqSW9SitMUCiPiJMUBomWsrcBLTnxp1JLepSL58RpkvM0yDpXc1x5zGqxPS4nI+YJLAX6qV2Alpz4y6klvUlF8+t2CVf8/VuA1pz4y6klfUlGc/SWAv1UrcBLTn5l1JLepKL58kcCfqkxTFeWFC058ZdSS3qSjueJHAUOlStwGs+fGvUgt6kovnyRwF+qVbgJac+MupRd1LRfPkjgKPSurITWhoFnz4y6klnUlF4hSWAv1SrsBLXnpl1JLupCM5+kcC/qlW4CWnPjPqQW9SUbz1JYD7CNeylbgNac+NOpJb1KRfPkngMHSvMPOY1OJ6XE5JzBJiZCvusVkXQqyE56ZC3jFot46NEx6kxMhcrdYqxOhVkJz0yFvHLBbxkaJj9JxZCvutVgnQiyE56ZC3jlot4yNEx6khMhsrdYrBOhVkJz0yFvGLRbx0eJjtJiZCwFusVgthVkJz00FvGLhbx0aJj5JiZCPutVcXQiyE56Yi3jl4t5CNEx6kxbCRjutVkXQixE56ZC3jlot4yNEx+k4shcrdaqxOhVmJzwyjvHLxbxUaJj1Ji2Gyt1qrE6EWQnPTIW8YtFvGRwmPEmJkLAW61WCdCLITnpmLeMXC3jo0THqUEyFBHddmHfManE9Lick5glhMicrdmqR7Eq8bnZgPeCXj3gpAbHaWEyJyt2SoE6KVw3OzAe8EtHvASI2PUuJkTlbs1SJ0SrhudmA94JePeCkRsdpYTIrK3ZqgTolXDc7MB7wS4e8FJjY5SwmRMBbs1SJ0SrhudmQ94BePeCkRsdpYbInL3ZqgTohXDc7MB7wqAe8JIjY7S4mRMRbs1SN0SrhOdmA94JcLeCkRsepYTInK3ZqkTolXjc6MB7waAe8BIjY7SwmReVuyVAnRKuG52Yj3gF494KSGx0lhMiYC3ZqkTolXDc6MRv7QS8e8FIjY7S4mRQBbtMw75jVYmpsTEnME2Jkfl7ulIN0cqhucV49u6Ae3aVGxwmhMj8rd0pBOj1SNzivG67Lx7dJUeSdJsTI7K3dqUbo5VDyjivG67oB7dJUbHCbEyQyt3SkE6PVQ3OK8brugHt2lxsbpsTI6At3alE6OVI3ODEbrqgGy7So2OE2JkdlbulIJ0cqhucVw9u6Ie3aVGxwmhMjoi3dqQbo5Ujc4rx7d0A9uksPJOk2NkflbulIJ0cqhub149u6Ee3SWGxymhMkMrd0pBujlSNzivHt1QD27S42N02JkfAW7tSCdHqkbnBgN11Qj27So2OE4JkeEW7zMO+YVWJqbExJD4gnxslMrYM/G6UUg3Na0brOiHtmmx5JqnxslcrYM/G6VUg3Na0e2dCNlmmx5JsnxMlcrYNQDdKqQcYmtaN1pRDZaJobGqfGyViPYNQDdKqQeUa1o3WlFMZZpweSaJ8bJWAtgz8TpVSDc1rx7ZUQ2WabHkmqfGyVy9gz8bpRSDyjWsHtnRjZaJscQmqfGyViLYRQDdKqMcRGtbMdZ0I2WabHkm6fHkpTL2DUA3SqlHlGtaN1pRjZZpsbGqfGyWy9gj8bpRSDyjWuG6zoh7ZpweSaJ4bJSA9hFAN0opRua1w3WdENlmmh5JqQDZKhEyFzDvmFTiWlxMScwJBsm8vY07G6bPxuZVY3VdIPasgHkmRIPJTeXsYdDyk2fjcyqx7V0Y2VZCNjMkEyby9jTsTps/HlGVWPaukHtWQDYyJBsnMvYw7G6bPxuZVY9rKQbKsiGxiRjZN5exp2LKTZ8PKMqwe1dINlYQDyTIkEyby9jDobps/HlGVWPaylGysIBsZEg2TkR7GnY3Th8NzKrG6rpBsqyAbGZINk3l7GHY3TZ+PKMasbqulGyrIB5JkSDZOZexh2N02fjcyqx7V0g9rCEeSYkgmTcBbGng3TZ+PKMqwbqukmbWEA8kyJBsmwj2OzDvmFViWmxKS8wKBMQ5WyhuNyE6HlV9SN1JTD2kJRtXlAmIcrZQ2E5CdDevqRupaUbKQlGxgUCYhy9lTcTkJ0N6+pG6lphspCUbV5QLJIsrZQ2G5CdDevqR7S0w9pCYbVxQNiGAtlTcbkJyN6+qHtJTD2kJRtXlAmIcvZQ2E5AdDevqR7SU49pSUbV5QJiGItlTYTkJyOIq+pG6kpR7SEo2MCgTEOXsqbCchOh5VdUjdS0w9pCUbV5QJiLK2VNxuQHQ3r6obqSmGykJhtXlImIYC2VNxOQnQ3rqobqSmGylJRtXlImIQi2VzDrmFViWlxKS/flgmJsrZszE5MaiesqBfHqcXx4qE1YWCYmytmzITkxsJ62oF8epxfHioTVpYJiZ9nDOLkxsJ62oF8epxfHioTVhYJifK2bMxOTGonrKgXx6QL48ViasLIsTZWzhmJyY1E9bUi+PU4vjxSJq0sExM+zhmJyY2E9bPH8fkC+PlQmrSwTE0RbOGYnJjUT1tQL49Ti+PFQmriwTEz7NmYnJjYT1k8Xx6QL48VCatLBMT5WzhmJyY1E9bUC+PU4vjxUJqwsExNAWzhmJyY1E9ZUC+PSBfHioTVhYJiaAtnMwxNZFVVTjaQM4km0iWcFxtIpaqkrZcmh99l9l1dbLnUNYYS58+YYSxmMswlgMaIwlyJ9JWy5ND77L7Lq62XOoawwlz58wwlDMZRhLAY0ZhLkVFJWy5ND77L7Lq60E6hrDCVUT5hhLGYyzCWAxozCXIn0lbLk0PvoIFdXWy59DWGEufPmGEsZjLMJYDGjMJcifSVoJND76DsurrZc6hrDCVPnzTCUMxlmEoBjRmEqRPpK2XJoffQdl1VaCfQ1hhLnz5hhKGYyzCWExozCVIn0laCTQ++g7Lq60E6hrDCXPnzDCWMxlmEsBjRmEuRPpK0Emh99l9l1dbLn0NYYS58+YYSxmMswlBMaMwlSJ9JWy5ND77L7Lqq0E6hrDCVPnzDCWMxlmEoBjRmEuRPpK2XJoffZfZdXWgnUNYYS58+aYSxmMswlAMaMwlyJ9JWy5NDCsB2Xd52nReYKP/0g+5kx1kuGp9PN4M2GkLjh758qGnKhqfTTeDNhpxhrw8eV9cvg+nmcGbDTFxww18qGnL4LR93mQ1M2GmKGvDx5X1yoan00zgzfrFxww18qGnKhqfTzODN+sXHDDXyoacuGp9PM4M2GmKGvDx5UNOVwY/bzIamb9ceOHjyoacuGp9PN4U2GmLjhhr5UNOVCP/j6aZDUzYaYuPCGvlQ05fB9O0L/ADmx0xccMdfKjpyuD6abwZ31i44fuJP1yuD6aZwZ31i+4D9xJ+uVwfTTeDO+sXHDx5P1yuD6abwZv1i44fuJX1yuD6aZwJv1i48OPJ+uVwfTTeBO+sX3AfuJX1yuD6abwZv1i44fuJP1yuD6abwZ31i+4hx5P1yuD6abwZv1i+4Dx5X1yuD6ebwZ31i+4D9xJ4krg+mbMHFxR4sI60EWFK4Pp5kdTMjpijrwx18qOnL4Pp5nBmx0xR14Y6+VFhyuD6eZHVTY6cY6+HHlR05fdJ9PM4M2OmKOvDHXyvrlcH08zgzY6Yo68PHlR05fB9PM4M2OmLjw48qOnL4Pp5kdTN+sUdeGOvlR05fB9PM4M2OmLjhjr5UdOXHUv/8APMjqZv1ijrw8eV9cvg+nmR1M36xccMdfKjpy+D6fMFHvjHThHTDHvBHVvqR8OZFxRjrYR1oIsIEdW+pHwxxcUY62EdaCOkCOrfVDjq5kdKMdbCOtlxYQI6t9SPhzI98eLCOtBHSBHVvqhxeWOOlGOtDHWgiwgcN9SOLyxx0ox1sI62XFhAi0t9UOLyxxcUY60MdaCOkCOrfUjjqxx0ox1sI60EdIEdW+pHHVzI6UY62EdaCLCBHVvqRxeWOLijHWwjrQRYQI6uHCzI28/OFgxYL6EYuEUe99J9KEWjZ+6MdGMe+MdKEdMMe+EdF9AUdEUe+MdKEdIMWiGLBfQeMYCi8Yx0oR0gx74R0X0Ix0RReMRaUI6QY98I6L6EY6IovGMdKEdIMWjCOi+haMYRjGOk+nCLRhHRfQFHRFHvjHShHShHvDFgvoRi4RReMY6UI6UItGEWC8WjHRFF4vpPpBj3wjovoZvn53eXzhG7zhdG6NvPzu8vK3n53+Ub4XeUY90fnbzhd5XefnC7yu8/O3l5Wjd5vd5X+d/lHM7reVvP8A/8QAURAAAAQCBQYKBQgGCQQDAAAAAAECAwQFERJ0scIGEyFRcbMQFDFhZHOBhLLwIDIzQXIiNFRjwcPE0RUjMEBTkSRQUoKDkpOi4WBicIBDkLT/2gAIAQEABj8A/wDGRf15yf8AS5oZbNZkVJ+4ew/3p/Mew/3p/Mew/wB6fzHsP9yfzBLeaNKaaKaSO7/oAnnGVJQfv26y/ZuZxClJcIuTlI0j2b/8k/mPZvfyT+Y9m/8AyT+Y9m9/JP5hTDTayrmVJqoKig6fd/XxIQk1KPQREQJ1+hTvuL3J/wCQ/wD3PEX7N3Omqhsk6C0U0j1V/wCYeqv/ADD1V/5h6q/8wU8yaiNBloM6aaTo/rxKC95kQIjU6Z66SB5pJ1lcqlaT4H/7niL9nTDmsl0cidI5Xv8AT/4HK/8A6f8AwOV7/T/4HK9/p/8AAJMSblWnQSiql+/af35r403+g/8A3PEX7N3PHVrkmhVFPJ7h84T/ACMfOE/yMfOE/wAjHzhP8jCmm15xalFRoPRQfLp/rykvcCI0Mnz1T/MZuJJLajP5Ki0J7aeB/wDueIv+j0tPmamvcr3p/Mg4aVpMl1Kunl+UR/8AvIf/AJDL/wC5Xk4NH/tfDwrZpJb7qG0mrkpWdBUhELFLaWtbROEbZmZUGZl7yLV/VMPxtxhefr1M0pR+pRTTSRa/3FrOrbVnK1FQzP1dpFr9Cj9jATXjmc43mf1Wbq1c6g1+tSdNFH7CVW6H8ZCGsKPGv94j5rxvN8Uz36rN1q2bQS/WpKimn9xlHeMH7jLWaauccUmnlorGkg3Bsqzy3G6xaCRr1nzBTLyaq00UlSR8pU+7gfj4eHrw0PXzi66Cq1E1laDOnk/YyLum4V+wlVuh/GQhrCjxr9KChXDUSH4lptRp5aFqIjoDMLCreWhcMlwzcMjOk1KL3EWr9xn3e9wn0Esw7TjriqaqEJNSjo0nQRBTMQy404mishaTSoqdOkj/AGkp7xg9OBOFdfXnzdrZ1SToqUUUVSLX+ylHX4kiBs53LESlptbiiJB0JSZnRVLUFJURkojMjI9BkYnve9wnhQ22hS1rMkpSkqTMz5CIhBQE0g3UIdS4o2nCW0aiJCjI/cfKQjISEbzbLebqopNVFZtKj0qp95+hIu6bhXoriGYV9xlumu4htSkJqlSdJloKgh+lTh/6ZQf62ur+PU9Wmjk4JVbofxkIewo8a/SlVuh/GQk1hXc6JnDQq2kLQy04ZuGZFQTaC9xHrEVCswzsSuFdU26bLanCIyMy9xe+jR+zlnFYVhivn62bbSimipRTVL0J93vcJ9CX/wCNulCYtw0O6+sktKNLaDWdBNpKmghM25lCqWuHNoiSaloNBmaiURkRlq9FLMO0484qmqhCTUo6NJ0EQUy+0404mishaTSoqSp0kfoynvOD08lLfjbEBAG9mc7BF+sq1qKprVyUkImWQqXY1bCUKM22jpMlJJVNUqddAW24hSFoUaVJUVBkZcpGXpyjr8SRBdQdyxG9QVyBF2hzxGJ93vcJ4cmeIQ+Zz0cVf5alU1Voo9Yz1iTWFdzomsLFLdQhEM24RtmRHSSGy95HrEbCtmo0MRLraTVy0IUZFTwyLum4VwQsC+paW3c5WNBkSvkoNRUUkeoR8oN6JJiHhicQolJrmZkjl0UUfKGUMK9CtRKIWIS20byEuGRJUsveXvo0ie973CR2H/8Ap4JVbofxkIawo3i/SlVuh/GQk1hXc6JzYUXNDK2243BOoh6FYceb41UdW2lS01WSMqDPSVH7D9OZx/jH9ilNT22b5KKeTgyZYeTWbdi1oWmmilKltkZaAyxBM5ptUKhZprKV8o1qKn5Rnq4Z73vcJ9CX/wCNulCcWFNzQyqtv3jnDATXjed43mf1Wbq1c6g1+tSdNFHBL/8AG3ShMP8AB3SfRlPeMHp5KW7G2JRZDucE4sKLmhlTxuEYiKkd8nOtpXRStymin05RaMSRBWc7liNs5XIE04w3XqRB1flGVFKlahPe97hPBIu6bhQyUt2NsSewrudE5sKLmhNbdEeM+GRd03ChL2HU1m3YtlC00mVKVLIjLQJTDwLOabVCrWaaylfKNLhU0qM9QnNiTc0Mq7d944J73vcJHZ+K4MmeIw+Zz0cVf5a101Voo9Yz1iGsKPGsPsRzOdbTCKWSayk/KJaSp+SZaxlMwymq21FIQhNNNCUrcIi0+hKrdD+MhJrCu50TmwouaGVttxuCe973CeBEQ9CvtsuUVHVNqShVYqSoM9B0kJBTF8Y4xHN//HUq1Fo5z1iXQOezOegfaVa9FU3FclJahEQGez2ZqfLq1KayCVyUnr4J73vcJHn6VwZKW4942JXCxbecZcgTrJpNNNXOKLSmgRkLCt5tlvNVE0mqis2lR6VUmJt3bGJ73vcJ4YWFr1M++21Xopq11EmmgSuFOIz9dh12tUqUUoWmiik9QnFhTc0Mqrb945wfpXi/9M/i11fx6nJTRyCRd03Chk5CuGokPxLjajToMiWpsjoEqhoVbq0LhnHDNwyM6TQ4XuItQmH+Duk+hI+6bgxKe8YBCQsU3nGXM7XTSaaaralFpLnITWEhW82y3AlVRSaqK2bUelVImtuiPGfoZKW7G2JRZDucE4sKLmhlXbsbnBxvir/F/wCNm1Zvlq+tycuj0ZR1+JIgrOdyxG2crkCb2jEoT3ve4SON8VY4x/Gzac585q+ty8gkXdNwoZKW4/G2JPYV3OicWFFzQnvFXGEZiOdrZ1SiprrVRRVI9XDIe6bhQyX4rCMMV475WbbSimhbdFNUSawrudE5sSbmhlVbfvHBPe97hI7PxQksQ1CsNvOcVruobSlaqzJmdJlpOkZKW7G2JSy+0262qBVWQtJKSdBOmVJGJsyw0202mBTVQhJJSVJNHoIhlXbsbnoSLjTjC+MRzVXNKUdFRaaaaxFrEnsK7nROLCi5oZWW3G4J73vcJ4JF3TcKGSluxtiTWI/vRMP8HdJE043CsRFTMVM62ldWmvTRSJ73vcJHn6UICa8bzvGs1+qzdWrnEGv1qTpooGSluxtiUWFfhdE2biodp9BQiFElxBLKmq3poMZUttoShCIxKUpSVBERLcoIiE973uEgovirHGP42bTX+cUety8nBKrdD+MhJ7Cu50TiwpuaGVVt+8cE6iHoRhx5vjVR1TaVLTVZIyoM9JUGPP0oSLum4UMlbcfjbEnsK7nRNoaKW6hCIZtwjbMiOkkNl7yPWI2FbNRoYiHW0mo9JkhVBU8HG+KscZ/jZtNf5zR63LyCR903BjJdtxBLQuMUlSVFSRka29BkJQ3Cw7TCDg1qNLaCQVNVwqaCE5sKLmhNbdEeM+GEmby2TZic3USlRmr9Yg1lSVGohkpbsbYlNkO5wTiwouaGVduxucC/i/E+jKOvxJEFZzuWI2zlcgTe0YlCe973CR5+lCRd03ChkpbsbYk9hXc6JxYUXNDKu3Y3OGQ903Chkpbj3jYk9hXc6JzYk3NDKq243BPe97hI8/ShIu6bhQyUt2NsSewrudE4sKLmhlXbsbnoZKW7G2JPYV3OicWFFzQystuNwT3ve4TwSLum4UMlbdjbEmsR3OicWFFzQyrt2NwT3ve4SPP0oSLuu5UMlLdjbEnsK/C6JtYkeFsZV27G4J73vcJCdv4nglVuh94Qk9hXc6JxYU3NDKq2/eOCe973CR5+lCRd03Chkrbj8bYk9hXc6JzYUXNDKu3FvHODz9KEj7puDGSluxtiT2FdzonFhRc0JrbojxnwyLum4UMlLdjbEosh3OCcWFHhaGVduxucC/i/E+jKOvxJEFZzuWI2zlcgTe0YlCe973CR5+lCRd03ChkpbsbYk9hXc6JxYUXNDKu3Y3OGRd03Chkpbj3jYk9hXc6JzYk3NDKq2/eOCe973CR5+lCRd03ChkpbsbYk9hXc6JxYUXNDKu3Y3BMpm84+l6Fz9RKVJJB5tsllTSRj9N5x/jP9ismp7bN8lFPJwZKW7G2JPYV3OicWFFzQystuNwT3ve4SP03nH+Mf2KU1PbZvkop5BIu6bhQyVt2NsSaxnc6JxYUXNDKu3Y3BPe97hI8/ShIu67hQyUt2NsSiwr8Lom1iR4WxlXbsbgnve9wkJ2/ieDJ3irj68/HJrZw0nRUWiiiqRaxJ7Cu50TiwpuaGVVt+8cE973uEjz9KEi7puFDJW3H42xJ7Cu50TmwouaGVduLxuCZzJ5x9L0LnqiUmkknm2yWVNJGY8/ShI+6bgxkpbj8bYlFgXc6JxYUXNDKPjbj6MxGrq5o0lTXWummsR6hMpm84+l6Fz9RKVJJJ5tsllTSRnwSLum4UMlbdjbEosh3OCcWFFzQyqt2NwTKZuuPpehs/USk0kk822SypIyMw58X4gvRlPX4kiC6g7lCN6grkib2jEoT3ve4SPP0oSLum4UMlLdjbEnsK7nROLCi5oZVW7G5wfpXi/wDTP4tdX8epyU0cgkXdNwoZK24942JPYV3Oic2JNzQyqtuNwT3ve4SOz8UJF3TcKGStuPxtiT2FdzonFhRc0Mq7djcE+2RW4IefpQhJm66wpqKzdRKTUaiziK5U0kRchDJS3Y2xJ7Cu50TiwouaGVltxuCe973CQe38SJF3TcKGStuxtiTWI/vBOLCi5oZV27G4J73vcJHn6UJF3TcKGSluxtiUWJfhdE2sSPC2Mq7djcE973uEhO38SGI6Ih6kO/Uza66TprprFoI6dJDJW3HvGxJ7Cu50TmwpuaGVVt+8cE973uEjz9KEi7puFDJW3H42xJ7Cu50TmwouaGVVtLxuCfbIrcEPP0oSPum5MZKW7G2JPYV3OicWFFzQyrtuNwT3ve4SP0pxf+h/xa6f7VTkpp5RIu6bhQyVt2NsSiyHc4JxYUXNDKu3Y3BPNsXuCDnxfiC9GU9fiSILqFXLEb1BXJE2tGJQnhWvcJFHn5yJGVk3ChktbsbYlB9CXc6JufQUXNDKm3Y3BPCte4SKPPzkSMrJuFDJbmjj8bYlB9BXc6JwfQ03NjKm243BPCte4SKPPzkSMrJuFDJa242xKD6Cu50Tc+hIuaGVNuxuCeFatyQo8/ORIysm4UMlrdjbEoPoK7nRN7Ci5oZV2zG4J4Vr3CQZc/4kSMrJuFDJe3Y2xJz6Gf3gm59BRc0MqbdjcE8K17hIo8/ORIysu5UMluaNxtiUH0JfhcE1PoafC2MqbdjcE8K17hISXP8AiRIysm4UMluaOPeNiUH0FdzonB9CTc0MqLZjWJ4Vr3CRR5+ciRlZNwoZLc0afjbEoPoK7nROD6Cm5oZU20vG4J6XNFbkhR5+ciSFZNyYyWt2NsSg+grudE3PoSLmhlVbcbgnhWvcJBlz/iRIysm4UMlrdjbEpPoh3OCbn0JFzQypt2NwTsueL3BBwv8Au/EF6Mp6/EkQVnO5QjeoLAJvaMShOitW5IUefnIkpWXcmMmeaMxtiUn0Ndzgmp9DRc2MpueMxuCdFatyQo8/ORJSsu5MZM80bjQJSfQ13OCbH0NNzYym54zGsTorVuSFHn5yJKVl3JjJm2Y2xKT6Gq5wTY+houbGU3PGY3BOitO5IUefnIkpWXcmMmeaMxtiUn0Ndzgmx9DRc2Mp+eMxuCdFatyQNPP+IElKy7kxk1bcbYlJ9EP7wTY+houbGUx64zG4J0Vq3JCjz85ElKzblQyZtmNsSo+hqucE0PXBp8LYymPXGY3BOitW5IEnn/ECSlZdyYyZ5o0/GgSk+hrucE2PoabmxlLa8axOitW5IUefnIkpWXcmMmuaMPxtiUn0Ndzgmx9CTc2MpueMLxrE7LmidyQo8/ORJisu5MZM2zG2JUfQl3OCbH0NFzYyn54zG4J0Vq3JBSef8QJKVl3JjJnmjcaBKz6KdyxNT6Gm5sZTc8ZjcE5K1bggtP8A3Fvy9GUdfiSILqDxCN6gsIm3X4lCblad0Qo8/OBKCs26MZO80XjQJWfRFXOCaH0RNzYyi54vGsTcrTuiFXz84EnKzboxk7zRZ+NAlh6oRVzgmh64UrmxlEdPLF41iblad0Qq+fnAlBWbdGMnT1RZ+NAlZ6oRVzgmatcIm5sZRHri8axOCtO6IVfPzgSgrNujGTvNFn40CWHqhFXOCZn0RNzYyj54rGsTctfGd0QNPn24lBWbdGMnT1RmNAlatUKeMTM9cIm5sZRc8XjWJuVp3RCr5+cCUFZ90Yyd5ovGgSw+iKucEyPoqfCgZRHri8axNytO6IEnn+/EoKzboxk6eqMPxoEsV0RVzgmZ9ETc2MoT1xWNYm5WndEKvn5wJQVm3RjJ7mi8aBLD6Iq5wTRXQ03NjKI9cWXjWJwWsojdEKvn5wJQVm3RjJ3mi8aBLD6Iq5wTNXRE3NjKPni8axNytO6IGnn+/EnKzbkxk7zRmNAlp6oY7liZn0RNzYyi54vGsTYtfGdyQWn/ALvvy9GU9fiSIPqDuUIzqCuSJt1+JQmhWjdEKvn24lZauL7oxIT1RWJAlx6oVVyxMVa4VNyBPj1xWJYmha+MbohV8+3EqKz7oxIj1RWNAlx9FVcsTFXRiwCenricaxNCtG6IVfPtxKy1cX3RiQnqisSBLj1QqrliYq1wqbkCfc8TiWJoWvP7ohV8+3ErKz7oxIT1RR+JAlx6oVVyxMVdFTcgT/nicSxNCtG6IGnz7cSstXF90YkXNFYkCXK1Qx4xMT1wqbkCfHrisSxNCtG6IVfPtxKys+6MSE9UViQJcroqrliPV0ZNyBPj1xOJYmha+MbogSef74SstXF90YkJ6orGgS5WqFVcsTFWuFTcgT09cTjWJoVo3RCr59uJWmz7oxIj1RWJAlytUKq5YmR9FTcgT49cViWJqWsn90Qq+fbiVlZ90YkJ6oo/EgS9WqFVcsTE9cKm5An564nEsTQtfGN0QNPP98JWWri+6MSE9UViQJeeqH+xYmKtcKm5Anx64rEsTMrRuiC08/33oynr8SRBdQdyhG9QVyRNuvxKExLr92Qq+fbCXF1G7MSbmiMSRAq1Q6rliOV0dNyBOT1xGJQmJdfuyFXz7YS4uo3ZiTc0QfiQIE9UOq5YjldHLAJyeuIxKExLr92Qq+fbCXF1G7MSY9URiQIE+jquWI5WuGTcgTk9cRiWJiWvPbshV8+2EuTqzG7MSY9UQfiSIE9UOdyxHHrh03IE6PXEYlCYlrz+7IGnz7US4uo3ZiTc0TiSIE+jnjEcqnlh03IE5PXEYlCYp6/dkKvn2wlxdTuzElPVEYkiBPo6rliNPo5XIE5PXEYlCYlrz+7IEnn+9EuLqN2Yk3NEYkiBVqh1XLEceuHK5AnPO/iUJinXn92Qq+fbCXFqzG7MSY9URiSIE9UOq5Yjz6MVyBOT1xGJQmRcz27IVfPthLi1ZjdmJMeqIxJECfR1XLEcroybkCdHriMShMS15/dkDT59qJcXUbsxJj1RGJIglfUfYoRx64dNyBOT1xGJYmBa8/uyC08/3voyrr8SRB9QdyxG9QVyRNevxKEcXW+AhV8+1ECWrNeAxKj1P4kiDV9QdyhGK1sFckTU9b+JQji67wEKvn2ogC6nwGJVzP4kiDVqYO5YjFa2SwianrexKEcXXeAhV8+1ECWrM+AxKj1P4kiDVqYO5QjD1sFckTU9b+JQjy153wEKvn2ogS6rwGJUep/EkQZ/UHcoRitbBXJE2PW9iUI4ted8BCr59qIEuq8BiV8z+JIgz+pPEIw9bBXJE1PW/iUI4ut8BCr59qIEuq8BiVHqfxJEGrUwdyhFq+pK5Imp638ShHF1vgIEnz7UQJdV4DEqPU/iSIM9TCrlCMPWwWETXnexKEeXW+AhV8+1ECXVeAxKj1P4kiDVqYO5QjT+oK5Imp638ShHl1vgIVfPtRAl1XgMSo9T+JIg1fUHcoRh62E3JE2PW/iUI4ut8BA0+faiBLqfAYlR6n8SRCHqZ+xQjD1sFckTXnfxKEcXW7sgpPP956Mp6/EkQfUHcsRnUJuQJt1+JQjC63wEKPPtBBl1XgMS3me+1IhT+pPEIo/qSwiY9d9qhGF1vgIUefaCDLqvAYlvXfakQp/UniEUf1RYRMud7EoRhdb4CFHn2ggy6rwGJb132pEKf1J4hFH9SWETLne+1QjC6zwCjz7QQZdV4DEt5nvtSIU/qTxCKP6ksImR63ftUIwut8BCjz7QQZdV4DEu5nvtSIU/qjxCKP6ksImXXfaoRhdb4CFHn2ggy6vwGJb132pEKf1J3KESf1RXJEy677VCMLrfAQIvPtBBl1XgMS3rjvSIU/qTxCKP6ksImPW/aYjC63wEKPPtBBl1XgMS7me+1IhT+pPEIo/qSuSJlzvfaoRhdZ4BR59oIMuq8AlvM99qRCn9SdyhFH9SWETLne+1QjC63wEDLz7QQZdV4DEu5nvtSIY/qvsUIo/qSuSJl132qEWXW+AKLnx+jAupbdSTLlZRKSRGekj0aeYQ8WTb1Rto0mk0lW9/IVPOIiLNt6o40SSSSSrFye6nmEc4pt1RPOVkklJGZaT5dPOH2TSszXXoMi0aU0Di1VdbXRo9akMMElZGipSZlo0JoEKtKHCzS6TpLl0lyBmIqOVUIMqKNPvD0QaF1VoIiKjT7vyEUs0OGTq6SoLk0nyh9k0rM116DItGlNA4tVXW10aPWpDDJJWRoqUmZaNCaBCrShwiaXSdJcukuQMxBIXQhFFFGn3/AJh6IqOVVoIiKjT7vyEUs0OGTq6SoLSWk+UPsKSszXXoMi0aU0Di1VdbXRo9akMMpSsjRUpMy0aE0CFWlDhE0uk6S0npLkDMQSHKqEGRlRp9/wCYeiDQ5VWgiIqNPu/IRSzQ4ZOrpKguTSfKH2DQszXXoMi0aU0Di1VdbXR8n1qQwySVkaKlJmWjQmgQq0ocIml0nSWk9JcgZiKjlCEUGVGn3/mHoio4aVooIqNPu/IRazQ4ZOrpIiLSWk+UPsqSszXXoMi0aU0Di1RdbXR8n1qQwwSVkaKlJmWjQmgQqyQss0uk6S5dJcgZiCQ5QhFFBlp9/wCYeiKi6q0UEVGn3fkIpZocMnV0lQXJpPlD7JpWZrr0GRaNKaBxaqutro+T61IYZJKyNFSkzLRoTQIVaUOFml0nSXLpI9AZiCQ5VQg0mVGn3/mHYg0OUKQREVGn3fkIpZocMnV0lQWktJ8ofZNKzNdfSRaNKaBxaqutro+T61IYZJKyNFSkzLRoTQIVaUOETS6TpLl0lyBmIJDlVCDIyo0+/wDMPRBoXVWigio0+78hFLNCzJ1dJUFpLSfKH2TSszXXoMi0aU0Di1VdbXRo9akMMElZGipSZlo0JoEKskOETS6TpLl0lyBqIqOUIQZGVGn3/mHn6i6q0UUUafd+QilqQ4ZOuUlQRUlpPlD7JpWZrr0GRaNKaBxaqutro0etSGWSSsjRUpMy0aE0CFWlDhE0uk6S5dJcgZiKjlVCKDIy0+/8w9EVF0LRRRQVPu/IRSzQ4ZOrpKguTSfKHmDSszXXoMi0aSoHFqq62ujR61IYZJKyNFSkzLRoTQIVaUOETTlJ0ly6S5A0/UcqoRQZUafeHog0LqrQREVGn3fkIpakOGTq6SoLSWkz0h5k0rM116DItGlNAOGqrra6Pk+tT6LXxBHwhfwh34gvtuHnWEdlwb2hBcwVsDm0L7bh51hHZcG9oTsCtgcLnCu24edYR2XBvaE7ArYHNoX23DzrCOy4N/EE7Av4Q7tC+24edYR2XBv4gnYFfCHNoX23DzrCOy4N7QnYFbA58QX23DzrCOwN7QnYFbA5tC+24edYR2XBvaE/CFfCHPiC+0edYR2XBv4gnYFfCHPiC+24edYR2XBvaE7ArYHNoX23ek3tCT5grYHNoX23DzrCOy4NfEEbAvYHfiC+0edYR2XBr4gnYF7A58QX2jzrCOy4NfEEbArYHPiC+24edYR2XBvaE7ArYHdoX23DzrCOy4N7Qj4QrYHdoX23DzrCOy4N7Qj4QrYHNoX2jzrCOy4NbQjYF7A5tC+24edYR2XBraEfCF7A7tC+24edYR2XBraE/CF7A7tC+24edYR2XBvaE7ArYHfiC+24edfoo2hOwK2Be0L7bh51hHYG9oTsCtgc2hfbcPOsI7Lg3tCdgVsDm0L7bh51hPZcG9oTsCtgc2hfbcPOsI7A3tCNgVsDm0L7bh51hHZcG9oTsCtgc2hfbcPOsI7A3tCdgVsDm0L7bh51hHZcG/iCNgVsDm0L7R51hHZcG9oTsCtgc2hfaPOsI7Lg3tCdgVsDnxBfbdwI7A3tCdgVsDm0K7bvSSCBgwoUBPYEbQnYFbAvaFcCQjaC2BQXtCu3gT2BG0J2A9gXtCuBIQE7ArYF7QrtFASQRtBbAo+YL2hXbwJCNoLYFHzBe0K7RQEhG0J2BWwK2hXAnsCNoTsCtgXtCuBPYEbQR8wUfMF7QrgT2BG0J2BWwL2hXb+yPgIECMGYPgoBAgRgzBg+AgQIwZgwfBQCBAwYMUAgQIGYUDFAIECFIUDFHAQIwYMHwECBAwoHwEQIEYMGDFAIFwGDB/1EXCf72f7p/8QAIhEBAAICAgICAwEAAAAAAAAAEQABAhAgMAMEElAFBkAT/9oACAECAQECAPqV6XT0rFix27ufL5Y3/A9uWWGWlygY6VVVYsY6eDF8mV34uN1/n/njX9t1l4/HtVVVVVaiqqrcVVVX69XisVi7WOl06VViqrFVjFVVVVV+sV6Hg6XTGMV0xVVVVVVVVViqqq6eLGLpXbGMeDH+h/jVVVVVVVVVViqqqxVVVVi6VVViqqv1Dt5KunT1rHg/rn7N4/LVq3kq4RVViuOSqxytWslX0J+r/lcZd1lMo3neVzDTlKyrJ04XMdXeNt3Vt6ZU+br0J5/Za1V3G9Ljq7lT5Y3leN1LtjVtXV3dXdxrV3H0J7+q1jL1eq1VunjcuPG7rTcqXMrZ6M97g7d1fU9LXB9Ge9qu6u6tPL0Z730rPRnv/TPh/Bef8FHSsVVVWLFVWKsZjhlh/EvS9FY/Hnenve69XqtV0VLl8L1XKoard6//xAA2EQAABAMECAMHBQEAAAAAAAAAAQIRAyGxBAUQgSAiJTFxdbLBMFBhEjJAQVKCkVFgcHJzkv/aAAgBAgEDPwD9pGxsIv0iL9IUZTJvjySDUT6JtI2C/qC/qBkUzf44yZgZjVz0XJgQSCSTfHEe8fNI1c/4CLxC0S/nA9M/GL9lt4j/AAk2fwYVsuqxLt9oQi1R4MeKcjSn2ISzSan3ExEIcaGiJDWlaFpJSVJNyURk5GR6JunjoSMahYzbwTc/A1k6BGWjsqwcivXqWIkUrLdxw0kiBdNjiEt5ma0EJq4hhN/k2E0hgTA3+7DVLGeQMiyIO+g4kRYTVxwZT+gmeQYMQciw1k56DEX9TEstDZVg5HevUsWiy3fbI0CKuFETcd1MtCjSonUgjYyDGfEbsx04TSH/AAY38CE/uIOZZhkt6CZ5YP8AgxQhM+IdswbkXoPl+hkGfiJFwMOlvQgxnxwf/kMZ5Cf3CWRjdwDMN2Yf8CRYSLgYlkQZsdlWDkd69Sxsm3cjurqQJ/cO46RM8hNIlkKEKjuOkM+WEshQgxnxG7MSyG/ITzEshQhPMfIUHYTzEsjFCDtxHcUwmQkXAUIO3oeOyrDyO9epY2VbuR3V1IFcJZBhUbsJ54UHYVFBQVwoOwnmKCgqHYSyG/IVFMKjuKDsHbjhQVx2VYeR3p1LGyrdyO6upArhTToO2hXCg7CuNcKYTwoK4U0a47LsPJL06ljZVu5JdXUjyfZdh5JenUsbKt3JLr6keTELsh2aDDTCX7KLHaYRa5+5FMzUQuyJZo0NUJfsrsdmhGXtn7kIyNJaReQ6if8ANZDUV/mjyeRf1MSMvQvJt2hv8GXgSE9Cfh7sf//EACERAQADAQEBAAIDAQEAAAAAABEAAQIDEAQFIBITFEBQ/9oACAEDAQECAIBAhcAAIBAPAgeABD9CBAIQh6eh6Q8Ie4r+r+rpn/u58u3PwMT+f8+lgHhDwDwCEAIHzc6z9VAGL/0/6d7AAIQAAAAAAzrl3+mAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAADwAAAAAAAgAAeAeAAABAAAAAAAgAAAAAAEAAAAAAAAAAAAAAAAAAAAAgAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACq1gAAAAAArAAAfm/wO+d4A48wMV9VBXMAAO3MAA5UB05gH1z8/+O71jlrheeFZxn5ufHFfTQfNNfPvmE3z+rkd4csdsZ54xvByoDrm/lA+uceG+evOmOFY5YmZjjfLvRxzidqrh9GPn598brly3zznOd87zvPfnjl0rlz3VY3MTnyD658kzWvO9ca1MTM150xrnqZm+evMy5uYmZz5zM1NTE4415fHjNzE44D658czNeawamZU15mbxuZmZrzMuamZUziZlzUxMy/MysamZmE+ufHKl+ZlzUzKl+ZlzUzKl+VLmpmVL8zLmpmZl+ZlzUzKhPrnySpcaly7q6lxq7lzN1L8q7lyrqXGruXM3UuNXcu83Xv1z5JUu5UuXKupflXcuVdS/Kly5V141LlypUvyvLlXXvT8ty/LKsYqqxVWKxVWKhes6gfsHhAPCBCEAhAi/wDi3+lw8D2/0JcAr2v1r9q9/8QAPREAAQIDBAMOBQMEAwAAAAAAAQACAxEiIXFycwSCgwUQEiAjJTAxMnWhsbLBE0BBUYFCUJEkUlNgM2Jw/9oACAEDAQM/AP8AUmlwDjILRv7ytG/vKY11BmPn3RDYhDcAPtxQHCYmPsoP+I/woP8AiP8ACaXUtkPkR0rHB3CE5SQAkBJcoMPFLHBwT/s1P+zUYhmfnnMnIyX0f/Km8YflD+wn9yPEPQnpSij8mf289OeMelO+egPFPRH90PEP/mszJOaSHCRHyji1zgLBKZ6GJou6Gls0OC92jwosKGLeE7hxGAgS6zOafDe5j2lrmkhzSJEEdYKcJTBE+I1zIpI7LZjiVtxBcvEv33Fhf9AZdCxrIRAkXNmd4ynxv6bSNTz4joTy13WOLzjpne+53pamQzpGnB5Lou6WlQy2Vg4LiuTg4EXhzpiTSJ/lAQyxsifjSn+FKYXJx8CLnBo6yZJ7nAGQm4j+ExrSTbOC43FVtvC5d9+/ye1YmRH/AFBdEfM3Isawz7QnxHM4M/1NBCPxIjxIAEDw3pw4GDeD9HawmU43smtgwpC2b5n7yKc4OIEw0TKDntb93ALgvc37Eje/p4+p58QOdEB6jFZ5IOdJplN7hdLic46X3tuf6WqDpGm6LDjQ2RGO3W3Qm17Q4GQceoovhw5GUoRcrIl0LzVW39kQSZWEmS5ONhQhmRkS2Ky1cozNiLkxkOQY185E0EG8qekcMyI+JKS5KFe/z3ixkiJERWLlGZsRcnBwJjA49ZHAIN5TZPfK34sp/hFpD59pj/BOcIZA7MFs0C9+axcHSQ6yXDeJIvhw7ezCJQLhP7hBkmtEgI/sjEZCAMv+Q+KAhmQAnAbNNMZzpWiIxOD3u+he5GJwrey0uU2xcMNCHwQZTEaU/wAKt15TjMgTkq35sNco3NiIP4dvZYTv846X3tuf6WrnHRO9t0PS5UbBysiXQvNVbf2U4UK9/mqIuFco/NYq25j1QMhysiXQlVt/ZF7IYH/fzRZKf1EwuUfmMVbc16c9kOX0YSqYl0PzVW39lYy6IqNg1co7NhrlG5r1QMhyJPC+jSJ/kqrb+ysZdEVByGrlH5kNVtzHotDyf1QnSVkS6Gqtv7J7jMSq4UvwqIuFco7MYuUbmvRaHk/qhOlv84aX3tuf6WrnHRO9d0PS5UbFysfdDVW29l8RkMTl2/NAMMhKcFqrdmMVbcx6oGS5WPuhqrbey7F0RNc0E/SC2SrdmMVbcx6oGS5WPuh+aq23srGXRPNUbFqrdmMVbcx6o2LkGNeBP9B8VVtvZWMuiKjYtVbsxirbmPVAyXKx90PzVW29lYy6IgxjpTqhAqt2YxVtzHqgZLt/nDS+9dz/AEtXOGi967oelyoGUV27oat2vsrGXPVOyCrdjYqm43KgZTlY+5iq2vsrGXPVBymqp2NirbjeqNk5dq6Gqtr7Kxlz1Rsmqt2NiqbjeqBlFWPuYqtr7Kxlz1QcpqrdjYqxjcqBlOVj7mK3a+ysZc9UHKaqnY2KT243qkZTt/nDSu9dA9LVzhoneun+lyp2ZXauardorG6ypOWFUcTVU3G5U7MrtXMVu0XZ1lTswqjiaqhicqRllWOuYrdouzrKnZhVHG1VDG5U7MrtXMVu0XZ1lTswqjjaqm4iqdmV2rmK3aKxtzlTswqjjaqhicqRlnf/AK/Su9dA8mrnDRe9NP8AS5WapXXqq3XXV+VZqBWnEFaMRVmqV16qt111ays1ArTiCtGIqzVK69VW666vyrNQK04grRiKs1SuvVVuurBrKzUCtOIK0YirNUrr1Vbrrq/Ks1QrTiCtGIqzVO/pz48V5iNm7SYEQ0jtQwJLTmR4TxEbNukx4gp/U8GaPhvHx3vJFFHePiij4Ioo7xmij4Ioo+CKM0UUZo758UV5Ioo+G/W7G1Vtxu/Z/MLqv/0aXQf/2Q==" alt=""></div>
					<div class="file">
						<svg version="1.2" baseProfile="tiny" class="xuz-block_ico-arrow_file" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="211.7 0 418.6 595.3" xml:space="preserve"><path d="M624.1,401c8.1-8.4,8.1-21.6,0-30c-8.4-8.1-21.9-8.1-30,0L442,523.2V21c0-11.7-9.3-21-21-21 s-21.3,9.3-21.3,21v502.2L247.8,371c-8.4-8.1-21.6-8.1-30,0c-8.1,8.4-8.1,21.6,0,30L406,589.2c8.1,8.1,21.6,8.1,30,0L624.1,401z"/></svg>
						<span>{music_is_ready_text} <br>{for_listen_text}</span>
					</div>
				</div>
				<a href="{returnUrl}" class="xuz-block_button" target="_top">
					<svg version="1.2" baseProfile="tiny" class="xuz-bloc_ico-play" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="168.8 0 504.2 595.3" xml:space="preserve"><g id="Play">
<path d="M645.9,255.5L249.7,5.9c-11.7-7-26.3-5.8-37.2-5.8c-43.9,0-43.7,33.9-43.7,42.5v510.1c0,7.3-0.2,42.5,43.7,42.5
	c11,0,25.5,1.2,37.2-5.8l396.1-249.6c32.5-19.3,26.9-42.2,26.9-42.2S678.4,274.8,645.9,255.5z"/></g></svg>
					<span>{listen_text}</span>
				</a>
				<div class="xuz-block_info">
					<div class="xuz-block_info-item __left">
						<svg version="1.2" baseProfile="tiny" class="xuz-block_like" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 21 561 514.5" xml:space="preserve"><g><path d="M0,535.5h102v-306H0V535.5z M561,255c0-28.1-23-51-51-51H349.4l25.5-117.3c0-2.6,0-5.1,0-7.7c0-10.2-5.1-20.4-10.2-28	l-28.1-25.5L168.3,193.8c-10.2,7.6-15.3,20.4-15.3,35.7v255c0,28,22.9,51,51,51h229.5c20.4,0,38.3-12.8,45.9-30.6l76.5-181.1
			c2.5-5.1,2.5-12.8,2.5-17.9v-51L561,255C561,257.5,561,255,561,255z"/></g></svg>
						<span>{music_likes}</span>
					</div>
					<div class="xuz-block_info-item __left">
						<svg version="1.2" baseProfile="tiny" class="xuz-block_no-like" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 21 561 514.5" xml:space="preserve"><g>
		<path d="M0,535.5h102v-306H0V535.5z M561,255c0-28.1-23-51-51-51H349.4l25.5-117.3c0-2.6,0-5.1,0-7.7c0-10.2-5.1-20.4-10.2-28
			l-28.1-25.5L168.3,193.8c-10.2,7.6-15.3,20.4-15.3,35.7v255c0,28,22.9,51,51,51h229.5c20.4,0,38.3-12.8,45.9-30.6l76.5-181.1
			c2.5-5.1,2.5-12.8,2.5-17.9v-51L561,255C561,257.5,561,255,561,255z"/></g></svg>
						<span>{music_dislikes}</span>
					</div>
					<div class="xuz-block_info-item __right">
						<svg version="1.2" baseProfile="tiny" class="xuz-block_ico-visits" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 105.3 519.6 309.1" xml:space="preserve"><g>
			<g>
				<path d="M513.1,245.1c0,0-140.7-139.8-253.3-139.8S6.5,245.1,6.5,245.1c-8.6,8.1-8.7,21.4,0,29.4c0,0,140.7,139.8,253.3,139.8
					s253.3-139.8,253.3-139.8C521.7,266.4,521.8,253.1,513.1,245.1z M260.9,372.4c-61.9,0-112.1-50.2-112.1-112.1
					s50.2-112.1,112.1-112.1S373,198.4,373,260.2S322.8,372.4,260.9,372.4z"/>
				<path d="M259.6,187.7c-39.3,0-71.2,32.1-71.2,71.5c0,39.4,31.9,71.5,71.2,71.5s71.2-32.1,71.2-71.5
					C330.8,219.8,298.9,187.7,259.6,187.7z M286.4,259.4c-12.2,0-22.1-9.9-22.1-22.3s9.9-22.3,22.1-22.3s22.1,9.9,22.1,22.3
					S298.7,259.4,286.4,259.4z"/>
			</g></g></svg>
						<span>{music_downloads}</span>
					</div>
				</div>
				<div class="xuz-block_other-file">
					<a href="{returnUrl}" target="_top">{other_compositions_text}</a>
					<svg version="1.2" baseProfile="tiny" class="xuz-block_ico-arrow_file" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="211.7 0 418.6 595.3" xml:space="preserve"><path d="M624.1,401c8.1-8.4,8.1-21.6,0-30c-8.4-8.1-21.9-8.1-30,0L442,523.2V21c0-11.7-9.3-21-21-21 s-21.3,9.3-21.3,21v502.2L247.8,371c-8.4-8.1-21.6-8.1-30,0c-8.1,8.4-8.1,21.6,0,30L406,589.2c8.1,8.1,21.6,8.1,30,0L624.1,401z"/></svg>
				</div>
			</div>
		</div>
	</body>
</html>'
    ],
    [
      'id' => self::TEMPLATE_MOVIES,
      'code' => 'movies',
      'name' => [
        'ru' => 'Кино',
        'en' => 'Movies',
      ],
      'template' => '<!DOCTYPE html>
<html class="xuz-block_html">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="keywords" content="">
		<title>xuz-block</title>
		<link href="https://fonts.googleapis.com/css?family=Roboto:400,300&subset=latin,cyrillic" rel="stylesheet" type="text/css">
		<!-- <link media="all" rel="stylesheet" href="style.css"> -->
		<style>.xuz-block_body{margin:0;color:#828282;font:400 12px "Roboto", sans-serif;min-width:100%;overflow:auto;width:100%;height:100%;min-height:100%;padding:40px 15px 0;-webkit-text-size-adjust:100%;-ms-text-size-adjust:none}.xuz-block_html{box-sizing:border-box;-moz-box-sizing:border-box;height:100%;width:100%;overflow:hidden}*,*:before,*:after{box-sizing:inherit;-moz-box-sizing:inherit}article,aside,details,figcaption,figure,footer,header,main,nav,section,summary{display:block}img{border-style:none}svg{width:auto;height:auto;display:inline-block;vertical-align:middle}.xuz-block{display:block;margin:0 auto 30px;width:100%;max-width:290px;min-width:284px;text-align:center}.xuz-block_top{background:#373737;padding:10px 15px;margin:0 -5px;color:#fff}.xuz-block_top span{display:inline-block;vertical-align:middle;font-size:18px;line-height:1}.xuz-block_top svg{fill:#e6e6e6;width:38px;height:27px;margin-right:10px}.xuz-block_main{background:#fff}.file{display:block;position:absolute;top:25%;left:50%;width:100%;-webkit-transform:translate(-50%, 0);-ms-transform:translate(-50%, 0);transform:translate(-50%, 0);color:#fff;text-align:center}.file svg{width:25px;height:36px;display:inline-block;vertical-align:middle;fill:#fff;margin-right:10px}.file span{display:inline-block;vertical-align:middle;color:#fff;font-weight:300;font-size:18px;line-height:1.22;text-align:left}.xuz-block_bg-wrap{width:100%;position:relative}.xuz-block_bg-wrap .image{width:100%;height:auto}.xuz-block_bg-wrap .image img{width:100%;height:auto;vertical-align:top}.xuz-block_button{display:block;margin:-44px auto 20px;width:81.68%;background:#d4373a;color:#fff;font-weight:300;text-align:center;padding:0 10px;text-decoration:none;border-radius:44px;transition:all 0.3s linear 0s;position:relative;z-index:10}.xuz-block_button:hover{background:#b52d30}.xuz-block_button svg{width:30px;height:35px;display:inline-block;vertical-align:middle;fill:#fff;margin-right:20px}.xuz-block_button span{display:inline-block;vertical-align:middle;font-size:24px;line-height:88px}.xuz-block_info{display:block;margin:0 0 20px;padding:5px 20px;overflow:hidden;font-weight:300}.xuz-block_info .xuz-block_info-item{display:inline-block;vertical-align:middle;margin-right:20px;width:auto}.xuz-block_info .xuz-block_info-item.__left{float:left}.xuz-block_info .xuz-block_info-item.__right{float:right;margin-left:20px;margin-right:0}.xuz-block_info .xuz-block_info-item span{display:inline-block;vertical-align:middle}.xuz-block_info .xuz-block_info-item svg{fill:#828282;display:inline-block;vertical-align:middle;margin-right:5px;width:16px;height:15px;position:relative;top:-2px}.xuz-block_info .xuz-block_info-item svg.xuz-block_like{-webkit-transform:rotate(10deg);-ms-transform:rotate(10deg);transform:rotate(10deg)}.xuz-block_info .xuz-block_info-item svg.xuz-block_no-like{-webkit-transform:rotate(170deg);-ms-transform:rotate(170deg);transform:rotate(170deg);top:2px}.xuz-block_info .xuz-block_info-item .xuz-block_ico-visits{width:20px;top:0;height:12px}.xuz-block_other-file{padding:8px 10px 14px;border-top:1px solid #e5e5e5;font-weight:300}.xuz-block_other-file a{color:#828282;display:inline-block;text-decoration:none;vertical-align:middle;border-bottom:1px dotted #828282;margin-right:5px}.xuz-block_other-file a:hover{padding-bottom:1px;border-bottom:0}.xuz-block_other-file svg{fill:#828282;width:8px;height:11px;display:inline-block;vertical-align:middle;-webkit-transform:rotate(-90deg);-ms-transform:rotate(-90deg);transform:rotate(-90deg)}@media only screen and (min-width: 414px) and (min-height: 625px){.xuz-block_body{font-size:16px;padding:50px 25px 0}.xuz-block{max-width:414px}.xuz-block_top{padding:15px 20px;margin:0 -10px}.xuz-block_top span{font-size:22px}.xuz-block_top svg{width:50px;height:36px}.file svg{width:35px;height:50px}.file span{font-size:25px}.xuz-block_button{border-radius:50px;margin-top:-50px}.xuz-block_button svg{width:35px;height:41px}.xuz-block_button span{font-size:28px;line-height:100px}.xuz-block_info .xuz-block_info-item svg{width:20px;height:18px}.xuz-block_info .xuz-block_info-item .xuz-block_ico-visits{width:25px;height:15px}.xuz-block_other-file{padding:11px 15px 15px}.xuz-block_other-file svg{width:12px;height:17px}}@media only screen and (min-width: 520px) and (min-height: 810px){.xuz-block_body{font-size:18px;padding:60px 25px 0}.xuz-block{max-width:600px}.xuz-block_top{padding:20px 25px;margin:0 -15px}.xuz-block_top span{font-size:28px}.xuz-block_top svg{width:60px;height:43px}.file svg{width:45px;height:64px}.file span{font-size:35px}.xuz-block_button{border-radius:60px;margin-top:-60px}.xuz-block_button svg{width:40px;height:47px}.xuz-block_button span{font-size:34px;line-height:120px}.xuz-block_info .xuz-block_info-item svg{width:20px;height:18px;top:-3px}.xuz-block_info .xuz-block_info-item svg.xuz-block_no-like{top:3px}.xuz-block_info .xuz-block_info-item .xuz-block_ico-visits{width:25px;height:15px}.xuz-block_other-file{padding:11px 15px 19px}.xuz-block_other-file svg{width:12px;height:17px}}</style>
	</head>
	<body class="xuz-block_body">
		<div class="xuz-block">
			<div class="xuz-block_top">
				<svg version="1.2" baseProfile="tiny" class="xuz-block_ico01" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 73.1 511.6 365.5" xml:space="preserve"><path d="M511.3,213c-0.2-10.3-1-23.3-2.4-39c-1.4-15.7-3.5-29.7-6.1-42.1c-3-13.9-9.7-25.6-19.8-35.1c-10.2-9.5-22-15-35.5-16.6
		c-42.3-4.8-106.1-7.1-191.6-7.1c-85.5,0-149.3,2.4-191.6,7.1c-13.5,1.5-25.3,7-35.4,16.6c-10.1,9.5-16.7,21.2-19.7,35.1
		c-2.9,12.4-5,26.4-6.4,42.1c-1.4,15.7-2.2,28.7-2.4,39C0.1,223.3,0,237.5,0,255.8c0,18.3,0.1,32.6,0.3,42.8c0.2,10.3,1,23.3,2.4,39
		c1.4,15.7,3.5,29.7,6.1,42.1c3,13.9,9.7,25.6,19.8,35.1c10.2,9.5,22,15,35.5,16.6c42.3,4.8,106.1,7.1,191.6,7.1
		c85.5,0,149.3-2.4,191.6-7.1c13.5-1.5,25.3-7,35.4-16.6c10.1-9.5,16.7-21.2,19.7-35.1c2.9-12.4,5-26.4,6.4-42.1
		c1.4-15.7,2.2-28.7,2.4-39c0.2-10.3,0.3-24.6,0.3-42.8C511.6,237.5,511.5,223.3,511.3,213z M356.9,271.2l-146.2,91.4
		c-2.7,1.9-5.9,2.9-9.7,2.9c-2.9,0-5.8-0.8-8.8-2.3c-6.3-3.4-9.4-8.8-9.4-16V164.5c0-7.2,3.1-12.6,9.4-16c6.5-3.4,12.7-3.2,18.6,0.6
		l146.2,91.4c5.7,3.2,8.6,8.4,8.6,15.4C365.4,262.9,362.6,268,356.9,271.2z"/></svg>
				<span>{movie_header_text}</span>
			</div>
			<div class="xuz-block_main">
				<div class="xuz-block_bg-wrap">
					<div class="image"><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAMDAwMDAwQEBAQFBQUFBQcHBgYHBwsICQgJCAsRCwwLCwwLEQ8SDw4PEg8bFRMTFRsfGhkaHyYiIiYwLTA+PlQBAwMDAwMDBAQEBAUFBQUFBwcGBgcHCwgJCAkICxELDAsLDAsRDxIPDg8SDxsVExMVGx8aGRofJiIiJjAtMD4+VP/CABEIAdcCgAMBIgACEQEDEQH/xAAdAAEBAQEBAQEBAQEAAAAAAAACAQADBAUHBggJ/9oACAEBAAAAAP8AlvUq1UlWlUqkqqrVbbbd6/oHY6DYSESQwgwc4TzJg5kmDmeSqSSSrSqSVdVVVqttuvX6sx2J0GhEkMAhAJPMknmSSAeKrVSSTVSSSVSqqqtt1u+usdhMTIJIYQTOZJHMkgEk8weKSSSSSSSSSSqSqttttu+l3k2GgkgkB05mHmSeYJPMkE8yeNTVSaSSSTqSSVVVtq1u9ntOxkwkIkBhhIBJ5jv/AEUJ+d/NkcyeDSSSSaSSaVSSSqtVttu7fSmw0hkEM5wwmcwSeZ/qf0rbfO/GfZ/Pgjikkk0kk0mkkkqlUrbbdb9XbGYnESEGEw8yCAP6r9I23zuH8p+cAngkk0k0k0k0kklUlarbrd9HrSdhITJzMJhPMkcyP6n9H23zvhfK/OSDwSaTSTSaSTSSSSqqtttu9nrh0hkEM5yEkgEjmR/S/pO2+V+KdfEQeCaSaaSaaSaSSSSqqttt3b6Emg0JhBMMJ5EkcwZ6QT5vJzBB86aTSaaaTTSTrSqVSttut+odoZgZOZgGgAJ5gg8gQTyBI87SaaTTTSbSSaSVSVqt11+g9hNBIQZyJwII5kgciQBzII87SaaTaaaaaTSSSStVtt19XpxkwMgMAJJJHMEHnzII58yCfMmmmmm002k00kkkqrVdbu/twmgkIM5kkkkciCOfMkHiQQfMm00m2mm00mmknUlarbbl9GHYQwGAEkkEcwTz5gEDmAQfMm0002m2mmmk0nUlVVbdd77sTIQZzJJJB5gA8+ZAPPmAQfMm002m02mm00mkklUrbbt6u2wkgMAJJJA5ggciARyABB8yaababTbTaabSSSSqttuvb1aCYgwAkkg8+ZB58wCOfMAEHytpptpttNtNNNNJJKq1a3P24SbnCecJBJHIgjkAQOQABA8zTababbTbTaaaTSSqtVt298kgMIBgJI5gEDkAQOJAAI8vRNNtpttNtptNNJ11Kq2671PSAmcySSCeQIHIAEc+RAAI8rabTbbbTbabaTTSSVStuu7d5gZOUJJBHMEDnzB5kcuYIAB8rTabbbabbabaaTSTqVVt2fqxEgBJJIPIEDkAAOfM8wQAPK2m22m222022mmmkklatbt7YJDzhAMI5gEc+YAA5AAAjmfK02m22222m202mmknUrbbt6bIQSRzOI5EA8uYIHPkRzIAA8rabbafRpttttNNppJOq1XXdephBJ5gycgCOfMAEcQAAAeZ8qabbbbbbabbabTTSSSqquy7w8zCOZJPMgHkAAOfIEcwQAPKm022222222002mmkkqlbtvTOZhHMkEEA8+YAA5AAAAADytNrom+jTbbbbabTSaaqSVu274EnmSASCByAPMc+YAAAAA8rTa6Nro2n0abbabaTTSVaqyx62EAEggkDkAQOfIAAAAADytNttro2n0afRNptpNpJVqrPBuEcySQCRz5gEDlzAAAAAA8rTa6Nro030abbabaTSaVaq103YnmSSCCRyABHPkAAAAAAPKm2uib6JtttttNtNJp1JJZbY9pzgMIBI58wQByAAAAAAA8qbTbbbbbbbabTaTTSSqq22zwhJIJA5gAjlzBHMgAAADyNpttro210abbabTSTSVVVt0lsMJIJHMAgDkAAADzAIA8jTbbTbbbbabbTaSTSrttu2m6GEkkHmACBz5ggAAAAADyptNtttp9Gm2002kmklVlrtpnjCSRzBBA5jmQAADzBAA8jabbTbba6JttNNNJJOq263SZ6GAkAEEDkeZAAIAAAA8rTTbafRNttNtNNNJKtW227aSqQknkSCRyAIABAAAPMjyNppttPom20200mmqkqrbdttN0MJPMkEjmACAeZAABAA8jaf9d/oX063W3W63W663Xa67a7bTa6bSaaTSTSaSaTfk35KAD5E2mm210TababSaSSVStt1200VhAhBI5kAggAgAEAEeRdEm0202020000kkkqrbrttpqpzMJJHMEEEAggAEAEeRtNNNtNtNNpppOpJK2rW7baSsCEwjmSCCQAQQAQAR5G00/sfZ/lmm002mk0mqlUrbbrtppGTDCeYJBJAII+l+jflH6b/D/zIBHlSb9v6X+vflv5Qmm2k2k0mkqqqrbrttpNZDCQCSQSCCD976n8N93638EQR5Um/v8A+pl+Ofk7aaaaaaSTVStVtt1200m0kIBJJIIJBHZfP6dvmkEeVJtd/wBz+N+UNNNNNJpJJJVVW3XXbTSayEEkkkkEEgf0/wCkfiP6p8X81II8qTaT9PJtNJtJNJJJKq223XbbTSXEgwQkkEkEG+z5ns8fmBI8qTTSaTaTTSTSSSqVVt1u222k2xEJMJJBJIBIIIJI8qSaaTSaaTSaSSVVSttuuu2mmmhMMJhBJJBIJBBII8ySTaSTTSTSdSTqVqttt12200kkhhhJJJJBJIBJBB8ySSaaSTSaSSSSSqtttt12200kkkMMJJJJBJIJBJB8rSSTSTSTSSSSVSVqtut12200k0MhhMJJIgJBJJIJ8qaSSaSSTSSSSVVVVtt1u22000kkJhhhIMIJJIJJB8ySSSaSSSaSqTqqtVttuu222mkkhkhMJJMIJJJIJJ8ySSSSSSSTSqSVVqtttuu222mkkkhkJMJJJJJJIhJ8yrSqSaSVSSSVSqtttt1110000kkkhMJhJJJJJJJJ89SSSSSSVSSSqqqqttuu2u202mOkMhhhhJJMJIghJ//EABcBAQEBAQAAAAAAAAAAAAAAAAABAgT/2gAIAQIQAAAAAAAAAAAAAAAAAAAAAAAkaAAAAAAzJdgAAAAAkaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADHJ3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/8QAFgEBAQEAAAAAAAAAAAAAAAAAAAYE/9oACAEDEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA10EoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//EAEUQAAACBgYECQoEBgMAAAAAAAECAAMEBaLRERIVUFNUFiAxQAYTFCEwQVFgsRAyMzRScXJzkZJEYXDBIjVDgYLhZJCj/9oACAEBAAE/AblVbe6BOYwbqO5jdIc4XCN3q/N3wb0Vde/KlJ1xwIQKRFLGavaV/UZJYrV7av6jJLEavbVfUZJYjV7ar6jJGh1tLMSuNUwBtq3aTmMG7jruf1k3yx8dVs9UX/KN4IoZlzSeqrLT+yNrCdi4usYDV+z8kHuQ5/WTfLHxDVa/VV/yjeCMBSlY1NHWUBR/fh/8/wBrsJ5u+uj1k3yx8dVr9VX/ACj+COxsVLFJFQjQcvNR2o/vw/8An+12K+vdR6B1GArUNPWQQ1W0wFZF1PWQQ+vkWLVq2iuYTUbKbsJ528jq8pacZZ9wpyppxln3CnKmrGWfcKcqasdZ9wodatWeecxveNPkHv6XnKFxDdyvdx1RvQm3ugG3dhvsuzeh1hvAmzugTbug6o6w3iG3uiHOG5DqjfJdm+jeZNxHVG+g274N/j0Q34XZ0w6w34XUHpxv0NvQDuI9yRv8NmsPcoNUejHuAHTj+iQdKPcMOkHXG/Q/TEe5A9yA77uNmUtj0UKVxaxDV6Q2bCiPUmjTlysZ5poy5MrGeaaMuTKxnmmjTkysZ5po05ctGeaaNuXLRnmmjbly0Z5po45stGeaaOObLRnmmjrmy0Z5po658tGeaaOufLRnmmjzny0Zppo86MvGaaaPujLxmmmj7oy8ZppYDoy8ZppYDpy8ZppYDpy8ZppYLpy8ZppYLqy8ZppYTqy8ZppYTqwIzTSwnVgRmmlhuvAjNNLDdeBGaaWG68CM00sN14EZppYjrwIzTSxHZgRmmliOzAiNNLEdmBEaaWI7MCI00sR2YERppYrswIjTSxXZgRGmliuzAiNNLFdmBEaaWI7MCI00sR2YERppYjswIjTSxXZgRGmliuzAiNNLEdmBEaaWI7MCI00sR2YEZppYbrwIzTSw3XgRmmlhuvAjNNLCdWBGaaWE6sCM00sJ1ZeM00sF1ZeM00sF05eM00sB05eM00sB0ZeM000fdGXjNNNH3Rl4zTTR50ZeM000ec+WjNNNHXPlozzTR1z5aM800dc2WjPNNHHNlozzTRxzZaM800bcuWjPNNG3LlozzTRpy5aM804UO1id3JeTKqlfjK38Qjso7f0FDvwxsTQ3LeLUlp7R6g96PV2WYZUHGV65eyjZdFO7MTNyxqVqa1Wv10Upor/y/wDz/wBouV8StWK6aahhCn3Ir4L11ZT8q84oD6Pt/uj0d9mryquMr0krU0UdfRqFJmhcRUWik5gAKfzRXwWaK4V15KvXRTSjKyqGNUCpUWqHj704VekZvhPfzqWq1LwUHWGqlARpH+yPpt41uEyhcIkqh5ooI0ijA1HVtigTrTAQFgU0jzUJwhaVDU2EOpOBygqAKQ949G7BAHizU4pfLwq9Iy/Ce/lSpYvWFVqy1jG2AjQzrmVZxa0tU3Z5Fas605SECkxhoAEaWVeyHAi4lQwhTR0hDnVmAxBEpg2CCOh/EaaFLSIFW9Ruo3+04VekZvhPfzl/mjP8Q+CPRxrW9qFcVaUoVQCgQ7EWk4padX7BhD6Iw8H1ypcoaOOJQAlPRQnCj19X8gPEemOtWLaBOcxqOYKRpv4pzENWKYQHtBOWNeOt+8UEREaR2pyxrD+ut+8UWLVi0aTnMYfzGm+af+u3/8QAJRABAQEBAQACAgMBAAIDAAAAAQAQESAhMUFRMGHwcUDRUJGx/9oACAEBAAE/EINCMCMCCDA0M5BBcgzmczly5czjcuTBn7J1G4+OFyTUuXLly5iYkkySYk4mOJqTjGEaGhBBgQYFzAgzlzOZy5czlzOXLkuic4yNxuM7wuXMS5nLlzBcxJkkxk1J+pMTwdNIwg8BBnIMCC5gZy5BczmcuZy5cxcH9lxuXLlyR1C5cxLmJnJJuYk4kkySeCSYkzjpGhGBEEYEGhBnIM5czmczlzOXLlyff+HlyS5cuXLlyblyblzE1uSYkmJJDEkxkkkxk0jSNIINCDAwIMC5BcuZzOZy5cuXM5fcXJLlyS5cuZy5JcuXJM5nJJJk1Jky6L+rg6IQYGv5yJef2iEkk/WM6RpBB4CDAwIMCCDOXM5nILmcubzKS5cLhINy5I7yRzklzEuYmkkx+JJIf7vw8gf8Pyu07/L9H9lvpCH6Jx46YTSNIiNCDQiCDAgg0M5cguZzOXN5BxjiD+y4XCQuFy5JqXM5Mkly5iTMkkkySenH+7+0aEOpw+1OuQ4zpHgiPARBBgQQXMCDOXM5nM5czly5co/q4XJuFyS5qXM5NzOSYkmpJPzp/wBn4ef8D9ow5+E/U+kwGdPBEEeCCCDSCCDQ0LmczmcuZy5cJ/T08uXJJLlyTmczkkmkxJknChcTP7ej5XHzjf8AQhhnx7zovDEmcIjyRER4CCCDAgggwM5BnLly5nLlwnwf3j55cm5cuSYk4kkkySaSSYURFE+kkjgGTzh03PBz6H//AFOHHyRER4DCIIIIwIIIMCDOXLlzOXM5cweI+XOXJuXMSTE1J+pJJJJxJmZmdcZmIjDwREREYGhBBBgQQYFzOZy5nLlwx+RwuSZySbmJJ4fnEkmTUnGZJwz6IiIjTyGEEEEGhBgQXM5vM5cuGJRNc4XJHOY/NySZJMSSTEwySTh8JOszHsiIiIiIiMDQgwIIM5nM5nLlwzs/7LjcbjnJLmcm5iTJJJiSTjrMzMzMzM6REREaR4DyREEeA3mczmcuakDcZ8JczkyY/FzEkk1MMzjj4ZPLphEREREREREREaEQQYFzOZzOXPCUvhuXMTEuTJqSSa/czM4ZmZwzMzMYR5PJHgPBBBBGBBgQZzeXNfUfp8NzOTiSYkmpJJM6z4TynkiIiIiIiIiIiIiIiI0INDOZzOXLhi5z+zW5cxMTGTEk8OGZnDMzOGZmZnDSIjyeT+AgjAggwM5vLlyYBzhJc1MScSTUnH6nwz5Z+ZmZmZw9ERERERERERERGkEYGczmcuauDNy5iYmOpJ4cMzOGZmZ8vgiIiIiIiPIeTyQQaEGBnN5cuEx5uXMZMScTUmZnU1xmZwzMzMzEREREeCIiIiIiIiIw0NDxzeXL7Jc1zkzqT5+0zM4ZnyzMzMzGGER4IiIiPB5IiI0gwM5c8Pg11JxJ1mZnwzMzM4Z8sz7IiIiIiPBEREYaRGhgZy54PkGScTH+E6z6M/UzMzMzpERERERHkiIiIiIiIjSIwMDeXLl8q4mOs/XhwzMzhmZmZmZmZnSIiIiIiMIiIiI/hIiNMDA3lyadMTwZx+8cZ+ZmZwzMzM+GZmZmIiIiIjCIiIiMMI08kRpgZzw+CTHHwZnH+BmZwzOMzMzMREREeCIiPJEREREeSNMM5cuX1jMzj8Tj4ZxwzOM/UzMzOMzMxEREeSIiPJERERERhpGEYHn6JZnHD4ZmZmZmdZmZmdZmYiIiPJERHgiIiIiIiI0jTxyTH8Jj4PlmZm+0zM+WZmfDMxEREeSIiPBERERERER4NPb444zOuMzOGZmcdZmZ8MzERER5IiI8ERERERERGkaeO3c7zGXhjPlmZn7mZmZdZmZnwzMRERHkiIjyREREREeCNIw9LpMvdZ8s4ZmZmdZmZnWZmIiIiPBERERpEREREeSMNHe3dfxyXHWZ8KfSmZmZmZmZmZiIiIiIiIiIiIiPR4IiMIwcG7vZZS66zMy8MfK8JmZmZ1mZmZiIiIiIiNIiIiI0iMIjwaO989h+TF18MyzMzMzMzM+WZmZw8kREREaREREREREeCHRzvjrdd7d6Y6zOLMzMzKZmZnGZmZmf4SIiIiIjyRHg0jTe727dLt27g/HhZxlOPhcfLMzMzOMzGEREeSIiIiIjwRERo73O52757dvtLi6svNZmZeEszMzMzMz5ZmIiIiIiIjyRERERGmEYN3Bzt332H5xdWZeyzPhezOMzPlmZmZmIiIvzX+3rifKH7P8A49VVWV303xSRRSZ746pIKJLKorrpoqrBRRRSSSSRRRSSRRTB/wDGKa6KqySiSqK+emUUkc9N9d/+2mP6/u/uZ/jPJERERERERpEODDg527nbt27du52Hpi4vZcWWXFxmZmZmZmfLOkYREREREeTyREMaMODnc7vbt27du6s7L2XFllxZZmZnWZ1mZmZmYiIiIiIiIiIiIiIwdGHRu53O3c7du3bt27dweN2WXVlxZZxdZmZmZmZmfDp5J9D8/wAD+1L8Ls9+p+3kfJhEMMOjDgw53O727dLpdLt27nZ6xZbsuLLqzMzMzO/kHJ+JwX66TH/Ug7neud5fRX4D5c47fwI/4vqOc6/qZnwRETfh6+nVyTxvZ2Vx/XQjZj9/tftflv8AE/ZEREREREMaQww4MODnc7nbt26b0u3d7i4uLLqyyzq6zMLRcv0fIi5TMVDp9yIqqvVZD5rXgMhmN9AjcmZmYiIiZUAfOv8Ae/6H7PQ4RDDEMaMMOdzudzudu3Tz0u3bsOdzuLqyy6zMszMz5lICHeHZIswekXj/AMxGpAvtWTECUj0VO/C/r+EwneiKuIl+FxfX/wCmL/J+SIiIiI0YYhh0Yc7dzudu727dul0u3bujnZbsvZcWWXFlllnwuf6v7y8d1BY6SKun565IZOcrvPvmN2ZmcIiI1pJAjcB+DuDpEMMMOjgw52G7nc7nbudbt26XS6XS7duudu52W7dlllxZZl1mWWYMJ/SIn/Em9dMqVVeqsAAIDgH/ALYKZnBZc/XXwzEaYREREeBwYYcHBhwd7nc7dzt27dLpdLpdu3c7dxwsuLqyy6szLPhxmZx0iIjwREMMYOEMODDDnYc7Ddzt3O3bt0ul0ul27dzsMt2W7iy4ssuLLLLLrMzM+GYiPJDHkhhhh0YcGG7nc7nc7dzrdu3bpdLt27dzt3O4udu4sudllxZZlnF1mZnDSIjSGGIdGGGHR3sOdzudzt27du3bt0u3bt27du73FxcWXVlxZll1cZZ1xiI0iI8DDEaMMODDg3c7nc7nbt3Ot27du3bt1zt3e53FlxcWXFllnVllnWWWcNIjBwYdIYYdGGHBzt3Ow3c7nbt3Ot1u3bt2670u73Oy3cWXFu6surLLrLM64RpDEYQxgww3cGHBhu53O52G7nbt3et27du3Xe3d7Ldxc7nZZcWXOyyy4zPhnDSHSIdGHRhhwYcG7nc7nc7dzt3e3W63W63XOl27du3c7i4uLLq6susussuuERhGjDGDDow6ODdhu53O527nW7dul27dbrdu3S7du527nc7i3bt3FlxZbuLLqyzjLhpGkYRDo6Q4O9zuDnc7d3t27d89Lt27vbudzuLi6uurLrOurf/EACIRAAEDAwMFAAAAAAAAAAAAAAEAAhEDBEEQElATYICBkP/aAAgBAgEBPwDvIlSVJ4Y6FZ4WFCj4vVWOfTe1ri0uaQHDE5Vna1rbf1Ll9bdEbsR7Pkb/AP/EACMRAAEDAgUFAAAAAAAAAAAAAAIDBBEFEgEGExQxACEjgJD/2gAIAQMBAT8A+kTBwk0fNnCqArporJmaJcKCJTiOMz2x6zPmCmV3a7KitqZo6l+jb5L4ibQDiPY3/9k=" alt=""></div>
					<div class="file">
						<svg version="1.2" baseProfile="tiny" class="xuz-block_ico-arrow_file" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="211.7 0 418.6 595.3" xml:space="preserve"><path d="M624.1,401c8.1-8.4,8.1-21.6,0-30c-8.4-8.1-21.9-8.1-30,0L442,523.2V21c0-11.7-9.3-21-21-21 s-21.3,9.3-21.3,21v502.2L247.8,371c-8.4-8.1-21.6-8.1-30,0c-8.1,8.4-8.1,21.6,0,30L406,589.2c8.1,8.1,21.6,8.1,30,0L624.1,401z"/></svg>
						<span>{movie_is_ready_text} <br>{for_watching_text}</span>
					</div>
				</div>
				<a href="{returnUrl}" class="xuz-block_button" target="_top">
					<svg version="1.2" baseProfile="tiny" class="xuz-bloc_ico-play" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="168.8 0 504.2 595.3" xml:space="preserve"><g id="Play">
<path d="M645.9,255.5L249.7,5.9c-11.7-7-26.3-5.8-37.2-5.8c-43.9,0-43.7,33.9-43.7,42.5v510.1c0,7.3-0.2,42.5,43.7,42.5
	c11,0,25.5,1.2,37.2-5.8l396.1-249.6c32.5-19.3,26.9-42.2,26.9-42.2S678.4,274.8,645.9,255.5z"/></g></svg>
					<span>{watch_text}</span>
				</a>
				<div class="xuz-block_info">
					<div class="xuz-block_info-item __left">
						<svg version="1.2" baseProfile="tiny" class="xuz-block_like" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 21 561 514.5" xml:space="preserve"><g><path d="M0,535.5h102v-306H0V535.5z M561,255c0-28.1-23-51-51-51H349.4l25.5-117.3c0-2.6,0-5.1,0-7.7c0-10.2-5.1-20.4-10.2-28	l-28.1-25.5L168.3,193.8c-10.2,7.6-15.3,20.4-15.3,35.7v255c0,28,22.9,51,51,51h229.5c20.4,0,38.3-12.8,45.9-30.6l76.5-181.1
			c2.5-5.1,2.5-12.8,2.5-17.9v-51L561,255C561,257.5,561,255,561,255z"/></g></svg>
						<span>{movies_likes}</span>
					</div>
					<div class="xuz-block_info-item __left">
						<svg version="1.2" baseProfile="tiny" class="xuz-block_no-like" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 21 561 514.5" xml:space="preserve"><g>
		<path d="M0,535.5h102v-306H0V535.5z M561,255c0-28.1-23-51-51-51H349.4l25.5-117.3c0-2.6,0-5.1,0-7.7c0-10.2-5.1-20.4-10.2-28
			l-28.1-25.5L168.3,193.8c-10.2,7.6-15.3,20.4-15.3,35.7v255c0,28,22.9,51,51,51h229.5c20.4,0,38.3-12.8,45.9-30.6l76.5-181.1
			c2.5-5.1,2.5-12.8,2.5-17.9v-51L561,255C561,257.5,561,255,561,255z"/></g></svg>
						<span>{movies_dislikes}</span>
					</div>
					<div class="xuz-block_info-item __right">
						<svg version="1.2" baseProfile="tiny" class="xuz-block_ico-visits" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 105.3 519.6 309.1" xml:space="preserve"><g>
			<g>
				<path d="M513.1,245.1c0,0-140.7-139.8-253.3-139.8S6.5,245.1,6.5,245.1c-8.6,8.1-8.7,21.4,0,29.4c0,0,140.7,139.8,253.3,139.8
					s253.3-139.8,253.3-139.8C521.7,266.4,521.8,253.1,513.1,245.1z M260.9,372.4c-61.9,0-112.1-50.2-112.1-112.1
					s50.2-112.1,112.1-112.1S373,198.4,373,260.2S322.8,372.4,260.9,372.4z"/>
				<path d="M259.6,187.7c-39.3,0-71.2,32.1-71.2,71.5c0,39.4,31.9,71.5,71.2,71.5s71.2-32.1,71.2-71.5
					C330.8,219.8,298.9,187.7,259.6,187.7z M286.4,259.4c-12.2,0-22.1-9.9-22.1-22.3s9.9-22.3,22.1-22.3s22.1,9.9,22.1,22.3
					S298.7,259.4,286.4,259.4z"/>
			</g></g></svg>
						<span>{movies_downloads}</span>
					</div>
				</div>
				<div class="xuz-block_other-file">
					<a href="{returnUrl}" target="_top">{other_movies_text}</a>
					<svg version="1.2" baseProfile="tiny" class="xuz-block_ico-arrow_file" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="211.7 0 418.6 595.3" xml:space="preserve"><path d="M624.1,401c8.1-8.4,8.1-21.6,0-30c-8.4-8.1-21.9-8.1-30,0L442,523.2V21c0-11.7-9.3-21-21-21 s-21.3,9.3-21.3,21v502.2L247.8,371c-8.4-8.1-21.6-8.1-30,0c-8.1,8.4-8.1,21.6,0,30L406,589.2c8.1,8.1,21.6,8.1,30,0L624.1,401z"/></svg>
				</div>
			</div>
		</div>
	</body>
</html>'
    ],
  ];


  public function up()
  {

    $this->delete(self::BANNER_TEMPLATES);

    foreach ($this->banner_templates as $template) {
      $template['name'] = serialize($template['name']);
      $template = array_merge($template, ['is_disabled' => 0, 'created_at' => 1, 'updated_at' => 1]);
      $this->insert(self::BANNER_TEMPLATES, $template);
    }

    foreach ($this->banners as $banner) {
      $banner['name'] = serialize($banner['name']);
      $banner = array_merge($banner, ['is_disabled' => 0, 'created_by' => 1, 'created_at' => 1, 'updated_at' => 1]);
      $this->insert(self::BANNERS, $banner);
    }


    foreach ($this->banner_templates_attributes as $attribute) {
      $attribute['name'] = serialize($attribute['name']);
      $this->insert(self::BANNER_TEMPLATES_ATTRIBUTES, $attribute);
    }

    foreach ($this->banners_attribute_values as $value) {
      $value['multilang_value'] = serialize($value['multilang_value']);
      $this->insert(self::BANNER_ATTRIBUTE_VALUES, $value);
    }

  }

  public function down()
  {
    $this->delete(self::BANNER_TEMPLATES);
  }
}
