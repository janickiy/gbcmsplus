<?php

use console\components\Migration;

class m161111_151256_add_new_ads_type extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    parent::init();
  }

  public function up()
  {
    $this->insert('ads_types', [
      'code' => 'replace_links',
      'name' => serialize([
        'ru' => 'Замена ссылок',
        'en' => 'Replace links'
      ]),
      'description' => serialize([
        'ru' => 'Заменяет ссылки на странице',
        'en' => 'Replace links on page'
      ]),
      'is_default' => 0,
      'status' => 2,
      'security' => 4,
      'profit' => 4,
      'created_at' => time(),
      'updated_at' => time(),
      'created_by' => 1,
      'updated_by' => 1
    ]);

    $this->createPermission('PromoCanEditLinksReplacementPercent',
      'Редактирование процента замены ссылок в типе рекламы "замена ссылок"',
      'PromoSettings',
      ['admin', 'root', 'reseller']
    );
  }

  public function down()
  {
    $this->delete('ads_types', ['code' => 'replace_links']);

    $this->removePermission('PromoCanEditLinksReplacementPercent');
  }
}
