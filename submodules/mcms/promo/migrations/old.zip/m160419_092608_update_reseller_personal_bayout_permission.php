<?php

use console\components\Migration;

class m160419_092608_update_reseller_personal_bayout_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {


    $this->assignRolesPermission('PromoCanViewPersonalProfitsWidget', ['reseller']);

    $ruleObject = new \mcms\promo\components\rbac\ViewOwnPersonalProfitsWidgetRule();
    $this->authManager->add($ruleObject);

    $this->createOrGetPermission('PromoCanViewOwnPersonalProfitsWidget', 'Can view own personal profits widget', $ruleObject->name);

    $this->assignRolesPermission('PromoCanViewOwnPersonalProfitsWidget', ['reseller']);

  }

  public function down()
  {
    if ($rule = $this->authManager->getRule('ViewOwnPersonalProfitsWidgetRule')) {
      $this->authManager->remove($rule);
    }
    $this->removePermission('PromoCanViewOwnPersonalProfitsWidget');
    $this->revokeRolesPermission('PromoCanViewPersonalProfitsWidget', ['reseller']);
  }


  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
