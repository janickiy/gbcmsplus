<?php

use console\components\Migration;

class m160511_141831_landing_cateogry_tb_url extends Migration
{
  public function up()
  {
    $this->addColumn(\mcms\promo\models\LandingCategory::tableName(), 'tb_url', 'VARCHAR(255)');
  }

  public function down()
  {
    $this->dropColumn(\mcms\promo\models\LandingCategory::tableName(), 'tb_url');
  }
}
