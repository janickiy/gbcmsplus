<?php

use console\components\Migration;
use rgk\settings\models\Setting;

class m180323_090636_remove_settings extends Migration
{
  const SETTINGS_MAIN_REBILL_PERCENT_FOR_INVESTOR = 'settings.main_rebill_percent_for_investor';
  const SETTINGS_MAIN_BUYOUT_PERCENT_FOR_INVESTOR = 'settings.main_buyout_percent_for_investor';
  const SETTINGS_MAIN_REBILL_PERCENT_FOR_RESELLER = 'settings.main_rebill_percent_for_reseller';

  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
  }

  public function up()
  {
    $this->settingsBuilder->removeSetting(self::SETTINGS_MAIN_REBILL_PERCENT_FOR_INVESTOR);
    $this->settingsBuilder->removeSetting(self::SETTINGS_MAIN_BUYOUT_PERCENT_FOR_INVESTOR);
    $this->settingsBuilder->removeSetting(self::SETTINGS_MAIN_REBILL_PERCENT_FOR_RESELLER);
  }

  public function down()
  {
    $title = ['ru' => 'Основной процент ребила для инвесторов', 'en' => 'Main rebill percent for investor'];
    $permissions = ['EditModuleSettingsPromo'];
    $category = 'app.common.group_buyouts_rebills';
    $validators = [["required"],["double"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTINGS_MAIN_REBILL_PERCENT_FOR_INVESTOR, $permissions, Setting::TYPE_FLOAT, $category, '', $validators);

    $title = ['ru' => 'Основной процент выкупа для инвесторов', 'en' => 'Main buyout percent for investor'];
    $permissions = ['EditModuleSettingsPromo'];
    $category = 'app.common.group_buyouts_rebills';
    $validators = [["required"],["double"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTINGS_MAIN_BUYOUT_PERCENT_FOR_INVESTOR, $permissions, Setting::TYPE_FLOAT, $category, '', $validators);

    $title = ['ru' => 'Основной процент ребила для реселлера', 'en' => 'Main rebill percent for reseller'];
    $permissions = ['EditModuleSettingsPromo'];
    $category = 'app.common.group_buyouts_rebills';
    $validators = [["required"],["double"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTINGS_MAIN_REBILL_PERCENT_FOR_RESELLER, $permissions, Setting::TYPE_FLOAT, $category, '', $validators);
  }


}
