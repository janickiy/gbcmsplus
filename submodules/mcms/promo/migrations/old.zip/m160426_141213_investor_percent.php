<?php

use console\components\Migration;
use mcms\promo\Module;

class m160426_141213_investor_percent extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->createOrGetPermission(Module::PERMISSION_USE_NOT_PERSONAL_PERCENT, 'Is user affected by personal_profits that has no user_id specified');

    $this->assignRolesPermission(Module::PERMISSION_USE_NOT_PERSONAL_PERCENT, ['partner']);

    \yii\caching\TagDependency::invalidate(Yii::$app->cache, [
      \mcms\promo\components\api\GetPersonalProfit::CACHE_KEY_PREFIX . 'module_percents'
    ]);
  }

  public function down()
  {
    $this->removePermission(Module::PERMISSION_USE_NOT_PERSONAL_PERCENT);
    echo "m160426_141213_investor_percent cannot be reverted.\n";
  }
}
