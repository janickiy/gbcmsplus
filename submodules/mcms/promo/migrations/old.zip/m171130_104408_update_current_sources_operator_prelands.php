<?php

use mcms\promo\models\PrelandDefaults;
use mcms\promo\models\Source;
use console\components\Migration;
use yii\db\Query;

class m171130_104408_update_current_sources_operator_prelands extends Migration
{
  const SOURCE_ADD_PRELAND_OPERATORS_TABLE = 'source_add_preland_operators';
  const SOURCE_OFF_PRELAND_OPERATORS_TABLE = 'source_off_preland_operators';

  public function up()
  {
    $sources = (new Query())
      ->select([
        'id',
        'user_id',
        'stream_id',
      ])
      ->from(Source::tableName())
      ->where(['status' => Source::STATUS_APPROVED])
      ->each();

    //Проходим по всем источникам
    foreach ($sources as $source) {
      foreach ([PrelandDefaults::TYPE_ADD, PrelandDefaults::TYPE_OFF] as $type) {

        $table = $type == PrelandDefaults::TYPE_ADD
          ? self::SOURCE_ADD_PRELAND_OPERATORS_TABLE
          : self::SOURCE_OFF_PRELAND_OPERATORS_TABLE;

        $defaultPrelands = (new Query())
          ->select([
            'operators',
          ])
          ->from(PrelandDefaults::tableName())
          ->where([
            'or', ['user_id' => $source['user_id']], ['user_id' => null]
          ])
          ->andWhere([
            'or', ['stream_id' => $source['stream_id']], ['stream_id' => null]
          ])
          ->andWhere([
            'or', ['source_id' => $source['id']], ['source_id' => null]
          ])
          ->andWhere(['status' => PrelandDefaults::STATUS_ACTIVE, 'type' => $type])
          ->each();

        $operators = [];
        $defaultPrelandsWithoutOperators = false;
        foreach ($defaultPrelands as $defaultPreland) {
          if ($defaultPreland['operators']) {
            $operators = array_merge($operators, unserialize($defaultPreland['operators']));
          } else {
            //Если у правила не указаны операторы
            $defaultPrelandsWithoutOperators = true;
          }
        }

        if ($defaultPrelandsWithoutOperators) {
          //Ищем всех возможных операторов для данного источника
          $sourcesOperators = (new Query())
            ->select([
              'sol.operator_id',
            ])
            ->from(Source::tableName() . 's')
            ->innerJoin('sources_operator_landings sol', 's.id = sol.source_id')
            ->where(['s.status' => Source::STATUS_APPROVED])
            ->andWhere(['s.id' => $source['id']])
            ->distinct();
          $operators = array_merge($operators, $sourcesOperators->column());
        }

        $operators = array_unique(array_filter($operators));

        $sourcePrelandOperators = (new Query())
          ->select([
            'operator_id',
          ])
          ->from($table)
          ->where([
            'source_id' => $source['id'],
          ])
          ->column();

        //Если у источника есть операторы для прелендов
        if ($sourcePrelandOperators) {
          //И их нет в правилах для прелендов
          $operatorsToInsert = array_diff($sourcePrelandOperators, $operators);
          if ($operatorsToInsert) {
            echo "Добаляем правило для источника " . $source['id'] . PHP_EOL;
            //Добавляем частное правило
            Yii::$app->db->createCommand()
              ->insert(
                PrelandDefaults::tableName(),
                [
                  'operators' => serialize($operatorsToInsert),
                  'status' => PrelandDefaults::STATUS_ACTIVE,
                  'source_id' => $source['id'],
                  'created_at' => time(),
                  'type' => $type,
                ]
              )
              ->execute();
          }
        }
      }
    }
  }

  public function down()
  {
    return true;
  }
}