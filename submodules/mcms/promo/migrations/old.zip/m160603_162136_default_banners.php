<?php

use console\components\Migration;

class m160603_162136_default_banners extends Migration
{
  public function up()
  {
    $this->update('landing_categories', ['banner_id' => 2], ['code' => 'music']);
    $this->update('landing_categories', ['banner_id' => 3], ['code' => 'movies']);
    $this->update('landing_categories', ['banner_id' => 1], ['code' => 'fileshare']);
  }

  public function down()
  {
    $this->update('landing_categories', ['banner_id' => null], ['code' => 'music']);
    $this->update('landing_categories', ['banner_id' => null], ['code' => 'movies']);
    $this->update('landing_categories', ['banner_id' => null], ['code' => 'fileshare']);
  }

}
