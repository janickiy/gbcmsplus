<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

/**
 * Группировка прав модуля Промо
 */
class m161110_065825_promo_permissions_group extends Migration
{
  use PermissionMigration;

  public function up()
  {
    // Разрешения
    $this->addChildPermission('PromoPermissions', 'PromoApplyPersonalPercentsAsInvestor');
    $this->addChildPermission('PromoPermissions', 'PromoApplyPersonalPercentsAsReseller');
    $this->addChildPermission('PromoPermissions', 'PromoApplyPersonalPercentsAsRoot');
    $this->addChildPermission('PromoPermissions', 'PromoCanEditDefaultClickNConfirmText');
    $this->addChildPermission('PromoPermissions', 'PromoCanHavePersonalBuyout');
    $this->addChildPermission('PromoPermissions', 'PromoCanResellerHidePromo');
    $this->addChildPermission('PromoPermissions', 'PromoIsUserEffectedByRebillConditionModerationFlag');
    $this->addChildPermission('PromoPermissions', 'PromoUseNotPersonalPercent');
    $this->addChildPermission('PromoPermissions', 'PromoPartnerHidePromo');

    $this->addChildPermission('PromoPermissions', 'CanLinkNotificationSend');
    $this->addChildPermission('PromoPermissions', 'CanStreamNotificationSend');
    $this->addChildPermission('PromoPermissions', 'CanEditLandingCategoryClickNConfirmText');

    // Экшены
    $this->addChildPermission('PromoLandingsController', 'PromoLandingsUpdateBuyoutProfit');

    // Контроллеры
    $this->createPermission('PromoInvestorPriorityController', null, 'PromoModule');
    $this->addChildPermission('PromoInvestorPriorityController', 'PromoInvestorPriorityUpdate');

    // Установка правильных парентов
    $this->addChildPermission('PromoLandingSetsController', 'PromoLandingSetsLinkSource');
    $this->addChildPermission('PromoLandingSetsController', 'PromoLandingSetsUnlinkSource');
    $this->addChildPermission('PromoLandingSetsController', 'PromoLandingSetsUpdateLandings');

    $this->movePermission('CanEditLandingCategoryAlterCategories', 'PromoLandingCategoriesController', 'PromoPermissions');
    $this->movePermission('CanEditLandingCategoryBannersIds', 'PromoLandingCategoriesController', 'PromoPermissions');
    $this->movePermission('CanEditLandingCategoryCode', 'PromoLandingCategoriesController', 'PromoPermissions');
    $this->movePermission('CanEditLandingCategoryName', 'PromoLandingCategoriesController', 'PromoPermissions');
    $this->movePermission('CanEditLandingCategoryStatus', 'PromoLandingCategoriesController', 'PromoPermissions');
    $this->movePermission('CanEditLandingCategoryTbUrl', 'PromoLandingCategoriesController', 'PromoPermissions');

    $this->movePermission('PromoSettings', 'PromoModule', 'PromoPermissions');

    $this->createPermission('PromoPersonalProfitsController', null, 'PromoModule');
    $this->movePermission('PromoPersonalProfitsCreateModal', 'PromoPersonalBuyoutsController', 'PromoPersonalProfitsController');
    $this->movePermission('PromoPersonalProfitsDelete', 'PromoPersonalBuyoutsController', 'PromoPersonalProfitsController');
    $this->movePermission('PromoPersonalProfitsIndex', 'PromoPersonalBuyoutsController', 'PromoPersonalProfitsController');
    $this->movePermission('PromoPersonalProfitsUpdateModal', 'PromoPersonalBuyoutsController', 'PromoPersonalProfitsController');

    $this->addChildPermission('PromoWebmasterSourcesController', 'PromoWebmasterSourcesLandingSetsAutosyncDisable');
    $this->addChildPermission('PromoWebmasterSourcesController', 'PromoWebmasterSourcesLandingSetsAutosyncEnable');
    $this->addChildPermission('PromoWebmasterSourcesController', 'PromoWebmasterSourcesLandingSetsDelete');
    $this->addChildPermission('PromoWebmasterSourcesController', 'PromoWebmasterSourcesLandingSetsSync');

    // Переименование
    $this->renamePermission('TraffickbackProvidersController', 'PromoTraffickbackProvidersController');
  }

  public function down()
  {
    // Разрешения
    $this->removeChildPermission('PromoPermissions', 'PromoApplyPersonalPercentsAsInvestor');
    $this->removeChildPermission('PromoPermissions', 'PromoApplyPersonalPercentsAsReseller');
    $this->removeChildPermission('PromoPermissions', 'PromoApplyPersonalPercentsAsRoot');
    $this->removeChildPermission('PromoPermissions', 'PromoCanEditDefaultClickNConfirmText');
    $this->removeChildPermission('PromoPermissions', 'PromoCanHavePersonalBuyout');
    $this->removeChildPermission('PromoPermissions', 'PromoCanResellerHidePromo');
    $this->removeChildPermission('PromoPermissions', 'PromoIsUserEffectedByRebillConditionModerationFlag');
    $this->removeChildPermission('PromoPermissions', 'PromoUseNotPersonalPercent');
    $this->removeChildPermission('PromoPermissions', 'PromoPartnerHidePromo');

    $this->removeChildPermission('PromoPermissions', 'CanLinkNotificationSend');
    $this->removeChildPermission('PromoPermissions', 'CanStreamNotificationSend');
    $this->removeChildPermission('PromoPermissions', 'CanEditLandingCategoryClickNConfirmText');

    // Экшены
    $this->removeChildPermission('PromoLandingsController', 'PromoLandingsUpdateBuyoutProfit');

    // Контроллеры
    $this->removePermission('PromoInvestorPriorityController');

    // Восстановление парентов
    $this->removeChildPermission('PromoLandingSetsController', 'PromoLandingSetsLinkSource');
    $this->removeChildPermission('PromoLandingSetsController', 'PromoLandingSetsUnlinkSource');
    $this->removeChildPermission('PromoLandingSetsController', 'PromoLandingSetsUpdateLandings');

    $this->movePermission('CanEditLandingCategoryAlterCategories', 'PromoPermissions', 'PromoLandingCategoriesController');
    $this->movePermission('CanEditLandingCategoryBannersIds', 'PromoPermissions', 'PromoLandingCategoriesController');
    $this->movePermission('CanEditLandingCategoryCode', 'PromoPermissions', 'PromoLandingCategoriesController');
    $this->movePermission('CanEditLandingCategoryName', 'PromoPermissions', 'PromoLandingCategoriesController');
    $this->movePermission('CanEditLandingCategoryStatus', 'PromoPermissions', 'PromoLandingCategoriesController');
    $this->movePermission('CanEditLandingCategoryTbUrl', 'PromoPermissions', 'PromoLandingCategoriesController');

    $this->removeChildPermission('PromoWebmasterSourcesController', 'PromoWebmasterSourcesLandingSetsAutosyncDisable');
    $this->removeChildPermission('PromoWebmasterSourcesController', 'PromoWebmasterSourcesLandingSetsAutosyncEnable');
    $this->removeChildPermission('PromoWebmasterSourcesController', 'PromoWebmasterSourcesLandingSetsDelete');
    $this->removeChildPermission('PromoWebmasterSourcesController', 'PromoWebmasterSourcesLandingSetsSync');

    $this->movePermission('PromoSettings', 'PromoPermissions', 'PromoModule');

    $this->movePermission('PromoPersonalProfitsCreateModal', 'PromoPersonalProfitsController', 'PromoPersonalBuyoutsController');
    $this->movePermission('PromoPersonalProfitsDelete', 'PromoPersonalProfitsController', 'PromoPersonalBuyoutsController');
    $this->movePermission('PromoPersonalProfitsIndex', 'PromoPersonalProfitsController', 'PromoPersonalBuyoutsController');
    $this->movePermission('PromoPersonalProfitsUpdateModal', 'PromoPersonalProfitsController', 'PromoPersonalBuyoutsController');
    $this->removePermission('PromoPersonalProfitsController');

    // Переименование
    $this->renamePermission('PromoTraffickbackProvidersController', 'TraffickbackProvidersController');
  }
}
