<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170816_085105_review_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->removePermission('PromoArbitrarySourcesDisable');
    $this->removePermission('PromoArbitrarySourcesFindUser');
    $this->removePermission('PromoArbitrarySourcesOperators');
    $this->removePermission('PromoArbitrarySourcesViewModal');
    $this->removePermission('PromoLandingCategoriesCreate');
    $this->removePermission('PromoLandingCategoriesUpdate');
    $this->removePermission('PromoLandingSetsCreate');
    $this->removePermission('PromoLandingSetsUpdateParams');
    $this->removePermission('PromoLandingUnblockRequestsCreate');
    $this->removePermission('PromoLandingUnblockRequestsFindUser');
    $this->removePermission('PromoLandingUnblockRequestsUpdate');
    $this->removePermission('PromoLandingUnblockRequestsView');
    $this->removePermission('PromoWebmasterSourcesDisable');
    $this->removePermission('PromoWebmasterSourcesEnable');
    $this->removePermission('PromoWebmasterSourcesFindUser');
    $this->removePermission('PromoWebmasterSourcesUpdateModal');
    $this->removePermission('PromoWebmasterSourcesViewModal');
    $this->updatePermissionDescription('PromoOperatorsViewModal', 'Просмотр оператора в модалке');
    $this->updatePermissionDescription('PromoPartnerProgramsLinkPartnerEditable', 'Управление партнерскими программами пользователя (прикрепление, удаление)');
    $this->updatePermissionDescription('PromoCanViewRebillConditionsWidget', 'Просмотр виджета условий ребила');
    $this->updatePermissionDescription('PromoCurrenciesUserMainCurrencyChanged', 'Выбор валюты для отображения (н-р: отображение статистики)');
    $this->updatePermissionDescription('PromoWebmasterSourcesLandingSetsAutosyncDisable', 'Выключение автосинхронизации с набором (в редактировании набора)');
    $this->updatePermissionDescription('PromoWebmasterSourcesLandingSetsAutosyncEnable', 'Включение автосинхронизации с набором (в редактировании набора)');
    $this->updatePermissionDescription('PromoApplyPersonalPercentsAsInvestor', 'Применение к текущему пользователю логики инвестора для формирования личных процентов (выкуп и ребилл)');
    $this->updatePermissionDescription('PromoApplyPersonalPercentsAsReseller', 'Применение к текущему пользователю логики реселлера для формирования личных процентов (выкуп и ребилл)');
    $this->updatePermissionDescription('PromoApplyPersonalPercentsAsRoot', 'Применение к текущему пользователю логики рута для формирования личных процентов (выкуп и ребилл)');
  }

  public function down()
  {
    $this->createPermission('PromoArbitrarySourcesDisable', 'Выключение ссылки арбитражников', 'PromoArbitrarySourcesController', ['admin', 'root', 'manager', 'reseller']);
    $this->createPermission('PromoArbitrarySourcesFindUser', 'Поиск пользователя', 'PromoArbitrarySourcesController', ['admin', 'root', 'manager', 'reseller']);
    $this->createPermission('PromoArbitrarySourcesOperators', 'Получение списка операторов', 'PromoArbitrarySourcesController', ['admin', 'root', 'manager', 'reseller']);
    $this->createPermission('PromoArbitrarySourcesViewModal', 'Просмотр ссылки арбитражников в модалке', 'PromoArbitrarySourcesController', ['admin', 'root', 'manager', 'reseller']);
    $this->createPermission('PromoLandingCategoriesCreate', 'Создание категории лендингов', 'PromoLandingCategoriesController', ['admin', 'root']);
    $this->createPermission('PromoLandingCategoriesUpdate', 'Редактирование категории лендингов', 'PromoLandingCategoriesController', ['admin', 'root', 'reseller']);
    $this->createPermission('PromoLandingSetsCreate', 'Создание набора', 'PromoLandingSetsController', ['admin', 'root', 'reseller']);
    $this->createPermission('PromoLandingSetsUpdateParams', 'Обновление параметров набора', 'PromoLandingSetsController', ['admin', 'root', 'reseller']);
    $this->createPermission('PromoLandingUnblockRequestsCreate', 'Создание запроса на разблокировку', 'PromoLandingUnblockRequestsController', ['admin', 'root']);
    $this->createPermission('PromoLandingUnblockRequestsFindUser', 'Поиск пользователей', 'PromoLandingUnblockRequestsController', ['admin', 'root', 'manager', 'reseller']);
    $this->createPermission('PromoLandingUnblockRequestsUpdate', 'Редактирование запроса на разблокировку', 'PromoLandingUnblockRequestsController', ['admin', 'root', 'manager', 'reseller']);
    $this->createPermission('PromoLandingUnblockRequestsView', 'Просмотр запроса на разблокировку', 'PromoLandingUnblockRequestsController', ['admin', 'root', 'manager', 'reseller']);
    $this->createPermission('PromoWebmasterSourcesDisable', 'Выключение источника веб-мастеров', 'PromoWebmasterSourcesController', ['admin', 'root', 'manager', 'reseller']);
    $this->createPermission('PromoWebmasterSourcesEnable', 'Включение источника веб-мастеров', 'PromoWebmasterSourcesController', ['admin', 'root', 'manager', 'reseller']);
    $this->createPermission('PromoWebmasterSourcesFindUser', 'Поиск пользователя', 'PromoWebmasterSourcesController', ['admin', 'root', 'manager', 'reseller']);
    $this->createPermission('PromoWebmasterSourcesUpdateModal', 'Редактирование источника веб-мастеров модалка', 'PromoWebmasterSourcesController', ['admin', 'root', 'manager', 'reseller']);
    $this->createPermission('PromoWebmasterSourcesViewModal', 'Просмотр источника веб-мастеров модалка', 'PromoWebmasterSourcesController', ['admin', 'root', 'manager', 'reseller']);
  }
}
