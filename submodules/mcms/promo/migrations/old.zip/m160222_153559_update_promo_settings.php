<?php

use console\components\Migration;

class m160222_153559_update_promo_settings extends Migration
{
  public function up()
  {
    /** @var \mcms\promo\Module $promo */
    $promo = Yii::$app->getModule('promo');

    $promo->settings->offsetSet('settings.domain_internet_bs_api_key', 'M3J7O4C3K5S4B6W8F7F6');
    $promo->settings->offsetSet('settings.domain_internet_bs_api_password', urlencode('InBS90241+'));
    $promo->settings->offsetSet('settings.domain_clone', 'forapi2.pw');
  }

  public function down()
  {
    echo "m160222_153559_update_promo_settings cannot be reverted.\n";
  }
}
