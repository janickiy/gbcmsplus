<?php

use console\components\Migration;

class m160314_133708_global_profits extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  const TABLE = 'personal_profit';

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    parent::init();
  }


  public function up()
  {
    $this->createOrGetPermission('PromoPersonalProfitsIndex', 'View profits settings');
    $this->assignRolesPermission('PromoPersonalProfitsIndex', ['root', 'admin', 'reseller']);

    $this->alterColumn(self::TABLE, 'user_id', 'mediumint(5) unsigned');
  }

  public function down()
  {
    Yii::$app->db->createCommand('SET FOREIGN_KEY_CHECKS = 0')->execute();
    $this->alterColumn(self::TABLE, 'user_id', 'mediumint(5) unsigned NOT NULL');
    Yii::$app->db->createCommand('SET FOREIGN_KEY_CHECKS = 1')->execute();

    $this->removePermission('PromoPersonalProfitsIndex');
  }
}
