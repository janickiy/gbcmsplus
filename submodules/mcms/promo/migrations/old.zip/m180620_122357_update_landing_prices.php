<?php

use console\components\Migration;

class m180620_122357_update_landing_prices extends Migration
{
  public function up()
  {
    $this->update('landing_operators', ['buyout_price_rub' => 0, 'buyout_price_usd' => 0, 'rebill_price_rub' => 0,
      'rebill_price_usd' => 0], ['default_currency_id' => 3]);

  }

  public function down()
  {
    echo "m180620_122357_update_landing_prices cannot be reverted.\n";

    return true;
  }
}
