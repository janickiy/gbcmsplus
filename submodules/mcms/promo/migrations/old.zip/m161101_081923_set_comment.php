<?php

use console\components\Migration;

class m161101_081923_set_comment extends Migration
{
    public function up()
    {
      $this->addColumn('landing_sets', 'description', $this->text());
    }

    public function down()
    {
      $this->dropColumn('landing_sets', 'description');
    }
}
