<?php

use console\components\Migration;

class m160428_132014_permission_groups extends Migration
{
  /** @var  \yii\rbac\ManagerInterface */
  private $authManager;
  private $groupPermission = [
    'name' =>  'PromoModule',
    'description' => 'Module Promo',
  ]
  ;
  private $groupPermissionControllers = [
    'PromoPermissions' => [
      'description' => 'Can view permissions',
      'permissions' => [
        'PromoCanViewBlockedLandings',
        'PromoCanViewOwnPersonalProfitsWidget',
        'PromoCanViewPersonalBuyoutWidget',
        'PromoCanViewPersonalProfitsWidget',
        'PromoCanViewRebillConditionsWidget',
        'PromoViewOtherPeopleSources',
        'PromoViewOtherPeopleStreams',
      ]
    ],
    'PromoAdsNetworksController' => [
      'description' => 'Promo Ads Networks Controller',
      'permissions' => [
        'PromoAdsNetworksCreate',
        'PromoAdsNetworksDisable',
        'PromoAdsNetworksEnable',
        'PromoAdsNetworksIndex',
        'PromoAdsNetworksUpdate',
        'PromoAdsNetworksView',
        'PromoAdsNetworksViewModal',
      ]
    ],
    'PromoAdsTypesController' => [
      'description' => 'Promo Ads types Controller',
      'permissions' => [
        'PromoAdsTypesCreateModal',
        'PromoAdsTypesDisable',
        'PromoAdsTypesEnable',
        'PromoAdsTypesIndex',
        'PromoAdsTypesUpdateModal',
      ]
    ],
    'PromoArbitrarySourcesController' => [
      'description' => 'Promo Arbitrary Sources Controller',
      'permissions' => [
        'PromoArbitrarySourcesDisable',
        'PromoArbitrarySourcesDisableModal',
        'PromoArbitrarySourcesEnable',
        'PromoArbitrarySourcesFindUser',
        'PromoArbitrarySourcesIndex',
        'PromoArbitrarySourcesOperators',
        'PromoArbitrarySourcesSelect2',
        'PromoArbitrarySourcesUpdate',
        'PromoArbitrarySourcesUpdateAddOperatorPreland',
        'PromoArbitrarySourcesUpdateOffOperatorPreland',
        'PromoArbitrarySourcesView',
        'PromoArbitrarySourcesViewModal',
      ]
    ],
    'PromoCitiesController' => [
      'description' => 'Promo Cities Controller',
      'permissions' => [
        'PromoCitiesCreate',
        'PromoCitiesCreateModal',
        'PromoCitiesDependentRegions',
        'PromoCitiesDisable',
        'PromoCitiesEnable',
        'PromoCitiesIndex',
        'PromoCitiesUpdate',
        'PromoCitiesUpdateModal',
        'PromoCitiesView',
        'PromoCitiesViewModal',
      ]
    ],
    'PromoCountriesController' => [
      'description' => 'Promo Countries Controller',
      'permissions' => [
        'PromoCountriesCreate',
        'PromoCountriesCreateModal',
        'PromoCountriesDisable',
        'PromoCountriesEnable',
        'PromoCountriesIndex',
        'PromoCountriesUpdate',
        'PromoCountriesUpdateModal',
        'PromoCountriesView',
        'PromoCountriesViewModal',
      ]
    ],
    'PromoCurrenciesController' => [
      'description' => 'Promo Currencies Controller',
      'permissions' => [
        'PromoCurrenciesCreate',
        'PromoCurrenciesCreateModal',
        'PromoCurrenciesDelete',
        'PromoCurrenciesIndex',
        'PromoCurrenciesUpdate',
        'PromoCurrenciesUpdateModal',
        'PromoCurrenciesUserMainCurrencyChanged',
        'PromoCurrenciesView',
        'PromoCurrenciesViewModal',
      ]
    ],
    'PromoDomainsController' => [
      'description' => 'Promo Domains Controller',
      'permissions' => [
        'PromoDomainsCreate',
        'PromoDomainsCreateModal',
        'PromoDomainsFindUser',
        'PromoDomainsIndex',
        'PromoDomainsUpdate',
        'PromoDomainsUpdateModal',
        'PromoDomainsView',
        'PromoDomainsViewModal',
      ]
    ],
    'PromoLandingCategoriesController' => [
      'description' => 'Promo LandingCategories Controller',
      'permissions' => [
        'PromoLandingCategoriesCreate',
        'PromoLandingCategoriesCreateModal',
        'PromoLandingCategoriesDisable',
        'PromoLandingCategoriesEnable',
        'PromoLandingCategoriesIndex',
        'PromoLandingCategoriesUpdate',
        'PromoLandingCategoriesUpdateModal',
        'PromoLandingCategoriesView',
        'PromoLandingCategoriesViewModal',
      ]
    ],
    'PromoLandingPayTypesController' => [
      'description' => 'Promo LandingPayTypes Controller',
      'permissions' => [
        'PromoLandingPayTypesCreateModal',
        'PromoLandingPayTypesDisable',
        'PromoLandingPayTypesEnable',
        'PromoLandingPayTypesIndex',
        'PromoLandingPayTypesUpdateModal',
      ]
    ],
    'PromoLandingRedirectsController' => [
      'description' => 'Promo LandingRedirects Controller',
      'permissions' => [
        'PromoLandingRedirectsCreateModal',
        'PromoLandingRedirectsDisable',
        'PromoLandingRedirectsEnable',
        'PromoLandingRedirectsIndex',
        'PromoLandingRedirectsUpdateModal',
        'PromoLandingRedirectsViewModal',
      ]
    ],
    'PromoLandingsController' => [
      'description' => 'Promo Landings Controller',
      'permissions' => [
        'PromoLandingsCreate',
        'PromoLandingsDisable',
        'PromoLandingsEnable',
        'PromoLandingsIndex',
        'PromoLandingsSelect2',
        'PromoLandingsUpdate',
        'PromoLandingsView',
        'PromoLandingsViewModal',
      ]
    ],
    'PromoLandingSubscriptionTypesController' => [
      'description' => 'Promo Landing Subscription Types Controller',
      'permissions' => [
        'PromoLandingSubscriptionTypesCreateModal',
        'PromoLandingSubscriptionTypesDisable',
        'PromoLandingSubscriptionTypesEnable',
        'PromoLandingSubscriptionTypesIndex',
        'PromoLandingSubscriptionTypesUpdateModal',
      ]
    ],
    'PromoLandingUnblockRequestsController' => [
      'description' => 'Promo Landing Unblock Requests Controller',
      'permissions' => [
        'PromoLandingUnblockRequestsCreate',
        'PromoLandingUnblockRequestsCreateModal',
        'PromoLandingUnblockRequestsFindUser',
        'PromoLandingUnblockRequestsIndex',
        'PromoLandingUnblockRequestsUpdate',
        'PromoLandingUnblockRequestsUpdateModal',
        'PromoLandingUnblockRequestsView',
        'PromoLandingUnblockRequestsViewModal',
      ]
    ],
    'PromoOperatorsController' => [
      'description' => 'Promo Operators Controller',
      'permissions' => [
        'PromoOperatorsCreate',
        'PromoOperatorsDisable',
        'PromoOperatorsEnable',
        'PromoOperatorsIndex',
        'PromoOperatorsSelect2',
        'PromoOperatorsUpdate',
        'PromoOperatorsView',
      ]
    ],
    'PromoPersonalBuyoutsController' => [
      'description' => 'Promo Personal Buyouts Controller',
      'permissions' => [
        'PromoPersonalBuyoutsCreateModal',
        'PromoPersonalBuyoutsDelete',
        'PromoPersonalBuyoutsIndex',
        'PromoPersonalBuyoutsUpdateModal',
        'PromoPersonalProfitsCreateModal',
        'PromoPersonalProfitsDelete',
        'PromoPersonalProfitsIndex',
        'PromoPersonalProfitsUpdateModal',
      ]
    ],
    'PromoPlatformsController' => [
      'description' => 'Promo Platforms Controller',
      'permissions' => [
        'PromoPlatformsCreateModal',
        'PromoPlatformsDisable',
        'PromoPlatformsEnable',
        'PromoPlatformsIndex',
        'PromoPlatformsUpdateModal',
      ]
    ],
    'PromoProvidersController' => [
      'description' => 'Promo Providers Controller',
      'permissions' => [
        'PromoProvidersCreate',
        'PromoProvidersDisable',
        'PromoProvidersEnable',
        'PromoProvidersIndex',
        'PromoProvidersRedirect',
        'PromoProvidersUpdate',
        'PromoProvidersView',
      ]
    ],
    'PromoRebillConditionsController' => [
      'description' => 'Promo Rebill Conditions Controller',
      'permissions' => [
        'PromoRebillConditionsCreateModal',
        'PromoRebillConditionsDelete',
        'PromoRebillConditionsIndex',
        'PromoRebillConditionsUpdateModal',
      ]
    ],
    'PromoRegionsController' => [
      'description' => 'Promo Regions Controller',
      'permissions' => [
        'PromoRegionsCreate',
        'PromoRegionsCreateModal',
        'PromoRegionsDisable',
        'PromoRegionsEnable',
        'PromoRegionsIndex',
        'PromoRegionsUpdate',
        'PromoRegionsUpdateModal',
        'PromoRegionsView',
        'PromoRegionsViewModal',
      ]
    ],
    'PromoStreamsController' => [
      'description' => 'Promo Streams Controller',
      'permissions' => [
        'PromoStreamsCreateModal',
        'PromoStreamsDisable',
        'PromoStreamsEnable',
        'PromoStreamsFindUser',
        'PromoStreamsIndex',
        'PromoStreamsStreamSearch',
        'PromoStreamsUpdate',
        'PromoStreamsUpdateModal',
        'PromoStreamsView',
        'PromoStreamsViewModal',
      ]
    ],
    'PromoTrafficTypesController' => [
      'description' => 'Promo Traffic Types Controller',
      'permissions' => [
        'PromoTrafficTypesCreate',
        'PromoTrafficTypesDisable',
        'PromoTrafficTypesEnable',
        'PromoTrafficTypesIndex',
        'PromoTrafficTypesUpdate',
      ]
    ],
    'PromoWebmasterSourcesController' => [
      'description' => 'Promo Webmaster Sources Controller',
      'permissions' => [
        'PromoWebmasterSourcesDisable',
        'PromoWebmasterSourcesDisableModal',
        'PromoWebmasterSourcesEnable',
        'PromoWebmasterSourcesEnableModal',
        'PromoWebmasterSourcesFindUser',
        'PromoWebmasterSourcesIndex',
        'PromoWebmasterSourcesUpdate',
        'PromoWebmasterSourcesUpdateAddOperatorPreland',
        'PromoWebmasterSourcesUpdateCategory',
        'PromoWebmasterSourcesUpdateModal',
        'PromoWebmasterSourcesUpdateOffOperatorPreland',
        'PromoWebmasterSourcesView',
        'PromoWebmasterSourcesViewModal',
      ]
    ],
  ];

  public function init()
  {
    parent::init();
    $this->authManager = \Yii::$app->authManager;
  }

  public function up()
  {
    foreach ($this->groupPermissionControllers as $controllerName => $controllerData) {
      $controllerPermission = $this->createOrGetPermission($controllerName, $controllerData['description']);
      foreach($controllerData['permissions'] as $childPermissionName) {
        $childPermission = $this->authManager->getPermission($childPermissionName);
        if ($childPermission && !$this->authManager->hasChild($controllerPermission, $childPermission)) {
          $this->authManager->addChild($controllerPermission, $childPermission);
        }
      }
      $groupPermission = $this->createOrGetPermission($this->groupPermission['name'], $this->groupPermission['description']);
      $this->authManager->addChild($groupPermission, $controllerPermission);
    }
  }

  public function down()
  {
    $permission = $this->authManager->getPermission($this->groupPermission);
    $this->authManager->remove($permission);
    foreach ($this->groupPermissionControllers as $controllerName => $controllerData) {
      $controllerPermission = $this->authManager->getPermission($controllerName);
      $this->authManager->remove($controllerPermission);
    }
  }

  public function createOrGetPermission($permissionName, $permissionDescription)
  {
    $permission = $this->authManager->getPermission($permissionName);
    if (!$permission) {
      $permission = $this->authManager->createPermission($permissionName);
      $permission->description = $permissionDescription;
      $this->authManager->add($permission);
    }
    return $permission;
  }
}
