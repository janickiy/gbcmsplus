<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

class m171025_090110_operators_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->renamePermission('PromoOperatorsUpdateBuyout', 'PromoOperatorsUpdateParams');
    $this->renamePermission('PromoOperatorsUpdateBuyoutParams', 'PromoOperatorsUpdateOperatorParams');

  }

  public function down()
  {
    $this->renamePermission('PromoOperatorsUpdateParams', 'PromoOperatorsUpdateBuyout');
    $this->renamePermission('PromoOperatorsUpdateOperatorParams', 'PromoOperatorsUpdateBuyoutParams');
  }
}
