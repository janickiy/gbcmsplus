<?php

use console\components\Migration;

class m160411_140405_update_landings_operators_detault_values extends Migration
{
  public function up()
  {
    $this->alterColumn(
      \mcms\promo\models\LandingOperator::tableName(),
      'buyout_price_usd',
      'DECIMAL(10,2) NOT NULL DEFAULT 0'
    );

    $this->alterColumn(
      \mcms\promo\models\LandingOperator::tableName(),
      'buyout_price_eur',
      'DECIMAL(10,2) NOT NULL DEFAULT 0'
    );

    $this->alterColumn(
      \mcms\promo\models\LandingOperator::tableName(),
      'buyout_price_rub',
      'DECIMAL(10,2) NOT NULL DEFAULT 0'
    );
  }

  public function down()
  {
    $this->alterColumn(
      \mcms\promo\models\LandingOperator::tableName(),
      'buyout_price_usd',
      'DECIMAL(10,2) NOT NULL'
    );

    $this->alterColumn(
      \mcms\promo\models\LandingOperator::tableName(),
      'buyout_price_eur',
      'DECIMAL(10,2) NOT NULL'
    );

    $this->alterColumn(
      \mcms\promo\models\LandingOperator::tableName(),
      'buyout_price_rub',
      'DECIMAL(10,2) NOT NULL'
    );
  }

}
