<?php

use console\components\Migration;

class m180219_154647_personal_profits_remove_pk extends Migration
{
  const TABLE = 'personal_profit';

  public function up()
  {
    $this->alterColumn(self::TABLE, 'id', 'MEDIUMINT(5) UNSIGNED NOT NULL');
    $this->dropPrimaryKey('id', self::TABLE);

    // Удаляем внешние ключи (иначе не добавить ПК)
    $this->dropForeignKey('personal_profit_user_id_fk', self::TABLE);
    $this->dropForeignKey('personal_profit_operator_id_fk', self::TABLE);
    $this->dropForeignKey('personal_profit_landing_id_fk', self::TABLE);

    $this->dropIndex('personal_profit_operator_id_fk', self::TABLE);
    $this->dropIndex('personal_profit_landing_id_fk', self::TABLE);


    $this->addPrimaryKey('personal_profit_pk', self::TABLE, ['user_id', 'operator_id', 'landing_id']);

    $this->dropColumn(self::TABLE, 'id');
  }

  public function down()
  {
    // Откатывать нет смысла, т.к похерятся ПК
    return true;
  }
}
