<?php

use console\components\Migration;

class m151028_092349_landing_operators__landing_redirects__landing_unblock_requests extends Migration
{

  protected $landingOperators = '{{%landing_operators}}';
  protected $landingRedirects = '{{%landing_redirects}}';
  protected $landingUnblockRequests = '{{%landing_unblock_requests}}';

  public function safeUp()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    /*
     * LANDING OPERATORS
     */
    $this->createTable($this->landingOperators, [
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'is_hold_account' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'default_currency_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'default_currency_rebill_price' => 'DECIMAL(10, 2) NOT NULL',
      'buyout_price_usd' => 'DECIMAL(10, 2) NOT NULL',
      'buyout_price_eur' => 'DECIMAL(10, 2) NOT NULL',
      'buyout_price_rub' => 'DECIMAL(10, 2) NOT NULL',
      'rebill_price_usd' => 'DECIMAL(10, 2) NOT NULL',
      'rebill_price_eur' => 'DECIMAL(10, 2) NOT NULL',
      'rebill_price_rub' => 'DECIMAL(10, 2) NOT NULL'
    ], $tableOptions);

    $this->addPrimaryKey('landing_operators' . '_pk', $this->landingOperators, ['landing_id', 'operator_id']);
    $this->createIndex('landing_operators' . '_' . 'is_hold_account' . '_index', $this->landingOperators, 'is_hold_account');

    $this->addForeignKey('landing_operators' . '_' . 'landing_id' . '_fk', $this->landingOperators, 'landing_id', '{{%landings}}', 'id');
    $this->addForeignKey('landing_operators' . '_' . 'operator_id' . '_fk', $this->landingOperators, 'operator_id', '{{%operators}}', 'id');
    $this->addForeignKey('landing_operators' . '_' . 'default_currency_id' . '_fk', $this->landingOperators, 'default_currency_id', '{{%currencies}}', 'id');

    /*
     * LANDING REDIRECTS
     */
    $this->createTable($this->landingRedirects, [
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'redirect_to' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->addPrimaryKey('landing_redirects' . '_pk', $this->landingRedirects, ['landing_id', 'redirect_to']);

    $this->addForeignKey('landing_redirects' . '_' . 'created_by' . '_fk', $this->landingRedirects, 'created_by', '{{%users}}', 'id');
    $this->addForeignKey('landing_redirects' . '_' . 'redirect_to' . '_fk', $this->landingRedirects, 'redirect_to', '{{%landings}}', 'id');
    $this->addForeignKey('landing_redirects' . '_' . 'landing_id' . '_fk', $this->landingRedirects, 'landing_id', '{{%landings}}', 'id');

    /*
     * LANDING UNBLOCK REQUESTS
     */
    $this->createTable($this->landingUnblockRequests, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'traffic_type' => $this->text()->notNull(),
      'description' => $this->text(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex('landing_unblock_requests' . '_' . 'status' . '_index', $this->landingUnblockRequests, 'status');

    $this->addForeignKey('landing_unblock_requests' . '_' . 'landing_id' . '_fk', $this->landingUnblockRequests, 'landing_id', '{{%landings}}', 'id');
    $this->addForeignKey('landing_unblock_requests' . '_' . 'user_id' . '_fk', $this->landingUnblockRequests, 'user_id', '{{%users}}', 'id');
  }

  public function safeDown()
  {
    $this->dropTable($this->landingUnblockRequests);
    $this->dropTable($this->landingRedirects);
    $this->dropTable($this->landingOperators);
  }
}
