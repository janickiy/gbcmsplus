<?php

use console\components\Migration;

class m160115_145002_redirects extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->removePermission('PromoLandingRedirectsCreate');
    $this->removePermission('PromoLandingRedirectsDelete');
    $this->removePermission('PromoLandingRedirectsUpdate');
    $this->removePermission('PromoLandingRedirectsView');

    $this->createOrGetPermission('PromoLandingRedirectsEnable', 'Can enable landing redirects');
    $this->createOrGetPermission('PromoLandingRedirectsDisable', 'Can disable landing redirects');

    $this->assignRolesPermission('PromoLandingRedirectsEnable', ['root', 'admin']);
    $this->assignRolesPermission('PromoLandingRedirectsDisable', ['root', 'admin']);

    $this->addColumn('landing_redirects', 'description', 'varchar(512) NOT NULL AFTER redirect_to');
  }

  public function down()
  {
    $this->removePermission('PromoLandingRedirectsDisable');
    $this->removePermission('PromoLandingRedirectsDisable');
    $this->dropColumn('landing_redirects', 'description');
  }

}
