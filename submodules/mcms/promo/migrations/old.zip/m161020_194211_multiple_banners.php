<?php

use console\components\Migration;

class m161020_194211_multiple_banners extends Migration
{
  const SOURCES_TABLE = 'sources';
  const SOURCES_BANNER_FIELD_KEY = 'sources_banner_id_fk';
  const SOURCES_BANNERS_LINK_TABLE = 'sources_banners';
  const SOURCES_BANNERS_SOURCE_FIELD = 'source_id';

  const LANDING_CATEGORIES_TABLE = 'landing_categories';
  const LANDING_CATEGORIES_BANNER_FIELD_KEY = 'landing_categories_banner_id_fk';
  const LANDING_CATEGORIES_BANNERS_LINK_TABLE = 'landing_categories_banners';
  const LANDING_CATEGORIES_BANNERS_SOURCE_FIELD = 'category_id';

  public function safeUp()
  {
    $this->safeUpInternal(
      static::SOURCES_TABLE,
      static::SOURCES_BANNER_FIELD_KEY,
      static::SOURCES_BANNERS_LINK_TABLE,
      static::SOURCES_BANNERS_SOURCE_FIELD
    );
    $this->safeUpInternal(
      static::LANDING_CATEGORIES_TABLE,
      static::LANDING_CATEGORIES_BANNER_FIELD_KEY,
      static::LANDING_CATEGORIES_BANNERS_LINK_TABLE,
      static::LANDING_CATEGORIES_BANNERS_SOURCE_FIELD
    );
  }

  public function safeDown()
  {
    $this->safeDownInternal(
      static::SOURCES_TABLE,
      static::SOURCES_BANNER_FIELD_KEY,
      static::SOURCES_BANNERS_LINK_TABLE,
      static::SOURCES_BANNERS_SOURCE_FIELD
    );
    $this->safeDownInternal(
      static::LANDING_CATEGORIES_TABLE,
      static::LANDING_CATEGORIES_BANNER_FIELD_KEY,
      static::LANDING_CATEGORIES_BANNERS_LINK_TABLE,
      static::LANDING_CATEGORIES_BANNERS_SOURCE_FIELD
    );
  }

  public function safeUpInternal($entitiesTable, $entitiesBannerKey, $linkTable, $linkEntityField)
  {
    $this->createBannersLinkTable($entitiesTable, $linkTable, $linkEntityField);
    $this->migrateBannersFromFieldToTable($entitiesTable, $linkTable, $linkEntityField);
    $this->deleteOldField($entitiesTable, $entitiesBannerKey);
  }

  public function safeDownInternal($entitiesTable, $entitiesBannerKey, $linkTable, $linkEntityField)
  {
    $this->restoreOldField($entitiesTable, $entitiesBannerKey);
    $this->migrateBannersFromTableToField($entitiesTable, $linkTable, $linkEntityField);
    $this->dropBannersLinkTable($linkTable);
  }

  private function createBannersLinkTable($entitiesTable, $linkTable, $linkEntityField)
  {
    $this->createTable($linkTable, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      $linkEntityField => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'banner_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
    ]);

    $this->execute(/** @lang MySQL */
      "ALTER TABLE $linkTable
      ADD CONSTRAINT {$linkTable}_{$entitiesTable}_id_fk
      FOREIGN KEY ($linkEntityField) REFERENCES $entitiesTable (id) ON DELETE CASCADE ON UPDATE CASCADE;
      
      ALTER TABLE $linkTable
      ADD CONSTRAINT {$linkTable}_banners_id_fk
      FOREIGN KEY (banner_id) REFERENCES banners (id) ON DELETE CASCADE ON UPDATE CASCADE;");

    $this->createIndex($linkTable . '_uq', $linkTable, [$linkEntityField, 'banner_id'], true);
  }

  private function dropBannersLinkTable($linkTable)
  {
    $this->dropTable($linkTable);
  }

  private function deleteOldField($entitiesTable, $entitiesBannerKey)
  {
    $this->dropForeignKey($entitiesBannerKey, $entitiesTable);
    $this->dropIndex($entitiesBannerKey, $entitiesTable);
    $this->dropColumn($entitiesTable, 'banner_id');
  }

  private function restoreOldField($entitiesTable, $entitiesBannerKey)
  {
    $this->execute(/** @lang MySQL */
      "
      ALTER TABLE $entitiesTable ADD COLUMN banner_id MEDIUMINT(5) UNSIGNED;
      CREATE INDEX $entitiesBannerKey ON $entitiesTable (banner_id);
      ALTER TABLE $entitiesTable
        ADD CONSTRAINT $entitiesBannerKey
        FOREIGN KEY (banner_id) REFERENCES banners (id) ON DELETE SET NULL ON UPDATE CASCADE;
      ");
  }

  private function migrateBannersFromFieldToTable($entitiesTable, $linkTable, $linkEntityField)
  {
    $this->db->createCommand(/** @lang MySQL */
      "
    INSERT INTO
    $linkTable ($linkEntityField, banner_id)
      SELECT $entitiesTable.id, $entitiesTable.banner_id
      FROM $entitiesTable
      WHERE banner_id IS NOT NULL
    ")->execute();
  }

  private function migrateBannersFromTableToField($entitiesTable, $linkTable, $linkEntityField)
  {
    $this->db->createCommand(/** @lang MySQL */
      "UPDATE $entitiesTable 
        SET $entitiesTable.banner_id = (SELECT $linkTable.banner_id FROM $linkTable WHERE $linkTable.$linkEntityField = $entitiesTable.id LIMIT 1)")->execute();
  }
}
