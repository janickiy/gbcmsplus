<?php

use console\components\Migration;

class m160608_090216_domain_name_field extends Migration
{
  public function up()
  {
    $this->addColumn('domains', 'domain_name', 'varchar(255) NOT NULL');

    $domains = \mcms\promo\models\Domain::find()->asArray()->each();
    foreach ($domains as $domain) {
      \mcms\promo\models\Domain::updateAll(
        ['domain_name' => parse_url($domain['url'], PHP_URL_HOST) ? : $domain['url']],
        ['id' => $domain['id']]
      );
      echo sprintf("Domain %s processed\n", $domain['url']);
    }

//    $this->createIndex('domains_domain_name_unique', 'domains', 'domain_name', true);
  }

  public function down()
  {
//    $this->dropIndex('domains_domain_name_unique', 'domains');
    $this->dropColumn('domains', 'domain_name');
  }
}
