<?php

use console\components\Migration;

class m160224_174855_add_disable_modal_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'WebmasterSources' => [
        ['disable-modal', 'Set source status inactive', ['admin', 'root', 'reseller']],
      ]
    ];
  }
}
