<?php

use console\components\Migration;

class m170211_164630_percent_profit_admin extends Migration
{
  const RESELLER_ID = 4;

  public function up()
  {
    /** @var \mcms\promo\Module $promo */
    $promo = Yii::$app->getModule('promo');

    $promo->settings->offsetSet('settings.main_rebill_percent_for_reseller', '100');

    $this->update('personal_profit', ['rebill_percent' => 100], ['user_id' => self::RESELLER_ID]);
  }

  public function down()
  {
    echo "m170211_164630_percent_profit_admin cannot be reverted.\n";

    return true;
  }

}
