<?php

use yii\db\Schema;
use console\components\Migration;

class m160201_134423_currency_symbols extends Migration
{

  const TABLE = 'currencies';

  public function up()
  {
    $this->update(self::TABLE, ['symbol' => 'Р'], ['code' => 'rub']);
    $this->update(self::TABLE, ['symbol' => '$'], ['code' => 'usd']);
    $this->update(self::TABLE, ['symbol' => '€'], ['code' => 'eur']);
    \yii\caching\TagDependency::invalidate(Yii::$app->cache, ['currency']);
  }

  public function down()
  {
    $this->update(self::TABLE, ['symbol' => 'RUB'], ['code' => 'rub']);
    $this->update(self::TABLE, ['symbol' => 'USD'], ['code' => 'usd']);
    $this->update(self::TABLE, ['symbol' => 'EUR'], ['code' => 'eur']);
    \yii\caching\TagDependency::invalidate(Yii::$app->cache, ['currency']);
  }
}
