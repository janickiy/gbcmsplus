<?php

use console\components\Migration;

class m161213_181635_operators_view_modal extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function up()
  {
    $this->createPermission('PromoOperatorsViewModal', 'Просмотр оператора', 'PromoOperatorsController', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('PromoOperatorsViewModal');
  }
}
