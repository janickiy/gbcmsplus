<?php

use console\components\Migration;

class m161026_125313_souce_set_link extends Migration
{
    public function up()
    {
      $this->addColumn('sources', 'set_id', 'MEDIUMINT(5) UNSIGNED');
      $this->addForeignKey(
        'sources_landing_sets_fk',
        'sources',
        'set_id',
        'landing_sets',
        'id',
        'CASCADE',
        'CASCADE'
      );
    }

    public function down()
    {
      $this->dropForeignKey('sources_landing_sets_fk', 'sources');
      $this->dropColumn('sources', 'set_id');
    }
}
