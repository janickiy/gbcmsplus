<?php

use console\components\Migration;

class m151123_142317_init_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'Cities' => [
        ['index', 'Lists all City models.', ['admin', 'root']],
        ['view', 'Displays a single City model', ['admin', 'root']],
        ['create', 'Creates a new City model', ['admin', 'root']],
        ['update', 'Updates an existing City model', ['admin', 'root']],
      ],
      'Countries' => [
        ['index', 'Lists all Country models', ['admin', 'root']],
        ['view', 'Displays a single Country model', ['admin', 'root']],
        ['create', 'Creates a new Country model', ['admin', 'root']],
        ['update', 'Updates an existing Country model', ['admin', 'root']],
      ],
      'Currencies' => [
        ['index', 'Lists all Currency models', ['admin', 'root']],
        ['view', 'Displays a single Currency model', ['admin', 'root']],
        ['create', 'Creates a new Currency model', ['admin', 'root']],
        ['update', 'Updates an existing Currency model', ['admin', 'root']],
        ['delete', 'Deletes an existing Currency model', ['admin', 'root']],
      ],
      'Domains' => [
        ['index', 'Lists all Domain models', ['admin', 'root']],
        ['view', 'Displays a single Domain model', ['admin', 'root']],
        ['create', 'Creates a new Domain model', ['admin', 'root']],
        ['update', 'Updates an existing Domain model', ['admin', 'root']],
        ['findUser', 'Allows find user by search string', ['admin', 'root']],
      ],
      'InvestorPriority' => [
        ['update', 'Ajax обработка ответа из виджета [[InvestorPriorityWidget]]', ['root', 'admin']],
      ],
      'LandingCategories' => [
        ['index', 'Lists all LandingCategory models', ['admin', 'root']],
        ['view', 'Displays a single LandingCategory model', ['admin', 'root']],
        ['create', 'Creates a new LandingCategory model', ['admin', 'root']],
        ['update', 'Updates an existing LandingCategory model', ['admin', 'root']],
        ['enable', 'Enable an existing LandingCategory model', ['admin', 'root']],
        ['disable', 'Disable an existing LandingCategory model', ['admin', 'root']],
      ],
      'LandingRedirects' => [
        ['index', 'Lists all LandingRedirect models', ['admin', 'root']],
        ['view', 'Displays a single LandingRedirect model', ['admin', 'root']],
        ['create', 'Creates a new LandingRedirect model', ['admin', 'root']],
        ['update', 'Updates an existing LandingRedirect model', ['admin', 'root']],
        ['delete', 'Deletes an existing LandingRedirect model', ['admin', 'root']],
      ],
      'Landings' => [
        ['index', 'Lists all Landing models', ['admin', 'root']],
        ['view', 'Displays a single Landing model', ['admin', 'root']],
        ['create', 'Creates a new Landing model', ['admin', 'root']],
        ['update', 'Updates an existing Landing model', ['admin', 'root']],
        ['select2', 'Search landings from select2', ['admin', 'root']],
      ],
      'LandingUnblockRequests' => [
        ['index', 'Lists all LandingUnblockRequest models', ['admin', 'root']],
        ['view', 'Displays a single LandingUnblockRequest model', ['admin', 'root']],
        ['create', 'Creates a new LandingUnblockRequest model', ['admin', 'root']],
        ['update', 'Updates an existing LandingUnblockRequest model', ['admin', 'root']],
        ['findUser', 'Search users from typeahead', ['admin', 'root']],
      ],
      'Operators' => [
        ['index', 'Lists all Operator models', ['admin', 'root']],
        ['view', 'Displays a single Operator model', ['admin', 'root']],
        ['create', 'Creates a new Operator model', ['admin', 'root']],
        ['update', 'Updates an existing Operator model', ['admin', 'root']],
        ['select2', 'Search landings from select2', ['admin', 'root']],
        ['enable', 'Enable an existing Operator model', ['admin', 'root']],
        ['disable', 'Disable an existing Operator model', ['admin', 'root']],
      ],
      'PersonalProfits' => [
        ['createModal', 'Create personal profits modal', ['admin', 'root']],
        ['updateModal', 'Updates an existing PersonalProfit model', ['admin', 'root']],
        ['delete', 'Deletes an existing PersonalProfit model', ['admin', 'root']],
      ],
      'Providers' => [
        ['index', 'Lists all Provider models', ['admin', 'root']],
        ['view', 'Displays a single Provider model', ['admin', 'root']],
        ['create', 'Creates a new Provider model', ['admin', 'root']],
        ['update', 'Updates an existing Provider model', ['admin', 'root']],
        ['redirect', 'Redirect provider', ['admin', 'root']],
        ['enable', 'Enable an existing Provider model', ['admin', 'root']],
        ['disable', 'Disable an existing Provider model', ['admin', 'root']],
      ],
      'Regions' => [
        ['index', 'Lists all Region models', ['admin', 'root']],
        ['view', 'Displays a single Region model', ['admin', 'root']],
        ['create', 'Creates a new Region model', ['admin', 'root']],
        ['update', 'Updates an existing Region model', ['admin', 'root']],
      ],
      'Streams' => [
        ['index', 'Lists all Stream models', ['admin', 'root']],
        ['view', 'Displays a single Stream model', ['admin', 'root']],
        ['Update', 'Updates an existing Stream model', ['admin', 'root']],
        ['enable', 'Enable an existing Stream model', ['admin', 'root']],
        ['disable', 'Disable an existing Stream model', ['admin', 'root']],
        ['findUser', 'Find user by search string', ['admin', 'root']],
      ],
      'WebmasterSources' => [
        ['index', 'Lists all Source models', ['admin', 'root']],
        ['view', 'Displays a single Source model', ['admin', 'root']],
        ['update', 'Updates an existing Source model', ['admin', 'root']],
        ['findUser', 'Find user by search string', ['admin', 'root']],
      ]
    ];
  }


}
