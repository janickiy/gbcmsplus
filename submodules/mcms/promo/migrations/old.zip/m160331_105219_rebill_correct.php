<?php

use console\components\Migration;

class m160331_105219_rebill_correct extends Migration
{

  const CONDITIONS = 'rebill_correct_conditions';
  const REBILLS = 'subscription_rebills';
  public function up()
  {
    $this->createTable(self::CONDITIONS, [
      'id' => 'mediumint(5) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'partner_id' => 'mediumint(5) unsigned DEFAULT NULL',
      'operator_id' => 'mediumint(5) unsigned DEFAULT NULL',
      'landing_id' => 'mediumint(5) unsigned DEFAULT NULL',
      'percent' => 'decimal(5,2) NOT NULL',
      'to_source_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'created_by' => 'mediumint(5) unsigned NOT NULL',
      'created_at' => 'int(10) unsigned NOT NULL',
      'updated_at' => 'int(10) unsigned DEFAULT NULL'
    ]);

    $this->addForeignKey(self::CONDITIONS . '_partner_id_fk', self::CONDITIONS, 'partner_id', 'users', 'id');
    $this->addForeignKey(self::CONDITIONS . '_operator_id_fk', self::CONDITIONS, 'operator_id', 'operators', 'id');
    $this->addForeignKey(self::CONDITIONS . '_landing_id_fk', self::CONDITIONS, 'landing_id', 'landings', 'id');
    $this->addForeignKey(self::CONDITIONS . '_to_source_id_fk', self::CONDITIONS, 'to_source_id', 'sources', 'id');

    $this->addColumn(self::REBILLS, 'old_source_id', 'mediumint(5) unsigned COMMENT \'кому изначально пришёл ребилл (до корректировки)\' after source_id');
  }

  public function down()
  {
    $this->dropColumn(self::REBILLS, 'old_source_id');
    $this->dropTable(self::CONDITIONS);
  }
}
