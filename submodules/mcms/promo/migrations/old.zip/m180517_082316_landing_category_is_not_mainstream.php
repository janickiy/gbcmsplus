<?php

use console\components\Migration;

class m180517_082316_landing_category_is_not_mainstream extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  const TABLE = 'landing_categories';
  const COLUMN = 'is_not_mainstream';

  const PERMISSION = 'CanEditLandingCategoryIsNotMainstream';

  const ADULT_ID = 3;

  public function up()
  {
    $this->createPermission(self::PERMISSION, 'Редактирование флага is_not_mainstream в категориях лендингов', 'PromoPermissions', ['root', 'admin']);
    $this->addColumn(self::TABLE, self::COLUMN, 'TINYINT(1) UNSIGNED DEFAULT \'0\' NOT NULL');
    $this->update(self::TABLE, [self::COLUMN => 1], ['id' => self::ADULT_ID]);
  }

  public function down()
  {
    $this->removePermission(self::PERMISSION);
    $this->dropColumn(self::TABLE, self::COLUMN);
  }
}
