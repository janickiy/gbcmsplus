<?php

use console\components\Migration;

class m160818_140206_provider_ai extends Migration
{
  public function up()
  {
    $lastId = $this->db->createCommand('SELECT MAX(id) FROM providers')->queryScalar();
    if (is_null($lastId)) $lastId = 0;

    $this->db->createCommand("ALTER TABLE providers AUTO_INCREMENT = :new;")
      ->bindValue(':new', ++$lastId)
      ->execute();
  }

  public function down()
  {
    echo "m160818_140206_provider_ai cannot be reverted.\n";

    return true;
  }
}
