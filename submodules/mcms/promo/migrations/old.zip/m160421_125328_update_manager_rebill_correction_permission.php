<?php

use console\components\Migration;

class m160421_125328_update_manager_rebill_correction_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->assignRolesPermission('PromoPersonalProfitsCreateModal', ['manager']);
    $this->assignRolesPermission('PromoPersonalProfitsDelete', ['manager']);
    $this->assignRolesPermission('PromoPersonalProfitsIndex', ['manager']);
    $this->assignRolesPermission('PromoPersonalProfitsUpdateModal', ['manager']);
    $this->assignRolesPermission('PromoCanViewPersonalProfitsWidget', ['manager']);
    $this->assignRolesPermission('PromoCanViewOwnPersonalProfitsWidget', ['manager']);


  }

  public function down()
  {
    $this->revokeRolesPermission('PromoPersonalProfitsCreateModal', ['manager']);
    $this->revokeRolesPermission('PromoPersonalProfitsDelete', ['manager']);
    $this->revokeRolesPermission('PromoPersonalProfitsIndex', ['manager']);
    $this->revokeRolesPermission('PromoPersonalProfitsUpdateModal', ['manager']);
    $this->revokeRolesPermission('PromoCanViewPersonalProfitsWidget', ['manager']);
    $this->revokeRolesPermission('PromoCanViewOwnPersonalProfitsWidget', ['manager']);
  }

}
