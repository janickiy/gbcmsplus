<?php

use mcms\promo\models\Source;
use console\components\Migration;

class m160323_175254_swap_source_statuses extends Migration
{
  const TEMP_VALUE = 10;
  const OLD_STATUS_DECLINED = 3;
  const OLD_STATUS_INACTIVE = 0;

  /*
    Как сейчас:
    STATUS_INACTIVE (0) ставится, когда администратор отклоняет ссылку или источник.
    STATUS_DECLINED (3) ставится, когда партнер сам удаляет ссылку или источник.

    Чтоб не было путаницы делаем STATUS_INACTIVE - когда партнер удалил, STATUS_DECLINED - когда админ отклонил.
    Т.е. наоборот.
   */
  public function up()
  {
    // STATUS_DECLINED временно в TEMP_VALUE (те, что удалил пользователь)
    Source::updateAll(['status' => self::TEMP_VALUE], ['status' => self::OLD_STATUS_DECLINED]);

    // STATUS_INACTIVE у которых нет reject_reason в STATUS_DECLINED (ранее удалял пользователь, или админ до того как был добавлен статус)
    Source::updateAll(['status' => self::OLD_STATUS_DECLINED], [
      'and',
      ['status' => self::OLD_STATUS_INACTIVE],
      ['is', 'reject_reason', null]
    ]);

    // Те, что были STATUS_DECLINED (сейчас TEMP_VALUE) в STATUS_INACTIVE
    Source::updateAll(['status' => self::OLD_STATUS_INACTIVE], ['status' => self::TEMP_VALUE]);
  }

  public function down(){}
}
