<?php

use console\components\Migration;

class m160329_152329_init_permissions_buyout_widget extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'Can' => [
        ['view-personal-buyout-widget', 'Can view personal buyout widget', ['admin', 'root']],
        ['have-personal-buyout', 'Can have personal buyouts', ['investor']],
      ],
    ];
  }
}