<?php

use console\components\Migration;

class m160506_075125_update_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->createOrGetPermission('PromoIsUserEffectedByRebillConditionModerationFlag', 'Is user effected by rebill condition moderation flag');
    $this->assignRolesPermission('PromoIsUserEffectedByRebillConditionModerationFlag', ['reseller']);
  }

  public function down()
  {
    $this->revokeRolesPermission('PromoIsUserEffectedByRebillConditionModerationFlag', ['reseller']);
  }
}
