<?php

use console\components\Migration;

class m180116_142926_tb_provider_categories extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  const TABLE = 'trafficback_providers';

  public function up()
  {
    $this->addColumn(self::TABLE, 'category_id', 'MEDIUMINT(5) UNSIGNED DEFAULT 0 NOT NULL ');
    $this->dropColumn(self::TABLE, 'is_default');
    $this->createPermission('PromoTrafficbackProvidersDisable', 'Деактивировать провайдер ТБ', 'PromoTraffickbackProvidersController');
    $this->createPermission('PromoTrafficbackProvidersEnable', 'Активировать провайдер ТБ', 'PromoTraffickbackProvidersController');
  }

  public function down()
  {
    $this->addColumn(self::TABLE, 'is_default', 'TINYINT(1) DEFAULT 0 NOT NULL AFTER status');
    $this->dropColumn(self::TABLE, 'category_id');
    $this->removePermission('PromoTrafficbackProvidersDisable');
    $this->removePermission('PromoTrafficbackProvidersEnable');
  }
}
