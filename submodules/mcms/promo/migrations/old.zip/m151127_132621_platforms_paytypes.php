<?php

use console\components\Migration;

class m151127_132621_platforms_paytypes extends Migration
{

  protected $platforms = 'platforms';
  protected $landingPlatforms = 'landing_platforms';

  protected $forbidden = 'forbidden_traffic_types';
  protected $landingForbiddens = 'landing_forbidden_traffic_types';

  protected $payTypes = 'landing_pay_types';
  protected $landingOperatorPayTypes = 'landing_operator_pay_types';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }


    /*
     * PLATFORMS
     */
    $this->createTable($this->platforms, [
      'id' => 'TINYINT(1) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string(100)->notNull(),
      'match_string' => $this->string(100)->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);


    $this->createTable($this->landingPlatforms, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'platform_id' => 'TINYINT(1) UNSIGNED NOT NULL'
    ]);
    $this->addForeignKey($this->landingPlatforms . '_' . 'landing_id' . '_fk', $this->landingPlatforms, 'landing_id', \mcms\promo\models\Landing::tableName(), 'id');
    $this->addForeignKey($this->landingPlatforms . '_' . 'platform_id' . '_fk', $this->landingPlatforms, 'platform_id', $this->platforms, 'id');


    /*
     * FORBIDDEN TRAFFIC TYPES
     */
    $this->createTable($this->forbidden, [
      'id' => 'TINYINT(1) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string(100)->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createTable($this->landingForbiddens, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'forbidden_traffic_type_id' => 'TINYINT(1) UNSIGNED NOT NULL'
    ]);
    $this->addForeignKey($this->landingForbiddens . '_' . 'landing_id' . '_fk', $this->landingForbiddens, 'landing_id', \mcms\promo\models\Landing::tableName(), 'id');
    $this->addForeignKey($this->landingForbiddens . '_' . 'forbidden_traffic_type_id' . '_fk', $this->landingForbiddens, 'forbidden_traffic_type_id', $this->forbidden, 'id');


    /*
     * PAY TYPES
     */
    $this->createTable($this->payTypes, [
      'id' => 'TINYINT(1) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string(100)->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createTable($this->landingOperatorPayTypes, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL'
    ]);
    $this->addForeignKey($this->landingOperatorPayTypes . '_' . 'landing_id' . '_fk', $this->landingOperatorPayTypes, 'landing_id', \mcms\promo\models\Landing::tableName(), 'id');
    $this->addForeignKey($this->landingOperatorPayTypes . '_' . 'operator_id' . '_fk', $this->landingOperatorPayTypes, 'operator_id', \mcms\promo\models\Operator::tableName(), 'id');
    $this->addForeignKey($this->landingOperatorPayTypes . '_' . 'landing_pay_types' . '_fk', $this->landingOperatorPayTypes, 'landing_pay_type_id', $this->payTypes, 'id');
  }

  public function down()
  {
    $this->dropTable($this->landingOperatorPayTypes);
    $this->dropTable($this->payTypes);
    $this->dropTable($this->landingForbiddens);
    $this->dropTable($this->forbidden);
    $this->dropTable($this->landingPlatforms);
    $this->dropTable($this->platforms);
  }
}
