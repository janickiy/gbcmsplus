<?php

use console\components\Migration;

class m160524_144154_banner_permissions extends Migration
{

  use \mcms\common\traits\PermissionGroupMigration;

  public function init()
  {
    parent::init();

    $this->groupPermissionName = 'PromoModule';
    $this->groupPermissionDescription = 'Module Promo';
    $this->groupPermissionDefaultRole = ['admin', 'root'];

    $this->groupPermissionControllers = [
      'PromoBannerTemplatesController' => [
        'description' => 'Promo banner templates Controller',
        'permissions' => [
          ['PromoBannerTemplatesIndex'],
          ['PromoBannerTemplatesCreate'],
          ['PromoBannerTemplatesDelete'],
          ['PromoBannerTemplatesAttributeModal'],
          ['PromoBannerTemplatesAttributeDelete'],
        ]
      ],
      'PromoBannersController' => [
        'description' => 'Promo banners Controller',
        'roles' => ['reseller'],
        'permissions' => [
          ['PromoBannersIndex'],
          ['PromoBannersUpdate'],
          ['PromoBannersCreate'],
          ['PromoBannersEnable'],
          ['PromoBannersDisable'],
          ['PromoBannersView'],
          ['PromoBannersFormPreview'],
        ]
      ]
    ];
  }


}
