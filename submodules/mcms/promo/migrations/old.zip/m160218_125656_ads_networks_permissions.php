<?php

use yii\db\Schema;
use console\components\Migration;

class m160218_125656_ads_networks_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'AdsNetworks' => [
        ['index', 'Lists all AdsNetwork models.', ['admin', 'root']],
        ['view', 'Displays a single AdsNetwork model', ['admin', 'root']],
        ['viewModal', 'Displays a single AdsNetwork model in modal window', ['admin', 'root']],
        ['create', 'Creates a new AdsNetwork model', ['admin', 'root']],
        ['update', 'Updates an existing AdsNetwork model', ['admin', 'root']],
        ['enable', 'Enable an existing AdsNetwork model', ['admin', 'root']],
        ['disable', 'Disable an existing AdsNetwork model', ['admin', 'root']],
      ],
    ];
  }


}
