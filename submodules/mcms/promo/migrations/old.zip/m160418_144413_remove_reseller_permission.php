<?php

use console\components\Migration;

class m160418_144413_remove_reseller_permission extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->revokeRolesPermission('PromoCanViewPersonalProfitsWidget', ['reseller']);
  }

  public function down()
  {
    $this->assignRolesPermission('PromoCanViewPersonalProfitsWidget', ['reseller']);
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
