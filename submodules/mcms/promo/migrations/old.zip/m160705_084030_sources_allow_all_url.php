<?php

use console\components\Migration;

class m160705_084030_sources_allow_all_url extends Migration
{
  const TABLE = 'sources';

  public function up()
  {
    $this->addColumn(self::TABLE, 'allow_all_url', 'TINYINT(1) NOT NULL DEFAULT 0 AFTER url');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'allow_all_url');
  }
}
