<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m170119_160435_remove_add_traffic_types extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->removePermission('PromoTrafficTypesCreate');
  }

  public function down()
  {
    $this->createPermission(
      'PromoTrafficTypesCreate',
      'Создание типа трафика',
      'PromoTrafficTypesController',
      ['admin', 'root', 'reseller']
    );
  }
}
