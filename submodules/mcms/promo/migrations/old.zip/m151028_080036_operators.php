<?php

use console\components\Migration;

class m151028_080036_operators extends Migration
{
  protected $operatorsTable = '{{%operators}}';
  protected $operatorIpsTable = '{{%operator_ips}}';

  public function safeUp()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    /*
     * OPERATORS
     */
    $this->createTable($this->operatorsTable, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'name' => $this->string(50)->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex('operators_status_index', $this->operatorsTable, 'status');
    $this->addForeignKey('operators_country_id_fk', $this->operatorsTable, 'country_id', '{{%countries}}', 'id');
    $this->addForeignKey('operators_created_by_fk', $this->operatorsTable, 'created_by', '{{%users}}', 'id');

    /*
     * OPERATOR_IPS
     */
    $this->createTable($this->operatorIpsTable, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'ip' => 'INT(10) UNSIGNED NOT NULL',
      'mask' => 'TINYINT(1) UNSIGNED',
    ], $tableOptions);
    $this->addForeignKey('operator_ips_operator_id_fk', $this->operatorIpsTable, 'operator_id', $this->operatorsTable, 'id');
  }

  public function safeDown()
  {
    $this->dropTable($this->operatorIpsTable);
    $this->dropTable($this->operatorsTable);
  }
}
