<?php

use console\components\Migration;

class m160718_104913_drop_stream_unique extends Migration
{
  public function up()
  {
    $this->dropIndex('streams_name_user_id_index', 'streams');
  }

  public function down()
  {
    $this->createIndex('streams_name_user_id_index', 'streams', ['name', 'user_id'], true);
  }
}
