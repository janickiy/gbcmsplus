<?php

use console\components\Migration;

class m160727_114959_sum_fix extends Migration
{
  public function up()
  {
    $this->db->createCommand("
      UPDATE sources SET postback_url = REPLACE(postback_url, '∑', '&sum');
      UPDATE sources SET trafficback_url = REPLACE(trafficback_url, '∑', '&sum');
    ")->execute();
  }

  public function down()
  {
    echo "m160727_114959_sum_fix cannot be reverted.\n";

    return true;
  }

}
