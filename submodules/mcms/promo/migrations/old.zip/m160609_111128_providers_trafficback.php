<?php

use console\components\Migration;

class m160609_111128_providers_trafficback extends Migration
{
  protected $table = '{{%trafficback_providers}}';

  public function safeUp()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable($this->table, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string(100)->notNull(),
      'url' => $this->string()->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_default' => 'TINYINT(1) NOT NULL DEFAULT 0',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex('trafficback_providers_status_index', $this->table, 'status');
    $this->addForeignKey('trafficback_providers_created_by_fk', $this->table, 'created_by', '{{%users}}', 'id');
  }

  public function safeDown()
  {
    $this->dropTable($this->table);
  }


}
