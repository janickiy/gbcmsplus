<?php

use yii\db\Schema;
use console\components\Migration;

class m160222_111947_operator_preland extends Migration
{
  const TABLE = 'sources';

  public function up()
  {
    $this->addColumn(self::TABLE, 'add_operator_preland', 'TEXT DEFAULT NULL');
    $this->addColumn(self::TABLE, 'off_operator_preland', 'TEXT DEFAULT NULL');

  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'add_operator_preland');
    $this->dropColumn(self::TABLE, 'off_operator_preland');
  }

}
