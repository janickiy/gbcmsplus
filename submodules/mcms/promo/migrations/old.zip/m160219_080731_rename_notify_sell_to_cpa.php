<?php

use yii\db\Schema;
use console\components\Migration;

class m160219_080731_rename_notify_sell_to_cpa extends Migration
{
  protected $sourcesTable = 'sources';

  public function up()
  {
    $this->renameColumn($this->sourcesTable, 'is_notify_sell', 'is_notify_cpa');
  }

  public function down()
  {
    $this->renameColumn($this->sourcesTable, 'is_notify_cpa', 'is_notify_sell');
  }

}
