<?php

use mcms\notifications\models\Notification;
use console\components\Migration;

class m160718_130131_update_notifications extends Migration
{
  const NOTIFICATION_TYPE_BROWSER = 1;
  const NOTIFICATION_TYPE_EMAIL = 2;
  
  public function up()
  {

    $moduleApiResult = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => 'promo'])
      ->getResult();
    $modulePromoId = $moduleApiResult->id;

    $notifications = [
      [
        'event' => 'mcms\promo\components\events\LandingListCreated',
        'data' => [
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'type' => self::NOTIFICATION_TYPE_EMAIL,
          'use_owner' => 0,
          'roles' => ['partner', 'reseller']
        ]
      ],
      [
        'event' => 'mcms\promo\components\events\LandingListCreated',
        'data' => [
          'type' => self::NOTIFICATION_TYPE_BROWSER,
          'use_owner' => 0,
          'roles' => ['partner', 'reseller']
        ]
      ],
      [
        'event' => 'mcms\promo\components\events\LandingCreated',
        'data' => [
          'from' => [
            'ru' => '{noreply_email}',
            'en' => '{noreply_email}',
          ],
          'type' => self::NOTIFICATION_TYPE_EMAIL,
          'use_owner' => 0,
          'roles' => ['partner', 'reseller']
        ]
      ],
      [
        'event' => 'mcms\promo\components\events\LandingCreated',
        'data' => [
          'type' => self::NOTIFICATION_TYPE_BROWSER,
          'use_owner' => 0,
          'roles' => ['partner', 'reseller']
        ]
      ],
    ];

    foreach ($notifications as $notification) {

      $notificationData = \yii\helpers\ArrayHelper::getValue($notification, 'data', []);
      $notificationType = \yii\helpers\ArrayHelper::getValue($notificationData, 'type');
      $notificationModel = $notification['event'] ? Notification::findOne([
        'event' => $notification['event'],
        'notification_type' => $notificationType,
      ]) : null;

      if (!$notificationModel) {
        $notificationModel = new Notification();
      }

      $notificationModel->setAttributes($notificationData, false);
      $notificationModel->event = $notification['event'];
      $notificationModel->notification_type = $notificationType;
      $notificationModel->use_owner = \yii\helpers\ArrayHelper::getValue($notificationData, 'use_owner', 0);
      $notificationModel->roles = \yii\helpers\ArrayHelper::getValue($notificationData, 'roles');
      $notificationModel->module_id = $modulePromoId;
      $notificationModel->save();
    }
  }

  public function down()
  {
    echo "m160630_091939_add_reseller cannot be reverted.\n";
  }
}
