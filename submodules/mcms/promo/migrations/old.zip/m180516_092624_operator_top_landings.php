<?php

use console\components\Migration;

class m180516_092624_operator_top_landings extends Migration
{
  const TABLE = 'operator_top_landings';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::TABLE, [
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'category_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'rating' => 'DECIMAL(9,5) UNSIGNED NOT NULL DEFAULT \'0\'',
    ], $tableOptions);

    $this->addPrimaryKey('operator_top_landings_pk', self::TABLE, ['operator_id', 'category_id']);
  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }

}
