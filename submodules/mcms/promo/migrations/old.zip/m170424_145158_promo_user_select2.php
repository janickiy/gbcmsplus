<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;
use yii\helpers\ArrayHelper;

class m170424_145158_promo_user_select2 extends Migration
{
  use PermissionTrait;

  public function up()
  {
    // Получение ролей, которым назначено разрешение на PromoPartnerProgramsLinkPartner
    // Аналогичному списку ролей назначаем PromoPartnerProgramsGetUsersByPartnerProgram
    $roles = array_map(function ($value) {
      return $value['parent'];
    }, Yii::$app->db->createCommand('
            SELECT parent 
            FROM auth_item_child aic INNER JOIN auth_item ON auth_item.name = aic.parent
            WHERE child = "PromoPartnerProgramsLinkPartner" AND auth_item.type = 1
      ')->queryAll());

    $this->createPermission('PromoPartnerProgramsGetUsersByPartnerProgram', 'Получение списка пользователей для ПП', 'PromoPartnerProgramsController', $roles);
  }

  public function down()
  {
    $this->removePermission('PromoPartnerProgramsGetUsersByPartnerProgram');
  }
}
