<?php

use console\components\Migration;

class m151217_081027_update_reseller_permissions extends Migration
{
  protected $authManager;
  protected $resellerRole;

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    $this->resellerRole = $this->authManager->getRole('reseller');
  }

  public function up()
  {
    $this->revoke('PromoLandingsUpdate');
    $this->revoke('PromoLandingsCreate');
  }

  public function down()
  {
    $this->assign('PromoLandingsUpdate');
    $this->assign('PromoLandingsCreate');
  }

  protected function revoke($name)
  {
    $permission = $this->authManager->getPermission($name);
    if ($permission && $this->authManager->hasChild($this->resellerRole, $permission)) {
      $this->authManager->removeChild($this->resellerRole, $permission);
    }
  }

  protected function assign($name)
  {
    $permission = $this->authManager->getPermission($name);
    if ($permission && !$this->authManager->hasChild($this->resellerRole, $permission)) {
      $this->authManager->addChild($this->resellerRole, $permission);
    }
  }

}
