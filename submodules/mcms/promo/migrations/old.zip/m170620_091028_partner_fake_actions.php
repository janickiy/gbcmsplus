<?php

use console\components\Migration;

class m170620_091028_partner_fake_actions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission(
      'UserFakeSettingsController',
      'Контроллер настроек для фейков',
      'PromoModule'
    );

    $this->createPermission(
      'PromoUserFakeSettingsUpdate',
      'Редактирование настроек для фейков',
      'UserFakeSettingsController',
      ['root', 'admin']
    );

    $this->createPermission(
      'PromoCanEditIndividualFakeSettings',
      'Разрешение редактировать индивидуальные параметры фейков',
      'PromoPermissions',
      ['root', 'admin', 'reseller']
    );


  }

  public function down()
  {
    $this->removePermission('PromoUserFakeSettingsUpdate');
    $this->removePermission('UserFakeSettingsController');
    $this->removePermission('PromoCanEditIndividualFakeSettings');
  }
}
