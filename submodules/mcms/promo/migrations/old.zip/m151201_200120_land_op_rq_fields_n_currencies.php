<?php

use console\components\Migration;

class m151201_200120_land_op_rq_fields_n_currencies extends Migration
{

  const LAND_OPER = 'landing_operators';
  const CURRENCIES = 'currencies';

  private $currencies = [
    ['id' => 1, 'name' => 'Рубли', 'code' => 'rub', 'symbol' => 'RUB'],
    ['id' => 2, 'name' => 'Доллары', 'code' => 'usd', 'symbol' => 'USD'],
    ['id' => 3, 'name' => 'Евро', 'code' => 'eur', 'symbol' => 'EUR']
  ];

  public function safeUp()
  {
    $this->alterColumn(self::LAND_OPER, 'rebill_price_usd', 'DECIMAL(10, 2)');
    $this->alterColumn(self::LAND_OPER, 'rebill_price_eur', 'DECIMAL(10, 2)');
    $this->alterColumn(self::LAND_OPER, 'rebill_price_rub', 'DECIMAL(10, 2)');

    $this->addColumn(self::CURRENCIES, 'is_fixed', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');

    $this->createIndex(self::CURRENCIES . '_' . 'is_fixed' . '_index', self::CURRENCIES, 'is_fixed');

    foreach ($this->currencies as $currency) {
      $model = \mcms\promo\models\Currency::findOne($currency['id']);

      if ($model) {
        $currency = array_merge($currency, ['created_by' => 1, 'is_fixed' => 1]);
        $this->update(self::CURRENCIES, $currency, ['id' => $currency['id']]);
        continue;
      }

      $currency = array_merge($currency, ['created_by' => 1, 'created_at' => time(), 'is_fixed' => 1]);
      $this->insert(self::CURRENCIES, $currency);
    }
  }

  public function safeDown()
  {
    $this->alterColumn(self::LAND_OPER, 'rebill_price_usd', 'DECIMAL(10, 2) NOT NULL');
    $this->alterColumn(self::LAND_OPER, 'rebill_price_eur', 'DECIMAL(10, 2) NOT NULL');
    $this->alterColumn(self::LAND_OPER, 'rebill_price_rub', 'DECIMAL(10, 2) NOT NULL');
  }
}
