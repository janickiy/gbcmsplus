<?php

use console\components\Migration;
use mcms\promo\models\LandingCategory;

class m160225_083740_landing_categories_translation extends Migration
{

  const TABLE = 'landing_categories';

  public $categories = [
    ['id' => 1, 'name' => ['ru' => 'Музыка', 'en' => 'Music']],
    ['id' => 2, 'name' => ['ru' => 'Кино', 'en' => 'Movies']],
    ['id' => 3, 'name' => ['ru' => 'Эротика', 'en' => 'Erotic']],
    ['id' => 4, 'name' => ['ru' => 'Файлообменники', 'en' => 'Fileshare']],
    ['id' => 5, 'name' => ['ru' => 'Знакомства', 'en' => 'Dating']],
    ['id' => 6, 'name' => ['ru' => 'Игры', 'en' => 'Games']],
    ['id' => 7, 'name' => ['ru' => 'Общие', 'en' => 'Common']],
    ['id' => 8, 'name' => ['ru' => 'Новости', 'en' => 'News']],
    ['id' => 9, 'name' => ['ru' => 'Рецепты', 'en' => 'Receipts']],
    ['id' => 10, 'name' => ['ru' => 'Мужской журнал', 'en' => 'Men\'s magazine']],
    ['id' => 11, 'name' => ['ru' => 'Гороскоп', 'en' => 'Horoscope']],
    ['id' => 12, 'name' => ['ru' => 'Сонник', 'en' => 'Book of dream interpretations']],
    ['id' => 13, 'name' => ['ru' => 'Женский журнал', 'en' => 'Women\'s magazine']],
  ];

  public function safeUp()
  {
    $this->alterColumn(self::TABLE, 'name', $this->string(150));
    foreach ($this->categories as $category) {

      $this->db->createCommand('
        INSERT INTO landing_categories (`id`, `name`, `created_by`, `status`, `created_at`, `updated_at`)
        VALUES (:id, :name, 1, 1, :now, :now) ON DUPLICATE KEY UPDATE `name` = VALUES(`name`)
      ')
        ->bindValue(':id', $category['id'])
        ->bindValue(':name', serialize($category['name']))
        ->bindValue(':now', time())
        ->execute();
    }
  }

  public function safeDown()
  {
    $this->alterColumn(self::TABLE, 'name', $this->string(50));
  }

}
