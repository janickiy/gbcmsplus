<?php

use console\components\Migration;

class m160610_101916_update_promo_permission extends Migration
{

  use \mcms\common\traits\PermissionGroupMigration;

  public function init()
  {
    parent::init();

    $this->groupPermissionName = 'PromoModule';
    $this->groupPermissionDescription = 'Module Promo';
    $this->groupPermissionDefaultRole = ['admin', 'root'];

    $this->groupPermissionControllers = [
      'TraffickbackProvidersController' => [
        'description' => 'Trafficback providers Controller',
        'roles' => ['admin', 'root'],
        'permissions' => [
          ['PromoTrafficbackProvidersCreate'],
          ['PromoTrafficbackProvidersIndex'],
          ['PromoTrafficbackProvidersUpdate'],
        ]
      ],
    ];
  }
}
