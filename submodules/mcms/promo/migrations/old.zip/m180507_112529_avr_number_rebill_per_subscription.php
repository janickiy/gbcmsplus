<?php

use rgk\settings\models\Setting;
use console\components\Migration;

class m180507_112529_avr_number_rebill_per_subscription extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  const SETTING = 'settings.avr_number_rebill_per_subscription';
  const PERMISSION = 'EditAvrNumberRebillPerSubscription';

  public function up()
  {
    $this->createPermission(self::PERMISSION, 'Разрешение на редактирование настройки "Среднее количество ребиллов на подписку"', 'PromoPermissions', ['root', 'admin', 'reseller']);

    $title = ['ru' => 'Среднее количество ребиллов на подписку', 'en' => 'Average number of rebills per subscription'];
    $description = ['ru' => 'Влияет на вычисление начальной цены выкупа новых лендов', 'en' => 'Affects the calculation of the initial price for the purchase of new lands'];
    $permissions = [self::PERMISSION];
    $category = 'app.common.group_buyouts_rebills';
    $validators = [["required"],["integer"]];
    Yii::$app->settingsBuilder->createSetting($title, $description, self::SETTING, $permissions, Setting::TYPE_INTEGER, $category, 5, $validators);
  }

  public function down()
  {
    $this->removePermission(self::PERMISSION);
    Yii::$app->settingsBuilder->removeSetting(self::SETTING);
  }
}
