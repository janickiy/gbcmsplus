<?php

use console\components\Migration;

class m170621_085731_add_currencies_to_personal_profits extends Migration
{
    public function up()
    {
      // добавляем cpa_profit по валютам
      $this->addColumn('personal_profit', 'cpa_profit_rub', 'DECIMAL(5,2) NULL DEFAULT NULL AFTER cpa_profit');
      $this->addColumn('personal_profit', 'cpa_profit_usd', 'DECIMAL(5,2) NULL DEFAULT NULL AFTER cpa_profit_rub');
      $this->addColumn('personal_profit', 'cpa_profit_eur', 'DECIMAL(5,2) NULL DEFAULT NULL AFTER cpa_profit_usd');

      // переносим данные из cpa_profit в соответствующие валюты

      $this->db->createCommand('
        UPDATE personal_profit p
        LEFT JOIN user_payment_settings s
          ON p.user_id = s.user_id
        SET p.cpa_profit_rub = IF(s.currency = "rub", p.cpa_profit, NULL),
            p.cpa_profit_usd = IF(s.currency = "usd", p.cpa_profit, NULL),
            p.cpa_profit_eur = IF(s.currency = "eur", p.cpa_profit, NULL);
        
      ')->execute();

      // удаляем поле cpa_profit (пока просто переименованием)
      $this->renameColumn('personal_profit', 'cpa_profit', '_cpa_profit');
    }

    public function down()
    {
      $this->renameColumn('personal_profit', '_cpa_profit', 'cpa_profit');

      $this->dropColumn('personal_profit', 'cpa_profit_rub');
      $this->dropColumn('personal_profit', 'cpa_profit_usd');
      $this->dropColumn('personal_profit', 'cpa_profit_eur');
    }
}
