<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170516_105014_enable_static_pages_config_setting extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission(
      'PromoCanEditStaticPagesConfig',
      'Разрешить указывать конфиг для статических страниц в микросервисе',
      'PromoPermissions',
      ['root', 'admin']
    );
  }

  public function down()
  {
    $this->removePermission(
      'PromoCanEditStaticPagesConfig'
    );
  }
}
