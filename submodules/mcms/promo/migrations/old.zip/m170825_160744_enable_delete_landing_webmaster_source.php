<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170825_160744_enable_delete_landing_webmaster_source extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission(
      'PromoWebmasterSourcesDeleteLanding',
      'Удаление лендинга из источника вебмастера',
      'PromoWebmasterSourcesController',
      ['admin', 'reseller', 'root']
    );
  }

  public function down()
  {
    $this->removePermission('PromoWebmasterSourcesDeleteLanding');
  }
}
