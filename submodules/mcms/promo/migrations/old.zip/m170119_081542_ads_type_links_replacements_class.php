<?php

use console\components\Migration;

class m170119_081542_ads_type_links_replacements_class extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function up()
  {
    $this->addColumn('sources', 'replace_links_css_class', $this->string(32));
//    $this->addColumn('sources', 'replace_links_percent', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');

    $this->createPermission('PromoCanEditLinksReplacementClass',
      'Редактирование CSS класса замены ссылок в типе рекламы "замена ссылок"',
      'PromoSettings',
      ['admin', 'root', 'reseller']
    );
  }

  public function down()
  {
    $this->dropColumn('sources', 'replace_links_css_class');
//    $this->dropColumn('sources', 'replace_links_percent');
    $this->removePermission('PromoCanEditLinksReplacementClass');
  }
}
