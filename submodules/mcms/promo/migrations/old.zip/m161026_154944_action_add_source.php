<?php

use console\components\Migration;

class m161026_154944_action_add_source extends Migration
{
  use \mcms\common\traits\PermissionMigration;
  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->moduleName = 'Promo';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'LandingSets' => [
        ['link-source', 'Can link sources', ['admin', 'root', 'reseller']],
        ['unlink-source', 'Can unlink sources', ['admin', 'root', 'reseller']],
      ],
    ];
  }
}
