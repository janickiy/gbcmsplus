<?php

use console\components\Migration;

class m151207_132606_landing_redirects_activity_column extends Migration
{

  protected $landingRedirects = '{{%landing_redirects}}';

  public function safeUp()
  {
    $this->addColumn($this->landingRedirects, 'status', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
    $this->createIndex('landing_redirects_status_index', $this->landingRedirects, 'status');
  }

  public function safeDown()
  {
    $this->dropColumn($this->landingRedirects, 'status');
  }
}