<?php

use console\components\Migration;

class m151208_121311_new_permissions extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'Currencies' => [
        ['createModal', 'Create a Currency model in modal window', ['admin', 'root']],
        ['updateModal', 'Updates an existing Currency model in modal window', ['admin', 'root']],
        ['viewModal', 'View an existing Currency model in modal window', ['admin', 'root']],
      ],
      'Domains' => [
        ['createModal', 'Create a Domain model in modal window', ['admin', 'root']],
        ['updateModal', 'Updates an existing Domain model in modal window', ['admin', 'root']],
        ['viewModal', 'View an existing Domain model in modal window', ['admin', 'root']],
      ],
      'LandingCategories' => [
        ['createModal', 'Create a LandingCategory model in modal window', ['admin', 'root']],
        ['updateModal', 'Updates an existing LandingCategory model in modal window', ['admin', 'root']],
        ['viewModal', 'View an existing LandingCategory model in modal window', ['admin', 'root']],
      ],
      'LandingUnblockRequests' => [
        ['createModal', 'Create a LandingUnblockRequest model in modal window', ['admin', 'root']],
        ['updateModal', 'Updates an existing LandingUnblockRequest model in modal window', ['admin', 'root', 'reseller']],
        ['viewModal', 'View an existing LandingUnblockRequest model in modal window', ['admin', 'root', 'reseller']],
      ],
      'LandingRedirects' => [
        ['createModal', 'Create a LandingRedirect model in modal window', ['admin', 'root']],
        ['updateModal', 'Updates an existing LandingRedirect model in modal window', ['admin', 'root']],
        ['viewModal', 'View an existing LandingRedirect model in modal window', ['admin', 'root']],
      ],
      'Streams' => [
        ['createModal', 'Create a Stream model in modal window', ['admin', 'root']],
        ['updateModal', 'Updates an existing Stream model in modal window', ['admin', 'root']],
        ['viewModal', 'View an existing Stream model in modal window', ['admin', 'root']],
      ]
    ];
  }
}
