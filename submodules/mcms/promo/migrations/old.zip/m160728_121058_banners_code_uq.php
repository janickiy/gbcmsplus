<?php

use console\components\Migration;

class m160728_121058_banners_code_uq extends Migration
{
  public function up()
  {
    $dups = $this->db->createCommand("
      SELECT a.id, a.code, IF(a.id < b.id AND a.code = 'default', 1, 0) AS ignored
      FROM banners a
        INNER JOIN banners b ON a.code = b.code AND a.template_id = b.template_id
      WHERE a.id <> b.id
      ")
      ->queryAll();

    if (empty($dups)) return true;

    foreach ($dups as $banner) {
      if ($banner['ignored']) continue;
      $this->update('banners', ['code' => Yii::$app->security->generateRandomString()], ['id' => $banner['id']]);
    }

    \mcms\promo\components\ApiHandlersHelper::generateBannerByTemplate();

    return true;
  }

  public function down()
  {
    echo "m160728_121058_banners_code_uq cannot be reverted.\n";

    return true;
  }

}
