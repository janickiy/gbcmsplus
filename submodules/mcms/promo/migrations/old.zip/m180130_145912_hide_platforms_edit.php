<?php

use console\components\Migration;

class m180130_145912_hide_platforms_edit extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->revokeRolesPermission('PromoPlatformsCreateModal', ['root', 'admin']);
    $this->revokeRolesPermission('PromoPlatformsUpdateModal', ['root', 'admin']);
  }

  public function down()
  {
    $this->assignRolesPermission('PromoPlatformsCreateModal', ['root', 'admin']);
    $this->assignRolesPermission('PromoPlatformsUpdateModal', ['root', 'admin']);
  }
}
