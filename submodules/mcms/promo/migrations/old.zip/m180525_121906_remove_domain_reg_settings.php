<?php


use console\components\Migration;
use rgk\settings\models\Setting;

class m180525_121906_remove_domain_reg_settings extends Migration
{
  const SETTINGS_DOMAIN_PRICE_USD = 'settings.domain_price_usd';
  const SETTINGS_DOMAIN_API_CLASS = 'settings.domain_api_class';

  const SETTINGS_DOMAIN_INTERNET_BS_API_KEY = 'settings.domain_internet_bs_api_key';
  const SETTINGS_DOMAIN_INTERNET_BS_API_PASSWORD = 'settings.domain_internet_bs_api_password';
  const SETTINGS_DOMAIN_CLONE = 'settings.domain_clone';

  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
  }


  public function up()
  {
    $this->settingsBuilder->removeSetting(self::SETTINGS_DOMAIN_PRICE_USD);
    $this->settingsBuilder->removeSetting(self::SETTINGS_DOMAIN_API_CLASS);
    $this->settingsBuilder->removeSetting(self::SETTINGS_DOMAIN_INTERNET_BS_API_KEY);
    $this->settingsBuilder->removeSetting(self::SETTINGS_DOMAIN_INTERNET_BS_API_PASSWORD);
    $this->settingsBuilder->removeSetting(self::SETTINGS_DOMAIN_CLONE);
  }

  public function down()
  {
    $title = ['ru' => '[ДОМЕНЫ] Стоимость, доллары', 'en' => '[DOMAINS] Price, USD'];
    $permissions = ['EditModuleSettingsPromo'];
    $category = 'app.common.form_group_domain_registration';
    $validators = [["required"],["double"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTINGS_DOMAIN_PRICE_USD, $permissions, Setting::TYPE_FLOAT, $category, '8', $validators, 1);

    $title = ['ru' => '[ДОМЕНЫ] АПИ, используемое для регистрации доменов', 'en' => '[DOMAINS] Api for domain registration'];
    $description = ['ru' => '<a href="https://internetbs.net/ResellerRegistrarDomainNameAPI/">InternetBs</a>', 'en' => 'href="https://internetbs.net/ResellerRegistrarDomainNameAPI/">InternetBs</a>'];
    $permissions = ['EditModuleSettingsPromo'];
    $category = 'app.common.form_group_domain_registration';
    $validators = [["required"]];
    $this->settingsBuilder->createSetting($title, $description, self::SETTINGS_DOMAIN_API_CLASS, $permissions, Setting::TYPE_FLOAT, $category, 'InternetBs', $validators, 2);

    $title = ['ru' => '[ДОМЕНЫ] Api ключ для InternetBs', 'en' => '[DOMAINS] Api key for InternetBs'];
    $permissions = ['EditModuleSettingsPromo'];
    $category = 'app.common.form_group_domain_registration';
    $validators = [["required"],["string"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTINGS_DOMAIN_INTERNET_BS_API_KEY, $permissions, Setting::TYPE_FLOAT, $category, '', $validators, 3);

    $title = ['ru' => '[ДОМЕНЫ] Api пароль для InternetBs', 'en' => '[DOMAINS] Api password for InternetBs'];
    $permissions = ['EditModuleSettingsPromo'];
    $category = 'app.common.form_group_domain_registration';
    $validators = [["required"],["string"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTINGS_DOMAIN_INTERNET_BS_API_PASSWORD, $permissions, Setting::TYPE_FLOAT, $category, '', $validators, 4);

    $title = ['ru' => '[ДОМЕНЫ] контакты клонировать из домена:', 'en' => '[ДОМЕНЫ] контакты клонировать из домена:'];
    $permissions = ['EditModuleSettingsPromo'];
    $category = 'app.common.form_group_domain_registration';
    $validators = [["required"],["string"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTINGS_DOMAIN_CLONE, $permissions, Setting::TYPE_FLOAT, $category, '', $validators, 5);
  }

}
