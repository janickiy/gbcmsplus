<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
 * TODO: Тесты
*/
class m181018_111023_buyout_conditions extends Migration
{
  const TABLE = 'buyout_conditions';
  const TABLE_OPERATORS = 'operators';

  use PermissionTrait;
  /**
  */
  public function up()
  {
    $this->createPermission('PromoBuyoutConditionsController', 'Контроллер условий выкупа', 'PromoModule', ['admin', 'root', 'reseller']);

    $this->createPermission('PromoBuyoutConditionsIndex', 'Список условий выкупа', 'PromoBuyoutConditionsController');

    $this->createPermission('PromoBuyoutConditionsUpdateModal', 'Редактирование условия выкупа', 'PromoBuyoutConditionsController');

    $this->createPermission('PromoBuyoutConditionsCreate', 'Создание условия выкупа', 'PromoBuyoutConditionsController');

    $this->createPermission('PromoBuyoutConditionsDelete', 'Удаление условия выкупа', 'PromoBuyoutConditionsController');

    $this->createTable(self::TABLE, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string()->notNull(),
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'type' => 'TINYINT(1) UNSIGNED NOT NULL',
      'buyout_minutes' => 'MEDIUMINT(5) UNSIGNED',
      'is_buyout_only_after_1st_rebill' => 'TINYINT(1) UNSIGNED',
      'is_buyout_only_unique_phone' => 'TINYINT(1) UNSIGNED',
      'created_by' => 'MEDIUMINT(5) UNSIGNED',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ]);

    $this->createIndex(self::TABLE . '_unique', self::TABLE, ['operator_id', 'user_id', 'type'], true);

    // Переносим условия из операторов

    $operators = (new \yii\db\Query())
      ->select(['id', 'name', 'buyout_minutes', 'is_buyout_only_after_1st_rebill', 'is_buyout_only_unique_phone'])
      ->from(self::TABLE_OPERATORS)
      ->where([
        'OR',
        ['IS NOT', 'buyout_minutes', null],
        ['IS NOT', 'is_buyout_only_after_1st_rebill', null],
        ['IS NOT', 'is_buyout_only_unique_phone', null],
      ])->all();


    foreach($operators as $operator){

      if ($operator['buyout_minutes'] !== null) {
        $this->insert(self::TABLE, [
          'name' => '#' . $operator['id']. ' - ' . $operator['name']. ' condition buyout minutes',
          'operator_id' => $operator['id'],
          'type' => 1,
          'buyout_minutes' => $operator['buyout_minutes'],
          'created_by' => 1,
          'created_at' => time()
        ]);
      }
      if ($operator['is_buyout_only_after_1st_rebill'] !== null) {
        $this->insert(self::TABLE, [
          'name' => '#' . $operator['id']. ' - ' . $operator['name']. ' condition is buyout only after 1st rebill',
          'operator_id' => $operator['id'],
          'type' => 2,
          'is_buyout_only_after_1st_rebill' => $operator['is_buyout_only_after_1st_rebill'],
          'created_by' => 1,
          'created_at' => time()
        ]);
      }
      if ($operator['is_buyout_only_unique_phone'] !== null) {
        $this->insert(self::TABLE, [
          'name' => '#' . $operator['id']. ' - ' . $operator['name']. ' condition is buyout only unique phone',
          'operator_id' => $operator['id'],
          'type' => 3,
          'is_buyout_only_unique_phone' => $operator['is_buyout_only_unique_phone'],
          'created_by' => 1,
          'created_at' => time()
        ]);
      }
    }

    $this->dropColumn(self::TABLE_OPERATORS, 'buyout_minutes');
    $this->dropColumn(self::TABLE_OPERATORS, 'is_buyout_only_after_1st_rebill');
    $this->dropColumn(self::TABLE_OPERATORS, 'is_buyout_only_unique_phone');

  }

  /**
  */
  public function down()
  {
    $this->addColumn(self::TABLE_OPERATORS, 'buyout_minutes', 'mediumint(5) unsigned after status');
    $this->addColumn(self::TABLE_OPERATORS, 'is_buyout_only_after_1st_rebill', 'tinyint(1) unsigned after buyout_minutes');
    $this->addColumn(self::TABLE_OPERATORS, 'is_buyout_only_unique_phone', 'tinyint(1) unsigned after is_buyout_only_after_1st_rebill');


    $conditions = (new \yii\db\Query())
      ->select(['operator_id', 'buyout_minutes', 'is_buyout_only_after_1st_rebill', 'is_buyout_only_unique_phone'])
      ->from(self::TABLE)
      ->where(['user_id' => 0])->all();

    foreach($conditions as $condition) {
      if ($condition['buyout_minutes'] !== null) {
        $this->update(self::TABLE_OPERATORS, [
          'buyout_minutes' => $condition['buyout_minutes'],
        ], [
          'id' => $condition['operator_id']
        ]);
      }
      if ($condition['is_buyout_only_after_1st_rebill'] !== null) {
        $this->update(self::TABLE_OPERATORS, [
          'is_buyout_only_after_1st_rebill' => $condition['is_buyout_only_after_1st_rebill'],
        ], [
          'id' => $condition['operator_id']
        ]);
      }
      if ($condition['is_buyout_only_unique_phone'] !== null) {
        $this->update(self::TABLE_OPERATORS, [
          'is_buyout_only_unique_phone' => $condition['is_buyout_only_unique_phone'],
        ], [
          'id' => $condition['operator_id']
        ]);
      }
    }

    $this->dropTable(self::TABLE);

    $this->removePermission('PromoBuyoutConditionsDelete');
    $this->removePermission('PromoBuyoutConditionsCreate');
    $this->removePermission('PromoBuyoutConditionsUpdateModal');
    $this->removePermission('PromoBuyoutConditionsIndex');
    $this->removePermission('PromoBuyoutConditionsController');
  }
}
