<?php

use console\components\Migration;

class m160222_164855_stream_index_unique_name_user extends Migration
{

  protected $streamsTable = 'streams';
  protected $indexName = 'streams_name_user_id_index';

  public function safeUp()
  {
    $this->createIndex($this->indexName, $this->streamsTable, ['name', 'user_id'], true);
  }

  public function safeDown()
  {
    $this->dropIndex($this->indexName, $this->streamsTable);
  }

}
