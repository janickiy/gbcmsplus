<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170914_153425_promo_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PromoOperatorsUpdateBuyoutParams', 'Разрешить редактирование выкупа у оператора', 'PromoPermissions', ['admin', 'root']);

    $this->createPermission('PromoOperatorsUpdateBuyout', 'Редактирование настройки выкупа у оператора', 'PromoOperatorsController', ['admin', 'root']);

  }

  public function down()
  {
    $this->removePermission('PromoOperatorsUpdateBuyout');
    $this->removePermission('PromoOperatorsUpdateBuyoutParams');
  }
}
