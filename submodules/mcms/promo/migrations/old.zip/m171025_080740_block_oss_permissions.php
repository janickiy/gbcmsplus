<?php

use console\components\Migration;

class m171025_080740_block_oss_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;
  public function up()
  {
    $this->createPermission('PromoTrafficBlockController', 'Контроллер TrafficBlock', 'PromoModule', ['admin', 'root', 'reseller']);
    $this->createPermission('PromoTrafficBlockList', 'Просмотр списка блокировок', 'PromoTrafficBlockController');
    $this->createPermission('PromoTrafficBlockDelete', 'Удаление блокировки', 'PromoTrafficBlockController');
    $this->createPermission('PromoTrafficBlockUpdateModal', 'Редактирование блокировки', 'PromoTrafficBlockController');
    $this->createPermission('PromoTrafficBlockCreateModal', 'Создание блокировки', 'PromoTrafficBlockController');

    $this->createPermission('CanViewTrafficBlockWidget', 'Разрешение видеть виджет TrafficBlockWidget', 'PromoPermissions', ['admin', 'root', 'reseller']);

    $this->createPermission('CanHaveTrafficBlock', 'Пользователю возможно заблокировать трафик', 'PromoPermissions', ['partner']);
  }

  public function down()
  {
    $this->removePermission('CanHaveTrafficBlock');
    $this->removePermission('CanViewTrafficBlockWidget');
    $this->removePermission('PromoTrafficBlockCreateModal');
    $this->removePermission('PromoTrafficBlockUpdateModal');
    $this->removePermission('PromoTrafficBlockDelete');
    $this->removePermission('PromoTrafficBlockList');
    $this->removePermission('PromoTrafficBlockController');
  }
}
