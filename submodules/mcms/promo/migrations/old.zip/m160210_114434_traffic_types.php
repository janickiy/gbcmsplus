<?php

use console\components\Migration;
use mcms\promo\models\TrafficType;

class m160210_114434_traffic_types extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  private $id = 1;

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    parent::init();
  }


  public function up()
  {
    $this->removePermission('PromoForbiddenTrafficTypesCreateModal');
    $this->removePermission('PromoForbiddenTrafficTypesDisable');
    $this->removePermission('PromoForbiddenTrafficTypesEnable');
    $this->removePermission('PromoForbiddenTrafficTypesIndex');
    $this->removePermission('PromoForbiddenTrafficTypesUpdateModal');

    $this->renameTable('forbidden_traffic_types', 'traffic_types');

    $this->createOrGetPermission('PromoTrafficTypesIndex', 'View traffic types list');
    $this->createOrGetPermission('PromoTrafficTypesCreate', 'Create new traffic type');
    $this->createOrGetPermission('PromoTrafficTypesUpdate', 'Update traffic type');
    $this->createOrGetPermission('PromoTrafficTypesDisable', 'Disable traffic type');
    $this->createOrGetPermission('PromoTrafficTypesEnable', 'Enable traffic type');

    $this->assignRolesPermission('PromoTrafficTypesIndex', ['root', 'admin', 'reseller']);
    $this->assignRolesPermission('PromoTrafficTypesCreate', ['root', 'admin', 'reseller']);
    $this->assignRolesPermission('PromoTrafficTypesUpdate', ['root', 'admin', 'reseller']);
    $this->assignRolesPermission('PromoTrafficTypesDisable', ['root', 'admin', 'reseller']);
    $this->assignRolesPermission('PromoTrafficTypesEnable', ['root', 'admin', 'reseller']);


    $this->delete('traffic_types');

    $this->createTrafficType('Контекстная реклама', 'Paid Search');
    $this->createTrafficType('Баннерная реклама ', 'Display');
    $this->createTrafficType('RichMedia', 'RichMedia');
    $this->createTrafficType('Email', 'Email');
    $this->createTrafficType('Социальные сети', 'Social Networks');
    $this->createTrafficType('Price-Comparison', 'Price-Comparison');
    $this->createTrafficType('Купоны/Промокоды', 'Coupon/Promo Codes');
    $this->createTrafficType('Teasers (Content)', 'Teasers (Content)');
    $this->createTrafficType('Clickunder/Popunder', 'Clickunder/Popunder');
    $this->createTrafficType('Дорвеи', 'Doorways');
    $this->createTrafficType('Контентные сайты', 'Content Sites');
    $this->createTrafficType('Мотивированный трафик', 'Incentive');
    $this->createTrafficType('SMS', 'SMS');
    $this->createTrafficType('Push Ads', 'Push Ads');
  }

  public function down()
  {
    echo "m160210_114434_traffic_types cannot be reverted.\n";
  }

  private function createTrafficType($ru, $en)
  {
    (new TrafficType([
      'id' => $this->id,
      'status' => TrafficType::STATUS_ACTIVE,
      'name' => ['ru' => $ru, 'en' => $en]
    ]))->save();
    $this->id++;
  }
}
