<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m170726_150533_providers_view_modal extends Migration
{
  use PermissionMigration;
  
  public function up()
  {
    $this->createPermission(
      'PromoProvidersViewModal',
      'Просмотр провайдера в модалке',
      'PromoProvidersController',
      ['root', 'admin']
    );
  }
  
  public function down()
  {
    $this->removePermission('PromoProvidersViewModal');
  }
}
