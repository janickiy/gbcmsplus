<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
 */
class m181101_105052_salvador_country extends Migration
{
  use PermissionTrait;

  public $countries = [
    [
      'name' => 'Ecuador',
      'code' => 'ec',
      'currency' => 'USD',
    ]
  ];

  /**
   */
  public function up()
  {
    $this->db->createCommand('
        INSERT INTO countries (id, name, status, code, currency, local_currency, created_at)
        VALUES (:id, :name, :status, :code, :currency, :local_currency, :created_at)
        ON DUPLICATE KEY UPDATE currency=VALUES(currency), local_currency=VALUES(local_currency)', [
      ':id' => 123,
      ':name' => 'El Salvador',
      ':status' => 0,
      ':code' => 'SV',
      ':currency' => 'eur',
      ':local_currency' => 'usd',
      ':created_at' => time(),
    ])->execute();
  }

  /**
   */
  public function down()
  {
    echo "m181101_105052_salvador_country cannot be reverted.\n";

    return true;
  }
}
