<?php

use console\components\Migration;

class m160325_133029_operator_ip_refactor extends Migration
{

  const TABLE = 'operator_ips';

  public function up()
  {
    $this->renameColumn(self::TABLE, 'ip', 'from_ip');
    $this->alterColumn(self::TABLE, 'from_ip', 'bigint(14) NOT NULL');
    $this->createIndex('from_ip', self::TABLE, 'from_ip');

    $this->addColumn(self::TABLE, 'to_ip', 'bigint(14) NOT NULL');
    $this->createIndex('to_ip', self::TABLE, 'to_ip');

    $this->update(self::TABLE, [
      'to_ip' => new \yii\db\Expression('INET_ATON(INET_NTOA(from_ip | ((0x100000000 >> mask ) -1 )))')
    ]);
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'to_ip');
    $this->dropIndex('from_ip', self::TABLE);
    $this->renameColumn(self::TABLE, 'from_ip', 'ip');
    $this->alterColumn(self::TABLE, 'ip', 'int(10) NOT NULL');
  }
}
