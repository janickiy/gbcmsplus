<?php

use console\components\Migration;

class m180712_120558_traffic_blocks_fields extends Migration
{
  const TABLE = 'traffic_blocks';

  public function up()
  {
    $this->addColumn(self::TABLE, 'created_by', 'MEDIUMINT(5) UNSIGNED NOT NULL');
    $this->addColumn(self::TABLE, 'updated_by', 'MEDIUMINT(5) UNSIGNED NOT NULL');
    $this->addColumn(self::TABLE, 'created_at', 'INT(10) UNSIGNED NOT NULL');
    $this->addColumn(self::TABLE, 'updated_at', 'INT(10) UNSIGNED NOT NULL');
    $this->addColumn(self::TABLE, 'comment', 'TEXT');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE,'created_by');
    $this->dropColumn(self::TABLE,'updated_by');
    $this->dropColumn(self::TABLE,'created_at');
    $this->dropColumn(self::TABLE,'updated_at');
    $this->dropColumn(self::TABLE,'comment');
  }

}
