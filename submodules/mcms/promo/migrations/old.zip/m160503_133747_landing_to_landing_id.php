<?php

use console\components\Migration;

class m160503_133747_landing_to_landing_id extends Migration
{
  const TABLE = 'landings';
  public function up()
  {
    $this->addColumn(self::TABLE, 'to_landing_id', 'MEDIUMINT(5)');
    $this->addColumn(self::TABLE, 'operators_text', 'VARCHAR(255) COLLATE utf8_unicode_ci');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'to_landing_id');
    $this->dropColumn(self::TABLE, 'operators_text');
  }
}
