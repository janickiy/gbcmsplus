<?php

use console\components\Migration;

class m180507_165011_remove_cities_regions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  protected $countryTable = '{{%countries}}';
  protected $regionTable = '{{%regions}}';
  protected $cityTable = '{{%cities}}';

  protected $regionsCountryFk = 'regions_country_id_fk';
  protected $citiesCountryFk = 'cities_country_id_fk';
  protected $citiesRegionFk = 'cities_region_id_fk';

  public function up()
  {
    $this->dropTable($this->cityTable);
    $this->dropTable($this->regionTable);

    $this->removePermission('PromoCitiesController');
    $this->removePermission('PromoCitiesCreate');
    $this->removePermission('PromoCitiesCreateModal');
    $this->removePermission('PromoCitiesDependentRegions');
    $this->removePermission('PromoCitiesDisable');
    $this->removePermission('PromoCitiesEnable');
    $this->removePermission('PromoCitiesIndex');
    $this->removePermission('PromoCitiesUpdate');
    $this->removePermission('PromoCitiesUpdateModal');
    $this->removePermission('PromoCitiesView');
    $this->removePermission('PromoCitiesViewModal');


    $this->removePermission('PromoRegionsController');
    $this->removePermission('PromoRegionsCreate');
    $this->removePermission('PromoRegionsCreateModal');
    $this->removePermission('PromoRegionsDisable');
    $this->removePermission('PromoRegionsEnable');
    $this->removePermission('PromoRegionsIndex');
    $this->removePermission('PromoRegionsUpdate');
    $this->removePermission('PromoRegionsUpdateModal');
    $this->removePermission('PromoRegionsView');
    $this->removePermission('PromoRegionsViewModal');
  }

  public function down()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    /*
     * REGIONS
     */
    $this->createTable($this->regionTable, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string(50)->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex('regions_status_index', $this->regionTable, 'status');
    $this->addForeignKey($this->regionsCountryFk, $this->regionTable, 'country_id', $this->countryTable, 'id');

    /*
     * CITIES
     */
    $this->createTable($this->cityTable, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => $this->string(50)->notNull(),
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'region_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex('cities_status_index', $this->cityTable, 'status');
    $this->addForeignKey($this->citiesCountryFk, $this->cityTable, 'country_id', $this->countryTable, 'id');
    $this->addForeignKey($this->citiesRegionFk, $this->cityTable, 'region_id', $this->regionTable, 'id');

    $this->createPermission('PromoCitiesController', 'Контроллер Cities', 'PromoModule');
    $this->createPermission('PromoCitiesCreate', 'Создание города', 'PromoCitiesController');
    $this->createPermission('PromoCitiesCreateModal', 'Создание города модалка', 'PromoCitiesController');
    $this->createPermission('PromoCitiesDependentRegions', 'Получение регионов', 'PromoCitiesController');
    $this->createPermission('PromoCitiesDisable', 'Выключение города', 'PromoCitiesController');
    $this->createPermission('PromoCitiesEnable', 'Включение города', 'PromoCitiesController');
    $this->createPermission('PromoCitiesIndex', 'Просмотр списка городов', 'PromoCitiesController');
    $this->createPermission('PromoCitiesUpdate', 'Редактирование города', 'PromoCitiesController');
    $this->createPermission('PromoCitiesUpdateModal', 'Редактирование города модалка', 'PromoCitiesController');
    $this->createPermission('PromoCitiesView', 'Просмотр города', 'PromoCitiesController');
    $this->createPermission('PromoCitiesViewModal', 'Просмотр города модалка', 'PromoCitiesController');

    $this->createPermission('PromoRegionsController', 'Контроллер Regions', 'PromoModule');
    $this->createPermission('PromoRegionsCreate', 'Создание региона', 'PromoRegionsController');
    $this->createPermission('PromoRegionsCreateModal', 'Создание региона модалка', 'PromoRegionsController');
    $this->createPermission('PromoRegionsDisable', 'Выключение региона', 'PromoRegionsController');
    $this->createPermission('PromoRegionsEnable', 'Включение региона', 'PromoRegionsController');
    $this->createPermission('PromoRegionsIndex', 'Просмотр списка регионов', 'PromoRegionsController');
    $this->createPermission('PromoRegionsUpdate', 'Редактирование региона', 'PromoRegionsController');
    $this->createPermission('PromoRegionsUpdateModal', 'Редактирование региона модалка', 'PromoRegionsController');
    $this->createPermission('PromoRegionsView', 'Просмотр региона', 'PromoRegionsController');
    $this->createPermission('PromoRegionsViewModal', 'Просмотр региона модалка', 'PromoRegionsController');
  }
}
