<?php

use console\components\Migration;

class m151214_092129_landing_redirects_new_structure extends Migration
{

  public function safeUp()
  {
    $this->truncateTable('landing_redirects');

    $this->dropForeignKey('landing_redirects_redirect_to_fk', 'landing_redirects');
    $this->dropForeignKey('landing_redirects_landing_id_fk', 'landing_redirects');
    $this->dropPrimaryKey('landing_redirects_pk', 'landing_redirects');
    $this->dropColumn('landing_redirects', 'redirect_to');
    $this->dropColumn('landing_redirects', 'landing_id');

    $this->addColumn('landing_redirects', 'id', 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST');

    $this->addColumn('landing_redirects', 'redirect_from', $this->text()->notNull() . ' AFTER ID');
    $this->addColumn('landing_redirects', 'redirect_to', $this->text()->notNull() . ' AFTER redirect_from');
  }

  public function safeDown()
  {
    $this->truncateTable('landing_redirects');

    $this->dropColumn('landing_redirects', 'redirect_to');
    $this->dropColumn('landing_redirects', 'redirect_from');
    $this->dropColumn('landing_redirects', 'id');

    $this->addColumn('landing_redirects', 'landing_id', 'MEDIUMINT(5) UNSIGNED NOT NULL');
    $this->addColumn('landing_redirects', 'redirect_to', 'MEDIUMINT(5) UNSIGNED NOT NULL');
    $this->addPrimaryKey('landing_redirects_pk', 'landing_redirects', ['landing_id', 'redirect_to']);

    $this->addForeignKey('landing_redirects_redirect_to_fk', 'landing_redirects', 'redirect_to', 'landings', 'id');
    $this->addForeignKey('landing_redirects_landing_id_fk', 'landing_redirects', 'landing_id', 'landings', 'id');
  }

}
