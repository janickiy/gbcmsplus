<?php

use console\components\Migration;

class m161103_092434_remove_prelends_edit_actions extends Migration
{
  private $authManager;
  private $rootRole;
  private $resellerRole;
  private $managerRole;
  private $adminRole;
  private $arbitrarySourcesController;
  private $webmasterSourcesController;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->getAuthManager();
    $this->rootRole = $this->authManager->getRole('root');
    $this->resellerRole = $this->authManager->getRole('reseller');
    $this->managerRole = $this->authManager->getRole('manager');
    $this->adminRole = $this->authManager->getRole('admin');
    $this->arbitrarySourcesController = $this->authManager->getPermission('PromoArbitrarySourcesController');
    $this->webmasterSourcesController = $this->authManager->getPermission('PromoWebmasterSourcesController');
  }

  public function up()
  {
    if ($pAsUaOp = $this->authManager->getPermission('PromoArbitrarySourcesUpdateAddOperatorPreland')) {
      $this->authManager->removeChild($this->rootRole, $pAsUaOp);
      $this->authManager->removeChild($this->resellerRole, $pAsUaOp);
      $this->authManager->removeChild($this->managerRole, $pAsUaOp);
      $this->authManager->removeChild($this->adminRole, $pAsUaOp);
      $this->authManager->removeChild($this->arbitrarySourcesController, $pAsUaOp);
      $this->authManager->remove($pAsUaOp);
    }
    if ($pWsUaOp = $this->authManager->getPermission('PromoWebmasterSourcesUpdateAddOperatorPreland')) {
      $this->authManager->removeChild($this->rootRole, $pWsUaOp);
      $this->authManager->removeChild($this->resellerRole, $pWsUaOp);
      $this->authManager->removeChild($this->managerRole, $pWsUaOp);
      $this->authManager->removeChild($this->adminRole, $pWsUaOp);
      $this->authManager->removeChild($this->webmasterSourcesController, $pWsUaOp);
      $this->authManager->remove($pWsUaOp);
    }
    if ($pAsUoOp = $this->authManager->getPermission('PromoArbitrarySourcesUpdateOffOperatorPreland')) {
      $this->authManager->removeChild($this->rootRole, $pAsUoOp);
      $this->authManager->removeChild($this->resellerRole, $pAsUoOp);
      $this->authManager->removeChild($this->managerRole, $pAsUoOp);
      $this->authManager->removeChild($this->adminRole, $pAsUoOp);
      $this->authManager->removeChild($this->arbitrarySourcesController, $pAsUoOp);
      $this->authManager->remove($pAsUoOp);
    }
    if ($pWsUoOp = $this->authManager->getPermission('PromoWebmasterSourcesUpdateOffOperatorPreland')) {
      $this->authManager->removeChild($this->rootRole, $pWsUoOp);
      $this->authManager->removeChild($this->resellerRole, $pWsUoOp);
      $this->authManager->removeChild($this->managerRole, $pWsUoOp);
      $this->authManager->removeChild($this->adminRole, $pWsUoOp);
      $this->authManager->removeChild($this->webmasterSourcesController, $pWsUoOp);
      $this->authManager->remove($pWsUoOp);
    }
  }

  public function down()
  {
    $pAsUaOp = $this->authManager->createPermission('PromoArbitrarySourcesUpdateAddOperatorPreland');
    $pAsUaOp->description = 'Set add_operator_preland';
    $this->authManager->add($pAsUaOp);
    $this->authManager->addChild($this->rootRole, $pAsUaOp);
    $this->authManager->addChild($this->resellerRole, $pAsUaOp);
    $this->authManager->addChild($this->managerRole, $pAsUaOp);
    $this->authManager->addChild($this->adminRole, $pAsUaOp);
    $this->authManager->addChild($this->arbitrarySourcesController, $pAsUaOp);

    $pWsUaOp = $this->authManager->createPermission('PromoWebmasterSourcesUpdateAddOperatorPreland');
    $pWsUaOp->description = 'Set add_operator_preland';
    $this->authManager->add($pWsUaOp);
    $this->authManager->addChild($this->rootRole, $pWsUaOp);
    $this->authManager->addChild($this->resellerRole, $pWsUaOp);
    $this->authManager->addChild($this->managerRole, $pWsUaOp);
    $this->authManager->addChild($this->adminRole, $pWsUaOp);
    $this->authManager->addChild($this->webmasterSourcesController, $pWsUaOp);

    $pAsUoOp = $this->authManager->createPermission('PromoArbitrarySourcesUpdateOffOperatorPreland');
    $pAsUoOp->description = 'Set off_operator_preland';
    $this->authManager->add($pAsUoOp);
    $this->authManager->addChild($this->rootRole, $pAsUoOp);
    $this->authManager->addChild($this->resellerRole, $pAsUoOp);
    $this->authManager->addChild($this->managerRole, $pAsUoOp);
    $this->authManager->addChild($this->adminRole, $pAsUoOp);
    $this->authManager->addChild($this->arbitrarySourcesController, $pAsUoOp);

    $pWsUoOp = $this->authManager->createPermission('PromoWebmasterSourcesUpdateOffOperatorPreland');
    $pWsUoOp->description = 'Set off_operator_preland';
    $this->authManager->add($pWsUoOp);
    $this->authManager->addChild($this->rootRole, $pWsUoOp);
    $this->authManager->addChild($this->resellerRole, $pWsUoOp);
    $this->authManager->addChild($this->managerRole, $pWsUoOp);
    $this->authManager->addChild($this->adminRole, $pWsUoOp);
    $this->authManager->addChild($this->webmasterSourcesController, $pWsUoOp);

  }
}
