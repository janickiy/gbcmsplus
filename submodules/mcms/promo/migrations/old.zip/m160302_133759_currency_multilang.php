<?php

use yii\db\Schema;
use console\components\Migration;
use mcms\promo\models\Currency;
class m160302_133759_currency_multilang extends Migration
{
  private $currencies = [
    ['id' => 1, 'name' => ['ru' => 'Рубли', 'en' => 'Rubles']],
    ['id' => 2, 'name' => ['ru' => 'Доллары', 'en' => 'Dollars']],
    ['id' => 3, 'name' => ['ru' => 'Евро', 'en' => 'Euro']],
  ];

  public function up()
  {
    foreach ($this->currencies as $currency) {
      /* @var Currency $model*/
      $model = Currency::findOne($currency['id']);
      $model->name = $currency['name'];
      $model->save();
    }
  }

}
