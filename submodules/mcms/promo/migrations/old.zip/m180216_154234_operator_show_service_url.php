<?php

use console\components\Migration;

class m180216_154234_operator_show_service_url extends Migration
{
  use \rgk\utils\traits\PermissionTrait;
  const IDS = [1, 2, 3, 7];
  const PERMISSION = 'CanChangeOperatorShowServiceUrl';

  public function up()
  {
    $this->addColumn('operators', 'show_service_url', 'TINYINT(1) UNSIGNED DEFAULT \'0\' NOT NULL');
    $this->update('operators', ['show_service_url' => 1], ['id' => self::IDS]);

    $this->createPermission(self::PERMISSION, 'Право менять свойство оператора "Отображать URL сервиса"', 'PromoPermissions', ['root']);
  }

  public function down()
  {
    $this->removePermission(self::PERMISSION);
    $this->dropColumn('operators', 'show_service_url');
  }
}
