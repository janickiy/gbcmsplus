<?php

use console\components\Migration;

class m171127_154646_add_preland_defaults_columns extends Migration
{
  const TABLE_NAME = 'preland_defaults';
  const OPERATORS_COLUMN_NAME = 'operators';
  const TYPE_COLUMN_NAME = 'type';
  const STATUS_COLUMN_NAME = 'status';
  const STREAM_COLUMN_NAME = 'stream_id';
  const SOURCE_COLUMN_NAME = 'source_id';

  public function up()
  {
    $this->alterColumn(self::TABLE_NAME, self::OPERATORS_COLUMN_NAME, 'TEXT');
    $this->addColumn(self::TABLE_NAME, self::STATUS_COLUMN_NAME, 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 1');
    $this->addColumn(self::TABLE_NAME, self::TYPE_COLUMN_NAME, 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 1');
    $this->addColumn(self::TABLE_NAME, self::STREAM_COLUMN_NAME, 'MEDIUMINT(5) UNSIGNED');
    $this->addColumn(self::TABLE_NAME, self::SOURCE_COLUMN_NAME, 'MEDIUMINT(5) UNSIGNED');

    $this->dropForeignKey(self::TABLE_NAME . '_user_id_fk', self::TABLE_NAME);
    $this->dropIndex(self::TABLE_NAME . '_user_id_uq', self::TABLE_NAME);
    $this->createIndex(self::TABLE_NAME . '_user_id_uq', self::TABLE_NAME, ['user_id', 'type', 'stream_id', 'source_id'], true);
  }

  public function down()
  {
    $this->alterColumn(self::TABLE_NAME, self::OPERATORS_COLUMN_NAME, 'TEXT NOT NULL');
    $this->dropColumn(self::TABLE_NAME, self::TYPE_COLUMN_NAME);
    $this->dropColumn(self::TABLE_NAME, self::STATUS_COLUMN_NAME);
    $this->dropColumn(self::TABLE_NAME, self::STREAM_COLUMN_NAME);
    $this->dropColumn(self::TABLE_NAME, self::SOURCE_COLUMN_NAME);

    $this->dropIndex(self::TABLE_NAME . '_user_id_uq', self::TABLE_NAME);
    $this->createIndex(self::TABLE_NAME . '_user_id_uq', self::TABLE_NAME, 'user_id', true);
  }
}