<?php

use console\components\Migration;

class m160510_152650_preland_defaults extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  const TABLE = 'preland_defaults';

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    parent::init();
  }


  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::TABLE, [
      'id' => 'mediumint(5) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'user_id' => 'mediumint(5) unsigned',
      'operators' => 'text NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex(self::TABLE . '_user_id_uq', self::TABLE, 'user_id', true);
    $this->addForeignKey(self::TABLE . '_user_id_fk', self::TABLE, 'user_id', 'users', 'id', 'CASCADE');

    $controllerPermission = $this->createOrGetPermission('PromoPrelandDefaultsController', 'Promo Preland Defaults Controller');
    $promoPermission = $this->authManager->getPermission('PromoModule');

    $this->authManager->addChild($promoPermission, $controllerPermission);

    $indexPermission = $this->createOrGetPermission('PromoPrelandDefaultsIndex', 'View Preland Defaults list');
    $this->authManager->addChild($controllerPermission, $indexPermission);

    $this->assignRolesPermission('PromoPrelandDefaultsIndex', ['root', 'admin', 'reseller', 'manager']);

    $formPermission = $this->createOrGetPermission('PromoPrelandDefaultsFormModal', 'Edit Preland Defaults condition');
    $this->authManager->addChild($controllerPermission, $formPermission);

    $this->assignRolesPermission('PromoPrelandDefaultsFormModal', ['root', 'admin', 'reseller', 'manager']);

    $deletePermission = $this->createOrGetPermission('PromoPrelandDefaultsDelete', 'Delete Preland Defaults condition');
    $this->authManager->addChild($controllerPermission, $deletePermission);

    $this->assignRolesPermission('PromoPrelandDefaultsDelete', ['root', 'admin', 'reseller', 'manager']);
  }

  public function down()
  {

    $this->removePermission('PromoPrelandDefaultsController');
    $this->removePermission('PromoPrelandDefaultsDelete');
    $this->removePermission('PromoPrelandDefaultsFormModal');
    $this->removePermission('PromoPrelandDefaultsIndex');

    $this->dropTable(self::TABLE);
  }
}
