<?php

use console\components\Migration;

class m160322_102752_currencies_button_perm extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  const PERMISSION = 'PromoCurrenciesUserMainCurrencyChanged';

  public function up()
  {
    $this->createOrGetPermission(self::PERMISSION, 'Main user currency is changed handler');
    $this->assignRolesPermission(self::PERMISSION, ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission(self::PERMISSION);
  }

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
  }
}
