<?php

use console\components\Migration;

class m160527_075310_set_default_banner extends Migration
{
  public function up()
  {

    $bannersTableName = \mcms\promo\models\Banner::tableName();
    $bannerTemplateTableName = \mcms\promo\models\BannerTemplate::tableName();

    $defaultBanner = (new \yii\db\Query())
      ->select($bannersTableName . '.id')
      ->from($bannersTableName)
      ->innerJoin(
        $bannerTemplateTableName,
        $bannersTableName . '.template_id = ' . $bannerTemplateTableName . '.id'
      )
      ->where([$bannersTableName . '.is_disabled' => 0])
      ->andWhere([$bannerTemplateTableName . '.code' => 'files'])
      ->one()
      ;

    $defaultBannerId = \yii\helpers\ArrayHelper::getValue($defaultBanner, 'id', false);
    if (!$defaultBannerId) {
      echo 'Default banner not found';
      return true;
    }
  }

  public function down()
  {
    echo "m160527_075310_set_default_banner cannot be reverted.\n";

  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
