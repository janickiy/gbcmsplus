<?php

use console\components\Migration;

class m160302_122655_update_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'ArbitrarySources' => [
        ['disable-modal', 'Set disable arbitrary source', ['admin', 'root', 'reseller']],
      ]
    ];
  }
}
