<?php

use console\components\Migration;

class m170407_072505_reseller_revoke extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->revokeRolesPermission('PromoRebillConditionsCreateModal', ['reseller']);
    $this->revokeRolesPermission('PromoRebillConditionsDelete', ['reseller']);
    $this->revokeRolesPermission('PromoRebillConditionsIndex', ['reseller']);
    $this->revokeRolesPermission('PromoRebillConditionsUpdateModal', ['reseller']);
  }

  public function down()
  {
    $this->assignRolesPermission('PromoRebillConditionsCreateModal', ['reseller']);
    $this->assignRolesPermission('PromoRebillConditionsDelete', ['reseller']);
    $this->assignRolesPermission('PromoRebillConditionsIndex', ['reseller']);
    $this->assignRolesPermission('PromoRebillConditionsUpdateModal', ['reseller']);
  }
}
