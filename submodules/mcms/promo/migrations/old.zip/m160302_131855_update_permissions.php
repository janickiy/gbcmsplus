<?php

use console\components\Migration;

class m160302_131855_update_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Promo';
    $this->permissions = [
      'WebmasterSources' => [
        ['update-add-operator-preland', 'Set add_operator_preland', ['admin', 'root', 'reseller']],
        ['update-off-operator-preland', 'Set off_operator_preland', ['admin', 'root', 'reseller']],
        ['update-category', 'Set category', ['admin', 'root', 'reseller']],
      ]
    ];
  }
}
