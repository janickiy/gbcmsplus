<?php

use console\components\Migration;

class m160726_163745_ampersand extends Migration
{
  public function up()
  {
    $this->db->createCommand("
      UPDATE sources SET postback_url = REPLACE(postback_url, '&amp;', '&');
      UPDATE sources SET trafficback_url = REPLACE(trafficback_url, '&amp;', '&');
    ")->execute();
  }

  public function down()
  {
    echo "m160726_163745_ampersand cannot be reverted.\n";

    return true;
  }
}
