<?php

use yii\db\Schema;
use mcms\promo\components\api\GetPersonalProfit;
use console\components\Migration;
use yii\caching\TagDependency;

class m160201_083350_clear_profit_cache extends Migration
{
  public function up()
  {
    // Сбрасываем кэш профитов, т.к. немного изменилась логика
    TagDependency::invalidate(Yii::$app->cache, [GetPersonalProfit::CACHE_KEY_PREFIX . 'module_percents']);
  }

  public function down()
  {
    echo "m160201_083350_clear_profit_cache cannot be reverted.\n";
  }
}
