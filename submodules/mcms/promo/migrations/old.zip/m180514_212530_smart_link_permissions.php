<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

class m180514_212530_smart_link_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PromoSmartLinksController', 'Контроллер смарт ссылок', 'PromoModule');
    $this->createPermission('PromoSmartLinksIndex', 'Просмотр списка смарт ссылок', 'PromoSmartLinksController', ['root', 'admin', 'reseller']);
    $this->createPermission('PromoSmartLinksUpdate', 'Редактирование смарт ссылки', 'PromoSmartLinksController', ['root', 'admin', 'reseller']);
    $this->createPermission('PromoSmartLinksView', 'Просмотр смарт ссылки', 'PromoSmartLinksController', ['root', 'admin', 'reseller']);

  }

  public function down()
  {
    $this->removePermission('PromoSmartLinksController');
    $this->removePermission('PromoSmartLinksIndex');
    $this->removePermission('PromoSmartLinksUpdate');
    $this->removePermission('PromoSmartLinksView');
  }

}
