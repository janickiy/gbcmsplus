<?php

use console\components\Migration;

class m160524_134612_banners extends Migration
{

  const TEMPL = 'banner_templates';

  const PROP = 'banner_template_attributes';

  const BANNER = 'banners';

  const BANNER_ATTRS = 'banner_attribute_values';

  public function up()
  {
    /** ШАБЛОН */
    $this->createTable(self::TEMPL, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'code' => $this->string()->notNull(),
      'name' => $this->string()->notNull(),
      'template' => $this->text(),
      'is_disabled' => 'TINYINT(1) NOT NULL DEFAULT 0',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED NOT NULL'
    ]);

    /** уникальность кода */
    $this->createIndex(self::TEMPL . '_code_uq', self::TEMPL, 'code', true);

    /** СВОЙСТВА КАТЕГОРИЙ */
    $this->createTable(self::PROP, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'type' => 'TINYINT(1) NOT NULL',
      'code' => $this->string()->notNull(),
      'name' => $this->string()->notNull(),
      'template_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL'
    ]);
    $this->createIndex(self::PROP . '_type_index', self::PROP, 'type');
    $this->createIndex(self::PROP . '_code_uq', self::PROP, ['template_id', 'code'], true);
    $this->addForeignKey(self::PROP . '_template_id_fk', self::PROP, 'template_id', self::TEMPL, 'id', 'CASCADE');

    /** БАННЕРЫ */
    $this->createTable(self::BANNER, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'code' => $this->string()->notNull(),
      'name' => $this->string()->notNull(),
      'template_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'is_disabled' => 'TINYINT(1) NOT NULL DEFAULT 0',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED NOT NULL'
    ]);

    $this->addForeignKey(self::BANNER . '_template_id_fk', self::BANNER, 'template_id', self::TEMPL, 'id', 'CASCADE');

    /** Значения свойств баннеров */
    $this->createTable(self::BANNER_ATTRS, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'banner_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'attribute_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'multilang_value' => $this->text(),
      'value' => $this->text()
    ]);
    $this->addForeignKey(self::BANNER_ATTRS . '_banner_id_fk', self::BANNER_ATTRS, 'banner_id', self::BANNER, 'id', 'CASCADE');
    $this->addForeignKey(self::BANNER_ATTRS . '_attribute_id_fk', self::BANNER_ATTRS, 'attribute_id', self::PROP, 'id', 'CASCADE');
  }

  public function down()
  {
    $this->dropTable(self::BANNER_ATTRS);
    $this->dropTable(self::BANNER);
    $this->dropTable(self::PROP);
    $this->dropTable(self::TEMPL);
  }
}
