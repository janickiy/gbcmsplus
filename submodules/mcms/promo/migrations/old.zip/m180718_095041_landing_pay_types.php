<?php

use console\components\Migration;

class m180718_095041_landing_pay_types extends Migration
{
  const TABLE = 'landing_pay_types';

  public function up()
  {
    $this->update(self::TABLE, ['name' => '3G (DCB)'], ['code' => '3g']);

  }

  public function down()
  {
    $this->update(self::TABLE, ['name' => '3G (1Click, DCB)'], ['code' => '3g']);
  }

}
