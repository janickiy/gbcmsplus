<?php

use console\components\Migration;

class m160323_114354_add_platform_3g_modem extends Migration
{
  const TABLE = 'platforms';

  public function up()
  {
    $this->insert(self::TABLE, [
      'id' => 111,
      'name' => '3G Modem',
      'match_string' => '/.*/',
      'check_order' => 11,
      'status' => 1,
      'created_at' => time(),
      'updated_at' => time()
    ]);
  }

  public function down()
  {
    $this->delete(self::TABLE, ['id' => 111]);
  }
}
