<?php

use console\components\Migration;

/**
 * Class m161031_141503_user_program_id
 */
class m161031_141503_user_program_id extends Migration
{

  const TABLE = 'user_promo_settings';
  const COLUMN = 'partner_program_id';
  const FK = self::TABLE . '_' . self::COLUMN . '_fk';

  /**
   *
   */
  public function up()
  {
    $this->addColumn(self::TABLE, self::COLUMN, 'mediumint(5) unsigned after is_reseller_buyout_prices');

    $this->addForeignKey(
      self::FK,
      self::TABLE,
      self::COLUMN,
      'partner_programs',
      'id',
      'SET NULL',
      'CASCADE'
    );
  }

  /**
   *
   */
  public function down()
  {
    $this->dropForeignKey(self::FK, self::TABLE);
    $this->dropColumn(self::TABLE, self::COLUMN);
  }
}
