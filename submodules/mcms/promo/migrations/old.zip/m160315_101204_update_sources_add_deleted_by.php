<?php

use mcms\promo\models\LandingCategory;
use console\components\Migration;

class m160315_101204_update_sources_add_deleted_by extends Migration
{
  const TABLE = 'sources';

  public function safeUp()
  {
    $this->addColumn(self::TABLE, 'deleted_by', 'mediumint(5) unsigned');
  }

  public function safeDown()
  {
    $this->dropColumn(self::TABLE, 'deleted_by');
  }
}
