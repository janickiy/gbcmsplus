<?php

use console\components\Migration;

class m160309_155604_sync_new_fields extends Migration
{

  const LANDS = 'landings';
  const LAND_OPS = 'landing_operators';
  const OPERS = 'operators';
  const COUNTRIES = 'countries';
  const SYNCED = 'sync_updated_at';
  const REB_PER = 'rebill_period';
  const COST = 'cost_price';

  public function safeUp()
  {
    $this->addColumn(self::LANDS, self::REB_PER, 'TINYINT(1) UNSIGNED AFTER allow_sync_buyout_prices');
    $this->addColumn(self::LANDS, self::SYNCED, 'int(10) unsigned COMMENT \'Время обновления у вендора\'');
    $this->addColumn(self::COUNTRIES, self::SYNCED, 'int(10) unsigned COMMENT \'Время обновления у вендора\'');
    $this->addColumn(self::OPERS, self::SYNCED, 'int(10) unsigned COMMENT \'Время обновления у вендора\'');

    $this->alterColumn(self::LAND_OPS, self::COST, $this->string(50));
  }

  public function safeDown()
  {
    $this->alterColumn(self::LAND_OPS, self::COST, 'decimal(10,2)');

    $this->dropColumn(self::OPERS, self::SYNCED);
    $this->dropColumn(self::COUNTRIES, self::SYNCED);
    $this->dropColumn(self::LANDS, self::SYNCED);
    $this->dropColumn(self::LANDS, self::REB_PER);
  }
}
