<?php

use console\components\Migration;

class m151203_151247_domain_is_system extends Migration
{
  public function up()
  {
    $this->addColumn('domains', 'is_system', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
    $this->createIndex('domains_is_system_index', 'domains', 'is_system');
  }

  public function down()
  {
    $this->dropColumn('domains', 'is_system');
  }


}
