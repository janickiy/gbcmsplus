<?php

use console\components\Migration;

class m160512_081346_edit_landing_category_tb_url_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  const PERMISSION = 'CanEditLandingCategoryTbUrl';

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->createOrGetPermission(self::PERMISSION, 'User can edit tb url in landing category');
    $this->assignRolesPermission(self::PERMISSION, ['root', 'admin']);
  }

  public function down()
  {
    $this->revokeRolesPermission(self::PERMISSION, ['root', 'admin']);
    $this->removePermission(self::PERMISSION);
  }
}
