<?php

use console\components\Migration;

class m160809_120409_land_promo extends Migration
{

  const TABLE = 'landings';
  const FIELD = 'promo_materials';

  public function up()
  {
    $this->addColumn(self::TABLE, self::FIELD, 'varchar(255)');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, self::FIELD);
  }
}
