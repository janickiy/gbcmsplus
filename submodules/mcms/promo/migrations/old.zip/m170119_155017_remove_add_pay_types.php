<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m170119_155017_remove_add_pay_types extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->removePermission('PromoLandingPayTypesCreateModal');
  }

  public function down()
  {
    $this->createPermission(
      'PromoLandingPayTypesCreateModal',
      'Создание типа оплаты модалка',
      'PromoLandingPayTypesController',
      ['admin', 'root']
    );
  }
}
