<?php

use console\components\Migration;

class m151123_141701_init_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Modmanager';
    $this->permissions = [
      'Modules' => [
        ['index', 'Can view list of installed modules', ['admin', 'root']],
        ['availableList', 'Can view list of available modules', ['admin', 'root']],
        ['install', 'Can install module', ['admin', 'root']],
        ['settings', 'Can edit module settings', ['admin', 'root']],
        ['delete', 'Can delete module', ['admin', 'root']],
        ['enable', 'Can enable module', ['admin', 'root']],
        ['disable', 'Can disable module', ['admin', 'root']],
      ],
      'Messages' => [
        ['view', 'Can view module messages form', ['admin', 'root']],
        ['edit', 'Can edit messages', ['admin', 'root']],
      ]
    ];
  }


}
