<?php

use console\components\Migration;
use mcms\modmanager\models\Module;
use yii\base\BootstrapInterface;
use yii\helpers\ArrayHelper;

class m150730_000001_init_modules extends Migration
{
  public $modules;

  public function init()
  {
    parent::init();
    $this->modules = [
      'users' => 'app.common.module_users',
      'notifications' => 'app.common.module_notifications',
      'promo' => 'promo.main.module_name',
      'support' => 'app.common.module_support',
      'partners' => 'partners.main.module_partners',
      'payments' => 'payments.menu.module',
      'pages' => 'app.common.module_pages',
      'logs' => 'app.common.module_logs',
      'statistic' => 'app.common.module_statistic',
    ];
  }

  public function up()
  {
    foreach($this->modules as $moduleId => $moduleName) {

      if(Module::findOne(['module_id' => $moduleId])) continue;

      $module = new Module();
      $module->module_id = $moduleId;
      $module->name = $moduleName;
      $module->is_disabled = 0;
      $module->save();

      $moduleConfig = $module->getModuleById($moduleId);
      $class = $moduleConfig['class'];

      $app = Yii::$app;
      $app->setModule($moduleId, $moduleConfig);

      if (ArrayHelper::getValue($moduleConfig, 'preload', false)) {
        $component = $app->getModule($moduleId);
        if ($component instanceof BootstrapInterface) {
          Yii::trace('Bootstrap with ' . get_class($component) . '::bootstrap()', __METHOD__);
          $component->bootstrap($app);
        } else {
          Yii::trace('Bootstrap "' . $class . '" with ' . get_class($component), __METHOD__);
        }
      }

    }
    Yii::$app->set('i18n', [
      'class' => 'mcms\common\translate\I18N',
      'translations' => [
        'app.*' => [
          'class' => 'yii\i18n\PhpMessageSource',
          'basePath' => '@app/messages'
        ],
        'commonMsg.*' => [
          'class' => 'yii\i18n\PhpMessageSource',
          'basePath' => '@mcms/common/messages'
        ],
        'kvgrid' => [
          'class' => 'yii\i18n\PhpMessageSource',
          'basePath' => '@vendor/kartik-v/yii2-grid/messages'
        ],
      ],
    ]);
  }

  public function down()
  {
    foreach($this->modules as $moduleId => $moduleName) {
      Module::deleteAll(['module_id' => $moduleId]);
    }
  }
}
