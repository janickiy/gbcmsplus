<?php

use console\components\Migration;

class m160427_111002_fix_roles_hardcode extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->removePermission('CanResellerEditSettings');

    $this->createOrGetPermission('EditModuleSettingsPartners', 'Edit Partners module settings');
    $this->assignRolesPermission('EditModuleSettingsPartners', ['admin', 'root', 'reseller', 'manager']);

    $this->createOrGetPermission('EditModuleSettingsPromo', 'Edit Promo module settings');
    $this->assignRolesPermission('EditModuleSettingsPromo', ['admin', 'root']);

    $this->createOrGetPermission('EditModuleSettingsStatistic', 'Edit Statistic module settings');
    $this->assignRolesPermission('EditModuleSettingsStatistic', ['admin', 'root']);

    $this->createOrGetPermission('EditModuleSettingsUsers', 'Edit Users module settings');
    $this->assignRolesPermission('EditModuleSettingsUsers', ['admin', 'root']);

    $this->createOrGetPermission('EditModuleSettingsSupport', 'Edit Support module settings');
    $this->assignRolesPermission('EditModuleSettingsSupport', ['admin', 'root']);

    $this->createOrGetPermission('EditModuleSettingsPages', 'Edit Pages module settings');
    $this->assignRolesPermission('EditModuleSettingsPages', ['admin', 'root']);

    $this->createOrGetPermission('EditModuleSettingsPayments', 'Edit Payments module settings');
    $this->assignRolesPermission('EditModuleSettingsPayments', ['admin', 'root']);

    $this->createOrGetPermission('EditModuleSettingsNotifications', 'Edit Notifications module settings');
    $this->assignRolesPermission('EditModuleSettingsNotifications', ['admin', 'root']);

    $this->createOrGetPermission('EditModuleSettingsLogs', 'Edit Logs module settings');
    $this->assignRolesPermission('EditModuleSettingsLogs', ['admin', 'root']);
  }

  public function down()
  {
    $this->removePermission('EditModuleSettingsLogs');
    $this->removePermission('EditModuleSettingsNotifications');
    $this->removePermission('EditModuleSettingsPayments');
    $this->removePermission('EditModuleSettingsPages');
    $this->removePermission('EditModuleSettingsSupport');
    $this->removePermission('EditModuleSettingsUsers');
    $this->removePermission('EditModuleSettingsStatistic');
    $this->removePermission('EditModuleSettingsPromo');
    $this->removePermission('EditModuleSettingsPartners');

    $this->createOrGetPermission('CanResellerEditSettings', 'Edit Partners module settings');
    $this->assignRolesPermission('CanResellerEditSettings', ['admin', 'root', 'reseller', 'manager']);
  }
}
