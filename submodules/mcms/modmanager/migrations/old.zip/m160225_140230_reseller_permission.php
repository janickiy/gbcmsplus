<?php

use yii\db\Schema;
use console\components\Migration;

class m160225_140230_reseller_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Modmanager';
    $this->permissions = [
      'Modules' => [
        ['index', 'Can view list of installed modules', ['root', 'admin', 'reseller']],
        ['settings', 'Can edit module settings', ['root', 'admin', 'reseller']],
        ['messages', 'Can edit module settings', ['root', 'admin', 'reseller']],
      ],
      'Messages' => [
        ['edit', 'Can edit messages', ['root', 'admin', 'reseller']],
      ]
    ];
  }
}
