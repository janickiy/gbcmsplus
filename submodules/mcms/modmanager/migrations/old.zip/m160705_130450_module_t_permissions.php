<?php

use console\components\Migration;
use yii\helpers\BaseInflector;

class m160705_130450_module_t_permissions extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {

    foreach ($this->getModules() as $module => $roles) {
      $permission = 'EditModuleTranslations' . BaseInflector::camelize($module);
      $this->createOrGetPermission($permission, 'Edit module translations (' . $module . ')');
      $this->assignRolesPermission($permission, $roles);
    }

  }

  public function down()
  {
    foreach ($this->getModules() as $module => $roles) {
      $permission = 'EditModuleTranslations' . BaseInflector::camelize($module);
      $this->removePermission($permission);
    }
  }

  protected function getModules()
  {
    return [
      'logs' => ['root', 'admin'],
      'notifications' => ['root', 'admin'],
      'pages' => ['root', 'admin'],
      'partners' => ['root', 'admin',  'reseller'],
      'payments' => ['root', 'admin'],
      'promo' => ['root', 'admin'],
      'statistic' => ['root', 'admin'],
      'support' => ['root', 'admin'],
      'users' => ['root', 'admin']
    ];
  }
}
