<?php

use yii\db\Schema;
use console\components\Migration;

class m150730_000000_create_modules_table extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    if(!$this->tableExists('modules')) {
      $this->createTable('modules', [
        'id' => 'TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
        'module_id' => $this->string()->notNull()->unique(),
        'name' => $this->string(),
        'settings' => $this->text(),
        'is_disabled' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
        'created_at' => 'INT(10) UNSIGNED NOT NULL',
        'updated_at' => 'INT(10) UNSIGNED NOT NULL',
      ], $tableOptions);
    }
  }

  public function down()
  {
    $this->dropTable('modules');
  }

  public function tableExists($tableName){
    return in_array($tableName, Yii::$app->db->schema->tableNames);
  }

}
