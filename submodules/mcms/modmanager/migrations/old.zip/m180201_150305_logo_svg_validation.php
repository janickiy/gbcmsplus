<?php

use console\components\Migration;

class m180201_150305_logo_svg_validation extends Migration
{
  public function up()
  {
    $this->razreshitSvg('settings.logo_image');
    $this->razreshitSvg('settings.admin_panel_logo_image');
    $this->razreshitSvg('settings.logo_public');
  }

  public function down()
  {
    $this->vernutKakBilo('settings.logo_image');
    $this->vernutKakBilo('settings.admin_panel_logo_image');
    $this->vernutKakBilo('settings.logo_public');
  }

  public function razreshitSvg($code)
  {
    Yii::$app->settingsBuilder->updateValidators($code, [
      ['file', ['extensions' => ['jpeg', 'jpg', 'png', 'gif', 'svg'], 'mimeTypes' => 'image/*']],
    ]);
  }

  public function vernutKakBilo($code)
  {
    Yii::$app->settingsBuilder->updateValidators($code, [['image', ['extensions' => ['jpeg', 'jpg', 'png', 'gif', 'svg']]]]);
  }
}
