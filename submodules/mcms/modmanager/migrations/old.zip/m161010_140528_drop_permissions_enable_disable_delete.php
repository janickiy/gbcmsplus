<?php

use console\components\Migration;

class m161010_140528_drop_permissions_enable_disable_delete extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  const MODMANAGER_MODULES_ENABLE = 'ModmanagerModulesEnable';
  const MODMANAGER_MODULES_DISABLE = 'ModmanagerModulesDisable';
  const MODMANAGER_MODULES_DELETE = 'ModmanagerModulesDelete';

  /**
   * @inheritDoc
   */
  public function init()
  {
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->removePermission(self::MODMANAGER_MODULES_ENABLE);
    $this->removePermission(self::MODMANAGER_MODULES_DISABLE);
    $this->removePermission(self::MODMANAGER_MODULES_DELETE);
  }

  public function down()
  {
    if ($this->createOrGetPermission(self::MODMANAGER_MODULES_ENABLE, 'Can enable module')) {
      $this->assignRolesPermission(self::MODMANAGER_MODULES_ENABLE, ['root']);
    }
    if ($this->createOrGetPermission(self::MODMANAGER_MODULES_DISABLE, 'Can disable module')) {
      $this->assignRolesPermission(self::MODMANAGER_MODULES_DISABLE, ['root']);
    }
    if ($this->createOrGetPermission(self::MODMANAGER_MODULES_DELETE, 'Can delete module')) {
      $this->assignRolesPermission(self::MODMANAGER_MODULES_DELETE, ['root']);
    }
  }
}
