<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m161109_126946_group_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('ModmanagerModule', null);
    $this->createPermission('ModmanagerMessagesController', null, 'ModmanagerModule');
    $this->createPermission('ModmanagerModulesController', null, 'ModmanagerModule');
    $this->createPermission('ModmanagerPermissions', null, 'ModmanagerModule');

    $this->addChildPermission('ModmanagerMessagesController', 'ModmanagerMessagesEdit');
    $this->addChildPermission('ModmanagerMessagesController', 'ModmanagerMessagesView');

    $this->addChildPermission('ModmanagerModulesController', 'ModmanagerModulesAvailableList');
    $this->addChildPermission('ModmanagerModulesController', 'ModmanagerModulesMessages');
    $this->addChildPermission('ModmanagerModulesController', 'ModmanagerModulesIndex');
    $this->addChildPermission('ModmanagerModulesController', 'ModmanagerModulesInstall');
    $this->addChildPermission('ModmanagerModulesController', 'ModmanagerModulesSettings');

    $this->addChildPermission('ModmanagerPermissions', 'EditModuleSettingsLogs');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleSettingsNotifications');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleSettingsPages');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleSettingsPartners');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleSettingsPayments');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleSettingsPromo');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleSettingsPromoUrl');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleSettingsStatistic');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleSettingsSupport');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleSettingsUsers');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleTranslationsLogs');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleTranslationsNotifications');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleTranslationsPages');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleTranslationsPartners');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleTranslationsPayments');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleTranslationsPromo');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleTranslationsStatistic');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleTranslationsSupport');
    $this->addChildPermission('ModmanagerPermissions', 'EditModuleTranslationsUsers');
  }

  public function down()
  {
    $this->removePermission('ModmanagerMessagesController');
    $this->removePermission('ModmanagerModulesController');
    $this->removePermission('ModmanagerPermissions');
    $this->removePermission('ModmanagerModule');
  }
}
