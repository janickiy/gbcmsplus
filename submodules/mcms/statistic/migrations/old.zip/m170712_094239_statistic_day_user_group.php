<?php

use console\components\Migration;

class m170712_094239_statistic_day_user_group extends Migration
{
  public function up()
  {
    $this->addColumn('statistic_day_user_group', 'count_hits', 'MEDIUMINT(5) UNSIGNED NOT NULL AFTER user_id');
  }

  public function down()
  {
    $this->dropColumn('statistic_day_user_group', 'count_hits');
  }
}
