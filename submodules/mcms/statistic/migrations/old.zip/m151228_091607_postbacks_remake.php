<?php

use console\components\Migration;

class m151228_091607_postbacks_remake extends Migration
{

  const TABLE = 'postbacks';

  public function up()
  {
    $this->truncateTable(self::TABLE);

    $this->dropColumn(self::TABLE, 'item_id');
    $this->dropColumn(self::TABLE, 'item_type');

    $this->addColumn(self::TABLE, 'subscription_id', 'INT(10) UNSIGNED AFTER id');
    $this->addForeignKey(
      self::TABLE . '_' . 'subscription_id' . '_fk',
      self::TABLE,
      'subscription_id',
      'subscriptions',
      'id'
    );

    $this->addColumn(self::TABLE, 'subscription_rebill_id', 'INT(10) UNSIGNED AFTER subscription_id');
    $this->addForeignKey(
      self::TABLE . '_' . 'subscription_rebill_id' . '_fk',
      self::TABLE,
      'subscription_rebill_id',
      'subscription_rebills',
      'id'
    );

    $this->addColumn(self::TABLE, 'subscription_off_id', 'INT(10) UNSIGNED AFTER subscription_rebill_id');
    $this->addForeignKey(
      self::TABLE . '_' . 'subscription_off_id' . '_fk',
      self::TABLE,
      'subscription_off_id',
      'subscription_offs',
      'id'
    );

    $this->addColumn(self::TABLE, 'sold_subscription_id', 'INT(10) UNSIGNED AFTER subscription_off_id');
    $this->addForeignKey(
      self::TABLE . '_' . 'sold_subscription_id' . '_fk',
      self::TABLE,
      'sold_subscription_id',
      'sold_subscriptions',
      'id'
    );

    $this->addColumn(self::TABLE, 'onetime_subscription_id', 'INT(10) UNSIGNED AFTER sold_subscription_id');
    $this->addForeignKey(
      self::TABLE . '_' . 'onetime_subscription_id' . '_fk',
      self::TABLE,
      'onetime_subscription_id',
      'onetime_subscriptions',
      'id'
    );

    $this->createIndex('postbacks_' . 'subscription_id' . '_unique_index', self::TABLE, 'subscription_id', true);
    $this->createIndex('postbacks_' . 'subscription_rebill_id' . '_unique_index', self::TABLE, 'subscription_rebill_id', true);
    $this->createIndex('postbacks_' . 'subscription_off_id' . '_unique_index', self::TABLE, 'subscription_off_id', true);
    $this->createIndex('postbacks_' . 'sold_subscription_id' . '_unique_index', self::TABLE, 'sold_subscription_id', true);
    $this->createIndex('postbacks_' . 'onetime_subscription_id' . '_unique_index', self::TABLE, 'onetime_subscription_id', true);
  }

  public function down()
  {
    $this->truncateTable(self::TABLE);

    $this->dropForeignKey(self::TABLE . '_' . 'subscription_id' . '_fk', self::TABLE);
    $this->dropForeignKey(self::TABLE . '_' . 'subscription_rebill_id' . '_fk', self::TABLE);
    $this->dropForeignKey(self::TABLE . '_' . 'subscription_off_id' . '_fk', self::TABLE);
    $this->dropForeignKey(self::TABLE . '_' . 'sold_subscription_id' . '_fk', self::TABLE);
    $this->dropForeignKey(self::TABLE . '_' . 'onetime_subscription_id' . '_fk', self::TABLE);

    $this->dropIndex('postbacks_' . 'subscription_id' . '_unique_index', self::TABLE);
    $this->dropIndex('postbacks_' . 'subscription_rebill_id' . '_unique_index', self::TABLE);
    $this->dropIndex('postbacks_' . 'subscription_off_id' . '_unique_index', self::TABLE);
    $this->dropIndex('postbacks_' . 'sold_subscription_id' . '_unique_index', self::TABLE);
    $this->dropIndex('postbacks_' . 'onetime_subscription_id' . '_unique_index', self::TABLE);

    $this->dropColumn(self::TABLE, 'subscription_id');
    $this->dropColumn(self::TABLE, 'subscription_rebill_id');
    $this->dropColumn(self::TABLE, 'subscription_off_id');
    $this->dropColumn(self::TABLE, 'sold_subscription_id');
    $this->dropColumn(self::TABLE, 'onetime_subscription_id');
    $this->addColumn(self::TABLE, 'item_type', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT \'0\'');
    $this->addColumn(self::TABLE, 'item_id', 'INT(10) UNSIGNED NOT NULL');
  }
}
