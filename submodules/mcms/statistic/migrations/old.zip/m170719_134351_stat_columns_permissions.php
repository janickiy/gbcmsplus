<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170719_134351_stat_columns_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('CanViewResCpr', 'Разрешение на просмотр реселлерского CPR', 'StatisticPermissions');
    $this->createPermission('CanViewInvestorChargesOnDate', 'Разрешение на просмотр инвесторского Charges On Date', 'StatisticPermissions');
    $this->createPermission('CanViewInvestorChargeRatio', 'Разрешение на просмотр инвесторского Charge ratio', 'StatisticPermissions');
    $this->createPermission('CanViewInvestorProfitOnDate', 'Разрешение на просмотр инвесторского Profit on date', 'StatisticPermissions');
    $this->createPermission('CanViewInvestorRevSub', 'Разрешение на просмотр инвесторского REV SUB', 'StatisticPermissions');
    $this->createPermission('CanViewInvestorRoiOnDate', 'Разрешение на просмотр инвесторского ROI on date', 'StatisticPermissions');
  }

  public function down()
  {
    $this->removePermission('CanViewResCpr');
    $this->removePermission('CanViewInvestorChargesOnDate');
    $this->removePermission('CanViewInvestorChargeRatio');
    $this->removePermission('CanViewInvestorProfitOnDate');
    $this->removePermission('CanViewInvestorRevSub');
    $this->removePermission('CanViewInvestorRoiOnDate');
  }
}
