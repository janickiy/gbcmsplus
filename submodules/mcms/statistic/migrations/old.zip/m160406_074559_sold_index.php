<?php

use console\components\Migration;

class m160406_074559_sold_index extends Migration
{

  const TABLE = 'sold_subscriptions';
  const KEY_NAME = self::TABLE . '_user_id_operator_id_landing_id_index';

  public function up()
  {
    $this->createIndex(self::KEY_NAME, self::TABLE, ['user_id', 'operator_id', 'landing_id', 'date']);
  }

  public function down()
  {
    $this->dropIndex(self::KEY_NAME, self::TABLE);
  }
}
