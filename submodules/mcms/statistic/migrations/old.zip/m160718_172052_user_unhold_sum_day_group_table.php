<?php

use console\components\Migration;

class m160718_172052_user_unhold_sum_day_group_table extends Migration
{
  const TABLE = 'user_unhold_profit_day_group';

  public function up()
  {
    $this->createTable(self::TABLE, [
      'user_id' => 'MEDIUMINT(5) unsigned NOT NULL',
      'landing_id' => 'mediumint(5) unsigned NOT NULL',
      'date' => 'date NOT NULL',
      'sum_profit_rub' => 'DECIMAL(8,2) NOT NULL',
      'sum_profit_eur' => 'DECIMAL(8,2) NOT NULL',
      'sum_profit_usd' => 'DECIMAL(8,2) NOT NULL',
    ]);
    $this->addPrimaryKey('user_id_landing_id_date_pk', self::TABLE, ['user_id', 'landing_id', 'date']);
  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }
}
