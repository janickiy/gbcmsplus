<?php

use console\components\Migration;

class m170324_083626_affshark_statistic_fields extends Migration
{
  public function up()
  {
    $this->addColumn('subscriptions_day_group', 'count_rebills_date_by_date', 'MEDIUMINT(5) UNSIGNED NOT NULL AFTER count_rebills');
    $this->addColumn('subscriptions_day_hour_group', 'count_rebills_date_by_date', 'MEDIUMINT(5) UNSIGNED NOT NULL AFTER count_rebills');
  }

  public function down()
  {
    $this->dropColumn('subscriptions_day_group', 'count_rebills_date_by_date');
    $this->dropColumn('subscriptions_day_hour_group', 'count_rebills_date_by_date');
  }
}
