<?php

use admin\migrations\dbfix\SettingsTransferTrait;
use console\components\Migration;

class m160208_214720_new_settings extends Migration
{
  use SettingsTransferTrait;

  const SETTINGS_EXPORT_LIMIT = 'export_limit';
  const SETTINGS_EXPORT_POSTBACK_LIMIT = 'export_postback_limit';
  const SETTINGS_PARTNERS_EXPORT_POSTBACK_LIMIT = 'partner_export_postback_limit';
  const SETTINGS_PREDICT_SAMPLE_DAYS = 'predict_sample_days';
  const SETTINGS_DRIVER_TYPE = 'driver';
  const SETTINGS_DRIVER_TYPE_MYSQL = 'mysql';
  const SETTINGS_POSTBACK_MAX_ATTEMPTS = 'postback_max_attempts';
  const SETTINGS_POSTBACK_MAX_DAYS = 'postback_max_day';
  const SETTINGS_POSTBACK_TRANSFER_PHONE = 'postback_transfer_phone';
  const SETTINGS_POSTBACK_HASH_PHONE = 'postback_hash_phone';
  const SETTINGS_POSTBACK_HASH_SALT = 'postback_hash_salt';
  const SETTINGS_BUYOUT_MINUTES = 'buyout_minutes';
  const SETTINGS_POSTBACK_IS_CAMPAIGN_WITH_PRELAND = 'postback_is_campaign_with_preland';
  const SETTINGS_POSTBACK_CAMPAIGN_WITH_PRELAND_URL = 'postback_campaign_with_preland_url';
  const SETTINGS_ENABLE_LABEL_STAT = 'enable_label_stat';
  const SETTINGS_ENABLE_RATIO_BY_UNIQUES = 'enable_ratio_by_uniques';
  const SETTINGS_SUBSCRIPTION_OFFS_SCOPE = 'subscription_offs_scope';
  const SETTINGS_AUTO_SUBMIT = 'auto_submit';
  const SETTINGS_RETURN_SUBSCRIPTION_AFTER_COMPLAINT = 'return_subscription_after_complaint';
  const STATISTIC_MAIN_HOUR = 'hour';
  const STATISTIC_MAIN_DATE = 'date';
  const STATISTIC_DETAIL_SUBSCRIPTIONS = 'subscriptions';
  const STATISTIC_DETAIL_IK = 'ik';
  const STATISTIC_DETAIL_SELLS = 'sells';
  const SETTINGS_CPA_DIFF_CALC_DAYS = 'cpa_diff_calc_days';
  const SETTINGS_UNIQUE_BUYOUT_HOURS = 'unique_buyout_hours';
  const SETTINGS_PARTNER_VIEW_TEXT_COMPLAIN = 'partner_view_text_complain';
  const SETTINGS_PARTNER_VIEW_CALL_COMPLAIN = 'partner_view_call_complain';
  const SETTINGS_PARTNER_VIEW_AUTO24_COMPLAIN = 'partner_view_auto24_complain';
  const SETTINGS_PARTNER_VIEW_AUTO_MOMENT_COMPLAIN = 'partner_view_auto_moment_complain';
  const SETTINGS_PARTNER_VIEW_AUTO_DUPLICATE_COMPLAIN = 'partner_view_auto_duplicate_complain';

  const MODULE_ID = 'statistic';

  const SETTINGS_TABLE = 'rgk_settings';
  const PERMISSIONS_TABLE = 'rgk_settings_permissions';
  const OPTIONS_TABLE = 'rgk_settings_options';
  const VALUES_TABLE = 'rgk_settings_values';

  public function up()
  {
    $this->insertValues();
  }

  public function down()
  {

  }

  private function getRepository()
  {
    return (new admin\migrations\dbfix\Repository())
      ->set(
        (new admin\migrations\dbfix\Options())
          ->setKey(self::SETTINGS_DRIVER_TYPE)
          ->setName('statistic.main.driver_type')
          ->setOption(
            self::SETTINGS_DRIVER_TYPE_MYSQL,
            'statistic.main.driver_type_mysql'
          )
          ->setValue(self::SETTINGS_DRIVER_TYPE_MYSQL)
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\Integer())
          ->setKey(self::SETTINGS_POSTBACK_MAX_ATTEMPTS)
          ->setName('statistic.main.postback_max_attempts')
          ->setValue(3)
          ->setGroup(['name' => 'app.common.group_links', 'sort' => 7])
          ->setFormGroup(['name' => 'app.common.form_group_postbacks', 'sort' => 1])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\Integer())
          ->setKey(self::SETTINGS_POSTBACK_MAX_DAYS)
          ->setName('statistic.main.postback_max_days')
          ->setHint('statistic.main.postback_max_days-hint')
          ->setValue(3)
          ->setGroup(['name' => 'app.common.group_links', 'sort' => 7])
          ->setFormGroup(['name' => 'app.common.form_group_postbacks', 'sort' => 1])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setKey(self::SETTINGS_POSTBACK_TRANSFER_PHONE)
          ->setName('statistic.main.settings_postback_transfer_phone')
          ->setValue(false)
          ->setGroup(['name' => 'app.common.group_links', 'sort' => 7])
          ->setFormGroup(['name' => 'app.common.form_group_postbacks', 'sort' => 1])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setKey(self::SETTINGS_POSTBACK_HASH_PHONE)
          ->setName('statistic.main.settings_postback_hash_phone')
          ->setValue(false)
          ->setGroup(['name' => 'app.common.group_links', 'sort' => 7])
          ->setFormGroup(['name' => 'app.common.form_group_postbacks', 'sort' => 1])
          ->setSort(4)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setKey(self::SETTINGS_POSTBACK_HASH_SALT)
          ->setName('statistic.main.settings_postback_hash_salt')
          ->setValidators([['required'], ['string', ['min' => 22]]])
          ->setGroup(['name' => 'app.common.group_links', 'sort' => 7])
          ->setFormGroup(['name' => 'app.common.form_group_postbacks', 'sort' => 1])
          ->setSort(5)
          ->setDependency(['attribute' => self::SETTINGS_POSTBACK_HASH_PHONE, 'value' => true])
      )
      ->set(
        (new admin\migrations\dbfix\Integer())
          ->setKey(self::SETTINGS_BUYOUT_MINUTES)
          ->setName('statistic.main.setting_buyout_minutes')
          ->setHint('statistic.main.setting_buyout_minutes-hint')
          ->setValue(1)
          ->setGroup(['name' => 'app.common.group_buyouts_rebills', 'sort' => 2])
          ->setSort(1)
      )->set(
        (new admin\migrations\dbfix\Integer())
          ->setKey(self::SETTINGS_UNIQUE_BUYOUT_HOURS)
          ->setName('statistic.main.setting_unique_buyout_hours')
          ->setValue(24)
          ->setGroup(['name' => 'app.common.group_buyouts_rebills', 'sort' => 2])
      )->set(
        (new admin\migrations\dbfix\Boolean())
          ->setKey(self::SETTINGS_ENABLE_LABEL_STAT)
          ->setName('statistic.main.setting_enable_label_stat')
          ->setValue(true)
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setSort(1)
      )->set(
        (new admin\migrations\dbfix\Boolean())
          ->setKey(self::SETTINGS_ENABLE_RATIO_BY_UNIQUES)
          ->setName('statistic.main.setting_enable_ratio_by_uniques')
          ->setValue(false)
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setSort(2)
      )->set(
        (new admin\migrations\dbfix\Boolean())
          ->setKey(self::SETTINGS_AUTO_SUBMIT)
          ->setName('statistic.main.setting_auto_submit')
          ->setValue(true)
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setSort(1)
      )->set(
        (new admin\migrations\dbfix\Boolean())
          ->setKey(self::SETTINGS_RETURN_SUBSCRIPTION_AFTER_COMPLAINT)
          ->setName('statistic.main.setting_return_subscription_after_complaint')
          ->setValue(true)
          ->setGroup(['name' => 'app.common.group_buyouts_rebills', 'sort' => 2])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\Integer())
          ->setKey(self::SETTINGS_PREDICT_SAMPLE_DAYS)
          ->setName('statistic.main.setting_predict_sample_days')
          ->setHint('statistic.main.setting_predict_sample_days_hint')
          ->setValue(1)
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\Integer())
          ->setKey(self::SETTINGS_CPA_DIFF_CALC_DAYS)
          ->setName('statistic.main.setting_cpa_diff_calc_days')
          ->setValue(3)
          ->setHint('statistic.main.setting_cpa_diff_calc_days_hint')
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setSort(4)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('statistic.main.export_limit')
          ->setValue(\mcms\common\grid\ExportMenu::DEFAULT_LIMIT)
          ->setKey(self::SETTINGS_EXPORT_LIMIT)
          ->setValidators([['integer']])
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_export', 'sort' => 1])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('statistic.main.export_postback_limit')
          ->setValue(\mcms\common\grid\ExportMenu::DEFAULT_LIMIT)
          ->setKey(self::SETTINGS_EXPORT_POSTBACK_LIMIT)
          ->setValidators([['integer']])
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_export', 'sort' => 1])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('statistic.main.partner_export_postback_limit')
          ->setValue(\mcms\common\grid\ExportMenu::DEFAULT_LIMIT)
          ->setKey(self::SETTINGS_PARTNERS_EXPORT_POSTBACK_LIMIT)
          ->setValidators([['integer']])
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_export', 'sort' => 1])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\Integer())
          ->setName('statistic.main.subscription_offs_scope')
          ->setValue(24)
          ->setKey(self::SETTINGS_SUBSCRIPTION_OFFS_SCOPE)
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setSort(5)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setKey(self::SETTINGS_POSTBACK_IS_CAMPAIGN_WITH_PRELAND)
          ->setName('statistic.main.settings_postback_is_campaign_with_preland')
          ->setValue(false)
          ->setGroup(['name' => 'app.common.group_links', 'sort' => 7])
          ->setFormGroup(['name' => 'app.common.form_group_postbacks', 'sort' => 1])
          ->setSort(6)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setKey(self::SETTINGS_POSTBACK_CAMPAIGN_WITH_PRELAND_URL)
          ->setName('statistic.main.settings_postback_campaign_with_preland_url')
          ->setValidators([['string'], ['url']])
          ->setGroup(['name' => 'app.common.group_links', 'sort' => 7])
          ->setFormGroup(['name' => 'app.common.form_group_postbacks', 'sort' => 1])
          ->setSort(7)
      )->set(
        (new admin\migrations\dbfix\Boolean())
          ->setKey(self::SETTINGS_PARTNER_VIEW_TEXT_COMPLAIN)
          ->setName('statistic.statistic.complain_type_text')
          ->setValue(true)
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_partner_complains', 'sort' => 4])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setKey(self::SETTINGS_PARTNER_VIEW_CALL_COMPLAIN)
          ->setName('statistic.statistic.complain_type_call')
          ->setValue(true)
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_partner_complains', 'sort' => 4])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setKey(self::SETTINGS_PARTNER_VIEW_AUTO24_COMPLAIN)
          ->setName('statistic.statistic.complain_type_auto_24')
          ->setValue(false)
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_partner_complains', 'sort' => 4])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setKey(self::SETTINGS_PARTNER_VIEW_AUTO_MOMENT_COMPLAIN)
          ->setName('statistic.statistic.complain_type_auto_moment')
          ->setValue(false)
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_partner_complains', 'sort' => 4])
          ->setSort(4)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setKey(self::SETTINGS_PARTNER_VIEW_AUTO_DUPLICATE_COMPLAIN)
          ->setName('statistic.statistic.complain_type_auto_duplicate')
          ->setValue(false)
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setFormGroup(['name' => 'app.common.form_group_partner_complains', 'sort' => 4])
          ->setSort(5)
      );
  }
}
