<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
*/
class m181019_135337_ltv_permissions extends Migration
{
  use PermissionTrait;
  /**
  */
  public function up()
  {
    $this->removePermission('StatisticFilterByLTV');
  }

  /**
  */
  public function down()
  {
    $this->createPermission('StatisticFilterByLTV', 'Просмотр фильтра по LTV', 'StatisticFilter');
    $this->assignRolesPermission('StatisticFilterByLTV', ['reseller']);
  }
}
