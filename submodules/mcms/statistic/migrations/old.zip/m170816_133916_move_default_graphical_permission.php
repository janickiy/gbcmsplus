<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170816_133916_move_default_graphical_permission extends Migration
{
  use PermissionTrait;
  
  public function up()
  {
    $this->movePermission('StatisticDefaultGraphical', 'StatisticDefaultIndex', 'StatisticDefaultController');
  }
  
  public function down()
  {
    $this->movePermission('StatisticDefaultGraphical', 'StatisticDefaultController', 'StatisticDefaultIndex');
  }
}
