<?php

use console\components\Migration;

class m180525_083144_columns_templates_refactor extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  const TABLE_NAME = 'columns_templates_refactored';

  public function up()
  {
    // Создание прав для нового контроллера
    $this->createPermission('StatisticColumnTemplatesRefactoredController', 'Контроллер ColumnTemplatesRefactored', 'StatisticModule');
    $this->createPermission('StatisticColumnTemplatesRefactoredCreate', 'Создание шаблона для столбцов таблицы', 'StatisticColumnTemplatesRefactoredController', ['admin', 'root', 'reseller']);
    $this->createPermission('StatisticColumnTemplatesRefactoredUpdate', 'Изменение шаблона для столбцов таблицы', 'StatisticColumnTemplatesRefactoredController', ['admin', 'root', 'reseller']);
    $this->createPermission('StatisticColumnTemplatesRefactoredDelete', 'Удаление шаблона для столбцов таблицы', 'StatisticColumnTemplatesRefactoredController', ['admin', 'root', 'reseller']);
    $this->createPermission('StatisticColumnTemplatesRefactoredGetTemplate', 'Получение списка шаблонов', 'StatisticColumnTemplatesRefactoredController', ['admin', 'root', 'reseller']);

    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(self::TABLE_NAME, [
      'id' => $this->primaryKey(5),
      'user_id' => 'MEDIUMINT(5) unsigned NOT NULL',
      'name' => $this->string(255)->notNull(),
      'columns' => $this->text()->notNull(),
    ], $tableOptions);

  }

  public function down()
  {
    $this->removePermission('StatisticColumnTemplatesRefactoredController');
    $this->removePermission('StatisticColumnTemplatesRefactoredCreate');
    $this->removePermission('StatisticColumnTemplatesRefactoredUpdate');
    $this->removePermission('StatisticColumnTemplatesRefactoredDelete');
    $this->removePermission('StatisticColumnTemplatesRefactoredGetTemplate');

    $this->dropTable(self::TABLE_NAME);
  }
}
