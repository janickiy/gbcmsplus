<?php

use console\components\Migration;

class m180323_121916_refactor_dash extends Migration
{
  const TABLE_DL = 'dashboard_landings';
  const TABLE_DPO = 'dashboard_profits_ons';

  public function up()
  {
    $this->addColumn(self::TABLE_DL,'count_ons_revshare','MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL');
    $this->addColumn(self::TABLE_DL,'count_ons_rejected','MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL');
    $this->addColumn(self::TABLE_DL,'count_ons_cpa','MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL');

    $this->dropColumn(self::TABLE_DL,'count_sold');
    $this->dropColumn(self::TABLE_DL,'count_ons');


    $this->addColumn(self::TABLE_DPO,'count_ons_revshare','MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'count_ons_rejected','MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'count_ons_cpa','MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL');

    $this->dropColumn(self::TABLE_DPO,'count_sold');
    $this->dropColumn(self::TABLE_DPO,'count_ons');


    $this->dropColumn(self::TABLE_DPO,'investor_buyout_price_rub');
    $this->dropColumn(self::TABLE_DPO,'investor_buyout_price_usd');
    $this->dropColumn(self::TABLE_DPO,'investor_buyout_price_eur');

    $this->dropColumn(self::TABLE_DPO,'partner_sold_price_rub');
    $this->dropColumn(self::TABLE_DPO,'partner_sold_price_usd');
    $this->dropColumn(self::TABLE_DPO,'partner_sold_price_eur');

    $this->addColumn(self::TABLE_DPO,'res_revshare_profit_rub','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'res_revshare_profit_usd','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'res_revshare_profit_eur','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');

    $this->addColumn(self::TABLE_DPO,'res_rejected_profit_rub','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'res_rejected_profit_usd','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'res_rejected_profit_eur','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');

    $this->addColumn(self::TABLE_DPO,'res_sold_profit_rub','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'res_sold_profit_usd','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'res_sold_profit_eur','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');

    $this->addColumn(self::TABLE_DPO,'partner_revshare_profit_rub','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'partner_revshare_profit_usd','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'partner_revshare_profit_eur','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');

    $this->addColumn(self::TABLE_DPO,'partner_rejected_profit_rub','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'partner_rejected_profit_usd','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'partner_rejected_profit_eur','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');

    $this->dropColumn(self::TABLE_DPO,'real_profit_rub');
    $this->dropColumn(self::TABLE_DPO,'real_profit_usd');
    $this->dropColumn(self::TABLE_DPO,'real_profit_eur');

    $this->dropColumn(self::TABLE_DPO,'partner_profit_rub');
    $this->dropColumn(self::TABLE_DPO,'partner_profit_usd');
    $this->dropColumn(self::TABLE_DPO,'partner_profit_eur');

    $this->dropColumn(self::TABLE_DPO,'res_profit_rub');
    $this->dropColumn(self::TABLE_DPO,'res_profit_usd');
    $this->dropColumn(self::TABLE_DPO,'res_profit_eur');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE_DL,'count_ons_revshare');
    $this->dropColumn(self::TABLE_DL,'count_ons_rejected');
    $this->dropColumn(self::TABLE_DL,'count_ons_cpa');

    $this->addColumn(self::TABLE_DL,'count_sold','MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL');
    $this->addColumn(self::TABLE_DL,'count_ons','MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL');

    $this->dropColumn(self::TABLE_DPO,'count_ons_revshare');
    $this->dropColumn(self::TABLE_DPO,'count_ons_rejected');
    $this->dropColumn(self::TABLE_DPO,'count_ons_cpa');

    $this->addColumn(self::TABLE_DPO,'count_sold','MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'count_ons','MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL');

    $this->addColumn(self::TABLE_DPO,'investor_buyout_price_rub','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'investor_buyout_price_usd','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'investor_buyout_price_eur','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');

    $this->addColumn(self::TABLE_DPO,'partner_sold_price_rub','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'partner_sold_price_usd','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'partner_sold_price_eur','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');

    $this->dropColumn(self::TABLE_DPO,'res_revshare_profit_rub');
    $this->dropColumn(self::TABLE_DPO,'res_revshare_profit_usd');
    $this->dropColumn(self::TABLE_DPO,'res_revshare_profit_eur');

    $this->dropColumn(self::TABLE_DPO,'res_rejected_profit_rub');
    $this->dropColumn(self::TABLE_DPO,'res_rejected_profit_usd');
    $this->dropColumn(self::TABLE_DPO,'res_rejected_profit_eur');

    $this->dropColumn(self::TABLE_DPO,'res_sold_profit_rub');
    $this->dropColumn(self::TABLE_DPO,'res_sold_profit_usd');
    $this->dropColumn(self::TABLE_DPO,'res_sold_profit_eur');

    $this->dropColumn(self::TABLE_DPO,'partner_revshare_profit_rub');
    $this->dropColumn(self::TABLE_DPO,'partner_revshare_profit_usd');
    $this->dropColumn(self::TABLE_DPO,'partner_revshare_profit_eur');

    $this->dropColumn(self::TABLE_DPO,'partner_rejected_profit_rub');
    $this->dropColumn(self::TABLE_DPO,'partner_rejected_profit_usd');
    $this->dropColumn(self::TABLE_DPO,'partner_rejected_profit_eur');

    $this->addColumn(self::TABLE_DPO,'real_profit_rub','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'real_profit_usd','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'real_profit_eur','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');

    $this->addColumn(self::TABLE_DPO,'partner_profit_rub','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'partner_profit_usd','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'partner_profit_eur','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');

    $this->addColumn(self::TABLE_DPO,'res_profit_rub','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'res_profit_usd','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'res_profit_eur','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
  }
}
