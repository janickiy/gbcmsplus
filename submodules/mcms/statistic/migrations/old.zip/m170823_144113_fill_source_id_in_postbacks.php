<?php

use console\components\Migration;

class m170823_144113_fill_source_id_in_postbacks extends Migration
{
  public function up()
  {
    Yii::$app->db->createCommand("
      INSERT INTO postbacks (id, url, time, last_time, source_id)
        SELECT
          postbacks.id,
          postbacks.url,
          postbacks.time,
          postbacks.last_time,
          CASE
          WHEN subscription_id IS NOT NULL
            THEN st.source_id
          WHEN subscription_rebill_id IS NOT NULL
            THEN srt.source_id
          WHEN subscription_off_id IS NOT NULL
            THEN sot.source_id
          WHEN sold_subscription_id IS NOT NULL
            THEN sst.source_id
          WHEN onetime_subscription_id IS NOT NULL
            THEN ost.source_id
          END AS source_id
        FROM postbacks
          LEFT JOIN subscriptions st ON st.id = subscription_id
          LEFT JOIN subscription_rebills srt ON srt.id = subscription_rebill_id
          LEFT JOIN subscription_offs sot ON sot.id = subscription_off_id
          LEFT JOIN sold_subscriptions sst ON sst.id = sold_subscription_id
          LEFT JOIN onetime_subscriptions ost ON ost.id = onetime_subscription_id
      ON DUPLICATE KEY UPDATE
        source_id = VALUES(source_id);
    ")->execute();
  }

  public function down()
  {
    Yii::$app->db->createCommand("
      INSERT INTO postbacks (id, url, time, last_time, source_id)
        SELECT
          postbacks.id,
          postbacks.url,
          postbacks.time,
          postbacks.last_time,
          NULL AS source_id
        FROM postbacks 
      ON DUPLICATE KEY UPDATE
        source_id = VALUES(source_id);
    ")->execute();
  }
}
