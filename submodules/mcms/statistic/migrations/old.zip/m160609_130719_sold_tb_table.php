<?php

use console\components\Migration;

class m160609_130719_sold_tb_table extends Migration
{

  const TABLE = 'sold_trafficback';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::TABLE, [
      'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'hit_id' => 'INT(10) UNSIGNED NOT NULL',
      'trans_id' => 'VARCHAR(64) NOT NULL',
      'time' => 'INT(10) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'hour' => 'TINYINT(1) UNSIGNED NOT NULL',
      'default_profit' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'default_profit_currency' => 'TINYINT(1) UNSIGNED NOT NULL',
      'currency_id' => 'tinyint(1) unsigned NOT NULL COMMENT \'оригинальная валюта\'',
      'real_profit_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'real_profit_eur' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'real_profit_usd' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'reseller_profit_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'reseller_profit_eur' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'reseller_profit_usd' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'profit_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'profit_eur' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'profit_usd' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'provider_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'stream_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'label1' => 'VARCHAR(512) DEFAULT NULL',
      'label2' => 'VARCHAR(512) DEFAULT NULL',
      'phone' => 'VARCHAR(16) NOT NULL',
      'ip' => 'BIGINT(12) NULL',
    ], $tableOptions);

    $this->createIndex('sold_trafficback_hit_id_unique', self::TABLE, 'hit_id', true);
//    $this->createIndex('sold_trafficback_group_by_date', self::TABLE, ['date', 'user_id', 'profit_rub', 'profit_eur', 'profit_usd']);


  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
