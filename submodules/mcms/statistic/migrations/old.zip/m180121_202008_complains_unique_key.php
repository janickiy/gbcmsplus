<?php

use console\components\Migration;

class m180121_202008_complains_unique_key extends Migration
{
  public function up()
  {
    $this->dropIndex('complains_hit_id_uk', 'complains');
    $this->createIndex('complains_hit_id_type_uk', 'complains', ['hit_id','type'], true);
  }

  public function down()
  {
    $this->dropIndex('complains_hit_id_type_uk', 'complains');
    $this->createIndex('complains_hit_id_uk', 'complains', 'hit_id', true);
  }

}
