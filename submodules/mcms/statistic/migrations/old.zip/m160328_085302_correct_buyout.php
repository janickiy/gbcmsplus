<?php

use console\components\Migration;

class m160328_085302_correct_buyout extends Migration
{

  const CONDITIONS = 'buyout_correct_conditions';
  const LOG = 'buyout_correct_history';

  public function up()
  {
    $this->createTable(self::CONDITIONS, [
      'id' => 'mediumint(5) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'investor_id' => 'mediumint(5) unsigned DEFAULT NULL',
      'partner_id' => 'mediumint(5) unsigned DEFAULT NULL',
      'operator_id' => 'mediumint(5) unsigned DEFAULT NULL',
      'landing_id' => 'mediumint(5) unsigned DEFAULT NULL',
      'percent' => 'decimal(5,2) NOT NULL',
      'created_by' => 'mediumint(5) unsigned NOT NULL',
      'created_at' => 'int(10) unsigned NOT NULL',
      'updated_at' => 'int(10) unsigned DEFAULT NULL'
    ]);

    $this->addForeignKey(self::CONDITIONS . '_investor_id_fk', self::CONDITIONS, 'investor_id', 'users', 'id');
    $this->addForeignKey(self::CONDITIONS . '_partner_id_fk', self::CONDITIONS, 'partner_id', 'users', 'id');
    $this->addForeignKey(self::CONDITIONS . '_operator_id_fk', self::CONDITIONS, 'operator_id', 'operators', 'id');
    $this->addForeignKey(self::CONDITIONS . '_landing_id_fk', self::CONDITIONS, 'landing_id', 'landings', 'id');

    $this->createTable(self::LOG, [
      'id' => 'int(10) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'hit_id' => 'int(10) unsigned NOT NULL',
      'time' => 'int(10) unsigned NOT NULL',
      'date' => 'date NOT NULL',
      'hour' => 'tinyint(1) unsigned NOT NULL',
      'stream_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'source_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'user_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'to_stream_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'to_source_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'to_user_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'landing_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'operator_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'platform_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'landing_pay_type_id' => 'tinyint(1) unsigned NOT NULL DEFAULT \'0\'',
      'provider_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'country_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
    ]);

    $this->createIndex(self::LOG . '_hit_id_unique', self::LOG, 'hit_id', true);
  }

  public function down()
  {
    $this->dropTable(self::LOG);
    $this->dropTable(self::CONDITIONS);
  }
}
