<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
 */
class m180917_093216_postbacks_hit_id extends Migration
{
  const TABLE = 'postbacks';
  use PermissionTrait;

  /**
   */
  public function up()
  {
    $this->addColumn(self::TABLE,'hit_id', 'BIGINT(20) UNSIGNED NOT NULL AFTER id');

    echo 'Update postbacks subscriptions hit_id' . PHP_EOL;
    $this->db->createCommand('UPDATE postbacks p INNER JOIN subscriptions s 
        ON s.id = p.subscription_id
        SET p.hit_id = s.hit_id 
    WHERE p.subscription_id IS NOT NULL')->execute();

    echo 'Update postbacks subscription_rebills hit_id' . PHP_EOL;
    $this->db->createCommand('UPDATE postbacks p INNER JOIN subscription_rebills s 
        ON s.id = p.subscription_rebill_id
        SET p.hit_id = s.hit_id 
    WHERE p.subscription_rebill_id IS NOT NULL')->execute();

    echo 'Update postbacks subscription_offs hit_id' . PHP_EOL;
    $this->db->createCommand('UPDATE postbacks p INNER JOIN subscription_offs s 
        ON s.id = p.subscription_off_id
        SET p.hit_id = s.hit_id 
    WHERE p.subscription_off_id IS NOT NULL')->execute();

    echo 'Update postbacks sold_subscriptions hit_id' . PHP_EOL;
    $this->db->createCommand('UPDATE postbacks p INNER JOIN sold_subscriptions s 
        ON s.id = p.sold_subscription_id
        SET p.hit_id = s.hit_id 
    WHERE p.sold_subscription_id IS NOT NULL')->execute();

    echo 'Update postbacks onetime_subscriptions hit_id' . PHP_EOL;
    $this->db->createCommand('UPDATE postbacks p INNER JOIN onetime_subscriptions s 
        ON s.id = p.onetime_subscription_id
        SET p.hit_id = s.hit_id 
    WHERE p.onetime_subscription_id IS NOT NULL')->execute();

    echo 'Update postbacks complains hit_id' . PHP_EOL;
    $this->db->createCommand('UPDATE postbacks p INNER JOIN complains s 
        ON s.id = p.complain_id
        SET p.hit_id = s.hit_id 
    WHERE p.complain_id IS NOT NULL')->execute();

  }

  /**
   */
  public function down()
  {
    $this->dropColumn(self::TABLE, 'hit_id');
  }
}
