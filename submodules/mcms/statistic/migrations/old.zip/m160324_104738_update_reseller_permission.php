<?php

use console\components\Migration;

class m160324_104738_update_reseller_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->createOrGetPermission('StatisticDetailIkDetail', 'View detail info by ik');
    $this->assignRolesPermission('StatisticDetailIkDetail', ['root', 'admin', 'reseller', 'investor']);
    $this->createOrGetPermission('StatisticDetailSellsDetail', 'View detail info by sell');
    $this->assignRolesPermission('StatisticDetailSellsDetail', ['root', 'admin', 'reseller', 'investor']);

  }

  public function down()
  {
    $this->createOrGetPermission('StatisticDetailIkDetail', 'View detail info by ik');
    $this->assignRolesPermission('StatisticDetailIkDetail', ['root', 'admin', 'investor']);
    $this->createOrGetPermission('StatisticDetailSellsDetail', 'View detail info by ik');
    $this->assignRolesPermission('StatisticDetailSellsDetail', ['root', 'admin', 'investor']);
  }
}
