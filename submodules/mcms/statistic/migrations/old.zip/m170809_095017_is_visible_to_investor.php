<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170809_095017_is_visible_to_investor extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('IsVisibleToInvestor', 'Доступна ли колонка инвестору', 'StatisticPermissions', ['investor']);
  }

  public function down()
  {
    $this->removePermission('IsVisibleToInvestor');
  }
}
