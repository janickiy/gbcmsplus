<?php

use console\components\Migration;

class m170629_100746_reseler_prof_description extends Migration
{
  public function up()
  {
    $this->addColumn('reseller_profits', 'description', 'text COMMENT \'служебная информация. Например описание даты расхолда\' AFTER unhold_month_start');
  }

  public function down()
  {
    $this->dropColumn('reseller_profits', 'description');
  }

}
