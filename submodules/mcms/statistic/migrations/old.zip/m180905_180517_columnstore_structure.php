<?php

use console\components\Migration;
use mcms\common\helpers\Console;
use rgk\utils\traits\PermissionTrait;

/**
 */
class m180905_180517_columnstore_structure extends Migration
{
  use PermissionTrait;

  const TABLE_HITS = 'hits';
  const TABLE_OFFS = 'subscription_offs';
  const TABLE_ONETIME = 'onetime_subscriptions';
  const TABLE_REBILLS = 'subscription_rebills';
  const TABLE_SOLD = 'sold_subscriptions';
  const TABLE_SUBS = 'subscriptions';

  public function init()
  {
    $this->db = 'dbCs';
    parent::init();
  }

  /**
   */
  public function up()
  {
    if (!Console::confirm('Для выполнения миграции необходим настроенный MariaDB ColumnStore. Продолжаем?', false)) {
      return true;
    }

    $tableOptions = 'default character set = latin1 ENGINE=columnstore';

    $this->createTable(self::TABLE_HITS, [
      'id' => 'BIGINT(10) UNSIGNED NOT NULL',
      'is_unique' => 'tinyint unsigned default 0 not null',
      'is_tb' => 'tinyint unsigned default 0 not null',
      'time' => 'int unsigned not null',
      'date' => 'date not null',
      'hour' => 'tinyint unsigned not null',
      'operator_id' => 'smallint unsigned default 0 not null',
      'country_id' => 'smallint unsigned default 0 not null',
      'landing_id' => 'smallint unsigned default 0 not null',
      'provider_id' => 'smallint unsigned default 0 not null',
      'source_id' => 'smallint unsigned default 0 not null',
      'source_type' => 'tinyint unsigned default 2 not null',
      'user_id' => 'smallint unsigned default 0 not null',
      'stream_id' => 'smallint unsigned default 0 not null',
      'platform_id' => 'smallint unsigned default 0 not null',
      'landing_pay_type_id' => 'tinyint unsigned default 0 not null',
      'is_cpa' => 'tinyint unsigned default 0',
      'ip' => 'bigint',
      'referer' => 'varchar(512)',
      'user_agent' => 'varchar(512)',
      'label1' => 'varchar(512)',
      'label2' => 'varchar(512)'
    ], $tableOptions
    );

    $this->createTable(self::TABLE_OFFS, [
      'id' => 'INT UNSIGNED NOT NULL',
      'hit_id' => 'bigint unsigned not null',
      'trans_id' => 'varchar(64)',
      'time' => 'int unsigned',
      'date' => 'date',
      'hour' => 'tinyint unsigned',
      'is_fake' => 'tinyint unsigned'
    ], $tableOptions
    );

    $this->createTable(self::TABLE_ONETIME, [
      'id' => 'INT UNSIGNED NOT NULL',
      'hit_id' => 'bigint unsigned not null',
      'trans_id' => 'varchar(64)',
      'time' => 'int unsigned',
      'date' => 'date',
      'hour' => 'tinyint unsigned',
      'profit_rub' => 'decimal(9, 5) unsigned not null',
      'profit_usd' => 'decimal(9, 5) unsigned not null',
      'profit_eur' => 'decimal(9, 5) unsigned not null',
      'is_visible_to_partner' => 'tinyint unsigned not null default 1',
    ], $tableOptions
    );

    $this->createTable(self::TABLE_REBILLS, [
      'id' => 'INT UNSIGNED NOT NULL',
      'hit_id' => 'bigint unsigned not null',
      'trans_id' => 'varchar(64)',
      'time' => 'int unsigned',
      'date' => 'date',
      'hour' => 'tinyint unsigned',
      'profit_rub' => 'decimal(9, 5) unsigned not null',
      'profit_usd' => 'decimal(9, 5) unsigned not null',
      'profit_eur' => 'decimal(9, 5) unsigned not null'
    ], $tableOptions
    );

    $this->createTable(self::TABLE_SOLD, [
      'id' => 'INT UNSIGNED NOT NULL',
      'hit_id' => 'bigint unsigned not null',
      'time' => 'int unsigned',
      'date' => 'date',
      'hour' => 'tinyint unsigned',
      'profit_rub' => 'decimal(9, 5) unsigned not null',
      'profit_usd' => 'decimal(9, 5) unsigned not null',
      'profit_eur' => 'decimal(9, 5) unsigned not null',
      'is_visible_to_partner' => 'tinyint unsigned not null default 1',
    ], $tableOptions
    );

    $this->createTable(self::TABLE_SUBS, [
      'id' => 'INT UNSIGNED NOT NULL',
      'hit_id' => 'bigint unsigned not null',
      'trans_id' => 'varchar(64)',
      'time' => 'int unsigned',
      'date' => 'date',
      'hour' => 'tinyint unsigned',
      'is_fake' => 'tinyint unsigned'
    ], $tableOptions
    );

  }

  /**
   */
  public function down()
  {
    $this->dropTable(self::TABLE_SUBS);
    $this->dropTable(self::TABLE_SOLD);
    $this->dropTable(self::TABLE_REBILLS);
    $this->dropTable(self::TABLE_ONETIME);
    $this->dropTable(self::TABLE_OFFS);
    $this->dropTable(self::TABLE_HITS);
  }
}
