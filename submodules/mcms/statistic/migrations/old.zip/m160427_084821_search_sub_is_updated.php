<?php

use console\components\Migration;

class m160427_084821_search_sub_is_updated extends Migration
{
  public function up()
  {
    $this->addColumn('search_subscriptions', 'is_updated', "tinyint(1) unsigned DEFAULT '0' COMMENT 'строка заполнилась в кроне полностью'");

    $this->createIndex('search_subscriptions_is_updated_index', 'search_subscriptions', 'is_updated');

    $this->update('search_subscriptions', ['is_updated' => 1]);
  }

  public function down()
  {
    $this->dropColumn('search_subscriptions', 'is_updated');
  }
}
