<?php

use console\components\Migration;

class m171213_141327_template_columns extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  const STATISTIC_DEFAULT_DELETE_COLUMNS_TEMPLATE = 'StatisticDefaultDeleteColumnsTemplate';
  const COLUMNS_TEMPLATES = 'columns_templates';
  const IS_SYSTEM = 'is_system';

  public function up()
  {
    $this->delete(self::COLUMNS_TEMPLATES, ['is_system' => 1]);
    $this->dropColumn(self::COLUMNS_TEMPLATES, self::IS_SYSTEM);

    $this->createPermission(
      self::STATISTIC_DEFAULT_DELETE_COLUMNS_TEMPLATE,
      'Удаление шаблона для столбцов таблицы',
      'StatisticDefaultIndex',
      ['admin', 'root', 'reseller', 'investor']
    );
  }

  public function down()
  {
    $this->removePermission(self::STATISTIC_DEFAULT_DELETE_COLUMNS_TEMPLATE);
  }
}
