<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
*/
class m181001_145921_res_filter_providers extends Migration
{
  use PermissionTrait;
  /**
  */
  public function up()
  {
    $this->assignRolesPermission('StatisticFilterByProviders', ['reseller']);
    $this->assignRolesPermission('StatisticGroupByProviders', ['reseller']);
  }

  /**
  */
  public function down()
  {
    $this->revokeRolesPermission('StatisticFilterByProviders', ['reseller']);
    $this->revokeRolesPermission('StatisticGroupByProviders', ['reseller']);
  }
}
