<?php

use console\components\Migration;
use mcms\promo\commands\SyncProvidersController;

class m180614_124532_euro_step3 extends Migration
{
  const COUNTRY_RU = 1;

  public function up()
  {
    if (!\mcms\common\helpers\Console::confirm('Нужно отключить кроны и синк. Продолжаем?', true)) {
      return false;
    }

    // MCMS-2215 15 июня в 00:00мск переводим РФ на евро
    $this->insert('country_currency_log', [
      'country_id' => self::COUNTRY_RU,
      'currency' => 'rub',
      'created_at' => 0,
    ]);
    $this->insert('country_currency_log', [
      'country_id' => self::COUNTRY_RU,
      'currency' => 'eur',
      'created_at' => Yii::$app->formatter->asTimestamp('2018-06-15 00:00:00') // форматтер подхватывает часовой пояс мск
    ]);

    $this->update('countries', ['currency' => 'eur'], ['id' => self::COUNTRY_RU]);

    $this->execute('UPDATE landing_operators lo LEFT JOIN operators o ON o.id=lo.operator_id 
    SET buyout_price_eur=(SELECT c.rur_eur FROM exchanger_courses c ORDER BY id DESC LIMIT 1) * buyout_price_rub 
    WHERE o.country_id = :country_id AND lo.buyout_price_eur=0;', [':country_id' => self::COUNTRY_RU]);
  }

  public function down()
  {
    if (!\mcms\common\helpers\Console::confirm('Нужно отключить кроны и синк. Продолжаем?', true)) {
      return false;
    }

    $this->update('countries', ['currency' => 'rub'], ['id' => self::COUNTRY_RU]);

    $this->delete('country_currency_log', ['country_id' => self::COUNTRY_RU]);

  }

}
