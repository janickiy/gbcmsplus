<?php

use console\components\Migration;

class m160328_194712_investor_sold_price extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  const PERMISSION = 'StatisticViewSoldPrice';

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->assignRolesPermission(self::PERMISSION, ['investor']);
  }

  public function down()
  {
    $this->revokeRolesPermission(self::PERMISSION, ['investor']);
  }
}
