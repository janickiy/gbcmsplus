<?php

use console\components\Migration;

/**
*/
class m180726_075810_fix_search extends Migration
{

  /**
  */
  public function up()
  {
    // в dbfix забыли обновить user_id на партнерский. Делаем это сейчас. Если будет дедлок, то надо запустить ещё раз миграцию пока не выполнится успешно
    $this->execute('update search_subscriptions ss
  inner join sources s ON s.id = ss.source_id
set ss.user_id = s.user_id
where ss.user_id <> s.user_id;');
  }

  /**
  */
  public function down()
  {
    echo "m180726_075810_fix_search cannot be reverted.\n";

    return true;
  }
}
