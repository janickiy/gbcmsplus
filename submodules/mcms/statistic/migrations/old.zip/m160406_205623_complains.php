<?php

use console\components\Migration;

class m160406_205623_complains extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  const PERMISSION = 'StatisticViewComplains';

  const PERMISSION_ACTION = 'StatisticDetailComplains';
  const PERMISSION_ACTION_1 = 'StatisticDetailComplainDetail';

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    parent::init();
  }

  public function up()
  {

    $this->execute("
CREATE TABLE `complains` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `hit_id` INT(10) UNSIGNED NOT NULL,
  `trans_id` VARCHAR(64) COLLATE utf8_unicode_ci NOT NULL,
  `time` INT(10) UNSIGNED NOT NULL,
  `date` DATE NOT NULL,
  `hour` TINYINT(1) UNSIGNED NOT NULL,
  `landing_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
  `source_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
  `operator_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
  `platform_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
  `landing_pay_type_id` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
  `provider_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
  `country_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
  `stream_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
  `description` VARCHAR(512) DEFAULT NULL,
  `label1` VARCHAR(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `label2` VARCHAR(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` VARCHAR(16) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` INT(10) UNSIGNED NOT NULL,
  `updated_at` INT(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `complains_hit_id_uk` (`hit_id`),
  KEY `cmpl_group_by_day_user` (`date`,`user_id`),
  KEY `complains_source_id_fk` (`source_id`),
  CONSTRAINT `complains_source_id_fk` FOREIGN KEY (`source_id`) REFERENCES `sources` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci
        ");

    $this->createOrGetPermission(self::PERMISSION, 'View complains column');
    $this->assignRolesPermission(self::PERMISSION, ['root', 'admin', 'reseller']);
    $this->createOrGetPermission(self::PERMISSION_ACTION, 'View complains statistic');
    $this->assignRolesPermission(self::PERMISSION_ACTION, ['root', 'admin', 'reseller']);
    $this->createOrGetPermission(self::PERMISSION_ACTION_1, 'View complains detail info');
    $this->assignRolesPermission(self::PERMISSION_ACTION_1, ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->dropTable('complains');
    $this->removePermission(self::PERMISSION);
    $this->removePermission(self::PERMISSION_ACTION);
    $this->removePermission(self::PERMISSION_ACTION_1);
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
