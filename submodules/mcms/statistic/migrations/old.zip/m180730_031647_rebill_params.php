<?php

use console\components\Migration;

class m180730_031647_rebill_params extends Migration
{
  const TABLE_R = 'rebill_params';
  const TABLE_O = 'onetime_params';

  public function up()
  {
    $this->createTable(self::TABLE_R, [
      'rebill_id' => 'INT(10) UNSIGNED NOT NULL PRIMARY KEY',
      'local_sum' => 'DECIMAL(7, 3) UNSIGNED NOT NULL',
      'local_currency' => 'CHAR(3) CHARACTER SET latin1  NOT NULL',
    ]);

    $this->createTable(self::TABLE_O, [
      'onetime_id' => 'INT(10) UNSIGNED NOT NULL PRIMARY KEY',
      'local_sum' => 'DECIMAL(7, 3) UNSIGNED NOT NULL',
      'local_currency' => 'CHAR(3) CHARACTER SET latin1  NOT NULL',
    ]);
  }

  public function down()
  {
    $this->dropTable(self::TABLE_R);
    $this->dropTable(self::TABLE_O);
  }
}
