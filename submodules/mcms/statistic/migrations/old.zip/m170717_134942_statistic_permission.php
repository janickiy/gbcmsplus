<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170717_134942_statistic_permission extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticViewInvestorSubscriptionOffs', 'Просмотр  отписок 24 по всем подпискам', 'StatisticPermissions', ['root', 'admin']);
  }

  public function down()
  {
    $this->removePermission('StatisticViewInvestorSubscriptionOffs');
  }

}
