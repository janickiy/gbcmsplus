<?php

use console\components\Migration;

class m160405_073933_rebill_fix extends Migration
{
  public function up()
  {
    $this->db->createCommand('
            UPDATE subscription_rebills sr
            JOIN buyout_correct_history bch ON sr.hit_id = bch.hit_id
            SET sr.source_id = bch.to_source_id
            WHERE bch.to_source_id <> sr.source_id;
        ')->execute();
  }

  public function down()
  {
    echo "m160405_073933_rebill_fix cannot be reverted.\n";
  }
}
