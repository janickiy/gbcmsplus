<?php

use console\components\Migration;

class m160415_131349_update_investor_statistic_permission extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->revokeRolesPermission('StatisticGroupByUsers', ['investor']);
  }

  public function down()
  {
    echo "m160415_131349_update_investor_statistic_permission cannot be reverted.\n";
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
