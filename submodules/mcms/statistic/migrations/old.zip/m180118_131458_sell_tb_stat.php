<?php

use console\components\Migration;

/**
 */
class m180118_131458_sell_tb_stat extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  /**
   * @throws \yii\base\Exception
   */
  public function up()
  {
    $this->createPermission('StatisticViewSoldTb', 'Просмотр продаж ТБ', 'StatisticView', ['root', 'admin', 'reseller']);

    // убираем ненужные поля для продажи ТБ
    $this->dropColumn('sold_trafficback', 'default_profit');
    $this->dropColumn('sold_trafficback', 'default_profit_currency');
    $this->dropColumn('sold_trafficback', 'real_profit_rub');
    $this->dropColumn('sold_trafficback', 'real_profit_usd');
    $this->dropColumn('sold_trafficback', 'real_profit_eur');
    $this->dropColumn('sold_trafficback', 'profit_rub');
    $this->dropColumn('sold_trafficback', 'profit_usd');
    $this->dropColumn('sold_trafficback', 'profit_eur');
    $this->dropColumn('sold_trafficback', 'label1');
    $this->dropColumn('sold_trafficback', 'label2');
    $this->dropColumn('sold_trafficback', 'ip');
    $this->dropColumn('sold_trafficback', 'phone');
    $this->addColumn('sold_trafficback', 'category_id', 'MEDIUMINT(5) UNSIGNED DEFAULT \'0\' NOT NULL');

    // чтобы не писать множество костылей, пока храним в этих столбцах просто 0 для всех строк
    $this->alterColumn('sold_trafficback', 'landing_id', 'TINYINT(1) UNSIGNED DEFAULT \'0\' NOT NULL COMMENT \'у всех будет 0\'');
    $this->alterColumn('sold_trafficback', 'provider_id', 'TINYINT(1) UNSIGNED DEFAULT \'0\' NOT NULL COMMENT \'у всех будет 0\'');

    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable('sell_tb_hits_grouped', [
      'count_hits' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\' COMMENT \'сколько ТБ отправлии на продажу\'',
      'date' => 'date NOT NULL',
      'hour' => 'tinyint(1) NOT NULL',
      'source_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'operator_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'platform_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',

      'stream_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'user_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'country_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'tb_provider_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'category_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0 COMMENT \'категория ТБ провайдера, а не ленда\'',

      // чтобы не писать множество костылей, пока храним в этих столбцах просто 0 для всех строк
      'landing_id' => 'tinyint(1) unsigned NOT NULL DEFAULT 0 COMMENT \'у всех будет 0\'',
      'landing_pay_type_id' => 'tinyint(1) UNSIGNED NOT NULL DEFAULT 0 COMMENT \'у всех будет 0\'',
      'provider_id' => 'tinyint(1) unsigned NOT NULL DEFAULT 0 COMMENT \'у всех будет 0\'',
    ], $tableOptions);

    $this->addPrimaryKey('sell_tb_hits_grouped_pk', 'sell_tb_hits_grouped', ['date', 'hour', 'source_id', 'operator_id', 'platform_id', 'tb_provider_id', 'category_id'
      /*, 'landing_id', 'landing_pay_type_id' - эти ключи осознанно не стали добавлять, т.к. ленда у ТБ нету, там всегда будет 0 */
      ]);
  }

  /**
   */
  public function down()
  {
    $this->removePermission('StatisticViewSoldTb');
    $this->addColumn('sold_trafficback', 'default_profit', 'DECIMAL(6, 2) UNSIGNED NOT NULL');
    $this->addColumn('sold_trafficback', 'default_profit_currency', 'TINYINT(1) UNSIGNED NOT NULL');

    $this->addColumn('sold_trafficback', 'real_profit_rub', 'DECIMAL(6, 2) UNSIGNED NOT NULL');
    $this->addColumn('sold_trafficback', 'real_profit_usd', 'DECIMAL(6, 2) UNSIGNED NOT NULL');
    $this->addColumn('sold_trafficback', 'real_profit_eur', 'DECIMAL(6, 2) UNSIGNED NOT NULL');
    $this->addColumn('sold_trafficback', 'profit_rub', 'DECIMAL(6, 2) UNSIGNED NOT NULL');
    $this->addColumn('sold_trafficback', 'profit_usd', 'DECIMAL(6, 2) UNSIGNED NOT NULL');
    $this->addColumn('sold_trafficback', 'profit_eur', 'DECIMAL(6, 2) UNSIGNED NOT NULL');
    $this->addColumn('sold_trafficback', 'label1', 'VARCHAR(512)');
    $this->addColumn('sold_trafficback', 'label2', 'VARCHAR(512)');
    $this->addColumn('sold_trafficback', 'ip', 'VARCHAR(16) NOT NULL');
    $this->addColumn('sold_trafficback', 'phone', 'BIGINT(12)');
    $this->dropColumn('sold_trafficback', 'category_id');
    $this->dropTable('sell_tb_hits_grouped');

    $this->alterColumn('sold_trafficback', 'landing_id', 'MEDIUMINT(5) UNSIGNED DEFAULT \'0\' NOT NULL');
    $this->alterColumn('sold_trafficback', 'provider_id', 'MEDIUMINT(5) UNSIGNED DEFAULT \'0\' NOT NULL');
  }

}
