<?php

use console\components\Migration;

class m151211_152319_statistic_date_user_group extends Migration
{
  public function up()
  {

    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    // сгруппированная статистика по пользователям и дням
    $this->createTable('statistic_day_user_group', [
      'date' => 'DATE NOT NULL',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'count_ons' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'count_offs' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'count_rebills' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'count_onetimes' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'count_solds' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'sum_rebill_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL',
      'sum_rebill_profit_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL',
      'sum_rebill_profit_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL',
      'sum_onetime_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL',
      'sum_onetime_profit_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL',
      'sum_onetime_profit_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL',
      'sum_sold_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL',
      'sum_sold_profit_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL',
      'sum_sold_profit_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL',
    ], $tableOptions);

    // добавляем PK
    $this->addPrimaryKey('sdug_pk', 'statistic_day_user_group', ['date', 'user_id']);

    $this->createIndex('sdg_group_by_day_user', 'subscriptions_day_group'
      , ['date', 'user_id', 'count_ons', 'count_offs', 'count_rebills', 'sum_profit_rub', 'sum_profit_eur', 'sum_profit_usd'
      ]);

    $this->createIndex('os_group_by_day_user', 'onetime_subscriptions'
      , ['date', 'user_id', 'profit_rub', 'profit_eur', 'profit_usd'
      ]);

    $this->createIndex('ss_group_by_day_user', 'sold_subscriptions'
      , ['date', 'user_id', 'price_rub', 'price_eur', 'price_usd'
      ]);

  }

  public function down()
  {
    $this->dropTable('statistic_day_user_group');
    $this->dropIndex('sdg_group_by_day_user', 'subscriptions_day_group');
    $this->dropIndex('os_group_by_day_user', 'onetime_subscriptions');
    $this->dropIndex('ss_group_by_day_user', 'sold_subscriptions');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
