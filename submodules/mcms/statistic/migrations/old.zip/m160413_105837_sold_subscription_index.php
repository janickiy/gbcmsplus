<?php

use console\components\Migration;

class m160413_105837_sold_subscription_index extends Migration
{

  const TABLE = 'sold_subscriptions';
  const KEY = self::TABLE . '_user_id_operator_id_landing_id_time_index';

  public function up()
  {
    $this->createIndex(self::KEY, self::TABLE, ['user_id', 'operator_id', 'landing_id', 'time']);
  }

  public function down()
  {
    $this->dropIndex(self::KEY, self::TABLE);
  }
}
