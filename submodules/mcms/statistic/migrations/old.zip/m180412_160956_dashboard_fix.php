<?php

use console\components\Migration;

class m180412_160956_dashboard_fix extends Migration
{
  const TABLE_DPO = 'dashboard_profits_ons';

  public function up()
  {
    $this->dropColumn(self::TABLE_DPO,'res_sold_price_rub');
    $this->dropColumn(self::TABLE_DPO,'res_sold_price_usd');
    $this->dropColumn(self::TABLE_DPO,'res_sold_price_eur');

    $this->dropColumn(self::TABLE_DPO,'real_sold_price_rub');
    $this->dropColumn(self::TABLE_DPO,'real_sold_price_usd');
    $this->dropColumn(self::TABLE_DPO,'real_sold_price_eur');
  }

  public function down()
  {
    $this->addColumn(self::TABLE_DPO,'res_sold_price_rub','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'res_sold_price_usd','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'res_sold_price_eur','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');

    $this->addColumn(self::TABLE_DPO,'real_sold_price_rub','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'real_sold_price_usd','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
    $this->addColumn(self::TABLE_DPO,'real_sold_price_eur','DECIMAL(9, 2) UNSIGNED DEFAULT "0.00" NOT NULL');
  }
}
