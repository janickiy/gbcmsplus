<?php

use console\components\Migration;

/**
 */
class m180810_144940_complains_uq_index extends Migration
{

  /**
   */
  public function up()
  {
    $this->execute('update complains
set trans_id = CONCAT(\'autocomplain_\', hit_id, \'-\',id)
WHERE trans_id = \'autocomplain\';');

    $this->execute('drop index complains_hit_id_type_uk ON complains;');

    $this->execute('create unique index complains_hit_id_trans_id_uq ON complains (hit_id, trans_id);');
  }

  /**
   */
  public function down()
  {
    $this->execute('drop index complains_hit_id_trans_id_uq ON complains');
    $this->execute('create unique index complains_hit_id_type_uk ON complains (hit_id, type)');

  }
}
