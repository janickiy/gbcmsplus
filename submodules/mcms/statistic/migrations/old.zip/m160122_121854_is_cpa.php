<?php

use yii\db\Schema;
use console\components\Migration;

class m160122_121854_is_cpa extends Migration
{
  public function safeUp()
  {
    $this->addColumn('hits', 'is_cpa', 'tinyint(1) unsigned DEFAULT \'0\'');

    /**
     * заполняем флаг hits.is_cpa = 1
     */

    // берём из hit_params.is_to_sell
    $this->db->createCommand('update hits h
      inner join hit_params p ON p.hit_id = h.id and p.is_to_sell = 1
      set h.is_cpa = 1')->execute();

    // берём из onetime_subscriptions (все записи означают что хит был с флагом is_cpa)
    $this->db->createCommand('update hits h
      inner join onetime_subscriptions os ON os.hit_id = h.id
      set h.is_cpa = 1')->execute();

    $this->dropIndex('hits_group_by_hour', 'hits');
    $this->createIndex('hits_group_by_hour', 'hits', ['date','source_id','landing_id','operator_id','platform_id','landing_pay_type_id','hour','is_unique','is_tb', 'is_cpa']);

    $this->dropColumn('hit_params', 'is_to_sell');


    $this->addColumn('hits_day_group', 'is_cpa', 'tinyint(1) unsigned DEFAULT \'0\'');
    $this->db->createCommand('ALTER TABLE hits_day_group DROP PRIMARY KEY, ADD PRIMARY KEY(`date`,`source_id`,`landing_id`,`operator_id`,`platform_id`,`landing_pay_type_id`, `is_cpa`)')->execute();

    $this->addColumn('hits_day_hour_group', 'is_cpa', 'tinyint(1) unsigned DEFAULT \'0\'');
    $this->db->createCommand('ALTER TABLE hits_day_hour_group DROP PRIMARY KEY, ADD PRIMARY KEY(`date`,`hour`,`source_id`,`landing_id`,`operator_id`,`platform_id`,`landing_pay_type_id`, `is_cpa`)')->execute();
    $this->dropIndex('hdhg_group_by_day', 'hits_day_hour_group');
    $this->createIndex('hdhg_group_by_day', 'hits_day_hour_group', ['date','source_id','landing_id','operator_id','platform_id','hour','landing_pay_type_id','count_hits','count_uniques','count_tb', 'is_cpa']);

    $this->renameColumn('search_subscriptions', 'is_to_sell', 'is_cpa');


    /** Пересчитаем данные скриптом statistic/cron, предварительно удалив старые данные */
    $this->truncateTable('hits_day_group');
    $this->truncateTable('hits_day_hour_group');
    //exec('php ' . __DIR__ . '/../../../../yii statistic/cron');
  }

  public function safeDown()
  {
    echo 'revert m160122_121854_is_cpa is unsupported';
    return false;
  }

}
