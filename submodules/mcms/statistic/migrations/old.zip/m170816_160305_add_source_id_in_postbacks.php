<?php

use console\components\Migration;

class m170816_160305_add_source_id_in_postbacks extends Migration
{
  const TABLE = 'postbacks';

  public function up()
  {
    $this->addColumn(self::TABLE, 'source_id', 'MEDIUMINT(5) UNSIGNED');

    $this->addForeignKey(
      self::TABLE . '_source_id_fk',
      self::TABLE,
      'source_id',
      'sources',
      'id',
      'SET NULL'
    );
  }

  public function down()
  {
    $this->dropForeignKey(self::TABLE . '_source_id_fk', self::TABLE);
    $this->dropColumn(self::TABLE, 'source_id');
  }
}
