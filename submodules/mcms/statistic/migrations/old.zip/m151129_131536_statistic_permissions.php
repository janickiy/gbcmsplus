<?php

use console\components\Migration;

class m151129_131536_statistic_permissions extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();

    $this->moduleName = 'Statistic';
    $this->authManager = Yii::$app->authManager;

    $this->permissions = [
      'Statistic' => [
        ['viewResellerProfit', 'Can view reseller profit', ['admin', 'root', 'reseller']],
        ['viewRealProfit', 'Can view real profit', ['admin', 'root']],
        ['viewPartnerProfit', 'Can view partner profit', ['admin', 'root', 'partner', 'investor']],

        ['groupByLandings', 'Can group by landings', ['admin', 'root']],
        ['groupBySources', 'Can group by sources', ['admin', 'root']],
        ['groupByStreams', 'Can group by streams', ['admin', 'root']],
        ['groupByPlatforms', 'Can group by platforms', ['admin', 'root']],
        ['groupByOperators', 'Can group by operators', ['admin', 'root']],
        ['groupByCountries', 'Can group by countries', ['admin', 'root']],
        ['groupByProviders', 'Can group by providers', ['admin', 'root']],
        ['groupByUsers', 'Can group by users', ['admin', 'root']],
        ['groupByLandingPayTypes', 'Can group by landing pay types', ['admin', 'root']],

        ['filterByLandings', 'Can filter landings', ['admin', 'root']],
        ['filterBySources', 'Can filter sources', ['admin', 'root']],
        ['filterByStreams', 'Can filter streams', ['admin', 'root']],
        ['filterByPlatforms', 'Can filter platforms', ['admin', 'root']],
        ['filterByOperators', 'Can filter operators', ['admin', 'root']],
        ['filterByCountries', 'Can filter countries', ['admin', 'root']],
        ['filterByProviders', 'Can filter providers', ['admin', 'root']],
        ['filterByUsers', 'Can filter users', ['admin', 'root']],
        ['filterByLandingPayTypes', 'Can filter landing pay types', ['admin', 'root']],
      ]
    ];
  }
}
