<?php

use console\components\Migration;

class m171116_085626_subscription_rebill_index_for_reseller_statistics extends Migration
{
  public function up()
  {
    $this->createIndex('subscription_rebills_reseller_profit_statistics', 'subscription_rebills', ['date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'landing_pay_type_id']);
  }

  public function down()
  {
    $this->dropIndex('subscription_rebills_reseller_profit_statistics', 'subscription_rebills');
  }
}
