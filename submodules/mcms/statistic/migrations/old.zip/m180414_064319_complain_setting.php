<?php

use rgk\settings\models\Setting;
use console\components\Migration;

class m180414_064319_complain_setting extends Migration
{

  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
  }

  public function up()
  {
    $title = ['ru' => 'Звонок КЦ ОСС', 'en' => 'Call MNO'];
    $permissions = ['EditModuleSettingsStatistic'];
    $category = 'app.common.form_group_partner_complains';
    $this->settingsBuilder->createSetting($title, [], 'partner_view_call_mno_complain', $permissions, Setting::TYPE_BOOLEAN, $category, 1);
  }

  public function down()
  {
    $this->settingsBuilder->removeSetting('partner_view_call_mno_complain');
  }
}
