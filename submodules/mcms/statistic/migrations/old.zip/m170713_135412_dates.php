<?php

use console\components\Migration;

class m170713_135412_dates extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable('days', [
      'date' => $this->date()->notNull(),
      'month_start' => $this->date()->notNull(),
      'month_end' => $this->date()->notNull(),
      'next_month_start' => $this->date()->notNull(),
      'week_start' => $this->date()->notNull(),
      'week_end' => $this->date()->notNull(),
      'next_week_start' => $this->date()->notNull(),
    ], $tableOptions);

    $this->addPrimaryKey('date_pk', 'days', 'date');
    $this->createIndex('month_start_i', 'days', 'month_start');
    $this->createIndex('month_end_i', 'days', 'month_start');
    $this->createIndex('next_month_start_i', 'days', 'month_start');
    $this->createIndex('week_start_i', 'days', 'month_start');
    $this->createIndex('week_end_i', 'days', 'month_start');
    $this->createIndex('next_week_start_i', 'days', 'month_start');

    for (
      $date = '2015-01-01';
      $date <= Yii::$app->formatter->asDate('2050-01-01', 'php:Y-m-d');
      $date = Yii::$app->formatter->asDate("$date + 1 day", 'php:Y-m-d')
    ) {

      Yii::$app->db->createCommand()->insert('days', [
        'date' => $date,
        'month_start' => Yii::$app->formatter->asDate($date, 'php:Y-m-01'),
        'month_end' => date('Y-m-t', strtotime($date)),
        'next_month_start' => Yii::$app->formatter->asDate(date('Y-m-t', strtotime($date)) . ' +1day', 'php:Y-m-d'),
        'week_start' => Yii::$app->formatter->asDate($date . ' monday this week', 'php:Y-m-d'),
        'week_end' => Yii::$app->formatter->asDate(Yii::$app->formatter->asDate($date . ' monday this week', 'php:Y-m-d') . ' +6day', 'php:Y-m-d'),
        'next_week_start' => Yii::$app->formatter->asDate($date . ' next Monday', 'php:Y-m-d'),
      ])->execute();
    }
  }

  public function down()
  {
    $this->dropTable('days');
  }
}
