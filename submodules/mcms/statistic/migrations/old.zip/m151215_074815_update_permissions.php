<?php

use console\components\Migration;

class m151215_074815_update_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Statistic';
    $this->permissions = [
      'DetailStatistic' => [
        // detail/index/
        ['subscriptionViewHitId', 'Can view subscription hit id', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewPhone', 'Can view subscription phone', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewIp', 'Can view subscription ip', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewStream', 'Can view subscription stream', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewSource', 'Can view subscription source', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewCountry', 'Can view subscription country', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewOperator', 'Can view subscription operator', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewPlatform', 'Can view subscription platform', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewSubscribedAt', 'Can view subscription subscribed at', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewUnSubscribedAt', 'Can view subscription unsubscribed at', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewLastRebillAt', 'Can view subscription last rebill at', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewCountRebills', 'Can view subscription count rebills', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewSumProfit', 'Can view subscription sum profit', [
          'admin',
          'partner',
          'reseller',
          'investor',
        ]],
        ['subscriptionViewDetailStatistic', 'Can view subscription detail statistic', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewDetailRebillList', 'Can view subscription detail rebill list', [
          'admin',
          'partner',
          'reseller',
          'investor',
        ]],
        ['subscriptionViewReferrer', 'Can view subscription referrer', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewUserAgent', 'Can view subscription user agent', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewLabel1', 'Can view subscription label1', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewLabel2', 'Can view subscription label2', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionViewLandingPayType', 'Can view subscription landing pay type', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        //detail/ik/
        ['ikViewHitId', 'Can view ik hit id', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',]],
        ['ikViewPhone', 'Can view ik phone', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ikViewIp', 'Can view ik ip', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ikViewStream', 'Can view ik stream', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ikViewSource', 'Can view ik source', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ikViewCountry', 'Can view ik country', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ikViewOperator', 'Can view ik operator', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ikViewPlatform', 'Can view ik platform', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ikViewLandingPayType', 'Can view ik landing pay type', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ikViewSubscribedAt', 'Can view ik subscribed at', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ikViewProfitSum', 'Can view ik profit sum', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ikViewReferrer', 'Can view ik referrer', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ikViewUserAgent', 'Can view ik user agent', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ikViewLabel1', 'Can view ik label1', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ikViewLabel2', 'Can view ik label2', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        //detail/sells/
        ['sellsViewHitId', 'Can view sells hit id', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sellsViewPhone', 'Can view sells phone', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sellsViewIp', 'Can view sells ip', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sellsViewStream', 'Can view sells stream', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sellsViewSource', 'Can view sells source', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sellsViewCountry', 'Can view sells country', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sellsViewOperator', 'Can view sells operator', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sellsViewPlatform', 'Can view sells platform', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sellsViewLandingPayType', 'Can view sells landing pay type', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sellsViewSubscribedAt', 'Can view sells subscribed at', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sellsViewProfitSum', 'Can view sells profit sum', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sellsViewReferrer', 'Can view sells referrer', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sellsViewUserAgent', 'Can view sells user agent', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sellsViewLabel1', 'Can view sells label1', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sellsViewLabel2', 'Can view sells label2', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],

        ['viewAdminProfit', 'View admin profit sum', ['admin', 'root',]],
        ['viewResellerProfit', 'View reseller profit sum', ['admin', 'reseller', 'root',]],
        ['viewProfit', 'View profit sum', ['admin', 'partner', 'reseller', 'investor', 'root',]],
      ],
      'DetailInfo' => [
        ['viewAdminProfit', 'View admin profit sum', ['admin', 'root',]],
        ['viewResellerProfit', 'View reseller profit sum', ['admin', 'reseller', 'root',]],
        ['viewProfit', 'View profit sum', ['admin', 'partner', 'reseller', 'investor', 'root',]],
      ],
      'Detail' => [
        ['subscriptions', 'View detail statistic by rebills', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ik', 'View detail statistic by ik', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sells', 'View detail statistic by sells', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['subscriptionDetail', 'Can view detailed info in detail statistic', [
          'admin',
          'root',
          'reseller'
        ]],
        ['ikDetail', 'Can view detailed info in detail statistic', [
          'admin',
          'root',
          'reseller',
        ]],
        ['sellsDetail', 'Can view detailed info in detail statistic', [
          'admin',
          'root',
          'reseller',
        ]],
      ],
      'Statistic' => [
        ['index', 'Can view main statistic', [
          'admin',
          'partner',
          'investor',
          'reseller',
          'root',
        ]],
        ['hour', 'Can view main statistic by hour', [
          'admin',
          'partner',
          'investor',
          'reseller',
          'root',
        ]]
      ]
    ];
  }
}
