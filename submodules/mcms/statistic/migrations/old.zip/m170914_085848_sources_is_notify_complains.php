<?php

use console\components\Migration;

class m170914_085848_sources_is_notify_complains extends Migration
{
  public function up()
  {
    $this->addColumn('postbacks', 'complain_id', 'INT(10) UNSIGNED NULL DEFAULT NULL AFTER onetime_subscription_id');
    $this->createIndex('postbacks_complain_id_unique_index', 'postbacks', 'complain_id', true);
  }

  public function down()
  {
    $this->dropColumn('postbacks', 'complain_id');
  }
}
