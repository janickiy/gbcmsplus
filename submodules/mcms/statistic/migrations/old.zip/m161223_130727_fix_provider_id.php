<?php

use console\components\Migration;

class m161223_130727_fix_provider_id extends Migration
{
  public function up()
  {
    $this->db->createCommand('
      UPDATE search_subscriptions
      SET provider_id = 1
      WHERE provider_id = 0;
    ')->execute();

    $this->db->createCommand('
      UPDATE subscription_offs
      SET provider_id = 1
      WHERE provider_id = 0;
    ')->execute();

    $this->db->createCommand('
      UPDATE sold_subscriptions
      SET provider_id = 1
      WHERE provider_id = 0;
    ')->execute();

    $this->db->createCommand('
      UPDATE buyout_correct_history
      SET provider_id = 1
      WHERE provider_id = 0;
    ')->execute();
  }

  public function down()
  {
    echo "m161223_130727_fix_provider_id cannot be reverted.\n";
  }
}
