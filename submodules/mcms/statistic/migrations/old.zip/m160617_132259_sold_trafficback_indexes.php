<?php

use console\components\Migration;

class m160617_132259_sold_trafficback_indexes extends Migration
{
  public function up()
  {
    $this->createIndex('st_group_by_day_user', 'sold_trafficback', [
      'date',
      'user_id',
      'profit_rub',
      'profit_eur',
      'profit_usd'
    ]);
  }

  public function down()
  {
    $this->dropIndex('st_group_by_day_user', 'sold_trafficback');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
