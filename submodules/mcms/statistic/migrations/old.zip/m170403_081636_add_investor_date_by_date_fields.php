<?php

use console\components\Migration;

class m170403_081636_add_investor_date_by_date_fields extends Migration
{
  public function up()
  {
    $this->addColumn('subscriptions_day_group', 'sum_profit_rub_date_by_date', 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0 AFTER sum_profit_usd');
    $this->addColumn('subscriptions_day_group', 'sum_profit_eur_date_by_date', 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0 AFTER sum_profit_rub_date_by_date');
    $this->addColumn('subscriptions_day_group', 'sum_profit_usd_date_by_date', 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0 AFTER sum_profit_eur_date_by_date');

    $this->addColumn('subscriptions_day_hour_group', 'sum_profit_rub_date_by_date', 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0 AFTER sum_profit_usd');
    $this->addColumn('subscriptions_day_hour_group', 'sum_profit_eur_date_by_date', 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0 AFTER sum_profit_rub_date_by_date');
    $this->addColumn('subscriptions_day_hour_group', 'sum_profit_usd_date_by_date', 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0 AFTER sum_profit_eur_date_by_date');
  }

  public function down()
  {
    echo "m170331_142432_investor_profit_additional_stat cannot be reverted.\n";
  }
}

