<?php

use console\components\Migration;

class m160429_215456_reseller_sold_price extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->revokeRolesPermission('StatisticViewSoldPrice', ['reseller', 'manager']);
  }

  public function down()
  {
    $this->assignRolesPermission('StatisticViewSoldPrice', ['reseller', 'manager']);
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
