<?php

use yii\db\Schema;
use console\components\Migration;

class m160208_142234_add_is_cpa extends Migration
{
  public function up()
  {

    // SUBSCRIPTIONS
    $this->addColumn('subscriptions', 'is_cpa', 'tinyint(1) unsigned NOT NULL DEFAULT \'0\'');

    $this->dropIndex('subscriptions_group_by_hour', 'subscriptions');
    $this->createIndex('subscriptions_group_by_hour', 'subscriptions', ['date','source_id','landing_id','operator_id','platform_id','hour','landing_pay_type_id', 'is_cpa']);

    Yii::$app->db->createCommand("UPDATE `subscriptions` s
      INNER JOIN `hits` ON s.`hit_id` = `hits`.id
      SET s.`is_cpa` = `hits`.`is_cpa`")
      ->execute();


    $this->dropIndex('subscriptions_ss_group', 'subscriptions');
    $this->createIndex('subscriptions_ss_group', 'subscriptions', ['time','hit_id','source_id','landing_id','operator_id','platform_id','landing_pay_type_id', 'is_cpa']);

    // SUBSCRIPTIONS_DAY_HOUR_GROUP
    $this->addColumn('subscriptions_day_hour_group', 'is_cpa', 'tinyint(1) unsigned NOT NULL DEFAULT \'0\'');
    $this->db->createCommand('ALTER TABLE subscriptions_day_hour_group DROP PRIMARY KEY, ADD PRIMARY KEY(`date`,`hour`,`source_id`,`landing_id`,`operator_id`,`platform_id`,`landing_pay_type_id`, `is_cpa`)')->execute();

    // SUBSCRIPTIONS_DAY_GROUP
    $this->addColumn('subscriptions_day_group', 'is_cpa', 'tinyint(1) unsigned NOT NULL DEFAULT \'0\'');
    $this->db->createCommand('ALTER TABLE subscriptions_day_group DROP PRIMARY KEY, ADD PRIMARY KEY(`date`,`source_id`,`landing_id`,`operator_id`,`platform_id`,`landing_pay_type_id`, `is_cpa`)')->execute();


    // SUBSCRIPTION_REBILLS
    $this->addColumn('subscription_rebills', 'is_cpa', 'tinyint(1) unsigned NOT NULL DEFAULT \'0\'');
    $this->dropIndex('subscription_rebills_group_by_hour', 'subscription_rebills');
    $this->createIndex('subscription_rebills_group_by_hour', 'subscription_rebills', ['date','source_id','landing_id','operator_id','platform_id','hour','landing_pay_type_id', 'is_cpa','real_profit_rub','reseller_profit_rub','profit_rub','profit_eur','profit_usd']);
    $this->dropIndex('subscription_rebills_ss_group', 'subscription_rebills');
    $this->createIndex('subscription_rebills_ss_group', 'subscription_rebills', ['time','hit_id','source_id','landing_id','operator_id','platform_id','landing_pay_type_id', 'is_cpa','real_profit_rub','reseller_profit_rub','profit_rub','profit_eur','profit_usd']);

    Yii::$app->db->createCommand("UPDATE `subscription_rebills` sr
      INNER JOIN `hits` ON sr.`hit_id` = `hits`.id
      SET sr.`is_cpa` = `hits`.`is_cpa`")
      ->execute();


    // SUBSCRIPTION_OFFS
    $this->addColumn('subscription_offs', 'is_cpa', 'tinyint(1) unsigned NOT NULL DEFAULT \'0\'');
    $this->dropIndex('subscription_offs_group_by_hour', 'subscription_offs');
    $this->createIndex('subscription_offs_group_by_hour', 'subscription_offs', ['date','source_id','landing_id','operator_id','platform_id','hour', 'is_cpa']);
    $this->dropIndex('subscription_offs_ss_group', 'subscription_offs');
    $this->createIndex('subscription_offs_ss_group', 'subscription_offs', ['time','hit_id','source_id','landing_id','operator_id','platform_id', 'is_cpa']);
    Yii::$app->db->createCommand("UPDATE `subscription_offs` so
      INNER JOIN `hits` ON so.`hit_id` = `hits`.id
      SET so.`is_cpa` = `hits`.`is_cpa`")
      ->execute();


    /** Пересчитаем данные скриптом statistic/cron, предварительно удалив старые данные */
    $this->truncateTable('subscriptions_day_group');
    $this->truncateTable('subscriptions_day_hour_group');
    //exec('php ' . __DIR__ . '/../../../../yii statistic/cron');
  }

  public function down()
  {
    echo "m160208_142234_add_is_cpa cannot be reverted.\n";
  }
}
