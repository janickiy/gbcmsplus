<?php

use console\components\Migration;

class m151116_130922_postback extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    // статистика по переходам
    $this->createTable('postbacks', [
      'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'item_id' => 'INT(10) UNSIGNED NOT NULL',
      'item_type' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'errors' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'response' => 'TEXT DEFAULT NULL',
      'url' => 'VARCHAR(512) NOT NULL',
      'data' => 'TEXT',
      'time' => 'INT(10) UNSIGNED NOT NULL',
      'last_time' => 'INT(10) UNSIGNED NOT NULL'
    ], $tableOptions);
  }

  public function down()
  {
    $this->dropTable('postbacks');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
