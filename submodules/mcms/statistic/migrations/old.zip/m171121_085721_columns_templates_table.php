<?php

use console\components\Migration;

class m171121_085721_columns_templates_table extends Migration
{
  const TABLE_NAME = 'columns_templates';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(self::TABLE_NAME, [
      'id' => $this->primaryKey(5),
      'user_id' => 'MEDIUMINT(5) unsigned NOT NULL',
      'is_system' => 'TINYINT(1) unsigned NOT NULL DEFAULT 0',
      'name' => $this->string(255)->notNull(),
      'columns' => $this->text()->notNull(),
    ], $tableOptions);

    $root = Yii::$app->getModule('users')->api('usersByRoles', ['root'])->getResult();
    $rootId = reset($root)['id'];

    $this->insert(self::TABLE_NAME, [
      'user_id' => $rootId,
      'is_system' => 1,
      'name' => 'Количественная статистика',
      'columns' => '["count_hits","count_uniques","count_tb","accepted","revshare_accepted","count_ons","count_scope_offs","revshare_ratio","count_offs","count_longs","charges_on_date","charge_ratio","cpa_accepted","cpa_ratio","ecpm","cpr","visible_subscriptions","count_complains","count_calls","total_count_scope_offs"]',
    ]);

    $this->insert(self::TABLE_NAME, [
      'user_id' => $rootId,
      'is_system' => 1,
      'name' => 'Финансовая статистика',
      'columns' => '["count_hits","count_uniques","count_tb","accepted","revshare_accepted","sum_on_date","rev_sub","sum_real_profit_rub","sum_reseller_profit_rub","sum_profit_rub","cpa_accepted","count_onetime","count_sold","onetime_real_profit_rub","onetime_reseller_profit_rub","onetime_profit_rub","sold_investor_price_rub","sold_reseller_price_rub","sold_price_rub","admin_total_profit_rub","admin_net_profit_rub","reseller_total_profit_rub","reseller_net_profit_rub","partner_total_profit_rub"]',
    ]);
  }

  public function down()
  {
    $this->dropTable(self::TABLE_NAME);
  }
}
