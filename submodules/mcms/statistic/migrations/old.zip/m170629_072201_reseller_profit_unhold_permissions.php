<?php

use console\components\Migration;

class m170629_072201_reseller_profit_unhold_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticResellerProfitUnholdPlan', 'План расхолда средств', 'StatisticResellerProfitController', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('StatisticResellerProfitUnholdPlan');
  }
}
