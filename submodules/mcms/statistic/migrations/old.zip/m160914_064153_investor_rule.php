<?php

use console\components\Migration;

class m160914_064153_investor_rule extends Migration
{
    public function up()
    {
      $auth = Yii::$app->authManager;
      // добавляем разрешение "StatisticFilterViewByCurrency" с родителем "StatisticPermissions"
      $parentPermission = $auth->getPermission('StatisticPermissions');
      $permission = $auth->createPermission('StatisticFilterViewByCurrency');
      $permission->description = 'View filters by currency';
      $auth->add($permission);
      $auth->addChild($parentPermission, $permission);
      // добавляем его инвестору
      $investorRole = $auth->getRole('investor');
      $auth->addChild($investorRole, $permission);
    }

    public function down()
    {
      $auth = Yii::$app->authManager;
      $investorRole = $auth->getRole('investor');
      $parentPermission = $auth->getPermission('StatisticPermissions');
      $permission = $auth->getPermission('StatisticFilterViewByCurrency');
      $auth->removeChild($parentPermission, $permission);
      $auth->removeChild($investorRole, $permission);
      $auth->remove($permission);
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
