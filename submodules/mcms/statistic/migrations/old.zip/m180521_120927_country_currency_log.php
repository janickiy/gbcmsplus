<?php

use console\components\Migration;

class m180521_120927_country_currency_log extends Migration
{
  const TABLE = 'country_currency_log';
  const COUNTRIES  = [4, 10]; //Belarus Kazakhstan
  const CURRENCY_RUB = 'rub';
  const CURRENCY_EUR = 'eur';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::TABLE, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'country_id' => 'MEDIUMINT(5) NOT NULL',
      'currency' => $this->string(3)->notNull(),
      'created_at' => 'INT(10) UNSIGNED NOT NULL'
    ], $tableOptions);

    $this->createIndex(
      'country_currency_index',
      self::TABLE,
      ['country_id', 'created_at']
    );

    foreach (self::COUNTRIES as $countryId) {
      $this->insert(self::TABLE, [
        'country_id' => $countryId,
        'currency' => self::CURRENCY_RUB,
        'created_at' => 0,
      ]);
      $this->insert(self::TABLE, [
        'country_id' => $countryId,
        'currency' => self::CURRENCY_EUR,
        'created_at' => mktime(
          0, 0, 0, 5, 22, 2018)
      ]);
    }

    $this->update('countries', ['currency' => self::CURRENCY_EUR], ['id' => self::COUNTRIES]);
  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }
}
