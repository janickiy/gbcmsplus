<?php

use rgk\settings\models\Setting;
use console\components\Migration;

class m180710_123332_global_after_1st_rebill extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  const SETTING = 'settings.buyout_after_1st_rebill_only';
  const PERMISSION = 'EditGlobalBuyoutAfter1stRebillOnly';

  public function up()
  {
    $this->createPermission(self::PERMISSION, 'Разрешение на редактирование настройки "Выкупать только после 1го ребилла"', 'PromoPermissions', ['root', 'admin', 'reseller']);

    $title = ['ru' => 'Выкупать только после 1го ребилла', 'en' => 'Buyout only after 1st rebill'];
    $description = ['ru' => 'Аналогичные флаги у операторов будут проигнорированы', 'en' => 'A similar flag for operators will be ignored'];
    $permissions = [self::PERMISSION];
    $category = 'app.common.group_buyouts_rebills';
    $validators = [["required"],["boolean"]];
    Yii::$app->settingsBuilder->createSetting($title, $description, self::SETTING, $permissions, Setting::TYPE_BOOLEAN, $category, false, $validators);
  }

  public function down()
  {
    $this->removePermission(self::PERMISSION);
    Yii::$app->settingsBuilder->removeSetting(self::SETTING);
  }
}
