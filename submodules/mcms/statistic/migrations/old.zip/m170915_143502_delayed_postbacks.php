<?php

use console\components\Migration;

class m170915_143502_delayed_postbacks extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable('postbacks_delayed', [
      'id' => 'INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'channel' => 'VARCHAR(50) NOT NULL',
      'type' => 'TINYINT(1) NOT NULL',
      'time' => 'INT UNSIGNED NOT NULL',
      'data' => 'TEXT NULL',
    ],$tableOptions);
  }

  public function down()
  {
    $this->dropTable('postbacks_delayed');
  }
}
