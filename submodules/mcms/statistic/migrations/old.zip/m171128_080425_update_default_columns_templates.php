<?php

use console\components\Migration;

class m171128_080425_update_default_columns_templates extends Migration
{
  const TABLE_NAME = 'columns_templates';

  public function up()
  {
    $this->update(self::TABLE_NAME, [
      'name' => 'Quantitative statistics',
      'columns' => '["count_hits","count_uniques","count_tb","accepted","revshare_accepted","count_ons","count_scope_offs","revshare_ratio","count_offs","count_longs","charges_on_date","charge_ratio","cpa_accepted","cpa_ratio","ecpm","cpr","visible_subscriptions","investor_count_rebills","count_complains","count_calls","total_count_scope_offs"]',
    ], [
      'is_system' => 1,
      'name' => 'Количественная статистика',
    ]);

    $this->update(self::TABLE_NAME, [
      'name' => 'Financial statistics',
      'columns' => '["count_hits","count_uniques","count_tb","accepted","revshare_accepted","sum_on_date","rev_sub","sum_real_profit_rub","sum_reseller_profit_rub","sum_profit_rub","cpa_accepted","count_onetime","count_sold","onetime_real_profit_rub","onetime_reseller_profit_rub","onetime_profit_rub","sold_investor_price_rub","sold_reseller_price_rub","sold_price_rub","investor_profit_rub","admin_total_profit_rub","admin_net_profit_rub","reseller_total_profit_rub","reseller_net_profit_rub","partner_total_profit_rub"]',
    ], [
      'is_system' => 1,
      'name' => 'Финансовая статистика',
    ]);
  }

  public function down()
  {
    $this->update(self::TABLE_NAME, [
      'name' => 'Количественная статистика',
      'columns' => '["count_hits","count_uniques","count_tb","accepted","revshare_accepted","count_ons","count_scope_offs","revshare_ratio","count_offs","count_longs","charges_on_date","charge_ratio","cpa_accepted","cpa_ratio","ecpm","cpr","visible_subscriptions","count_complains","count_calls","total_count_scope_offs"]',
    ], [
      'is_system' => 1,
      'name' => 'Quantitative statistics',
    ]);

    $this->update(self::TABLE_NAME, [
      'name' => 'Финансовая статистика',
      'columns' => '["count_hits","count_uniques","count_tb","accepted","revshare_accepted","sum_on_date","rev_sub","sum_real_profit_rub","sum_reseller_profit_rub","sum_profit_rub","cpa_accepted","count_onetime","count_sold","onetime_real_profit_rub","onetime_reseller_profit_rub","onetime_profit_rub","sold_investor_price_rub","sold_reseller_price_rub","sold_price_rub","admin_total_profit_rub","admin_net_profit_rub","reseller_total_profit_rub","reseller_net_profit_rub","partner_total_profit_rub"]',
    ], [
      'is_system' => 1,
      'name' => 'Financial statistics',
    ]);
  }
}
