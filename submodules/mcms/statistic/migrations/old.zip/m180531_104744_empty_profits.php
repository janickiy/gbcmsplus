<?php

use console\components\Migration;

class m180531_104744_empty_profits extends Migration
{
  const TABLE = 'user_balances_grouped_by_day';

  public function up()
  {
    // Удаляем строки с пустым профитом
    $this->delete(self::TABLE, ['profit_rub' => 0, 'profit_usd' => 0, 'profit_eur' => 0]);
  }

  public function down()
  {
    echo "m180531_104744_empty_profits cannot be reverted.\n";

    return true;
  }
}
