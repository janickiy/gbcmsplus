<?php

use console\components\Migration;
use yii\db\Query;
use yii\helpers\ArrayHelper;

class m170818_123141_remove_response_from_postback_table extends Migration
{
  const TABLE = 'postbacks';

  public function up()
  {
    $this->addColumn(self::TABLE, 'status_code', 'MEDIUMINT(5) NULL');

    $query = (new Query())
      ->select(['id','url','time','last_time', 'response'])
      ->from(self::TABLE);

    /** Создаем копию соединения с БД и отключаем там буферизацию (иначе памяти может не хватить) */
    $unbufferedDb = new \yii\db\Connection([
      'dsn' => Yii::$app->db->dsn,
      'username' => Yii::$app->db->username,
      'password' => Yii::$app->db->password,
      'charset' => Yii::$app->db->charset,
    ]);
    $unbufferedDb->open();
    $unbufferedDb->pdo->setAttribute(\PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);

    foreach ($query->batch(1000, $unbufferedDb) as $rows) {
      $batch = [];

      foreach ($rows as $row) {
        $batch[] = [
          'id' => (int)$row['id'],
          'url' => $row['url'],
          'time' => $row['time'],
          'last_time' => $row['last_time'],
          'status_code' => ArrayHelper::getValue(json_decode($row['response']), 'status'),
        ];
      }

      $sql = Yii::$app->db->createCommand()->batchInsert(
        self::TABLE,
        [
          'id',
          'url',
          'time',
          'last_time',
          'status_code'
        ],
        $batch
      )->rawSql;
      $sql .= 'ON DUPLICATE KEY UPDATE status_code = VALUES(status_code)';

      Yii::$app->db->createCommand($sql)->execute();
    }

    /** Закрываем созданное соединение с БД */
    $unbufferedDb->close();

    $this->dropColumn(self::TABLE, 'response');
  }

  public function down()
  {
    $this->addColumn(self::TABLE, 'response', 'TEXT');
    $this->dropColumn(self::TABLE, 'status_code');
  }
}
