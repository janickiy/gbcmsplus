<?php

use console\components\Migration;

class m160815_134109_group_permissions1 extends Migration
{

  public function up()
  {
    $manager = Yii::$app->authManager;

    $module = $manager->getPermission('StatisticModule');

    $manager->removeChild($module, $manager->getPermission('StatisticView'));
    $manager->removeChild($module, $manager->getPermission('StatisticFilter'));
    $manager->removeChild($module, $manager->getPermission('StatisticGroup'));
  }

  public function down()
  {
    $manager = Yii::$app->authManager;
    $module = $manager->getPermission('StatisticModule');

    $manager->addChild($module, $manager->getPermission('StatisticView'));
    $manager->addChild($module, $manager->getPermission('StatisticFilter'));
    $manager->addChild($module, $manager->getPermission('StatisticGroup'));
  }

}
