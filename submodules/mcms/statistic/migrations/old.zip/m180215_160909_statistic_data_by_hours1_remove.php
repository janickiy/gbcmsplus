<?php

use console\components\Migration;

class m180215_160909_statistic_data_by_hours1_remove extends Migration
{
  const TABLE_SDHG = 'statistic_data_hour_group';
  const TABLE_SDHG1 = 'statistic_data_hour_group_1';
  const TABLE_SDHG_OLD = 'statistic_data_hour_group_old';

  public function up()
  {
    $this->renameTable(self::TABLE_SDHG, self::TABLE_SDHG_OLD);
    $this->renameTable(self::TABLE_SDHG1, self::TABLE_SDHG);
  }

  public function down()
  {
    $this->renameTable(self::TABLE_SDHG, self::TABLE_SDHG1);
    $this->renameTable(self::TABLE_SDHG_OLD, self::TABLE_SDHG);
  }
}
