<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m170120_122600_view_popover_permission extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('CanViewCorrectionCalculation', 'Просмотр расчета корректировок', 'StatisticPermissions', ['root', 'admin']);
  }

  public function down()
  {
    $this->removePermission('CanViewCorrectionCalculation');
  }
}
