<?php

use console\components\Migration;

class m180129_133031_days_index_fix extends Migration
{
  public function up()
  {
    $this->dropIndexes();

    $this->createIndex('month_end_i', 'days', 'month_end');
    $this->createIndex('next_month_start_i', 'days', 'next_month_start');
    $this->createIndex('week_start_i', 'days', 'week_start');
    $this->createIndex('week_end_i', 'days', 'week_end');
    $this->createIndex('next_week_start_i', 'days', 'next_week_start');
  }

  public function down()
  {
    $this->dropIndexes();

    $this->createIndex('month_end_i', 'days', 'month_start');
    $this->createIndex('next_month_start_i', 'days', 'month_start');
    $this->createIndex('week_start_i', 'days', 'month_start');
    $this->createIndex('week_end_i', 'days', 'month_start');
    $this->createIndex('next_week_start_i', 'days', 'month_start');
  }

  private function dropIndexes()
  {
    $this->dropIndex('month_end_i', 'days');
    $this->dropIndex('next_month_start_i', 'days');
    $this->dropIndex('week_start_i', 'days');
    $this->dropIndex('week_end_i', 'days');
    $this->dropIndex('next_week_start_i', 'days');
  }
}
