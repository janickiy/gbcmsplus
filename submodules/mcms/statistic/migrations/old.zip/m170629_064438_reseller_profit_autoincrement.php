<?php

use console\components\Migration;

class m170629_064438_reseller_profit_autoincrement extends Migration
{
  public function up()
  {
    $this->execute('
ALTER TABLE reseller_profits MODIFY id INT(10) unsigned NOT NULL AUTO_INCREMENT COMMENT \'будем давать id строкам профитов для удобства синкать\';
');
  }

  public function down()
  {
  }
}
