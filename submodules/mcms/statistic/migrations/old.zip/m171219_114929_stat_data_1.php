<?php


use console\components\Migration;

/**
 */
class m171219_114929_stat_data_1 extends Migration
{
  /**
   */
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    // отличается от statistic_data_hour_group одним столбцом в ключе: is_cpa. TODO MCMS-1819
    $this->createTable('statistic_data_hour_group_1', [
      'count_scope_offs' => 'mediumint(5) unsigned NOT NULL',
      'count_rebills_date_by_date' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'sum_profit_rub_date_by_date' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'sum_profit_eur_date_by_date' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'sum_profit_usd_date_by_date' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'date' => 'date NOT NULL',
      'hour' => 'tinyint(1) NOT NULL',
      'source_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'landing_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'operator_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'platform_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_fake' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'currency_id' => 'tinyint(1) unsigned NOT NULL',
      'provider_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'stream_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'user_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'country_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'is_cpa' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    $this->addPrimaryKey('sdhg1_pk', 'statistic_data_hour_group_1', ['date', 'hour', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'landing_pay_type_id', 'is_fake', 'is_cpa']);
  }

  /**
   */
  public function down()
  {
    $this->dropTable('statistic_data_hour_group_1');
  }
}
