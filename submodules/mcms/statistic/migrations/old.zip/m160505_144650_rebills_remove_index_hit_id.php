<?php

use console\components\Migration;

class m160505_144650_rebills_remove_index_hit_id extends Migration
{

  const TABLE = 'subscription_rebills';

  public function up()
  {
    $this->dropIndex(self::TABLE . '_hit_id_index', self::TABLE);
  }

  public function down()
  {
    $this->createIndex(self::TABLE . '_hit_id_index', self::TABLE, 'hit_id');
  }
}
