<?php

use console\components\Migration;

class m160627_135320_statistic_permissions extends Migration
{
  public $newPermissions = [
    'StatisticViewFullPhone' => ['root', 'admin'],
  ];

  public function safeUp()
  {
    $auth = Yii::$app->authManager;
    foreach ($this->newPermissions as $newPermissionName => $roles) {

      $permission = $auth->getPermission($newPermissionName);
      if (!$permission) {
        $permission = $auth->createPermission($newPermissionName);
        $auth->add($permission);
      }

      foreach ($roles as $role) {
        $roleDb = $auth->getRole($role);
        if (!$auth->hasChild($roleDb, $permission)) {
          $auth->addChild($roleDb, $permission);
        }
      }
    }

  }

  public function safeDown()
  {
    $auth = Yii::$app->authManager;
    foreach ($this->newPermissions as $newPermissionName => $roles) {

      $permission = $auth->getPermission($newPermissionName);
      if (!$permission) {
        $permission = $auth->createPermission($newPermissionName);
        $auth->add($permission);
      }

      foreach ($roles as $role) {
        $roleDb = $auth->getRole($role);
        if (!$auth->hasChild($roleDb, $permission)) {
          $auth->removeChild($roleDb, $permission);
        }
      }
    }
  }
}
