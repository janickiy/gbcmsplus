<?php

use console\components\Migration;

class m170526_163615_invest_statistic_tables extends Migration
{
  public function up()
  {
    $this->db->createCommand("
      CREATE TABLE `invest_subscriptions_day_group` (
        `count_ons` MEDIUMINT(5) UNSIGNED NOT NULL,
        `count_offs` MEDIUMINT(5) UNSIGNED NOT NULL,
        `count_rebills` MEDIUMINT(5) UNSIGNED NOT NULL,
        `count_rebills_date_by_date` MEDIUMINT(5) UNSIGNED NOT NULL,
        `currency_id` TINYINT(1) UNSIGNED NOT NULL COMMENT 'оригинальная валюта',
        `sum_real_profit_rub` DECIMAL(9,2) UNSIGNED NOT NULL,
        `sum_real_profit_eur` DECIMAL(6,2) UNSIGNED NOT NULL,
        `sum_real_profit_usd` DECIMAL(6,2) UNSIGNED NOT NULL,
        `sum_reseller_profit_rub` DECIMAL(9,2) UNSIGNED NOT NULL,
        `sum_reseller_profit_eur` DECIMAL(6,2) UNSIGNED NOT NULL,
        `sum_reseller_profit_usd` DECIMAL(6,2) UNSIGNED NOT NULL,
        `sum_profit_rub` DECIMAL(9,2) UNSIGNED NOT NULL,
        `sum_profit_eur` DECIMAL(9,2) UNSIGNED NOT NULL,
        `sum_profit_usd` DECIMAL(9,2) UNSIGNED NOT NULL,
        `sum_profit_rub_date_by_date` DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT '0.00',
        `sum_profit_eur_date_by_date` DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT '0.00',
        `sum_profit_usd_date_by_date` DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT '0.00',
        `date` DATE NOT NULL,
        `source_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `from_source_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `landing_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `operator_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `platform_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `landing_pay_type_id` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
        `provider_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `from_stream_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `stream_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `from_user_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `user_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `country_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        PRIMARY KEY (`date`, `from_source_id`, `source_id`, `landing_id`, `operator_id`, `platform_id`, `landing_pay_type_id`),
        INDEX `inv_sdg_group_by_day_user` (`date`, `user_id`, `from_user_id`),
        INDEX `inv_sdg_group_by_day_user_landing` (`date`, `landing_id`, `user_id`, `from_user_id`)
      )
      COLLATE='utf8_unicode_ci'
      ENGINE=InnoDB
      ;
    ")->execute();


    $this->db->createCommand("
      CREATE TABLE `invest_subscriptions_day_hour_group` (
        `count_ons` MEDIUMINT(5) UNSIGNED NOT NULL,
        `count_offs` MEDIUMINT(5) UNSIGNED NOT NULL,
        `count_rebills` MEDIUMINT(5) UNSIGNED NOT NULL,
        `count_rebills_date_by_date` MEDIUMINT(5) UNSIGNED NOT NULL,
        `currency_id` TINYINT(1) UNSIGNED NOT NULL COMMENT 'оригинальная валюта',
        `sum_real_profit_rub` DECIMAL(8,2) UNSIGNED NOT NULL,
        `sum_real_profit_eur` DECIMAL(6,2) UNSIGNED NOT NULL,
        `sum_real_profit_usd` DECIMAL(6,2) UNSIGNED NOT NULL,
        `sum_reseller_profit_rub` DECIMAL(8,2) UNSIGNED NOT NULL,
        `sum_reseller_profit_eur` DECIMAL(6,2) UNSIGNED NOT NULL,
        `sum_reseller_profit_usd` DECIMAL(6,2) UNSIGNED NOT NULL,
        `sum_profit_rub` DECIMAL(8,2) UNSIGNED NOT NULL,
        `sum_profit_eur` DECIMAL(8,2) UNSIGNED NOT NULL,
        `sum_profit_usd` DECIMAL(8,2) UNSIGNED NOT NULL,
        `sum_profit_rub_date_by_date` DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT '0.00',
        `sum_profit_eur_date_by_date` DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT '0.00',
        `sum_profit_usd_date_by_date` DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT '0.00',
        `date` DATE NOT NULL,
        `hour` TINYINT(1) NOT NULL,
        `landing_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `from_source_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `source_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `operator_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `platform_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `landing_pay_type_id` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
        `provider_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `from_stream_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `stream_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `from_user_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `user_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        `country_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0',
        PRIMARY KEY (`date`, `hour`, `from_source_id`, `source_id`, `landing_id`, `operator_id`, `platform_id`, `landing_pay_type_id`),
        INDEX `inv_sdhg_group_by_day` (`date`, `from_source_id`, `source_id`, `landing_id`, `operator_id`, `platform_id`,  `landing_pay_type_id`)
      )
      COLLATE='utf8_unicode_ci'
      ENGINE=InnoDB
    ")->execute();

    $this->db->createCommand('
      CREATE TABLE `invest_statistic_data_hour_group` (
        `count_scope_offs` MEDIUMINT(5) UNSIGNED NOT NULL,
        `date` DATE NOT NULL,
        `hour` TINYINT(1) NOT NULL,
        `from_source_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT "0",
        `source_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT "0",
        `landing_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT "0",
        `operator_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT "0",
        `platform_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT "0",
        `landing_pay_type_id` TINYINT(1) UNSIGNED NOT NULL DEFAULT "0",
        `currency_id` TINYINT(1) UNSIGNED NOT NULL,
        `provider_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT "0",
        `from_stream_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT "0",
        `stream_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT "0",
        `from_user_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT "0",
        `user_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT "0",
        `country_id` MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT "0",
        PRIMARY KEY (`date`, `hour`, `source_id`, `from_source_id`, `landing_id`, `operator_id`, `platform_id`, `landing_pay_type_id`)
      )
      COLLATE=\'utf8_unicode_ci\'
      ENGINE=InnoDB
      ;

    ')->execute();
  }

  public function down()
  {
    $this->dropTable('invest_statistic_data_hour_group');

    $this->dropIndex('sold_to', 'sold_subscriptions');

    $this->dropTable('invest_subscriptions_day_group');
    $this->dropTable('invest_subscriptions_day_hour_group');
  }
}
