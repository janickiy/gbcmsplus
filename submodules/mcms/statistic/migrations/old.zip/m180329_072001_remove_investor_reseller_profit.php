<?php

use console\components\Migration;
use yii\db\Query;

class m180329_072001_remove_investor_reseller_profit extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->removeResellerProfitNoInvestorsPermissions();
    $this->disallowOldStatistic();
    $this->deactivateInvestors();
  }

  public function down()
  {
    $this->renameTable('reseller_profits', 'reseller_profits_noinvestors');
    $this->renameTable('reseller_profits_old', 'reseller_profits');
  }

  private function removeResellerProfitNoInvestorsPermissions()
  {
    $this->removePermission('StatisticResellerProfitNoInvestorsController');
    $this->removePermission('StatisticResellerProfitNoInvestorsIndex');
    $this->removePermission('StatisticResellerProfitNoInvestorsUnholdPlan');
  }

  private function disallowOldStatistic()
  {
    $this->removePermission('StatisticDefaultIndex');
    $this->createPermission('StatisticDefaultIndex', 'Просмотр статистики по датам', 'StatisticDefaultController', []);
  }

  private function deactivateInvestors()
  {
    $investorsIds = (new Query)
      ->select('user_id')
      ->from('auth_assignment')
      ->where(['item_name' => 'investor'])
      ->column();

    Yii::$app->db->createCommand()->update('users', ['status' => 9], ['id' => $investorsIds])->execute();
  }
}
