<?php

use console\components\Migration;
use yii\db\Query;
use mcms\common\helpers\ArrayHelper;
use yii\db\Expression;

class m160401_101053_fix_investor_rebills extends Migration
{

  protected $courses;

  public function up()
  {
    $paymentsModule = Yii::$app->getModule('payments');

    $this->courses = $paymentsModule->api('exchangerCourses')->getCurrencyCourses();

    $promoModule = Yii::$app->getModule('promo');
    $allCurrencies = $promoModule->api('mainCurrencies')->getResult();
    $currencies = ArrayHelper::map($allCurrencies, 'id', 'code');

    $rebills = (new Query())
      ->select('sr.operator_id, sr.landing_id, s.user_id, sr.source_id, sr.currency_id')
      ->from('subscription_rebills sr')
      ->innerJoin('sources s', 'sr.source_id = s.id')
      ->where('profit_rub = 0 AND profit_usd = 0 AND profit_eur = 0 AND currency_id <> :currencyRub', [
        ':currencyRub' => array_search('rub', $currencies)
      ])
      ->andWhere(['>=', 'date', date('Y-m-d', time() - 4*86400)])
      ->groupBy('operator_id, landing_id, source_id');

    foreach ($rebills->each() AS $rebill) {
      $profitPercents = $promoModule->api('personalProfit', [
        'userId' => $rebill['user_id'],
        'operatorId' => $rebill['operator_id'],
        'landingId' => $rebill['landing_id']
      ])->getResult();
      $profitPercent = ArrayHelper::getValue($profitPercents, 'rebill_percent') / 100;

      $originalCurrency = ArrayHelper::getValue($currencies, $rebill['currency_id']);

      $profitTemplate = 'reseller_profit_%s * %s * %s';

      $this->update('subscription_rebills', [
        'profit_rub' => new Expression(sprintf(
            $profitTemplate,
            $originalCurrency,
            $profitPercent,
            $this->getCourse($originalCurrency, 'rub')
          )
        ),
        'profit_eur' => new Expression(sprintf(
            $profitTemplate,
            $originalCurrency,
            $profitPercent,
            $this->getCourse($originalCurrency, 'eur')
          )
        ),
        'profit_usd' => new Expression(sprintf(
            $profitTemplate,
            $originalCurrency,
            $profitPercent,
            $this->getCourse($originalCurrency, 'usd')
          )
        )
      ], [
        'source_id' => $rebill['source_id'],
        'operator_id' => $rebill['operator_id'],
        'landing_id' => $rebill['landing_id']
      ]);
    }
  }

  public function down()
  {

  }


  protected function getCourse($fromCurrency, $toCurrency)
  {
    if ($fromCurrency == $toCurrency) return 1;

    // костыльная замена rub => rur
    $fromCurrency = $fromCurrency == 'rub' ? 'rur' : $fromCurrency;
    $toCurrency = $toCurrency == 'rub' ? 'rur' : $toCurrency;

    $convertType = sprintf('%s_%s', $fromCurrency, $toCurrency);

    return $this->courses->{$convertType};
  }
}
