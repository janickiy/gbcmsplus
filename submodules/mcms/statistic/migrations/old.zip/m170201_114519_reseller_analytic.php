<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170201_114519_reseller_analytic extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticFilterByLTV', 'Просмотр фильтра по LTV', 'StatisticFilter');
    $this->assignRolesPermission('StatisticFilterByLTV', ['reseller']);
    $this->assignRolesPermission('StatisticAnalyticsIndex', ['reseller']);
  }

  public function down()
  {
    $this->revokeRolesPermission('StatisticAnalyticsIndex', ['reseller']);
    $this->removePermission('StatisticFilterByLTV');
  }
}
