<?php

use console\components\Migration;

class m151215_133750_update_statistic_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Statistic';
    $this->permissions = [
      'DetailStatistic' => [
        // detail/index/
        ['index', 'Can view detail subscription ', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['ik', 'Can view detail ik', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['sells', 'Can view detail sells', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
      ],
      'Statistic' => [
        ['groupByLandings', 'Can group by landings',
          ['admin', 'root', 'investor', 'reseller', 'partner']
        ],
        ['groupBySources', 'Can group by sources',
          ['admin', 'root', 'investor', 'reseller', 'partner']
        ],
        ['groupByStreams', 'Can group by streams',
          ['admin', 'root', 'investor', 'reseller', 'partner']
        ],
        ['groupByPlatforms', 'Can group by platforms',
          ['admin', 'root', 'investor', 'reseller', 'partner']
        ],
        ['groupByOperators', 'Can group by operators',
          ['admin', 'root', 'investor', 'reseller', 'partner']
        ],
        ['groupByCountries', 'Can group by countries',
          ['admin', 'root', 'investor', 'reseller', 'partner']
        ],
        ['groupByLandingPayTypes', 'Can group by landing pay types',
          ['admin', 'root', 'investor', 'reseller', 'partner']
        ],
      ]
    ];
  }


}
