<?php

use console\components\Migration;

class m170514_082750_reseller_export extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticExportController', 'Контроллер Export', 'StatisticModule');
    $this->createPermission('StatisticExportReseller', 'Скачать статистику реселлера', 'StatisticExportController', ['reseller', 'admin', 'root']);
  }

  public function down()
  {
    $this->removePermission('StatisticExportReseller');
    $this->removePermission('StatisticExportController');
  }
}
