<?php

use console\components\Migration;

class m151116_113058_init extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    // статистика по переходам
    $this->createTable('hits', [
      'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'is_unique' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_tb' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'time' => 'INT(10) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'hour' => 'TINYINT(1) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    $this->createIndex('hits_group_by_hour', 'hits', ['date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'landing_pay_type_id', 'hour', 'is_unique', 'is_tb']);

    // детальная информация по переходам
    $this->createTable('hit_params', [
      'hit_id' => 'INT(10) UNSIGNED NOT NULL PRIMARY KEY',
      'ip' => 'INT(11) NOT NULL',
      'referer' => 'VARCHAR(512) DEFAULT NULL',
      'user_agent' => 'VARCHAR(512) DEFAULT NULL',
      'label1' => 'VARCHAR(512) DEFAULT NULL',
      'label2' => 'VARCHAR(512) DEFAULT NULL'
    ], $tableOptions);

    // подписки
    $this->createTable('subscriptions', [
      'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'hit_id' => 'INT(10) UNSIGNED NOT NULL',
      'trans_id' => 'VARCHAR(64) NOT NULL',
      'time' => 'INT(10) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'hour' => 'TINYINT(1) UNSIGNED NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'phone' => 'VARCHAR(16) NOT NULL'
    ], $tableOptions);

    // может быть только одна подписка от одного перехода
    $this->createIndex('subscr_hit_id_uk', 'subscriptions', ['hit_id'], true);

    $this->createIndex('subscriptions_group_by_hour', 'subscriptions', ['date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'hour', 'landing_pay_type_id']);

    $this->createIndex('subscriptions_ss_group', 'subscriptions', ['time', 'hit_id', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'landing_pay_type_id']);

    // ребиллы
    $this->createTable('subscription_rebills', [
      'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'hit_id' => 'INT(10) UNSIGNED NOT NULL',
      'trans_id' => 'VARCHAR(64) NOT NULL',
      'time' => 'INT(10) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'hour' => 'TINYINT(1) UNSIGNED NOT NULL',
      'default_profit' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'default_profit_currency' => 'TINYINT(1) UNSIGNED NOT NULL',
      'real_profit_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'reseller_profit_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'profit_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'profit_eur' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'profit_usd' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    // может быть много ребилов от одной подписки проверяем уникальность транзакции
    $this->createIndex('subscr_rebills_hit_id_trans_id_uk', 'subscription_rebills', ['hit_id', 'trans_id'], true);

    $this->createIndex('subscription_rebills_group_by_hour', 'subscription_rebills'
      , ['date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'hour', 'landing_pay_type_id', 'real_profit_rub', 'reseller_profit_rub', 'profit_rub', 'profit_eur', 'profit_usd']);

    $this->createIndex('subscription_rebills_ss_group', 'subscription_rebills'
      , ['time', 'hit_id', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'landing_pay_type_id', 'real_profit_rub', 'reseller_profit_rub', 'profit_rub', 'profit_eur', 'profit_usd']);

    // отписки
    $this->createTable('subscription_offs', [
      'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'hit_id' => 'INT(10) UNSIGNED NOT NULL',
      'trans_id' => 'VARCHAR(64) NOT NULL',
      'time' => 'INT(10) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'hour' => 'TINYINT(1) UNSIGNED NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    // может быть только одна отписка от одного перехода
    $this->createIndex('subscr_off_hit_id_uk', 'subscription_offs', ['hit_id'], true);

    $this->createIndex('subscription_offs_group_by_hour', 'subscription_offs'
      , ['date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'hour']);

    $this->createIndex('subscription_offs_ss_group', 'subscription_offs'
      , ['time', 'hit_id', 'source_id', 'landing_id', 'operator_id', 'platform_id']);

    // единоразовые списания
    $this->createTable('onetime_subscriptions', [
      'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'hit_id' => 'INT(10) UNSIGNED NOT NULL',
      'trans_id' => 'VARCHAR(64) NOT NULL',
      'time' => 'INT(10) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'hour' => 'TINYINT(1) UNSIGNED NOT NULL',
      'default_profit' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'default_profit_currency' => 'TINYINT(1) UNSIGNED NOT NULL',
      'real_profit_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'reseller_profit_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'profit_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'profit_eur' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'profit_usd' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'provider_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'stream_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'label1' => 'VARCHAR(512) DEFAULT NULL',
      'label2' => 'VARCHAR(512) DEFAULT NULL',
      'phone' => 'VARCHAR(16) NOT NULL'
    ], $tableOptions);

    // может быть только одно единоразовое списание от одного перехода
    $this->createIndex('onetime_subscr_hit_id_uk', 'onetime_subscriptions', ['hit_id'], true);

    // продажи
    $this->createTable('sold_subscriptions', [
      'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'hit_id' => 'INT(10) UNSIGNED NOT NULL',
      'real_price_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'reseller_price_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'price_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'price_eur' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'price_usd' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'time' => 'INT(10) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'hour' => 'TINYINT(1) UNSIGNED NOT NULL',
      'stream_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'to_stream_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'to_source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'to_user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'provider_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    // подписку продать можно только один раз
    $this->createIndex('sold_subscr_hit_id_uk', 'sold_subscriptions', ['hit_id'], true);

  }

  public function down()
  {
    $this->dropTable('hits');
    $this->dropTable('hit_params');
    $this->dropTable('subscriptions');
    $this->dropTable('subscription_rebills');
    $this->dropTable('subscription_offs');
    $this->dropTable('onetime_subscriptions');
    $this->dropTable('sold_subscriptions');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
