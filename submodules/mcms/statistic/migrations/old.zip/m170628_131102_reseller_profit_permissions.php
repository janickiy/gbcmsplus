<?php

use console\components\Migration;

class m170628_131102_reseller_profit_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticResellerProfitController', 'Контроллер ResellerProfit', 'StatisticModule', ['root', 'admin', 'reseller']);
    $this->createPermission('StatisticResellerProfitIndex', 'Статистика профита реселлера', 'StatisticResellerProfitController', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('StatisticResellerProfitController');
    $this->removePermission('StatisticResellerProfitIndex');
  }
}
