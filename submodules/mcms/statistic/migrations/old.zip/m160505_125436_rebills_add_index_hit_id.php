<?php

use console\components\Migration;

class m160505_125436_rebills_add_index_hit_id extends Migration
{

  const TABLE = 'subscription_rebills';
  public function up()
  {
    $this->createIndex(self::TABLE . '_hit_id_index', self::TABLE, 'hit_id');

    $this->createIndex('subscription_rebills_ss_group_profits', self::TABLE, [
      'hit_id',
      'time',
      'real_profit_rub',
      'real_profit_eur',
      'real_profit_usd',
      'reseller_profit_rub',
      'reseller_profit_eur',
      'reseller_profit_usd',
      'profit_rub',
      'profit_eur',
      'profit_usd'
    ]);
  }

  public function down()
  {
    $this->dropIndex('subscription_rebills_ss_group_profits', self::TABLE);
    $this->dropIndex(self::TABLE . '_hit_id_index', self::TABLE);
  }
}
