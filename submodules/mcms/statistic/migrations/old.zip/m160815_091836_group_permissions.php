<?php

use console\components\Migration;

/**
 * Class m160815_091836_group_permissions
 */
class m160815_091836_group_permissions extends Migration
{
  use \mcms\common\traits\PermissionGroupMigration;

  public function init()
  {
    parent::init();

    $this->groupPermissionName = 'StatisticModule';
    $this->groupPermissionDescription = 'Module Statistic';
//    $this->groupPermissionDefaultRole = ['admin', 'root'];

    $this->groupPermissionControllers = [
      'StatisticDefaultController' => [
        'description' => 'Main statistic controller [group]',
        'permissions' => [
          ['StatisticDefaultIndex'], ['StatisticDefaultHour']
        ]
      ],
      'StatisticDetailController' => [
        'description' => 'Detail statistic controller [group]',
        'permissions' => [
          ['StatisticDetailSubscriptions'], ['StatisticDetailSubscriptionDetail'],
          ['StatisticDetailSells'], ['StatisticDetailSellsDetail'],
          ['StatisticDetailIk'], ['StatisticDetailIkDetail'],
          ['StatisticDetailComplains'], ['StatisticDetailComplainDetail']
        ],
      ],
      'StatisticStatFiltersController' => [
        'description' => 'Statistic select2 actions [group]',
        'permissions' => [
          ['StatisticStatFiltersSources'],
          ['StatisticStatFiltersStreams'],
          ['StatisticStatFiltersUsers']
        ]
      ],
      'StatisticPermissions' => [
        'description' => 'Statistic permissions [group]',
        'permissions' => [
          ['StatisticFilter'], ['StatisticGroup'], ['StatisticView']
        ]
      ],
      'StatisticFilter' => [
        'description' => 'Statistic filters [group]',
        'permissions' => [
          ['StatisticFilterByUsers'],
          ['StatisticFilterBySources'],
          ['StatisticFilterByStreams'],
          ['StatisticFilterByCurrency'],
          ['StatisticFilterByLandings'],
          ['StatisticFilterByCountries'],
          ['StatisticFilterByOperators'],
          ['StatisticFilterByPlatforms'],
          ['StatisticFilterByProviders'],
          ['StatisticFilterByFakeRevshare'],
          ['StatisticFilterByLandingPayTypes']
        ]
      ],
      'StatisticGroup' => [
        'description' => 'Statistic groups [group]',
        'permissions' => [
          ['StatisticGroupByHours'],
          ['StatisticGroupByUsers'],
          ['StatisticGroupBySources'],
          ['StatisticGroupByStreams'],
          ['StatisticGroupByLandings'],
          ['StatisticGroupByCountries'],
          ['StatisticGroupByOperators'],
          ['StatisticGroupByPlatforms'],
          ['StatisticGroupByProviders'],
          ['StatisticGroupByLandingPayTypes']
        ]
      ],
      'StatisticView' => [
        'description' => 'Statistic view permissions [group]',
        'permissions' => [
          ['StatisticViewIp'],
          ['StatisticViewUser'],
          ['StatisticViewPhone'],
          ['StatisticViewLabel1'],
          ['StatisticViewLabel2'],
          ['StatisticViewSource'],
          ['StatisticViewStream'],
          ['StatisticViewCountry'],
          ['StatisticViewLanding'],
          ['StatisticViewOperator'],
          ['StatisticViewPlatform'],
          ['StatisticViewProvider'],
          ['StatisticViewReferrer'],
          ['StatisticViewComplains'],
          ['StatisticViewFullPhone'],
          ['StatisticViewSoldPrice'],
          ['StatisticViewUserAgent'],
          ['StatisticViewAdminProfit'],
          ['StatisticViewPartnerProfit'],
          ['StatisticViewBlackListUsers'],
          ['StatisticViewResellerProfit'],
          ['StatisticViewDetailStatistic'],
          ['StatisticViewDetailRebillList'],
          ['StatisticViewSellPartnerPrice'],
          ['StatisticViewSellInvestorPrice'],
          ['StatisticViewInvestorBuyoutPrice'],
          ['StatisticViewHiddenSoldSubscriptions'],
          ['StatisticViewBuyoutPriceInsteadProfit'],
          ['StatisticViewHiddenOnetimeSubscriptions']
        ]
      ]

    ];
  }

  public function down()
  {
    echo 'No down migration';
    return true;
  }


}
