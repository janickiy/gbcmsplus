<?php

use console\components\Migration;

class m160304_215037_update_reseller_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->createOrGetPermission('StatisticDetailSubscriptionDetail', 'View detail info by subscription');
    $this->assignRolesPermission('StatisticDetailSubscriptionDetail', ['root', 'admin', 'reseller', 'investor']);

  }

  public function down()
  {
    $this->createOrGetPermission('StatisticDetailSubscriptionDetail', 'View detail info by subscription');
    $this->assignRolesPermission('StatisticDetailSubscriptionDetail', ['root', 'admin', 'investor']);
  }

}
