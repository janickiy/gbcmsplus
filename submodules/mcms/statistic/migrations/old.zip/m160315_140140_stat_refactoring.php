<?php

use console\components\Migration;

class m160315_140140_stat_refactoring extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  const SOLD = 'sold_subscriptions';
  const PROFIT_RUB = 'profit_rub';
  const PROFIT_EUR = 'profit_eur';
  const PROFIT_USD = 'profit_usd';
  const IS_VISIBLE = 'is_visible_to_partner';
  const REBILLS = 'subscription_rebills';
  const ONETIME = 'onetime_subscriptions';
  const PERM_CAN_VIEW = 'StatisticViewHiddenSoldSubscriptions';
  const SEARCH_SUB = 'search_subscriptions';
  const SUB_DHG = 'subscriptions_day_hour_group';
  const SUB_DG = 'subscriptions_day_group';
  const CAN_FILTER = 'StatisticFilterByCurrency';
  const SUB = 'subscriptions';
  const SUB_OFFS = 'subscription_offs';
  const VIEW_SOLD_PRICE = 'StatisticViewSoldPrice';

  public function up()
  {
    $this->addColumn(self::SOLD, self::PROFIT_RUB, 'decimal(6,2) unsigned NOT NULL DEFAULT 0 after price_usd');
    $this->addColumn(self::SOLD, self::PROFIT_EUR, 'decimal(6,2) unsigned NOT NULL DEFAULT 0 after ' . self::PROFIT_RUB);
    $this->addColumn(self::SOLD, self::PROFIT_USD, 'decimal(6,2) unsigned NOT NULL DEFAULT 0 after ' . self::PROFIT_EUR);

    echo "    > миграция профита для партнера ...\n";
    $this->db->createCommand('UPDATE sold_subscriptions SET profit_rub = price_rub, profit_usd = price_usd, profit_eur = price_eur')->execute();

    $this->addColumn(self::SOLD, self::IS_VISIBLE, 'tinyint(1) unsigned NOT NULL DEFAULT 1');


    $this->createOrGetPermission(self::PERM_CAN_VIEW, 'Can view sold_subscriptions that are hidden for partner');
    $this->assignRolesPermission(self::PERM_CAN_VIEW, ['root', 'reseller', 'admin', 'investor']);

    // новые валюты для ребиллов
    $this->addColumn(self::REBILLS, 'currency_id', 'tinyint(1) unsigned NOT NULL COMMENT \'оригинальная валюта\' after default_profit_currency');
    $this->addColumn(self::REBILLS, 'real_profit_eur', 'decimal(6,2) unsigned NOT NULL after real_profit_rub');
    $this->addColumn(self::REBILLS, 'real_profit_usd', 'decimal(6,2) unsigned NOT NULL after real_profit_eur');
    $this->addColumn(self::REBILLS, 'reseller_profit_eur', 'decimal(6,2) unsigned NOT NULL after reseller_profit_rub');
    $this->addColumn(self::REBILLS, 'reseller_profit_usd', 'decimal(6,2) unsigned NOT NULL after reseller_profit_eur');
    echo "    > все ребиллы currency_id = 1 ...\n";
    $this->update(self::REBILLS, ['currency_id' => 1]);

    // новые валюты для onetime
    $this->addColumn(self::ONETIME, 'currency_id', 'tinyint(1) unsigned NOT NULL COMMENT \'оригинальная валюта\' after default_profit_currency');
    $this->addColumn(self::ONETIME, 'real_profit_eur', 'decimal(6,2) unsigned NOT NULL after real_profit_rub');
    $this->addColumn(self::ONETIME, 'real_profit_usd', 'decimal(6,2) unsigned NOT NULL after real_profit_eur');
    $this->addColumn(self::ONETIME, 'reseller_profit_eur', 'decimal(6,2) unsigned NOT NULL after reseller_profit_rub');
    $this->addColumn(self::ONETIME, 'reseller_profit_usd', 'decimal(6,2) unsigned NOT NULL after reseller_profit_eur');
    echo "    > все ИК currency_id = 1 ...\n";
    $this->update(self::ONETIME, ['currency_id' => 1]);

    // новые валюты для выкупа
    $this->addColumn(self::SOLD, 'currency_id', 'tinyint(1) unsigned NOT NULL COMMENT \'оригинальная валюта\' after hit_id');
    $this->addColumn(self::SOLD, 'real_price_eur', 'decimal(6,2) unsigned NOT NULL after real_price_rub');
    $this->addColumn(self::SOLD, 'real_price_usd', 'decimal(6,2) unsigned NOT NULL after real_price_eur');
    $this->addColumn(self::SOLD, 'reseller_price_eur', 'decimal(6,2) unsigned NOT NULL after reseller_price_rub');
    $this->addColumn(self::SOLD, 'reseller_price_usd', 'decimal(6,2) unsigned NOT NULL after reseller_price_eur');
    echo "    > все выкупы currency_id = 1 ...\n";
    $this->update(self::SOLD, ['currency_id' => 1]);


    // subscriptions_day_hour_group
    $this->addColumn(self::SUB_DHG, 'currency_id', 'tinyint(1) unsigned NOT NULL COMMENT \'оригинальная валюта\' after count_rebills');
    $this->addColumn(self::SUB_DHG, 'sum_real_profit_eur', 'decimal(6,2) unsigned NOT NULL after sum_real_profit_rub');
    $this->addColumn(self::SUB_DHG, 'sum_real_profit_usd', 'decimal(6,2) unsigned NOT NULL after sum_real_profit_eur');
    $this->addColumn(self::SUB_DHG, 'sum_reseller_profit_eur', 'decimal(6,2) unsigned NOT NULL after sum_reseller_profit_rub');
    $this->addColumn(self::SUB_DHG, 'sum_reseller_profit_usd', 'decimal(6,2) unsigned NOT NULL after sum_reseller_profit_eur');

    // subscriptions_day_group
    $this->addColumn(self::SUB_DG, 'currency_id', 'tinyint(1) unsigned NOT NULL COMMENT \'оригинальная валюта\' after count_rebills');
    $this->addColumn(self::SUB_DG, 'sum_real_profit_eur', 'decimal(6,2) unsigned NOT NULL after sum_real_profit_rub');
    $this->addColumn(self::SUB_DG, 'sum_real_profit_usd', 'decimal(6,2) unsigned NOT NULL after sum_real_profit_eur');
    $this->addColumn(self::SUB_DG, 'sum_reseller_profit_eur', 'decimal(6,2) unsigned NOT NULL after sum_reseller_profit_rub');
    $this->addColumn(self::SUB_DG, 'sum_reseller_profit_usd', 'decimal(6,2) unsigned NOT NULL after sum_reseller_profit_eur');

    $this->createOrGetPermission(self::CAN_FILTER, 'Can filter by currency in statistic');
    $this->assignRolesPermission(self::CAN_FILTER, ['root', 'admin', 'reseller', 'investor']);

    // subscriptions
    $this->addColumn(self::SUB, 'currency_id', 'tinyint(1) unsigned NOT NULL COMMENT \'оригинальная валюта\' after is_cpa');
    $this->db->createCommand('UPDATE ' . self::SUB . ' s JOIN landing_operators lo ON lo.landing_id = s.landing_id AND lo.operator_id = s.operator_id SET s.currency_id = lo.default_currency_id')->execute();

    // subscription_offs
    $this->addColumn(self::SUB_OFFS, 'currency_id', 'tinyint(1) unsigned NOT NULL COMMENT \'оригинальная валюта\' after is_cpa');
    $this->db->createCommand('UPDATE ' . self::SUB_OFFS . ' s JOIN landing_operators lo ON lo.landing_id = s.landing_id AND lo.operator_id = s.operator_id SET s.currency_id = lo.default_currency_id')->execute();


    // search_subscriptions
    $this->addColumn(self::SEARCH_SUB, 'currency_id', 'tinyint(1) unsigned NOT NULL COMMENT \'оригинальная валюта\' after is_cpa');
    $this->addColumn(self::SEARCH_SUB, 'sum_real_profit_eur', 'decimal(6,2) unsigned NOT NULL after sum_real_profit_rub');
    $this->addColumn(self::SEARCH_SUB, 'sum_real_profit_usd', 'decimal(6,2) unsigned NOT NULL after sum_real_profit_eur');
    $this->addColumn(self::SEARCH_SUB, 'sum_reseller_profit_eur', 'decimal(6,2) unsigned NOT NULL after sum_reseller_profit_rub');
    $this->addColumn(self::SEARCH_SUB, 'sum_reseller_profit_usd', 'decimal(6,2) unsigned NOT NULL after sum_reseller_profit_eur');
    $this->db->createCommand('UPDATE ' . self::SEARCH_SUB . ' s JOIN landing_operators lo ON lo.landing_id = s.landing_id AND lo.operator_id = s.operator_id SET s.currency_id = lo.default_currency_id')->execute();


    $this->createOrGetPermission(self::VIEW_SOLD_PRICE, 'Can view subscription sold price');
    $this->assignRolesPermission(self::VIEW_SOLD_PRICE, ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission(self::VIEW_SOLD_PRICE);

    $this->dropColumn(self::SEARCH_SUB, 'currency_id');
    $this->dropColumn(self::SEARCH_SUB, 'sum_real_profit_eur');
    $this->dropColumn(self::SEARCH_SUB, 'sum_real_profit_usd');
    $this->dropColumn(self::SEARCH_SUB, 'sum_reseller_profit_eur');
    $this->dropColumn(self::SEARCH_SUB, 'sum_reseller_profit_usd');

    $this->dropColumn(self::SUB, 'currency_id');
    $this->dropColumn(self::SUB_OFFS, 'currency_id');

    $this->removePermission(self::CAN_FILTER);

    $this->dropColumn(self::SUB_DG, 'currency_id');
//    $this->db->createCommand('ALTER TABLE ' . self::SUB_DG . ' DROP PRIMARY KEY, ADD PRIMARY KEY(`date`,`source_id`,`landing_id`,`operator_id`,`platform_id`,`landing_pay_type_id`,`is_cpa`)')->execute();
    $this->dropColumn(self::SUB_DG, 'sum_real_profit_eur');
    $this->dropColumn(self::SUB_DG, 'sum_real_profit_usd');
    $this->dropColumn(self::SUB_DG, 'sum_reseller_profit_eur');
    $this->dropColumn(self::SUB_DG, 'sum_reseller_profit_usd');

//    $this->db->createCommand('ALTER TABLE ' . self::SUB_DHG . ' DROP PRIMARY KEY, ADD PRIMARY KEY(`date`,`hour`,`source_id`,`landing_id`,`operator_id`,`platform_id`,`landing_pay_type_id`,`is_cpa`)')->execute();
    $this->dropColumn(self::SUB_DHG, 'currency_id');
    $this->dropColumn(self::SUB_DHG, 'sum_real_profit_eur');
    $this->dropColumn(self::SUB_DHG, 'sum_real_profit_usd');
    $this->dropColumn(self::SUB_DHG, 'sum_reseller_profit_eur');
    $this->dropColumn(self::SUB_DHG, 'sum_reseller_profit_usd');

    $this->dropColumn(self::SOLD, 'reseller_price_usd');
    $this->dropColumn(self::SOLD, 'reseller_price_eur');
    $this->dropColumn(self::SOLD, 'real_price_usd');
    $this->dropColumn(self::SOLD, 'real_price_eur');
    $this->dropColumn(self::SOLD, 'currency_id');

    $this->dropColumn(self::ONETIME, 'reseller_profit_usd');
    $this->dropColumn(self::ONETIME, 'reseller_profit_eur');
    $this->dropColumn(self::ONETIME, 'real_profit_usd');
    $this->dropColumn(self::ONETIME, 'real_profit_eur');
    $this->dropColumn(self::ONETIME, 'currency_id');

    $this->dropColumn(self::REBILLS, 'reseller_profit_usd');
    $this->dropColumn(self::REBILLS, 'reseller_profit_eur');
    $this->dropColumn(self::REBILLS, 'real_profit_usd');
    $this->dropColumn(self::REBILLS, 'real_profit_eur');
    $this->dropColumn(self::REBILLS, 'currency_id');

    $this->removePermission(self::PERM_CAN_VIEW);
    $this->dropColumn(self::SOLD, self::PROFIT_USD);
    $this->dropColumn(self::SOLD, self::PROFIT_EUR);
    $this->dropColumn(self::SOLD, self::PROFIT_RUB);
    $this->dropColumn(self::SOLD, self::IS_VISIBLE);

  }

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    parent::init();
  }


}
