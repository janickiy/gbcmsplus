<?php

use console\components\Migration;

class m170628_113023_reseller_profits extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable('reseller_profits', [
      'id' => 'int(10) UNSIGNED PRIMARY KEY COMMENT \'будем давать id строкам профитов для удобства синкать\'',
      'investor_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT 0 COMMENT \'Ссылка на инвестора\'',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL COMMENT \'Ссылка на страну\'',
      'date' => 'DATE NOT NULL COMMENT \'дата\'',
      'week_start' => 'DATE NOT NULL COMMENT \'дата начала недели (понедельника)\'',
      'month_start' => 'DATE NOT NULL COMMENT \'дата начала месяца\'',
      'profit_rub' => 'DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0 COMMENT \'Сумма профита RUB\'',
      'profit_usd' => 'DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0 COMMENT \'Сумма профита USD\'',
      'profit_eur' => 'DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0 COMMENT \'Сумма профита EUR\'',
      'unhold_date' => 'DATE NOT NULL COMMENT \'дата, в которую расхолдится эта запись (можно вычислить по country_id)\'',
      'unhold_week_start' => 'DATE NOT NULL COMMENT \'неделя расхолда\'',
      'unhold_month_start' => 'DATE NOT NULL COMMENT \'месяц расхолда\'',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->createIndex(
      'reseller_profits_uq',
      'reseller_profits',
      ['date', 'country_id', 'investor_id'],
      true
    );

    $this->createIndex('group_statistic_by_week', 'reseller_profits', ['week_start']);
    $this->createIndex('group_statistic_by_month', 'reseller_profits', ['month_start']);
    $this->createIndex('group_statistic_unhold_by_date', 'reseller_profits', ['unhold_date']);
    $this->createIndex('group_statistic_unhold_by_week', 'reseller_profits', ['unhold_week_start']);
    $this->createIndex('group_statistic_unhold_by_month', 'reseller_profits', ['unhold_month_start']);
  }

  public function down()
  {
    $this->dropTable('reseller_profits');
  }
}
