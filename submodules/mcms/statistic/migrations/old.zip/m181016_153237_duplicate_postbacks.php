<?php

use console\components\Migration;
use mcms\common\helpers\Console;
use rgk\utils\traits\PermissionTrait;

/**
*/
class m181016_153237_duplicate_postbacks extends Migration
{
  const TABLE = 'postbacks';
  use PermissionTrait;
  /**
  */
  public function up()
  {
    if (!Console::confirm('Для выполнения миграции нужно остановить отправку ПБ. Продолжаем?', true)) {
      return false;
    }

    $this->addColumn(self::TABLE, 'is_duplicate', "TINYINT(1) UNSIGNED NOT NULL DEFAULT '0' AFTER errors");
    $this->createIndex(
      'postbacks_is_duplicate_index',
      self::TABLE,
      'is_duplicate'
    );

    $this->dropForeignKey(self::TABLE . '_' . 'subscription_id' . '_fk', self::TABLE);
    $this->dropForeignKey(self::TABLE . '_' . 'subscription_rebill_id' . '_fk', self::TABLE);
    $this->dropForeignKey(self::TABLE . '_' . 'subscription_off_id' . '_fk', self::TABLE);
    $this->dropForeignKey(self::TABLE . '_' . 'sold_subscription_id' . '_fk', self::TABLE);
    $this->dropForeignKey(self::TABLE . '_' . 'onetime_subscription_id' . '_fk', self::TABLE);

    $this->dropIndex('postbacks_' . 'subscription_id' . '_unique_index', self::TABLE);
    $this->dropIndex('postbacks_' . 'subscription_rebill_id' . '_unique_index', self::TABLE);
    $this->dropIndex('postbacks_' . 'subscription_off_id' . '_unique_index', self::TABLE);
    $this->dropIndex('postbacks_' . 'sold_subscription_id' . '_unique_index', self::TABLE);
    $this->dropIndex('postbacks_' . 'onetime_subscription_id' . '_unique_index', self::TABLE);

    $this->createIndex('postbacks_' . 'subscription_id' . '_unique_index', self::TABLE, ['subscription_id', 'is_duplicate'], true);
    $this->createIndex('postbacks_' . 'subscription_rebill_id' . '_unique_index', self::TABLE, ['subscription_rebill_id', 'is_duplicate'], true);
    $this->createIndex('postbacks_' . 'subscription_off_id' . '_unique_index', self::TABLE, ['subscription_off_id', 'is_duplicate'], true);
    $this->createIndex('postbacks_' . 'sold_subscription_id' . '_unique_index', self::TABLE, ['sold_subscription_id', 'is_duplicate'], true);
    $this->createIndex('postbacks_' . 'onetime_subscription_id' . '_unique_index', self::TABLE, ['onetime_subscription_id', 'is_duplicate'], true);

    $this->addForeignKey(
      self::TABLE . '_' . 'subscription_id' . '_fk',
      self::TABLE,
      'subscription_id',
      'subscriptions',
      'id'
    );

    $this->addForeignKey(
      self::TABLE . '_' . 'subscription_rebill_id' . '_fk',
      self::TABLE,
      'subscription_rebill_id',
      'subscription_rebills',
      'id'
    );

    $this->addForeignKey(
      self::TABLE . '_' . 'subscription_off_id' . '_fk',
      self::TABLE,
      'subscription_off_id',
      'subscription_offs',
      'id'
    );

    $this->addForeignKey(
      self::TABLE . '_' . 'sold_subscription_id' . '_fk',
      self::TABLE,
      'sold_subscription_id',
      'sold_subscriptions',
      'id'
    );

    $this->addForeignKey(
      self::TABLE . '_' . 'onetime_subscription_id' . '_fk',
      self::TABLE,
      'onetime_subscription_id',
      'onetime_subscriptions',
      'id'
    );

    $this->dropColumn('sources', 'is_duplicate_postback');

    $this->update('rgk_settings', ['title_en' => 'Duplicate postbacks'], ['key' => 'postback_is_campaign_with_preland']);
  }

  /**
  */
  public function down()
  {
    $this->dropIndex('postbacks_is_duplicate_index', self::TABLE);
    $this->dropColumn(self::TABLE, 'is_duplicate');
    $this->addColumn('sources', 'is_duplicate_postback', "TINYINT(1) UNSIGNED NOT NULL DEFAULT '0'");

    $this->dropForeignKey(self::TABLE . '_' . 'subscription_id' . '_fk', self::TABLE);
    $this->dropForeignKey(self::TABLE . '_' . 'subscription_rebill_id' . '_fk', self::TABLE);
    $this->dropForeignKey(self::TABLE . '_' . 'subscription_off_id' . '_fk', self::TABLE);
    $this->dropForeignKey(self::TABLE . '_' . 'sold_subscription_id' . '_fk', self::TABLE);
    $this->dropForeignKey(self::TABLE . '_' . 'onetime_subscription_id' . '_fk', self::TABLE);

    $this->dropIndex('postbacks_' . 'subscription_id' . '_unique_index', self::TABLE);
    $this->dropIndex('postbacks_' . 'subscription_rebill_id' . '_unique_index', self::TABLE);
    $this->dropIndex('postbacks_' . 'subscription_off_id' . '_unique_index', self::TABLE);
    $this->dropIndex('postbacks_' . 'sold_subscription_id' . '_unique_index', self::TABLE);
    $this->dropIndex('postbacks_' . 'onetime_subscription_id' . '_unique_index', self::TABLE);

    $this->createIndex('postbacks_' . 'subscription_id' . '_unique_index', self::TABLE, 'subscription_id', true);
    $this->createIndex('postbacks_' . 'subscription_rebill_id' . '_unique_index', self::TABLE, 'subscription_rebill_id', true);
    $this->createIndex('postbacks_' . 'subscription_off_id' . '_unique_index', self::TABLE, 'subscription_off_id', true);
    $this->createIndex('postbacks_' . 'sold_subscription_id' . '_unique_index', self::TABLE, 'sold_subscription_id', true);
    $this->createIndex('postbacks_' . 'onetime_subscription_id' . '_unique_index', self::TABLE, 'onetime_subscription_id', true);

    $this->addForeignKey(
      self::TABLE . '_' . 'subscription_id' . '_fk',
      self::TABLE,
      'subscription_id',
      'subscriptions',
      'id'
    );

    $this->addForeignKey(
      self::TABLE . '_' . 'subscription_rebill_id' . '_fk',
      self::TABLE,
      'subscription_rebill_id',
      'subscription_rebills',
      'id'
    );

    $this->addForeignKey(
      self::TABLE . '_' . 'subscription_off_id' . '_fk',
      self::TABLE,
      'subscription_off_id',
      'subscription_offs',
      'id'
    );

    $this->addForeignKey(
      self::TABLE . '_' . 'sold_subscription_id' . '_fk',
      self::TABLE,
      'sold_subscription_id',
      'sold_subscriptions',
      'id'
    );

    $this->addForeignKey(
      self::TABLE . '_' . 'onetime_subscription_id' . '_fk',
      self::TABLE,
      'onetime_subscription_id',
      'onetime_subscriptions',
      'id'
    );
  }
}
