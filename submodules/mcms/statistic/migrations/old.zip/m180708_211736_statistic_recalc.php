<?php

use console\components\Migration;

class m180708_211736_statistic_recalc extends Migration
{
  const TABLE = 'statistic_recalc';

  public function up()
  {

    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(static::TABLE, [
      'trans_id' => 'VARCHAR(64) NOT NULL',
      'time' => 'INT(10) UNSIGNED NOT NULL',
    ], $tableOptions);

  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }
}
