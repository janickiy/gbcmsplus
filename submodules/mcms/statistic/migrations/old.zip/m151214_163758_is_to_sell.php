<?php

use console\components\Migration;

class m151214_163758_is_to_sell extends Migration
{
  public function up()
  {
    $this->addColumn('hit_params', 'is_to_sell', 'TINYINT(1) UNSIGNED DEFAULT 0 AFTER label2');
    $this->addColumn('search_subscriptions', 'is_to_sell', 'TINYINT(1) UNSIGNED DEFAULT 0 AFTER phone');
  }

  public function down()
  {
    $this->dropColumn('hit_params', 'is_to_sell');
    $this->dropColumn('search_subscriptions', 'is_to_sell');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
