<?php

use console\components\Migration;

class m180503_121838_remove_investor_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->removePermission('CanViewResCpr');
  }

  public function down()
  {
    $this->createPermission('CanViewResCpr', 'Разрешение на просмотр реселлерского CPR', 'StatisticPermissions');
  }

}