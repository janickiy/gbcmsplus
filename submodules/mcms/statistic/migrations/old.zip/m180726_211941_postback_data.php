<?php

use console\components\Migration;

/**
*/
class m180726_211941_postback_data extends Migration
{
  const TABLE = 'postback_data';

  /**
  */
  public function up()
  {
    $this->createTable(self::TABLE, [
      'id' => 'BIGINT(12) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'handler_code' => $this->string(255)->notNull(),
      'provider_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'data' => $this->text()->notNull(),
      'time' => 'INT(10) UNSIGNED NOT NULL',
      'is_handled' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
    ]);

    $this->createIndex(self::TABLE . '_time_provider_id_index', self::TABLE, ['time', 'provider_id']);
    $this->createIndex(self::TABLE . '_is_handled_index', self::TABLE, ['is_handled']);
  }

  /**
  */
  public function down()
  {
    $this->dropTable(self::TABLE);
  }
}
