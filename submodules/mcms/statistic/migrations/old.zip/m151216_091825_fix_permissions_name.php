<?php

use console\components\Migration;

class m151216_091825_fix_permissions_name extends Migration
{

  public function safeUp()
  {

    $this->delete('auth_item', ['like', 'name', 'Statistic%', false]);

    $newPermissions = [


      'StatisticDefaultIndex' => ['root', 'admin', 'reseller', 'investor'], // основная статистика
      'StatisticDetailIk' => ['root', 'admin', 'reseller', 'investor'], // детальная по ик
      'StatisticDetailSells' => ['root', 'admin', 'reseller', 'investor'], //детальная по продажам
      'StatisticDetailSubscriptions' => ['root', 'admin', 'reseller', 'investor'], //детальная по подпискам

      // фильтры
      'StatisticFilterByCountries' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticFilterByLandingPayTypes' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticFilterByLandings' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticFilterByOperators' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticFilterByPlatforms' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticFilterByProviders' => ['root', 'admin'],
      'StatisticFilterBySources' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticFilterByStreams' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticFilterByUsers' => ['root', 'admin', 'reseller', 'investor'],

      // группировки
      'StatisticGroupByCountries' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticGroupByLandingPayTypes' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticGroupByLandings' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticGroupByOperators' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticGroupByPlatforms' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticGroupByProviders' => ['root', 'admin', 'investor'],
      'StatisticGroupBySources' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticGroupByStreams' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticGroupByUsers' => ['root', 'admin', 'reseller', 'investor'],
      'StatisticGroupByHours' => ['root', 'admin', 'reseller', 'investor', 'partner'],

      // профиты
      'StatisticViewBlackListUsers' => ['root', 'admin'],
      'StatisticViewPartnerProfit' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticViewResellerProfit' => ['root', 'admin', 'reseller'],
      'StatisticViewAdminProfit' => ['root', 'admin'],

      // модальное окно в детальной
      'StatisticViewDetailRebillList' => ['root', 'admin'],
      'StatisticViewDetailStatistic' => ['root', 'admin', 'reseller'],

      // колонки которые может понадобится скрыть
      'StatisticViewIp' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticViewLabel1' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticViewLabel2' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticViewOperator' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticViewPhone' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticViewPlatform' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticViewUser' => ['root', 'admin', 'reseller', 'investor'],
      'StatisticViewProvider' => ['root', 'admin', 'investor'],
      'StatisticViewReferrer' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticViewSource' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticViewStream' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticViewUserAgent' => ['root', 'admin', 'reseller', 'investor', 'partner'],
      'StatisticViewCountry' => ['root', 'admin', 'reseller', 'investor', 'partner'],
    ];

    $auth = Yii::$app->authManager;
    foreach ($newPermissions as $newPermissionName => $roles) {

      $permission = $auth->getPermission($newPermissionName);
      if (!$permission) {
        $permission = $auth->createPermission($newPermissionName);
        $auth->add($permission);
      }

      foreach ($roles as $role) {
        $roleDb = $auth->getRole($role);
        if (!$auth->hasChild($roleDb, $permission)) {
          $auth->addChild($roleDb, $permission);
        }
      }
    }

  }

  public function safeDown()
  {
    // Nothing to do
  }
  
  
}
