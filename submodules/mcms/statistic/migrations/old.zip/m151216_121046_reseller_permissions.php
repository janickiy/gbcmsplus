<?php

use console\components\Migration;

class m151216_121046_reseller_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Statistic';
    $this->permissions = [
      'Default' => [
        ['index', 'Can view main statistic', ['reseller']]
      ]
    ];
  }

}
