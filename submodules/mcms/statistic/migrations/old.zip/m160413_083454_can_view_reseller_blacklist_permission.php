<?php

use console\components\Migration;

class m160413_083454_can_view_reseller_blacklist_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  const PERMISSION = 'ViewResellerBlacklistUsers';

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    parent::init();
  }

  public function up()
  {
    $this->createOrGetPermission(self::PERMISSION, 'View reseller blacklist users');
    $this->assignRolesPermission(self::PERMISSION, ['root', 'admin']);
  }

  public function down()
  {
    $this->removePermission(self::PERMISSION);
  }

}
