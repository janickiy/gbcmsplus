<?php

use console\components\Migration;

class m151229_124335_statistic_index_n_key extends Migration
{
  public function up()
  {
    $this->addForeignKey('subscriptions' . '_' . 'source_id' . '_fk', 'subscriptions', 'source_id', 'sources', 'id');
    $this->addForeignKey('subscription_rebills' . '_' . 'source_id' . '_fk', 'subscription_rebills', 'source_id', 'sources', 'id');
    $this->addForeignKey('subscription_offs' . '_' . 'source_id' . '_fk', 'subscription_offs', 'source_id', 'sources', 'id');
    $this->addForeignKey('sold_subscriptions' . '_' . 'source_id' . '_fk', 'sold_subscriptions', 'source_id', 'sources', 'id');
    $this->addForeignKey('onetime_subscriptions' . '_' . 'source_id' . '_fk', 'onetime_subscriptions', 'source_id', 'sources', 'id');
    $this->createIndex('postbacks_status_errors_index', 'postbacks', ['status', 'errors']);
  }

  public function down()
  {
    $this->dropIndex('postbacks_status_errors_index', 'postbacks');
    $this->dropForeignKey('onetime_subscriptions' . '_' . 'source_id' . '_fk', 'onetime_subscriptions');
    $this->dropForeignKey('sold_subscriptions' . '_' . 'source_id' . '_fk', 'sold_subscriptions');
    $this->dropForeignKey('subscription_offs' . '_' . 'source_id' . '_fk', 'subscription_offs');
    $this->dropForeignKey('subscription_rebills' . '_' . 'source_id' . '_fk', 'subscription_rebills');
    $this->dropForeignKey('subscriptions_source_id_fk', 'subscriptions');
  }
}
