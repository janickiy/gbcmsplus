<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

class m180215_104458_analytics_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->revokeRolesPermission('StatisticAnalyticsIndex', ['investor']);
  }

  public function down()
  {
    $this->assignRolesPermission('StatisticAnalyticsIndex', ['investor']);
  }
}
