<?php

use console\components\Migration;
use yii\db\Query;

class m180530_074031_euro_step2 extends Migration
{
  public function up()
  {
    if (!\mcms\common\helpers\Console::confirm('Нужно отключить кроны и синк. Продолжаем?', true)) {
      return false;
    }

    // MCMS-2194 30-31 мая в 00:00мск переводим Азербайджан и все баксовые страны на евро
    $counties = (new Query())->from('countries')->where(['or', ['currency' => 'usd'], ['code' => 'AZ']])->all();

    foreach ($counties as $country) {
      $this->insert('country_currency_log', [
        'country_id' => $country['id'],
        'currency' => $country['currency'],
        'created_at' => 0,
      ]);
      $this->insert('country_currency_log', [
        'country_id' => $country['id'],
        'currency' => 'eur',
        'created_at' => Yii::$app->formatter->asTimestamp('2018-05-31 00:00:00') // форматтер подхватывает часовой пояс мск
      ]);
      $this->update('countries', ['currency' => 'eur'], ['id' => $country['id']]);
    }
  }

  public function down()
  {
    if (!\mcms\common\helpers\Console::confirm('Нужно отключить кроны и синк. Продолжаем?', true)) {
      return false;
    }

    $logEntries = (new Query())->from('country_currency_log')
      ->where(['not in', 'country_id', [4, 10]])
      ->andWhere(['created_at' => 0])
      ->all();

    foreach ($logEntries as $logEntry) {
      $this->update('countries', ['currency' => $logEntry['currency']], ['id' => $logEntry['country_id']]);
    }

    $this->delete('country_currency_log', ['not in', 'country_id', [4, 10]]);
  }
}
