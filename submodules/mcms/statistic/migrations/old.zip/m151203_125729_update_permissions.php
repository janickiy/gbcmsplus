<?php

use console\components\Migration;

class m151203_125729_update_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Statistic';
    $this->permissions = [
      'Statistic' => [
        ['viewPartnerTotalProfit', 'Can view partner total profit', ['admin', 'partner', 'reseller']],
        ['viewResellerTotalProfit', 'Can view reseller total profit', ['admin', 'reseller']],
        ['viewAdminTotalProfit', 'Can view admin total profit', ['admin']],
      ]
    ];
  }


}
