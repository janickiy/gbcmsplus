<?php

use console\components\Migration;

class m160329_083437_buyout_vs_solds extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  const PERMISSION = 'StatisticViewBuyoutsInsteadOfSolds';

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->createOrGetPermission(self::PERMISSION, 'View buyouts instead of solds at main statistic');
    $this->assignRolesPermission(self::PERMISSION, ['investor']);
  }

  public function down()
  {
    $this->removePermission(self::PERMISSION);
  }
}
