<?php

use console\components\Migration;

class m160718_172053_label_index extends Migration
{

  public function up()
  {

    $approve = \mcms\common\helpers\Console::confirm('Эта миграция тяжелая. Вы уверены, что хотите выполнить её?', true);

    if (!$approve)  return true;

    $this->db->createCommand("
    CREATE TABLE `_tmp_statistic_label_group` (
      `label1` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
      `label2` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
      `label1_hash` binary(16) NOT NULL,
      `label2_hash` binary(16) NOT NULL,
      `date` date NOT NULL,
      `hour` tinyint(1) NOT NULL,
      `source_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `operator_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `landing_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `platform_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `landing_pay_type_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
      `is_cpa` tinyint(1) unsigned NOT NULL DEFAULT '0',
      `is_visible_to_partner` tinyint(1) unsigned NOT NULL DEFAULT '1',
      `user_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `stream_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `provider_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `country_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_hits` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_uniques` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_tb` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_ons` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_sold` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_onetime` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_offs` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_rebills` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `sum_real_profit_rub` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_real_profit_eur` decimal(6,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_real_profit_usd` decimal(6,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_reseller_profit_rub` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_reseller_profit_eur` decimal(6,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_reseller_profit_usd` decimal(6,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_profit_rub` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_profit_eur` decimal(6,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_profit_usd` decimal(6,2) unsigned NOT NULL DEFAULT '0.00',
      `currency_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
      PRIMARY KEY (`label1_hash`,`label2_hash`,`date`,`hour`,`source_id`,`operator_id`,`landing_id`,`platform_id`,`landing_pay_type_id`,`is_cpa`,`is_visible_to_partner`),
      KEY `statistic_label_group_l1_index` (`label1_hash`),
      KEY `statistic_label_group_l2_index` (`label2_hash`),
      KEY `statistic_label_group_l12_index` (`label1_hash`,`label2_hash`),
      KEY `statistic_label_group_provider_id_index` (`provider_id`),
      KEY `statistic_label_group_date_hour_index` (`date`,`hour`),
      KEY `statistic_label_group_user_id_index` (`user_id`),
      KEY `statistic_label_group_source_id_index` (`source_id`),
      KEY `statistic_label_group_operator_id_index` (`operator_id`),
      KEY `statistic_label_group_landing_id_index` (`landing_id`),
      KEY `statistic_label_group_platform_id_index` (`platform_id`),
      KEY `statistic_label_group_is_cpa_index` (`is_cpa`),
      KEY `statistic_label_group_stream_id_index` (`stream_id`),
      KEY `statistic_label_group_country_id_index` (`country_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci
    ")->execute();

    $this->db->createCommand("
      INSERT INTO `_tmp_statistic_label_group`
      SELECT * FROM statistic_label_group;
    ")->execute();

    $this->dropTable('statistic_label_group');
    $this->renameTable('_tmp_statistic_label_group', 'statistic_label_group');
  }

  public function down()
  {
    $this->db->createCommand("
    CREATE TABLE `_tmp_statistic_label_group` (
      `label1` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
      `label2` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
      `label1_hash` binary(16) NOT NULL,
      `label2_hash` binary(16) NOT NULL,
      `date` date NOT NULL,
      `hour` tinyint(1) NOT NULL,
      `source_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `operator_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `landing_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `platform_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `landing_pay_type_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
      `is_cpa` tinyint(1) unsigned NOT NULL DEFAULT '0',
      `is_visible_to_partner` tinyint(1) unsigned NOT NULL DEFAULT '1',
      `user_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `stream_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `provider_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `country_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_hits` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_uniques` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_tb` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_ons` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_sold` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_onetime` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_offs` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `count_rebills` mediumint(5) unsigned NOT NULL DEFAULT '0',
      `sum_real_profit_rub` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_real_profit_eur` decimal(6,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_real_profit_usd` decimal(6,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_reseller_profit_rub` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_reseller_profit_eur` decimal(6,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_reseller_profit_usd` decimal(6,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_profit_rub` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_profit_eur` decimal(6,2) unsigned NOT NULL DEFAULT '0.00',
      `sum_profit_usd` decimal(6,2) unsigned NOT NULL DEFAULT '0.00',
      `currency_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
      PRIMARY KEY (`label1_hash`,`label2_hash`,`date`,`hour`,`source_id`,`operator_id`,`landing_id`,`platform_id`,`landing_pay_type_id`,`is_cpa`,`is_visible_to_partner`),
      KEY `statistic_label_group_l1_index` (`label1_hash`),
      KEY `statistic_label_group_l2_index` (`label2_hash`),
      KEY `statistic_label_group_l12_index` (`label1_hash`,`label2_hash`),
      KEY `statistic_label_group_provider_id_index` (`provider_id`),
      KEY `statistic_label_group_date_hour_index` (`date`,`hour`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci
    ")->execute();

    $this->db->createCommand("
      INSERT INTO `_tmp_statistic_label_group`
      SELECT * FROM statistic_label_group;
    ")->execute();

    $this->dropTable('statistic_label_group');
    $this->renameTable('_tmp_statistic_label_group', 'statistic_label_group');
  }
}
