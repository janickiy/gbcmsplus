<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;


class m180219_135239_analytics_filters_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticAnalyticsFilters', 'Получение фильтров', 'StatisticAnalyticsController', ['root','admin','reseller','manager']);
  }

  public function down()
  {
    $this->removePermission('StatisticAnalyticsFilters');
  }
}

