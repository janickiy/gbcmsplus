<?php

use console\components\Migration;

class m160530_153331_create_smart_filters_table extends Migration
{

  const TABLE = 'stat_filters';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(self::TABLE, [
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'provider_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'stream_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    $this->addPrimaryKey(
      'stat_filters_pk',
      self::TABLE,
      ['user_id', 'landing_id', 'operator_id', 'platform_id', 'landing_pay_type_id', 'provider_id', 'source_id', 'stream_id']
    );

    $this->createIndex('user_stat_filters_user_id_index', self::TABLE, 'user_id');
    $this->createIndex('user_stat_filters_landing_id_index', self::TABLE, 'landing_id');
    $this->createIndex('user_stat_filters_operator_id_index', self::TABLE, 'operator_id');
    $this->createIndex('user_stat_filters_country_id_index', self::TABLE, 'country_id');
    $this->createIndex('user_stat_filters_platform_id_index', self::TABLE, 'platform_id');
    $this->createIndex('user_stat_filters_landing_pay_type_id_index', self::TABLE, 'landing_pay_type_id');
    $this->createIndex('user_stat_filters_provider_id_index', self::TABLE, 'provider_id');
    $this->createIndex('user_stat_filters_source_id_index', self::TABLE, 'source_id');
    $this->createIndex('user_stat_filters_stream_id_index', self::TABLE, 'stream_id');
  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }
}
