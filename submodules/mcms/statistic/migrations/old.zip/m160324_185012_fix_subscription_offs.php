<?php

use console\components\Migration;

class m160324_185012_fix_subscription_offs extends Migration
{
  public function up()
  {
    $this->db->createCommand('
      UPDATE subscription_offs so JOIN hits h ON so.hit_id = h.id
      SET so.source_id = h.source_id
      WHERE h.source_id <> so.source_id;
    ')->execute();
  }

  public function down()
  {
    echo "m160324_185012_fix_subscription_offs cannot be reverted.\n";
  }
}
