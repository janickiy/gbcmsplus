<?php

use console\components\Migration;
use mcms\common\traits\PermissionMigration;

class m161122_092612_referrals_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission(
      'StatisticReferralsController',
      'Контроллер Referrals',
      'StatisticModule',
      ['root', 'admin', 'reseller']
    );

    $this->createPermission(
      'StatisticReferralsIndex',
      'Статистика по рефералам',
      'StatisticReferralsController'
    );

    $this->createPermission(
      'StatisticReferralsPartnerModal',
      'Статистика по рефераллам партнера',
      'StatisticReferralsController'
    );
  }

  public function down()
  {
    $this->removePermission('StatisticReferralsPartnerModal');
    $this->removePermission('StatisticReferralsIndex');
    $this->removePermission('StatisticReferralsController');
  }

}
