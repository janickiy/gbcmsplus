<?php

use console\components\Migration;

/**
 * Class m170912_120430_hold_rules_page
 */
class m170912_120430_hold_rules_page extends Migration
{

  use \rgk\utils\traits\PermissionTrait;
  /**
   *
   */
  public function up()
  {
    $this->createPermission('StatisticResellerHoldRulesController', 'Контроллер правила холдирования профитов реселлера', 'StatisticModule');
    $this->createPermission('StatisticResellerHoldRulesIndex', 'Просмотр правил холдирования профитов реселлера', 'StatisticResellerHoldRulesController', ['root', 'admin', 'reseller']);

  }

  /**
   */
  public function down()
  {
    $this->removePermission('StatisticResellerHoldRulesIndex');
    $this->removePermission('StatisticResellerHoldRulesController');
  }
}
