<?php

use console\components\Migration;

class m160318_120637_update_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  protected $permissionName = 'StatisticViewUser';

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->removePermission($this->permissionName);
    $this->createOrGetPermission($this->permissionName, 'View user in statistic');
    $this->assignRolesPermission($this->permissionName, ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission($this->permissionName);
  }
}
