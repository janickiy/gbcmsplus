<?php

use console\components\Migration;

class m160414_084636_add_investor_permissions extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->assignRolesPermission('PromoArbitrarySourcesSelect2', ['root', 'admin', 'reseller', 'manager', 'investor']);
  }

  public function down()
  {
    echo "m160414_084636_add_investor_permissions cannot be reverted.\n";
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
