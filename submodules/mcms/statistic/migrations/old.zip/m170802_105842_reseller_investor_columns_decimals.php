<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170802_105842_reseller_investor_columns_decimals extends Migration
{
  use PermissionTrait;
  
  public function up()
  {
    $this->createPermission('StatisticViewColumnsDecimals', 'Для изменения количества знаков после запятой', 'StatisticPermissions', ['reseller', 'investor']);
  }
  
  public function down()
  {
    $this->removePermission('StatisticViewColumnsDecimals');
  }
}
