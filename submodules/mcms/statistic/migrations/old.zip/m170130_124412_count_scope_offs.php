<?php

use console\components\Migration;

class m170130_124412_count_scope_offs extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable('statistic_data_hour_group', [
      'count_scope_offs' => 'mediumint(5) unsigned NOT NULL',
      'date' => 'date NOT NULL',
      'hour' => 'tinyint(1) NOT NULL',
      'source_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'landing_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'operator_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'platform_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_fake' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'currency_id' => 'tinyint(1) unsigned NOT NULL',
      'provider_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'stream_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'user_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0',
      'country_id' => 'mediumint(5) unsigned NOT NULL DEFAULT 0'
    ], $tableOptions);

    $this->addPrimaryKey('sdhg_pk', 'statistic_data_hour_group', ['date', 'hour', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'landing_pay_type_id', 'is_fake']);
  }

  public function down()
  {
    $this->dropTable('statistic_data_hour_group');
  }
}
