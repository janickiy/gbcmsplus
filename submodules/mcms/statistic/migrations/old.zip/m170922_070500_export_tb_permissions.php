<?php

use console\components\Migration;

class m170922_070500_export_tb_permissions extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticExportTb', 'Скачать отчет по ТБ', 'StatisticExportController', ['reseller', 'admin', 'root']);
  }

  public function down()
  {
    $this->removePermission('StatisticExportTb');
  }
}
