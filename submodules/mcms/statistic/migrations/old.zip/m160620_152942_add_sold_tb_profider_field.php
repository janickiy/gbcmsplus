<?php

use console\components\Migration;

class m160620_152942_add_sold_tb_profider_field extends Migration
{

  const TABLE = 'sold_trafficback';

  public function up()
  {
    $this->addColumn(self::TABLE, 'tb_provider_id', 'MEDIUMINT(5) UNSIGNED NOT NULL AFTER provider_id');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'tb_provider_id');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
