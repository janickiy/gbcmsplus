<?php

use console\components\Migration;

class m170202_133553_new_labels extends Migration
{

  const TABLE = 'statistic_label_group_1';


  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET latin1 ENGINE=InnoDB';
    }

    $this->createTable(self::TABLE, [
      'label1' => $this->string(512),
      'label2' => $this->string(512),
      'label1_hash' => 'char(8) NOT NULL',
      'label2_hash' => 'char(8) NOT NULL',
      'date' => $this->date()->notNull(),
      'user_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'source_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'operator_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'landing_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'platform_id' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'landing_pay_type_id' => 'tinyint(1) unsigned NOT NULL DEFAULT \'0\'',
      'is_cpa' => 'tinyint(1) unsigned NOT NULL DEFAULT \'0\'',
      'count_hits' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'count_uniques' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'count_tb' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'count_ons' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'count_sold' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'count_onetime' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'count_offs' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'count_rebills' => 'mediumint(5) unsigned NOT NULL DEFAULT \'0\'',
      'sum_profit_rub' => 'decimal(8,2) unsigned NOT NULL DEFAULT \'0\'',
      'sum_profit_eur' => 'decimal(6,2) unsigned NOT NULL DEFAULT \'0\'',
      'sum_profit_usd' => 'decimal(6,2) unsigned NOT NULL DEFAULT \'0\'',
    ], $tableOptions);

    $this->addPrimaryKey(self::TABLE . '_pk', self::TABLE, [
      'label1_hash',
      'label2_hash',
      'date',
      'source_id',
      'operator_id',
      'landing_id',
      'platform_id',
      'landing_pay_type_id',
      'is_cpa'
    ]);
    $this->createIndex(self::TABLE . '_l1_index', self::TABLE, ['label1_hash', 'user_id', 'date']);
    $this->createIndex(self::TABLE . '_l2_index', self::TABLE, ['label2_hash', 'user_id', 'date']);
    $this->createIndex(self::TABLE . '_l12_index', self::TABLE, ['label1_hash', 'label2_hash', 'user_id', 'date']);
  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }
}
