<?php

use console\components\Migration;

/**
 */
class m171222_135713_buyout_price_delete extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  /**
   */
  public function up()
  {
    $this->removePermission('StatisticViewBuyoutPriceInsteadProfit');
  }

  /**
   */
  public function down()
  {
    $this->createPermission('StatisticViewBuyoutPriceInsteadProfit', 'Просмотр цены выкупа вместо дохода', 'StatisticView', ['admin', 'manager', 'reseller', 'root']);
  }
}
