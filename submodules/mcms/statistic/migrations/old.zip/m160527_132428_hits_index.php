<?php

use console\components\Migration;

class m160527_132428_hits_index extends Migration
{
  public function up()
  {

    $approve = \mcms\common\helpers\Console::confirm('Эту миграцию должен выполнить админ. Пропустить миграцию?');

    if ($approve) return true;

    $this->createIndex(
      'hits_time_source_id_landing_id_operator_id_index',
      'hits',
      ['time', 'source_id', 'landing_id', 'operator_id']
    );

    /**
     *
     * ALTER TABLE `hits` ADD INDEX `hits_time_source_id_landing_id_operator_id_index` (`time`, `source_id`, `landing_id`, `operator_id`)
     *
     */
  }

  public function down()
  {

  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
