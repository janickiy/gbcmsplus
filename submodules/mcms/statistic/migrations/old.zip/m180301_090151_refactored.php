<?php

use console\components\Migration;

/**
 */
class m180301_090151_refactored extends Migration
{

  use \rgk\utils\traits\PermissionTrait;
  /**
   */
  public function up()
  {
    $this->createPermission('StatisticMainRefactored', 'Получение фильтров', 'StatisticMainController', ['root']);

  }

  /**
   */
  public function down()
  {
    $this->removePermission('StatisticMainRefactored');
  }

}
