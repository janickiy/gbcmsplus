<?php

use console\components\Migration;

class m151116_131051_grouped_data_tables extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    // сгруппированная по дням статистика по переходам
    $this->createTable('hits_day_group', [
      'count_hits' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'count_uniques' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'count_tb' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'provider_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'stream_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    // добавляем PK
    $this->addPrimaryKey('hdg_pk', 'hits_day_group',
      ['date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'landing_pay_type_id']);

    // сгруппированная по дням статистика по подпискам
    $this->createTable('subscriptions_day_group', [
      'count_ons' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'count_offs' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'count_rebills' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'sum_real_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL',
      'sum_reseller_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL',
      'sum_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL',
      'sum_profit_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL',
      'sum_profit_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'provider_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'stream_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    // добавляем PK
    $this->addPrimaryKey('sdg_pk', 'subscriptions_day_group',
      ['date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'landing_pay_type_id']);


    // сгруппированная по дням и часам статистика по переходам
    $this->createTable('hits_day_hour_group', [
      'count_hits' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'count_uniques' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'count_tb' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'hour' => 'TINYINT(1) NOT NULL',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'provider_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'stream_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    // добавляем PK
    $this->addPrimaryKey('hdhg_pk', 'hits_day_hour_group',
      ['date', 'hour', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'landing_pay_type_id']);

    $this->createIndex('hdhg_group_by_day', 'hits_day_hour_group', ['date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'hour', 'landing_pay_type_id', 'count_hits', 'count_uniques', 'count_tb']);

    // сгруппированная по дням и часам статистика по подпискам
    $this->createTable('subscriptions_day_hour_group', [
      'count_ons' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'count_offs' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'count_rebills' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'sum_real_profit_rub' => 'DECIMAL(8,2) UNSIGNED NOT NULL',
      'sum_reseller_profit_rub' => 'DECIMAL(8,2) UNSIGNED NOT NULL',
      'sum_profit_rub' => 'DECIMAL(8,2) UNSIGNED NOT NULL',
      'sum_profit_eur' => 'DECIMAL(8,2) UNSIGNED NOT NULL',
      'sum_profit_usd' => 'DECIMAL(8,2) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'hour' => 'TINYINT(1) NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'provider_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'stream_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    // добавляем PK
    $this->addPrimaryKey('sdhg_pk', 'subscriptions_day_hour_group',
      ['date', 'hour', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'landing_pay_type_id']);

    $this->createIndex('sdhg_group_by_day', 'subscriptions_day_hour_group'
      , ['date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'hour', 'landing_pay_type_id', 'count_ons', 'count_offs', 'count_rebills',
        'sum_real_profit_rub', 'sum_reseller_profit_rub', 'sum_profit_rub', 'sum_profit_eur', 'sum_profit_usd'
      ]);

    // сгруппированная информация для поиска по подпискам
    $this->createTable('search_subscriptions', [
      'hit_id' => 'INT(10) UNSIGNED NOT NULL PRIMARY KEY',
      'time_on' => 'INT(10) UNSIGNED NOT NULL',
      'time_off' => 'INT(10) UNSIGNED NOT NULL',
      'time_rebill' => 'INT(10) UNSIGNED NOT NULL',
      'last_time' => 'INT(10) UNSIGNED NOT NULL',
      'count_rebills' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'sum_real_profit_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'sum_reseller_profit_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'sum_profit_rub' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'sum_profit_eur' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'sum_profit_usd' => 'DECIMAL(6,2) UNSIGNED NOT NULL',
      'label1' => 'VARCHAR(512) DEFAULT NULL',
      'label2' => 'VARCHAR(512) DEFAULT NULL',
      'phone' => 'VARCHAR(16) NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'provider_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'stream_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0'
    ], $tableOptions);

    $this->createIndex('ss_last_time', 'search_subscriptions', ['last_time']);

  }

  public function down()
  {
    $this->dropTable('hits_day_group');
    $this->droptable('subscriptions_day_group');
    $this->dropTable('hits_day_hour_group');
    $this->droptable('subscriptions_day_hour_group');
    $this->droptable('search_subscriptions');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
