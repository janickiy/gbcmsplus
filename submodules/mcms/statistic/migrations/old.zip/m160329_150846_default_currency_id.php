<?php

use console\components\Migration;

class m160329_150846_default_currency_id extends Migration
{
  public function up()
  {
    $this->db->createCommand('UPDATE subscriptions SET currency_id=1 WHERE currency_id = 0;')->execute();
    $this->db->createCommand('UPDATE subscription_offs SET currency_id=1 WHERE currency_id = 0;')->execute();
    $this->db->createCommand('UPDATE subscriptions_day_hour_group SET currency_id=1 WHERE currency_id = 0;')->execute();
    $this->db->createCommand('UPDATE subscriptions_day_group SET currency_id=1 WHERE currency_id = 0;')->execute();
    $this->db->createCommand('UPDATE search_subscriptions SET currency_id=1 WHERE currency_id = 0;')->execute();
  }

  public function down()
  {
    echo "m160329_150846_default_currency_id cannot be reverted.\n";
  }

}
