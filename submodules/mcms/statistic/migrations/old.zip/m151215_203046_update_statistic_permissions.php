<?php

use console\components\Migration;

class m151215_203046_update_statistic_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Statistic';
    $this->permissions = [
      'DetailStatistic' => [
        // detail/index/
        ['subscriptionViewHitId', 'Can view subscription hit id', ['admin', 'root']],
        ['subscriptionViewPhone', 'Can view subscription phone', ['admin', 'root']],
        ['subscriptionViewIp', 'Can view subscription ip', ['admin', 'root']],
        ['subscriptionViewStream', 'Can view subscription stream', ['admin', 'root']],
        ['subscriptionViewSource', 'Can view subscription source', ['admin', 'root']],
        ['subscriptionViewCountry', 'Can view subscription country', ['admin', 'root']],
        ['subscriptionViewOperator', 'Can view subscription operator', ['admin', 'root']],
        ['subscriptionViewPlatform', 'Can view subscription platform', ['admin', 'root']],
        ['subscriptionViewSubscribedAt', 'Can view subscription subscribed at', ['admin', 'root']],
        ['subscriptionViewUnSubscribedAt', 'Can view subscription unsubscribed at', ['admin', 'root']],
        ['subscriptionViewLastRebillAt', 'Can view subscription last rebill at', ['admin', 'root']],
        ['subscriptionViewCountRebills', 'Can view subscription count rebills', ['admin', 'root']],
        ['subscriptionViewSumProfit', 'Can view subscription sum profit', ['admin', 'root']],
        ['subscriptionViewDetailStatistic', 'Can view subscription detail statistic', ['admin', 'root']],
        ['subscriptionViewDetailRebillList', 'Can view subscription detail rebill list', ['admin', 'root']],
        ['subscriptionViewReferrer', 'Can view subscription referrer', ['admin', 'root']],
        ['subscriptionViewUserAgent', 'Can view subscription user agent', ['admin', 'root']],
        ['subscriptionViewLabel1', 'Can view subscription label1', ['admin', 'root']],
        ['subscriptionViewLabel2', 'Can view subscription label2', ['admin', 'root']],
        ['subscriptionViewLandingPayType', 'Can view subscription landing pay type', ['admin', 'root']],
        //detail/ik/
        ['ikViewHitId', 'Can view ik hit id', ['admin', 'root']],
        ['ikViewPhone', 'Can view ik phone', ['admin', 'root']],
        ['ikViewIp', 'Can view ik ip', ['admin', 'root']],
        ['ikViewStream', 'Can view ik stream', ['admin', 'root']],
        ['ikViewSource', 'Can view ik source', ['admin', 'root']],
        ['ikViewCountry', 'Can view ik country', ['admin', 'root']],
        ['ikViewOperator', 'Can view ik operator', ['admin', 'root']],
        ['ikViewPlatform', 'Can view ik platform', ['admin', 'root']],
        ['ikViewLandingPayType', 'Can view ik landing pay type', ['admin', 'root']],
        ['ikViewSubscribedAt', 'Can view ik subscribed at', ['admin', 'root']],
        ['ikViewProfitSum', 'Can view ik profit sum', ['admin', 'root']],
        ['ikViewReferrer', 'Can view ik referrer', ['admin', 'root']],
        ['ikViewUserAgent', 'Can view ik user agent', ['admin', 'root']],
        ['ikViewLabel1', 'Can view ik label1', ['admin', 'root']],
        ['ikViewLabel2', 'Can view ik label2', ['admin', 'root']],
        //detail/sells/
        ['sellsViewHitId', 'Can view sells hit id', ['admin', 'root']],
        ['sellsViewPhone', 'Can view sells phone', ['admin', 'root']],
        ['sellsViewIp', 'Can view sells ip', ['admin', 'root']],
        ['sellsViewStream', 'Can view sells stream', ['admin', 'root']],
        ['sellsViewSource', 'Can view sells source', ['admin', 'root']],
        ['sellsViewCountry', 'Can view sells country', ['admin', 'root']],
        ['sellsViewOperator', 'Can view sells operator', ['admin', 'root']],
        ['sellsViewPlatform', 'Can view sells platform', ['admin', 'root']],
        ['sellsViewLandingPayType', 'Can view sells landing pay type', ['admin', 'root']],
        ['sellsViewSubscribedAt', 'Can view sells subscribed at', ['admin', 'root']],
        ['sellsViewProfitSum', 'Can view sells profit sum', ['admin', 'root']],
        ['sellsViewReferrer', 'Can view sells referrer', ['admin', 'root']],
        ['sellsViewUserAgent', 'Can view sells user agent', ['admin', 'root']],
        ['sellsViewLabel1', 'Can view sells label1', ['admin', 'root']],
        ['sellsViewLabel2', 'Can view sells label2', ['admin', 'root']],

        ['viewAdminProfit', 'View admin profit sum', ['admin', 'root']],
        ['viewResellerProfit', 'View reseller profit sum', ['admin', 'root']],
        ['viewProfit', 'View profit sum', ['admin', 'root']],
      ],
      'DetailInfo' => [
        ['viewAdminProfit', 'View admin profit sum', ['admin', 'root']],
        ['viewResellerProfit', 'View reseller profit sum', ['admin', 'root']],
        ['viewProfit', 'View profit sum', ['admin', 'root']],
      ],
      'Detail' => [
        ['subscriptions', 'View detail statistic by rebills', ['admin', 'root']],
        ['ik', 'View detail statistic by ik', ['admin', 'root']],
        ['sells', 'View detail statistic by sells', ['admin', 'root']],
        ['subscriptionDetail', 'Can view detailed info in detail statistic', ['admin', 'root', 'root']],
        ['ikDetail', 'Can view detailed info in detail statistic', ['admin', 'root', 'root']],
        ['sellsDetail', 'Can view detailed info in detail statistic', ['admin', 'root', 'root']],
      ],
      'Default' => [
        ['index', 'Can view main statistic', ['admin', 'root']]
      ]
    ];
  }
}
