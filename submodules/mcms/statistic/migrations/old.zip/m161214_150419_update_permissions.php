<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m161214_150419_update_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission(
      'StatisticDefaultGraphical',
      'Доступ к графической статистике',
      'StatisticDefaultIndex'
    );
  }

  public function down()
  {
    $this->removePermission('StatisticDefaultGraphical');
  }
}
