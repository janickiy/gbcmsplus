<?php

use console\components\Migration;

class m160328_145020_investor_permission_fix extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  const PERMISSION = 'StatisticFilterByCurrency';

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->revokeRolesPermission(self::PERMISSION, ['investor']);
  }

  public function down()
  {
    $this->assignRolesPermission(self::PERMISSION, ['investor']);
  }
}
