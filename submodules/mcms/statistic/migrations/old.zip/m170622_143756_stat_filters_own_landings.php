<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170622_143756_stat_filters_own_landings extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticFilterByOwnLandings', 'Стат фильтры. Просмотр только своих лендингов в стат фильтрах', 'StatisticPermissions', ['investor']);
  }

  public function down()
  {
    $this->removePermission('StatisticFilterByOwnLandings');
  }
}
