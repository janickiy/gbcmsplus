<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
*/
class m181114_112952_refunds extends Migration
{
  use PermissionTrait;
  /**
  */
  public function up()
  {
    $this->execute('
      CREATE TABLE refunds
        (
          id                      int UNSIGNED AUTO_INCREMENT PRIMARY KEY,
          type            tinyint(1) UNSIGNED DEFAULT 0   NOT NULL,
          hit_id                  bigint UNSIGNED                    NOT NULL,
          trans_id                varchar(64)                     NOT NULL,
          time                    int UNSIGNED                    NOT NULL,
          date                    date                            NOT NULL,
          hour                    tinyint(1) UNSIGNED             NOT NULL,
          description            varchar(512),
          currency_id             tinyint(1) UNSIGNED             NOT NULL,
          local_currency             char(3) CHARSET latin1 NOT NULL,
          local_sum             decimal(9, 5) UNSIGNED          NOT NULL,
          reseller_rub     decimal(9, 5) UNSIGNED          NOT NULL,
          reseller_usd     decimal(9, 5) UNSIGNED          NOT NULL,
          reseller_eur     decimal(9, 5) UNSIGNED          NOT NULL,
          landing_id              mediumint(5) UNSIGNED DEFAULT 0 NOT NULL,
          source_id               mediumint(5) UNSIGNED DEFAULT 0 NOT NULL,
          operator_id             mediumint(5) UNSIGNED DEFAULT 0 NOT NULL,
          platform_id             mediumint(5) UNSIGNED DEFAULT 0 NOT NULL,
          landing_pay_type_id     tinyint(1) UNSIGNED DEFAULT 0   NOT NULL,
          is_cpa                  tinyint(1) UNSIGNED DEFAULT 0   NOT NULL,
          CONSTRAINT refunds_hit_id_uq
          UNIQUE (hit_id)
        )
          COLLATE = utf8_bin;
    ');

    $this->createIndex('refunds_statistic', 'refunds', ['date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'hour', 'landing_pay_type_id', 'is_cpa']);
  }

  /**
  */
  public function down()
  {
    $this->dropTable('refunds');
  }
}
