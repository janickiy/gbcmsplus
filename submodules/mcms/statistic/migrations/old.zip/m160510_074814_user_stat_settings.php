<?php

use console\components\Migration;

class m160510_074814_user_stat_settings extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  const TABLE = 'user_stat_settings';

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(self::TABLE, [
      'user_id' => 'mediumint(5) unsigned NOT NULL',
      'is_label_stat_enabled' => 'tinyint(1) unsigned NOT NULL DEFAULT \'1\'',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    $this->addPrimaryKey(self::TABLE . '_user_id_pk', self::TABLE, 'user_id');
    $this->addForeignKey(self::TABLE . '_user_id_fk', self::TABLE, 'user_id', 'users', 'id', 'CASCADE');
  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }
}
