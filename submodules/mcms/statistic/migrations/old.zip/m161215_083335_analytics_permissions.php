<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m161215_083335_analytics_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->assignRolesPermission('StatisticAnalyticsIndex', ['root', 'admin']);
  }

  public function down()
  {
    $this->revokeRolesPermission('StatisticAnalyticsIndex', ['root', 'admin']);
  }
}
