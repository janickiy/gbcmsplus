<?php

use console\components\Migration;

class m160909_085446_stat_filters_update extends Migration
{
    public function up()
    {
      Yii::$app->db->createCommand("
        CREATE TABLE `_stat_filters_tmp` (
          `user_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
          `landing_id` mediumint(5) unsigned NOT NULL,
          `operator_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
          `country_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
          `platform_id` mediumint(5) unsigned NOT NULL,
          `landing_pay_type_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
          `provider_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
          `source_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
          `stream_id` mediumint(5) unsigned NOT NULL DEFAULT '0',
          PRIMARY KEY (`user_id`,`landing_id`,`operator_id`,`platform_id`,`landing_pay_type_id`,`provider_id`,`source_id`,`stream_id`),
          KEY `user_stat_filters_user_id_index` (`user_id`),
          KEY `user_stat_filters_landing_id_index` (`landing_id`),
          KEY `user_stat_filters_operator_id_index` (`operator_id`),
          KEY `user_stat_filters_country_id_index` (`country_id`),
          KEY `user_stat_filters_platform_id_index` (`platform_id`),
          KEY `user_stat_filters_landing_pay_type_id_index` (`landing_pay_type_id`),
          KEY `user_stat_filters_provider_id_index` (`provider_id`),
          KEY `user_stat_filters_source_id_index` (`source_id`),
          KEY `user_stat_filters_stream_id_index` (`stream_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci
        ")->execute();

      Yii::$app->db->createCommand("
        INSERT INTO _stat_filters_tmp SELECT * FROM stat_filters where (user_id,operator_id) NOT IN (SELECT user_id, operator_id
        FROM hits_day_group
        GROUP BY operator_id, user_id
        HAVING SUM(count_hits) = SUM(count_tb))
        ")->execute();

      $this->dropTable('stat_filters');
      $this->renameTable('_stat_filters_tmp', 'stat_filters');
    }

  public function down()
  {

  }
}
