<?php

use console\components\Migration;

class m160609_084538_sdg_index extends Migration
{

  const SDG = 'subscriptions_day_group';

  public function up()
  {
    $this->createIndex('sdg_group_by_day_user_landing', self::SDG, [
      'date', 'landing_id', 'user_id',
      'sum_profit_rub', 'sum_profit_eur', 'sum_profit_usd',
      'sum_reseller_profit_rub', 'sum_reseller_profit_eur', 'sum_reseller_profit_usd'
    ]);
  }

  public function down()
  {
    $this->dropIndex('sdg_group_by_day_user_landing', self::SDG);
  }
}
