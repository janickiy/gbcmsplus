<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170807_174609_csv_download_permission extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticDetailDownloadCsv', 'Загрузка csv', 'StatisticDetailController', ['admin', 'investor', 'manager', 'root', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('StatisticDetailDownloadCsv');
  }
}
