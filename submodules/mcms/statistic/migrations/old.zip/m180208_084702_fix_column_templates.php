<?php

use console\components\Migration;
use yii\db\Query;

class m180208_084702_fix_column_templates extends Migration
{
  const TABLE = 'columns_templates';

  public function up()
  {
    $templates = (new Query)
      ->select(['id', 'columns'])
      ->from(self::TABLE);

    foreach ($templates->each() as $template) {
      (new Query())->createCommand()->update(
        self::TABLE,
        ['columns' => \yii\helpers\Html::decode($template['columns'])],
        ['id' => $template['id']]
      )->execute();

    }

  }

  public function down()
  {
    return true;
  }

}
