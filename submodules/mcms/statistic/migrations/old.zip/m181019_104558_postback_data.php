<?php

use console\components\Migration;

/**
*/
class m181019_104558_postback_data extends Migration
{
  const TABLE = 'postback_data';
  const COLUMN = 'data';
  /**
  */
  public function up()
  {
    $approve = \mcms\common\helpers\Console::confirm('Эту миграцию должен выполнить админ. Пропустить миграцию?');
    if ($approve) {
      return true;
    }

    $this->alterColumn(self::TABLE, self::COLUMN, 'MEDIUMTEXT');
  }

  /**
  */
  public function down()
  {
    $this->alterColumn(self::TABLE, self::COLUMN, 'TEXT');
  }
}
