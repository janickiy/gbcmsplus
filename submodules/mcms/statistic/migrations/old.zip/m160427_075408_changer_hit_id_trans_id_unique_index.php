<?php

use console\components\Migration;
use yii\db\Query;

class m160427_075408_changer_hit_id_trans_id_unique_index extends Migration
{

  const REBILLS = 'subscription_rebills';
  const OFF = 'subscription_offs';
  const SUBS = 'subscriptions';


  public function up()
  {

    $this->dropIndex('subscr_rebills_hit_id_trans_id_uk', self::REBILLS);
    $this->addColumn(self::REBILLS, 'provider_id', 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0');

    $this->db->createCommand('UPDATE ' . self::REBILLS . ' set provider_id = 1')->execute();

    $this->createIndex(
      'subscr_rebills_trans_id_provider_id_uk',
      self::REBILLS,
      ['trans_id', 'provider_id'],
      true
    );

    $this->addColumn(self::OFF, 'provider_id', 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0');
    $this->addColumn(self::SUBS, 'provider_id', 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0');
    $this->db->createCommand('UPDATE ' . self::OFF . ' set provider_id = 1')->execute();
    $this->db->createCommand('UPDATE ' . self::SUBS . ' set provider_id = 1')->execute();
  }

  public function down()
  {
    $this->dropIndex('subscr_rebills_trans_id_provider_id_uk', self::REBILLS);
    $this->dropColumn(self::REBILLS, 'provider_id');
    $this->createIndex(
      'subscr_rebills_hit_id_trans_id_uk',
      self::REBILLS,
      ['hit_id', 'trans_id'],
      true
    );

    $this->dropColumn(self::OFF, 'provider_id');
    $this->dropColumn(self::SUBS, 'provider_id');
  }
}
