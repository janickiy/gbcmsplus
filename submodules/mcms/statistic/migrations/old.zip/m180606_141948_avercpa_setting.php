<?php

use rgk\settings\models\Setting;
use console\components\Migration;

class m180606_141948_avercpa_setting extends Migration
{
  const SETTING = 'settings.calc_avercpa_all_subs';

  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
  }

  public function up()
  {
    $this->settingsBuilder->createSetting(
      ['en' => 'Calculate Aver. CPA for all subscriptions (Sold+Rejected)', 'ru' => 'Считать Aver. CPA относительно всех подписок (Sold+Rejected)'],
      [],
      self::SETTING,
      ['EditModuleSettingsStatistic'],
      Setting::TYPE_BOOLEAN,
      'app.common.group_statistic',
      false,
      [['boolean']]
    );
  }

  public function down()
  {
    $this->settingsBuilder->removeSetting(self::SETTING);
  }
}