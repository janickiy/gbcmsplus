<?php

use console\components\Migration;


class m180420_082558_balance_country extends Migration
{
  public function up()
  {
    if (!\mcms\common\helpers\Console::confirm('Нужно отключить кроны. Продолжаем?', true)) {
      return false;
    }
    $this->addColumn('user_balances_grouped_by_day', 'country_id', 'MEDIUMINT(5) NOT NULL DEFAULT 0 AFTER user_id');
    $this->dropPrimaryKey('user_balances_grouped_by_day_pk', 'user_balances_grouped_by_day');
    $this->addPrimaryKey(
      'user_balances_grouped_by_day_pk',
      'user_balances_grouped_by_day',
      ['date', 'user_id', 'country_id', 'type', 'user_currency']
    );

    $reseller = Yii::$app->getModule('users')->api('usersByRoles', ['reseller'])->getResult();
    $resellerId = current($reseller)['id'];
    // давно пора было это сделать :D
    $this->delete('user_balances_grouped_by_day', ['user_id' => $resellerId]);
  }

  public function down()
  {
    $this->dropPrimaryKey(
      'user_balances_grouped_by_day_pk',
      'user_balances_grouped_by_day'
    );
    $this->addPrimaryKey('user_balances_grouped_by_day_pk', 'user_balances_grouped_by_day', ['date', 'user_id', 'type', 'user_currency']);
    $this->dropColumn('user_balances_grouped_by_day', 'country_id');
  }
}
