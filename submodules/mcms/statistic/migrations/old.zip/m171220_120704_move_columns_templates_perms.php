<?php

use console\components\Migration;

class m171220_120704_move_columns_templates_perms extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    // Удаление прав для старого контроллера
    $this->removePermission('StatisticDefaultCreateColumnsTemplate');
    $this->removePermission('StatisticDefaultUpdateColumnsTemplate');
    $this->removePermission('StatisticDefaultGetColumnsTemplate');
    $this->removePermission('StatisticDefaultDeleteColumnsTemplate');

    // Создание прав для нового контроллера
    $this->createPermission('StatisticColumnTemplatesController', 'Контроллер ColumnTemplates', 'StatisticModule');
    $this->createPermission('StatisticColumnTemplatesCreate', 'Создание шаблона для столбцов таблицы', 'StatisticColumnTemplatesController', ['admin', 'root', 'reseller', 'investor']);
    $this->createPermission('StatisticColumnTemplatesUpdate', 'Изменение шаблона для столбцов таблицы', 'StatisticColumnTemplatesController', ['admin', 'root', 'reseller', 'investor']);
    $this->createPermission('StatisticColumnTemplatesDelete', 'Удаление шаблона для столбцов таблицы', 'StatisticColumnTemplatesController', ['admin', 'root', 'reseller', 'investor']);
    $this->createPermission('StatisticColumnTemplatesGetTemplate', 'Получение списка шаблонов', 'StatisticColumnTemplatesController', ['admin', 'root', 'reseller', 'investor']);
  }

  public function down()
  {
    // Удаление прав для нового контроллера
    $this->removePermission('StatisticColumnTemplatesController');
    $this->removePermission('StatisticColumnTemplatesCreate');
    $this->removePermission('StatisticColumnTemplatesUpdate');
    $this->removePermission('StatisticColumnTemplatesDelete');
    $this->removePermission('StatisticColumnTemplatesGetTemplate');

    // Восстановление прав для нового контроллера
    $this->createPermission('StatisticDefaultCreateColumnsTemplate', 'Создание шаблона для столбцов таблицы', 'StatisticDefaultIndex', ['admin', 'root', 'reseller', 'investor']);
    $this->createPermission('StatisticDefaultUpdateColumnsTemplate', 'Изменение шаблона для столбцов таблицы', 'StatisticDefaultIndex', ['admin', 'root', 'reseller', 'investor']);
    $this->createPermission('StatisticDefaultDeleteColumnsTemplate', 'Удаление шаблона для столбцов таблицы', 'StatisticDefaultIndex', ['admin', 'root', 'reseller', 'investor']);
    $this->createPermission('StatisticDefaultGetColumnsTemplate', 'Получение списка шаблонов', 'StatisticDefaultIndex', ['admin', 'root', 'reseller', 'investor']);
  }
}
