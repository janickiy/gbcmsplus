<?php

use console\components\Migration;
use yii\db\Query;
use yii\helpers\ArrayHelper;
use yii\helpers\Json;

class m180716_113720_transfer_columns_templates extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  const TABLE = 'columns_templates';
  const TABLE_REFACTORED = 'columns_templates_refactored';

  public function up()
  {
    $templates = (new Query)
      ->select(['id', 'columns'])
      ->from(self::TABLE);

    foreach ($templates->each() as $template) {
      $columns = array_map(function ($column) {
        $newColumn = $this->oldToNewColumn($column);
        if (!$newColumn) {
          echo "Column '$column' is unknown" . PHP_EOL;
        }
        return $newColumn ?: $column;
      }, Json::decode($template['columns']));

      $this->update(
        self::TABLE,
        ['columns' => Json::encode($columns)],
        ['id' => $template['id']]
      );
    }

    $this->dropTable(self::TABLE_REFACTORED);

    $this->removePermission('StatisticColumnTemplatesRefactoredController');
    $this->removePermission('StatisticColumnTemplatesRefactoredCreate');
    $this->removePermission('StatisticColumnTemplatesRefactoredUpdate');
    $this->removePermission('StatisticColumnTemplatesRefactoredDelete');
    $this->removePermission('StatisticColumnTemplatesRefactoredGetTemplate');

    $this->removePermission('StatisticMainRefactored');

  }

  public function down()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(self::TABLE_REFACTORED, [
      'id' => $this->primaryKey(5),
      'user_id' => 'MEDIUMINT(5) unsigned NOT NULL',
      'name' => $this->string(255)->notNull(),
      'columns' => $this->text()->notNull(),
    ], $tableOptions);

    $templates = (new Query)
      ->select(['id', 'columns'])
      ->from(self::TABLE);

    foreach ($templates->each() as $template) {
      $columns = array_map(function ($column) {
        $newColumn = $this->newToOldColumn($column);
        if (!$newColumn) {
          echo "Column '$column' is unknown" . PHP_EOL;
        }
        return $newColumn ?: $column;
      }, Json::decode($template['columns']));

      $this->update(
        self::TABLE,
        ['columns' => Json::encode($columns)],
        ['id' => $template['id']]
      );
    }


    $this->createPermission('StatisticColumnTemplatesRefactoredController', 'Контроллер ColumnTemplatesRefactored', 'StatisticModule');
    $this->createPermission('StatisticColumnTemplatesRefactoredCreate', 'Создание шаблона для столбцов таблицы', 'StatisticColumnTemplatesRefactoredController', ['admin', 'root', 'reseller']);
    $this->createPermission('StatisticColumnTemplatesRefactoredUpdate', 'Изменение шаблона для столбцов таблицы', 'StatisticColumnTemplatesRefactoredController', ['admin', 'root', 'reseller']);
    $this->createPermission('StatisticColumnTemplatesRefactoredDelete', 'Удаление шаблона для столбцов таблицы', 'StatisticColumnTemplatesRefactoredController', ['admin', 'root', 'reseller']);
    $this->createPermission('StatisticColumnTemplatesRefactoredGetTemplate', 'Получение списка шаблонов', 'StatisticColumnTemplatesRefactoredController', ['admin', 'root', 'reseller']);

    $this->createPermission('StatisticMainRefactored', 'Просмотр основной статистики (рефактореной)', 'StatisticMainController', ['root']);
  }

  private function oldToNewColumn($key)
  {
    return ArrayHelper::getValue($this->oldToNewColumns(), $key);
  }

  private function newToOldColumn($key)
  {
    return ArrayHelper::getValue(array_flip($this->oldToNewColumns()), $key);
  }

  private function oldToNewColumns()
  {
    return [
      // ТРАФИК
      'count_hits' => 'hits',
      'count_uniques' => 'uniques',
      'accepted' => 'accepted',
      'count_tb' => 'tb',
      // ЭФФЕКТИВНОСТЬ
      'ecpc' => 'ecpc',
      // РЕВШАР
      'revshare_accepted' => 'revshareAccepted',
      'count_ons' => 'ons',
      'count_offs' => 'offs',
      'count_scope_offs' => 'scopeOffsData',
      'revshare_ratio' => 'revshareRatio',
      'revshare_cr' => 'revshareCr',
      'charges_on_date' => 'rebillsDateByDate',
      'charge_ratio' => 'chargeRatio',
      'sum_on_date' => 'profitDateByDate',
      'count_rebills' => 'rebills',
      'sum_reseller_profit_{currency}' => 'revshareResellerProfit',
      'revshare_reseller_net_profit_{currency}' => 'revshareResellerNetProfit',
      'sum_profit_{currency}' => 'partnerRevshareProfit',
      'revshare_ecpc' => 'ecpcRevshare',
      // ЦПА
      'cpa_accepted' => 'cpaAccepted',
      'count_cpa_ons' => 'cpaOns',
      'count_sold' => 'sold',
      'count_not_sold' => 'rejectedOns',
      'visible_subscriptions' => 'soldVisible',
      'cpa_count_offs' => 'cpaOffs',
      'cpa_count_scope_offs' => 'cpaScopeOffsData',
      'cpa_ratio' => 'cpaRatio',
      'cpa_cr' => 'cpaCr',
      'cpa_cr_sold' => 'cpaCrSold',
      'partner_visible_cpa_cr' => 'cpaCrVisible',
      'cpa_charges_on_date' => 'cpaRebillsDateByDate',
      'cpa_charge_ratio' => 'cpaChargeRatio',
      'cpa_sum_on_date' => 'cpaProfitDateByDate',
      'cpa_count_rebills' => 'cpaRebills',
      'cpa_count_rebills_sold' => 'soldRebills',
      'cpa_rejected_count_rebills' => 'rejectedRebills',
      'cpa_profit_{currency}' => 'cpaProfit',
      'sold_cpa_profit_{currency}' => 'soldRebillsProfit',
      'rejected_cpa_profit_{currency}' => 'rejectedProfit',
      'cpa_reseller_net_profit_{currency}' => 'cpaResellerNetProfit',
      'sold_partner_profit_{currency}' => 'soldPartnerProfit',
      'ecp' => 'cpaEcp',
      'cpa_ecpc' => 'cpaEcpc',
      'cpr' => 'cpaCpr',
      'avg_cpa' => 'avgCpa',
      'rev_sub' => 'revSub',
      'roi_on_date' => 'roiOnDate',
      // ИК
      'onetime_accepted' => 'acceptedOnetime',
      'count_onetime' => 'onetime',
      'partner_visible_count_onetime' => 'visibleOnetime',
      'onetime_ratio' => 'onetimeRatio',
      'onetime_cr' => 'onetimeCr',
      'partner_visible_onetime_cr' => 'visibleOnetimeCr',
      'onetime_reseller_profit_{currency}' => 'onetimeResellerProfit',
      'onetime_reseller_net_profit_{currency}' => 'onetimeResellerNetProfit',
      'onetime_profit_{currency}' => 'onetimeProfit',
      'onetime_ecpc' => 'ecpcOnetime',
      // ТБ
      'sell_tb_accepted' => 'sellTbAccepted',
      'count_sold_tb' => 'soldTb',
      'sold_tb_reseller_profit_{currency}' => 'soldTbProfit',
      // ИТОГО
      'reseller_total_profit_{currency}' => 'resellerTotalProfit',
      'reseller_net_profit_{currency}' => 'resellerNetProfit',
      'partner_total_profit_{currency}' => 'partnerTotalProfit',
      // ЖАЛОБЫ
      'count_complains' => 'complains',
      'count_calls' => 'calls',
      'count_calls_mno' => 'callsMno',
      'complains_rate' => 'complainsRate',
    ];
  }
}
