<?php

use console\components\Migration;

class m151208_070520_update_permissions extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Statistic';
    $this->permissions = [
      'DetailStatistic' => [
        // detail/index/
        ['subscriptionViewHitId', 'Can view subscription hit id', ['admin']],
        ['subscriptionViewPhone', 'Can view subscription phone', ['admin']],
        ['subscriptionViewIp', 'Can view subscription ip', ['admin']],
        ['subscriptionViewStream', 'Can view subscription stream', ['admin']],
        ['subscriptionViewSource', 'Can view subscription source', ['admin']],
        ['subscriptionViewCountry', 'Can view subscription country', ['admin']],
        ['subscriptionViewOperator', 'Can view subscription operator', ['admin']],
        ['subscriptionViewPlatform', 'Can view subscription platform', ['admin']],
        ['subscriptionViewSubscribedAt', 'Can view subscription subscribed at', ['admin']],
        ['subscriptionViewUnSubscribedAt', 'Can view subscription unsubscribed at', ['admin']],
        ['subscriptionViewLastRebillAt', 'Can view subscription last rebill at', ['admin']],
        ['subscriptionViewCountRebills', 'Can view subscription count rebills', ['admin']],
        ['subscriptionViewSumProfit', 'Can view subscription sum profit', ['admin']],
        ['subscriptionViewDetailStatistic', 'Can view subscription detail statistic', ['admin']],
        ['subscriptionViewDetailRebillList', 'Can view subscription detail rebill list', ['admin']],
        ['subscriptionViewReferrer', 'Can view subscription referrer', ['admin']],
        ['subscriptionViewUserAgent', 'Can view subscription user agent', ['admin']],
        ['subscriptionViewLabel1', 'Can view subscription label1', ['admin']],
        ['subscriptionViewLabel2', 'Can view subscription label2', ['admin']],
        ['subscriptionViewLandingPayType', 'Can view subscription landing pay type', ['admin']],
        //detail/ik/
        ['ikViewHitId', 'Can view ik hit id', ['admin']],
        ['ikViewPhone', 'Can view ik phone', ['admin']],
        ['ikViewIp', 'Can view ik ip', ['admin']],
        ['ikViewStream', 'Can view ik stream', ['admin']],
        ['ikViewSource', 'Can view ik source', ['admin']],
        ['ikViewCountry', 'Can view ik country', ['admin']],
        ['ikViewOperator', 'Can view ik operator', ['admin']],
        ['ikViewPlatform', 'Can view ik platform', ['admin']],
        ['ikViewLandingPayType', 'Can view ik landing pay type', ['admin']],
        ['ikViewSubscribedAt', 'Can view ik subscribed at', ['admin']],
        ['ikViewProfitSum', 'Can view ik profit sum', ['admin']],
        ['ikViewReferrer', 'Can view ik referrer', ['admin']],
        ['ikViewUserAgent', 'Can view ik user agent', ['admin']],
        ['ikViewLabel1', 'Can view ik label1', ['admin']],
        ['ikViewLabel2', 'Can view ik label2', ['admin']],
        //detail/sells/
        ['sellsViewHitId', 'Can view sells hit id', ['admin']],
        ['sellsViewPhone', 'Can view sells phone', ['admin']],
        ['sellsViewIp', 'Can view sells ip', ['admin']],
        ['sellsViewStream', 'Can view sells stream', ['admin']],
        ['sellsViewSource', 'Can view sells source', ['admin']],
        ['sellsViewCountry', 'Can view sells country', ['admin']],
        ['sellsViewOperator', 'Can view sells operator', ['admin']],
        ['sellsViewPlatform', 'Can view sells platform', ['admin']],
        ['sellsViewLandingPayType', 'Can view sells landing pay type', ['admin']],
        ['sellsViewSubscribedAt', 'Can view sells subscribed at', ['admin']],
        ['sellsViewProfitSum', 'Can view sells profit sum', ['admin']],
        ['sellsViewReferrer', 'Can view sells referrer', ['admin']],
        ['sellsViewUserAgent', 'Can view sells user agent', ['admin']],
        ['sellsViewLabel1', 'Can view sells label1', ['admin']],
        ['sellsViewLabel2', 'Can view sells label2', ['admin']],

        ['viewAdminProfit', 'View admin profit sum', ['admin']],
        ['viewResellerProfit', 'View reseller profit sum', ['admin']],
        ['viewProfit', 'View profit sum', ['admin']],
      ],
      'DetailInfo' => [
        ['viewAdminProfit', 'View admin profit sum', ['admin']],
        ['viewResellerProfit', 'View reseller profit sum', ['admin']],
        ['viewProfit', 'View profit sum', ['admin']],
      ],
      'Detail' => [
        ['subscriptions', 'View detail statistic by rebills', ['admin']],
        ['ik', 'View detail statistic by ik', ['admin']],
        ['sells', 'View detail statistic by sells', ['admin']],
        ['subscriptionDetail', 'Can view detailed info in detail statistic', ['admin', 'root']],
        ['ikDetail', 'Can view detailed info in detail statistic', ['admin', 'root']],
        ['sellsDetail', 'Can view detailed info in detail statistic', ['admin', 'root']],
      ],
      'Default' => [
        ['index', 'Can view main statistic', ['admin']]
      ]
    ];
  }


}
