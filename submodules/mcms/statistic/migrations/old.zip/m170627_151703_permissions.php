<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170627_151703_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticFilterByRoles', 'Просмотр фильтра по ролям', 'StatisticFilter', ['root', 'admin', 'reseller', 'manager']);
  }

  public function down()
  {
    $this->removePermission('StatisticFilter');
  }

}