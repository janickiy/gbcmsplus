<?php

use console\components\Migration;

class m160627_144710_stat_filters_action extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {

    $parent = $this->authManager->getPermission('StatisticFilterByUsers');
    $child = $this->authManager->createPermission('StatisticStatFiltersUsers');
    $this->authManager->add($child);
    $this->authManager->addChild($parent, $child);

    $parent = $this->authManager->getPermission('StatisticFilterBySources');
    $child = $this->authManager->createPermission('StatisticStatFiltersSources');
    $this->authManager->add($child);
    $this->authManager->addChild($parent, $child);

    $parent = $this->authManager->getPermission('StatisticFilterByStreams');
    $child = $this->authManager->createPermission('StatisticStatFiltersStreams');
    $this->authManager->add($child);
    $this->authManager->addChild($parent, $child);
  }

  public function down()
  {
    $this->removePermission('StatisticStatFiltersUsers');
    $this->removePermission('StatisticStatFiltersSources');
    $this->removePermission('StatisticStatFiltersStreams');
  }
}
