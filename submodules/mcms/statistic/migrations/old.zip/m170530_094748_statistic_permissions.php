<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170530_094748_statistic_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticViewVisibleSubscriptions', 'Просмотр поля видимые подписики в статистике', 'StatisticPermissions', ['root', 'admin']);
  }

  public function down()
  {
    $this->removePermission('StatisticViewVisibleSubscriptions');
  }


}
