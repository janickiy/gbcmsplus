<?php

use console\components\Migration;

class m170914_075355_create_statistic_landing_hour_group extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable('statistic_landing_hour_group', [
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'hour' => 'TINYINT(1) NOT NULL',
      'count_hits' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'count_subscriptions' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    $this->addPrimaryKey(
      'slhg_pk',
      'statistic_landing_hour_group',
      ['source_id', 'landing_id', 'operator_id', 'date', 'hour']
    );
  }

  public function down()
  {
    $this->dropTable('statistic_landing_hour_group');
  }
}
