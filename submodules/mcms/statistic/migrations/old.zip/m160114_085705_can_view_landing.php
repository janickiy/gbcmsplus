<?php

use console\components\Migration;

class m160114_085705_can_view_landing extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  protected $permissionName = 'StatisticViewLanding';

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->createOrGetPermission($this->permissionName, 'View landing in statistic');
    $this->assignRolesPermission($this->permissionName, ['root', 'admin', 'investor', 'reseller', 'partner']);
  }

  public function down()
  {
    $this->removePermission($this->permissionName);
  }
}
