<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

class m171102_131139_partner_complain_view extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->assignRolesPermission('StatisticViewComplains', ['partner']);
  }

  public function down()
  {
    $this->revokeRolesPermission('StatisticViewComplains', ['partner']);
  }
}
