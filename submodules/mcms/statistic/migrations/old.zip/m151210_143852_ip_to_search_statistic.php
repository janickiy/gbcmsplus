<?php

use console\components\Migration;

class m151210_143852_ip_to_search_statistic extends Migration
{
  public function up()
  {
    $this->addColumn('search_subscriptions','ip','bigint(12) DEFAULT NULL AFTER phone');
    $this->alterColumn('hit_params','ip','bigint(12) DEFAULT NULL');
    $this->addColumn('onetime_subscriptions','ip','bigint(12) DEFAULT NULL AFTER phone');

  }

  public function down()
  {
    $this->dropColumn('search_subscriptions','ip');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
