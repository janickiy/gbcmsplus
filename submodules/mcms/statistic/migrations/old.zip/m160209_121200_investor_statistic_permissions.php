<?php


use console\components\Migration;

class m160209_121200_investor_statistic_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    parent::init();
  }

  public function up()
  {
    $this->revokeRolesPermission('StatisticDetailSells', 'investor');
    $this->revokeRolesPermission('StatisticDetailIk', 'investor');
  }

  public function down()
  {
    $this->assignRolesPermission('StatisticDetailSells', 'investor');
    $this->assignRolesPermission('StatisticDetailIk', 'investor');
  }

}
