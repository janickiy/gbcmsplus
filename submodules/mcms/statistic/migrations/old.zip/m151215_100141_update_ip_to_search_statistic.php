<?php

use console\components\Migration;

class m151215_100141_update_ip_to_search_statistic extends Migration
{
  public function up()
  {
    //nothing
  }

  public function down()
  {
    $this->dropColumn('onetime_subscriptions', 'ip');
  }
}
