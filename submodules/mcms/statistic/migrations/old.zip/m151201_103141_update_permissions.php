<?php

use console\components\Migration;

class m151201_103141_update_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Statistic';
    $this->permissions = [
      'Statistic' => [
        ['viewBlackListUsers', 'can view black list users', ['admin', 'root']]
      ]
    ];
  }


}
