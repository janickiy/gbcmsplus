d<?php

use console\components\Migration;
use mcms\common\helpers\Console;
use rgk\utils\traits\PermissionTrait;

/**
 *
 */
class m181108_084617_add_hit_traffic_type extends Migration
{
  /**
   *
   */
  public function up()
  {
    $approve = Console::confirm('Это ресурсоемкая миграция. Пропустить?');

    if ($approve) {
      return true;
    }

    $this->addColumn('hits', 'traffic_type', 'TINYINT(1) NOT NULL DEFAULT 0');
  }

  /**
   */
  public function down()
  {
    $this->dropColumn('hits', 'traffic_type');
  }
}
