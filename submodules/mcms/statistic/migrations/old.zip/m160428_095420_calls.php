<?php

use console\components\Migration;

class m160428_095420_calls extends Migration
{

  const TABLE = 'complains';

  public function up()
  {
    $this->addColumn(self::TABLE, 'type', "tinyint(1) unsigned NOT NULL DEFAULT 1 COMMENT '1-текст,2-звонок'");
    $this->createIndex(self::TABLE . '_type_index', self::TABLE, 'type');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'type');
  }
}
