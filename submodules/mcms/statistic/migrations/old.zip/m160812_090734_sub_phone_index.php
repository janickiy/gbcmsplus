<?php

use console\components\Migration;

class m160812_090734_sub_phone_index extends Migration
{
  const TABLE = 'subscriptions';

  public function up()
  {
    $this->createIndex(self::TABLE . '_phone_index', self::TABLE, 'phone');
  }

  public function down()
  {
    $this->dropIndex(self::TABLE . '_phone_index', self::TABLE);
  }
}
