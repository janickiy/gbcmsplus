<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170530_080645_investor_statistic_permissions extends Migration
{
    use PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticFilterByInvestStreams', 'Статистика инвестора по партнерам (потоки)', 'StatisticFilter');
    $this->createPermission('StatisticFilterByInvestSources', 'Статистика инвестора по партнерам (источники)', 'StatisticFilter');
    $this->createPermission('StatisticFilterByInvestUsers', 'Статистика инвестора по партнерам (партнеры)', 'StatisticFilter');

    $this->createPermission('StatisticInvestFiltersController', 'Контроллер для заполнения фильтров', 'StatisticModule', ['investor']);

    $this->createPermission('StatisticInvestFiltersStreams', 'данные dropdown фильтра потоков для инвестора', 'StatisticInvestFiltersController', ['investor']);
    $this->createPermission('StatisticInvestFiltersSources', 'данные dropdown фильтра источников для инвестора', 'StatisticInvestFiltersController', ['investor']);
    $this->createPermission('StatisticInvestFiltersUsers', 'данные dropdown фильтра юзеров для инвестора', 'StatisticInvestFiltersController', ['investor']);
  }

  public function down()
  {
    $this->removePermission('StatisticFilterByInvestStreams');
    $this->removePermission('StatisticFilterByInvestSources');
    $this->removePermission('StatisticFilterByInvestUsers');

    $this->removePermission('StatisticInvestFiltersStreams');
    $this->removePermission('StatisticInvestFiltersSources');
    $this->removePermission('StatisticInvestFiltersUsers');

    $this->removePermission('StatisticInvestFiltersController');

  }
}