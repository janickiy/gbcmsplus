<?php

use console\components\Migration;

class m180316_153123_reseller_profits_noinvestors extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticResellerProfitNoInvestorsController', 'Контроллер ResellerProfitNoInvestors', 'StatisticModule', ['root']);
    $this->createPermission('StatisticResellerProfitNoInvestorsIndex', 'Статистика профита реселлера (без инвесторов)', 'StatisticResellerProfitNoInvestorsController', ['root']);
    $this->createPermission('StatisticResellerProfitNoInvestorsUnholdPlan', 'План расхолда средств (без инвесторов)', 'StatisticResellerProfitNoInvestorsController', ['root']);

    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable('reseller_profits_noinvestors', [
      'id' => $this->primaryKey(10)->comment('будем давать id строкам профитов для удобства синкать'),
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL COMMENT \'Ссылка на страну\'',
      'date' => 'DATE NOT NULL COMMENT \'дата\'',
      'week_start' => 'DATE NOT NULL COMMENT \'дата начала недели (понедельника)\'',
      'month_start' => 'DATE NOT NULL COMMENT \'дата начала месяца\'',
      'profit_rub' => 'DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0 COMMENT \'Сумма профита RUB\'',
      'profit_usd' => 'DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0 COMMENT \'Сумма профита USD\'',
      'profit_eur' => 'DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0 COMMENT \'Сумма профита EUR\'',
      'unhold_date' => 'DATE NOT NULL COMMENT \'дата, в которую расхолдится эта запись (можно вычислить по country_id)\'',
      'unhold_week_start' => 'DATE NOT NULL COMMENT \'неделя расхолда\'',
      'unhold_month_start' => 'DATE NOT NULL COMMENT \'месяц расхолда\'',
      'description' => 'text COMMENT \'служебная информация. Например описание даты расхолда\'',
      'rule_hash' => 'char(8) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL COMMENT \'хэш правила для проверки изменилось или нет\'',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED',
    ], $tableOptions);

    foreach (['rub', 'usd', 'eur'] as $currency) {
      $this->addColumn('reseller_profits_noinvestors', 'profit_onetime_' . $currency, $this->decimal(10, 2)->unsigned()->defaultValue(0.00)->after('profit_' . $currency));
      $this->addColumn('reseller_profits_noinvestors', 'profit_cpa_rejected_' . $currency, $this->decimal(10, 2)->unsigned()->defaultValue(0.00)->after('profit_' . $currency));
      $this->addColumn('reseller_profits_noinvestors', 'profit_cpa_sold_' . $currency, $this->decimal(10, 2)->unsigned()->defaultValue(0.00)->after('profit_' . $currency));
      $this->addColumn('reseller_profits_noinvestors', 'profit_revshare_' . $currency, $this->decimal(10, 2)->unsigned()->defaultValue(0.00)->after('profit_' . $currency));
    }

    $this->createIndex(
      'reseller_profits_noinvestors_uq',
      'reseller_profits_noinvestors',
      ['date', 'country_id'],
      true
    );

    $this->createIndex('group_statistic_by_week', 'reseller_profits_noinvestors', ['week_start']);
    $this->createIndex('group_statistic_by_month', 'reseller_profits_noinvestors', ['month_start']);
    $this->createIndex('group_statistic_unhold_by_date', 'reseller_profits_noinvestors', ['unhold_date']);
    $this->createIndex('group_statistic_unhold_by_week', 'reseller_profits_noinvestors', ['unhold_week_start']);
    $this->createIndex('group_statistic_unhold_by_month', 'reseller_profits_noinvestors', ['unhold_month_start']);
  }

  public function down()
  {
    $this->removePermission('StatisticResellerProfitNoInvestorsController');
    $this->removePermission('StatisticResellerProfitNoInvestorsIndex');
    $this->removePermission('StatisticResellerProfitNoInvestorsUnholdPlan');

    $this->dropTable('reseller_profits_noinvestors');
  }
}
