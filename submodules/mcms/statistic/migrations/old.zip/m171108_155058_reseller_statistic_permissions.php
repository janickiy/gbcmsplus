<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

class m171108_155058_reseller_statistic_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticResellerProfitStatisticsController', 'Контроллер статистики дохода реселера', 'StatisticModule');
    $this->createPermission('StatisticResellerProfitStatisticsIndex', 'Просмотр статистики дохода реселера', 'StatisticResellerProfitStatisticsController', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('StatisticResellerProfitStatisticsIndex');
    $this->removePermission('StatisticResellerProfitStatisticsController');
  }
}
