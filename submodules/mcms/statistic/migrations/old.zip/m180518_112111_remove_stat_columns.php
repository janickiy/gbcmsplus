<?php

use console\components\Migration;

class m180518_112111_remove_stat_columns extends Migration
{
  const TABLE = 'statistic';
  const COLUMNS = [
    'partner_rejected_profit_rub',
    'partner_rejected_profit_usd',
    'partner_rejected_profit_eur',
    'partner_sold_profit_rub',
    'partner_sold_profit_usd',
    'partner_sold_profit_eur',
  ];

  public function up()
  {
    if (!\mcms\common\helpers\Console::confirm('Нужно отключить кроны статы. Продолжаем?', true)) {
      return false;
    }

    foreach (self::COLUMNS as $column) {
      $this->dropColumn(self::TABLE, $column);
    }
  }

  public function down()
  {
    foreach (self::COLUMNS as $column) {
      $this->addColumn(self::TABLE, $column, 'DECIMAL(9, 2) UNSIGNED DEFAULT \'0.00\' NOT NULL');
    }
  }
}
