<?php

use console\components\Migration;

/**
 * Class m170801_125410_res_rule_hash
 */
class m170801_125410_res_rule_hash extends Migration
{
  /**
   *
   */
  public function up()
    {
      $this->addColumn('reseller_profits', 'rule_hash', 'char(8) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL COMMENT \'хэш правила для проверки изменилось или нет\' AFTER description');
    }

  /**
   */
  public function down()
    {
      $this->dropColumn('reseller_profits', 'rule_hash');
    }
}
