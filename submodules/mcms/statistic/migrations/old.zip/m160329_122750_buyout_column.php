<?php

use console\components\Migration;

class m160329_122750_buyout_column extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  const PERMISSION_DEL = 'StatisticViewBuyoutsInsteadOfSolds';
  const PERMISSION = 'StatisticViewInvestorBuyoutPrice';

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->removePermission(self::PERMISSION_DEL);
    $this->createOrGetPermission(self::PERMISSION, 'View investor buyout sum');
    $this->assignRolesPermission(self::PERMISSION, ['investor']);

  }

  public function down()
  {
    $this->removePermission(self::PERMISSION);
    $this->createOrGetPermission(self::PERMISSION_DEL, 'View buyouts instead of solds at main statistic');
    $this->assignRolesPermission(self::PERMISSION_DEL, ['investor']);
  }
}
