<?php

use console\components\Migration;

class m170124_120259_rename_module extends Migration
{
  public function up()
  {
    $this->update('modules',
      [ 'name' => 'statistic.main.statistic', ],
      [ 'module_id' => 'statistic', ]
    );
  }

  public function down()
  {
    $this->update('modules',
      [ 'name' => 'app.common.module_statistic', ],
      [ 'module_id' => 'statistic', ]
    );
  }
}
