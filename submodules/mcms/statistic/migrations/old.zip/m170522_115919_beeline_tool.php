<?php

use console\components\Migration;

class m170522_115919_beeline_tool extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticToolsController', 'Контроллер Tools', 'StatisticModule');
    $this->createPermission('StatisticToolsBeeline', 'Обработчик файла от Билайна', 'StatisticToolsController', [ 'admin', 'root']);
  }

  public function down()
  {
   $this->removePermission('StatisticToolsBeeline');
   $this->removePermission('StatisticToolsController');
  }
}
