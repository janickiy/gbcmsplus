<?php

use console\components\Migration;

class m160520_140209_statistic_label_group_index extends Migration
{
  const TABLE = 'statistic_label_group';
  public function up()
  {
    $approve = \mcms\common\helpers\Console::confirm('Эту миграцию должен выполнить админ. Пропустить миграцию?');

    if ($approve)  return true;

    $this->createIndex('statistic_label_group_date_hour_index', self::TABLE, ['date', 'hour']);
    $this->createIndex('statistic_label_group_provider_id_index', self::TABLE, ['provider_id']);

    /*
    ALTER TABLE `statistic_label_group` ADD INDEX `statistic_label_group_date_hour_index` (`date`, `hour`);
    ALTER TABLE `statistic_label_group` ADD INDEX `statistic_label_group_provider_id_index` (`provider_id`);
    */
  }

  public function down()
  {
    $this->dropIndex('statistic_label_group_date_hour_index', self::TABLE);
    $this->dropIndex('statistic_label_group_provider_id_index', self::TABLE);
  }
}
