<?php

use yii\db\Schema;
use console\components\Migration;

class m160212_125740_investor_hour_stat_permission extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    parent::init();
  }

  public function up()
  {
    $this->assignRolesPermission('StatisticDefaultHour', 'investor');
  }

  public function down()
  {
    $this->revokeRolesPermission('StatisticDefaultHour', 'investor');
  }

}
