<?php

use console\components\Migration;

class m171030_095420_group_by_managers extends Migration
{
  use \rgk\utils\traits\PermissionTrait;
  const TABLE = 'partners_managers';

  public function up()
  {
    $this->createPermission('StatisticGroupByManagers', 'Просмотр статистики сгруппированной по менеджерам', 'StatisticGroup', ['root', 'admin', 'reseller']);

    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(self::TABLE, [
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'manager_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
    ],$tableOptions);

    $this->addPrimaryKey('primary_' . self::TABLE, self::TABLE, ['user_id', 'date']);

    // начальная дата
    $dateFrom = (new \yii\db\Query())
      ->select('date')
      ->from('hits_day_group')
      ->orderBy('date ASC')
      ->limit(1)->scalar();

    for (
      $date = $dateFrom;
      $date <= Yii::$app->formatter->asDate('today', 'php:Y-m-d');
      $date = Yii::$app->formatter->asDate("$date + 1 day", 'php:Y-m-d'))
    {
      echo '    > insert into ' . self::TABLE . ' '. $date . ' ...' . "\n";
      $query = 'INSERT INTO ' . self::TABLE . ' (user_id, manager_id, date) (SELECT id, manager_id, \'' . $date . '\' FROM users WHERE manager_id IS NOT NULL)';
      $this->db->createCommand($query)->execute();
    }

  }

  public function down()
  {
    $this->removePermission('StatisticGroupByManagers');
    $this->dropTable(self::TABLE);
  }
}
