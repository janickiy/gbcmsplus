<?php

use console\components\Migration;
use rgk\settings\models\Setting;


class m180109_132009_cpr_calc_setting extends Migration
{
  const KEY = 'settings.cpr_calc_through_price';

  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
  }

  public function up()
  {
    $this->settingsBuilder->createSetting(
      ['en' => 'CPR calculation through price instead of profit', 'ru' => 'Расчёт CPR через price вместо profit'],
      [],
      self::KEY,
      ['EditModuleSettingsStatistic'],
      Setting::TYPE_BOOLEAN,
      'app.common.group_statistic',
      1
    );
  }

  public function down()
  {
    $this->settingsBuilder->removeSetting(self::KEY);
  }
}