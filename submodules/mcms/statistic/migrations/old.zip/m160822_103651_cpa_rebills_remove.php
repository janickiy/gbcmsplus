<?php

use console\components\Migration;

class m160822_103651_cpa_rebills_remove extends Migration
{
  public function up()
  {
    // Партнер не должен видеть ребиллы, подписки, отписки с флагом is_cpa = 1. Если есть строки, с count_sold=0,
    // то их можно смело грохнуть
    $this->db->createCommand("
    DELETE FROM statistic_label_group
    WHERE (count_rebills > 0 OR count_ons > 0 OR count_offs > 0) AND is_cpa = 1 AND count_sold = 0;
    ")->execute();

  }

  public function down()
  {
    echo "m160822_103651_cpa_rebills_remove cannot be reverted.\n";

    return true;
  }

}
