<?php

use console\components\Migration;

class m170802_073230_new_dashboard extends Migration
{
  const PROFITS_ONS_TABLE = 'dashboard_profits_ons';
  const LANDINGS_TABLE = 'dashboard_landings';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET latin1 ENGINE=InnoDB';
    }

    $this->createTable(self::PROFITS_ONS_TABLE, [
      'date' => 'DATE NOT NULL',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'real_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'real_profit_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'real_profit_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'real_onetime_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'real_onetime_profit_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'real_onetime_profit_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'real_sold_price_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'real_sold_price_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'real_sold_price_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'real_sold_tb_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'real_sold_tb_profit_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'real_sold_tb_profit_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'res_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'res_profit_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'res_profit_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'res_onetime_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'res_onetime_profit_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'res_onetime_profit_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'res_sold_price_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'res_sold_price_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'res_sold_price_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'res_sold_tb_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'res_sold_tb_profit_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'res_sold_tb_profit_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_profit_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_profit_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_onetime_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_onetime_profit_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_onetime_profit_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_sold_price_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_sold_price_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_sold_price_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_sold_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_sold_profit_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_sold_profit_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_sold_tb_profit_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_sold_tb_profit_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'partner_sold_tb_profit_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'investor_buyout_price_rub' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'investor_buyout_price_usd' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'investor_buyout_price_eur' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'count_ons' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'count_onetime' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'count_sold' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'count_hits' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    $this->addPrimaryKey('dpo_pk', self::PROFITS_ONS_TABLE, ['date', 'country_id', 'user_id', 'operator_id']);

    /**
     *   Как заполняются поля в таблице
     *
     *   res_profit_              = sum_reseller_profit_ из subscriptions_day_group  *
     *   res_onetime_profit_      = reseller_profit_ из onetime_subscriptions *
     *   res_sold_price_          = reseller_price_ из sold_subscriptions *
     *   res_sold_tb_profit_      = reseller_profit_ из sold_trafficback *
     *
     *   real_profit_             = sum_real_profit_ из subscriptions_day_group  *
     *   real_onetime_profit_     = real_profit_ из onetime_subscriptions *
     *   real_sold_price_         = real_price_ из sold_subscriptions *
     *   real_sold_tb_profit_     = real_profit_ из sold_trafficback *
     *
     *   partner_profit_          = sum_profit_ из subscriptions_day_group  *
     *   partner_onetime_profit_  = profit_ из onetime_subscriptions *
     *   partner_sold_price_      = price_ из sold_subscriptions *
     *   partner_sold_profit_     = profit_ из sold_subscriptions *
     *   partner_sold_tb_profit_  = profit_ из sold_trafficback *
     *
     *   investor_buyout_price_   = price_ из sold_subscriptions (сгруппированный по to_user_id)*
     *
     *   count_ons                = count_ons из subscriptions_day_group  *
     *   count_onetime            = COUNT(hit_id) из onetime_subscriptions *
     *   count_sold               = COUNT(hit_id) из sold_subscriptions *
     *   count_hits               = count_hits из hits_day_group
     *
     */

    $this->createTable(self::LANDINGS_TABLE, [
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'count_hits' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'count_tb' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'count_ons' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'count_sold' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
      'count_onetime' => 'MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    $this->addPrimaryKey('dl_pk', self::LANDINGS_TABLE, ['landing_id', 'date', 'user_id', 'country_id', 'operator_id']);

    /**
     *   Как заполняются поля в таблице
     *
     *   count_hits    = count_hits из hits_day_group
     *   count_tb      = count_tb из hits_day_group
     *   count_ons     = count_ons из subscriptions_day_group
     *   count_sold    = COUNT(hit_id) из sold_subscriptions
     *   count_onetime = COUNT(hit_id) из onetime_subscriptions
     *
     */


    /*
     * Использование данных таблицы в дашборде
     *
     *
     *   Админ:
     *
     *   RS Прибыль                  = real_profit_
     *   СПА Прибыль                 = real_onetime_profit_ + real_sold_price_
     *   Админкий валовый доход      = real_profit_ + real_onetime_profit_ + real_sold_price_ + real_sold_tb_profit_
     *
     *
     *   Реселлер:
     *
     *   RS Прибыль                  = res_profit_rub
     *   СПА Прибыль                 = res_sold_price_ + res_onetime_profit_
     *   Реселлерский валовый доход  = res_profit_rub + res_sold_price_ + res_onetime_profit_ + res_sold_tb_profit_
     *
     *
     *   Инвестор:
     *
     *   RS Прибыль                  = partner_profit_
     *   СПА Прибыль                 = partner_onetime_profit_ + (если есть разрешение StatisticViewBuyoutPriceInsteadProfit, то partner_sold_price_, иначе - partner_sold_profit_)
     *   Партнерский валовый доход   = partner_profit_ + СПА Прибыль + partner_sold_tb_profit_
     *
     *
     *   Админский чистый доход      = Админкий валовый доход - Реселлерский валовый доход
     *   Реселлерский чистый доход   = Реселлерский валовый доход - Партнерский валовый доход
     *   Инвесторский чистый доход   = Партнерский валовый доход - real_sold_price_
     *
     *
     *   RS ПДП                      = count_ons
     *   CPA ПДП                     = count_onetime + count_sold
     *   Хиты                        = count_hits + count_sold
     *
     *
     *   Виджет Инвесторов
     *
     *   ОБОРОТ ПО РЕБИЛЛАМ  = partner_profit_ + partner_onetime_profit_ + partner_sold_profit_ + partner_sold_tb_profit_
     *   КУПЛЕНО             = real_sold_price_
     *
     *   Топ лендингов
     *
     *   Клики =  count_hits + count_sold
     *   Ратио =  (count_hits - count_tb)/(count_ons + count_sold + count_onetime)
     *
     */
  }

  public function down()
  {
    $this->dropTable(self::PROFITS_ONS_TABLE);
    $this->dropTable(self::LANDINGS_TABLE);
  }
}
