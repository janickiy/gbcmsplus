<?php

use console\components\Migration;
use mcms\common\traits\PermissionMigration;

class m161205_145900_manager_filters extends Migration
{
  use PermissionMigration;

  const SOURCES_PERMISSION = 'StatisticStatFiltersSources';
  const USERS_PERMISSION = 'StatisticStatFiltersUsers';
  const STREAMS_PERMISSION = 'StatisticStatFiltersStreams';

  public function up()
  {
    $this->assignRolesPermission(self::SOURCES_PERMISSION, ['manager']);
    $this->assignRolesPermission(self::USERS_PERMISSION, ['manager']);
    $this->assignRolesPermission(self::STREAMS_PERMISSION, ['manager']);
  }

  public function down()
  {
    $this->revokeRolesPermission(self::SOURCES_PERMISSION, ['manager']);
    $this->revokeRolesPermission(self::USERS_PERMISSION, ['manager']);
    $this->revokeRolesPermission(self::STREAMS_PERMISSION, ['manager']);
  }
}
