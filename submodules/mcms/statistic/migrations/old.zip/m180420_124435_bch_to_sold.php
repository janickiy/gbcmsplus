<?php

use console\components\Migration;
use yii\db\Query;

class m180420_124435_bch_to_sold extends Migration
{

  public function up()
  {
    foreach ((new Query)
               ->select('bch.*, subscriptions.currency_id')
               ->from('buyout_correct_history bch')
               ->innerJoin('subscriptions', 'subscriptions.hit_id = bch.hit_id')
               ->each() as $correct) {

      echo 'Insert in sold subs hit id : ' . $correct['hit_id']. PHP_EOL;

      $this->insert('sold_subscriptions', [
        'hit_id' => $correct['hit_id'],
        'currency_id' => $correct['currency_id'],
        'real_price_rub' => 0,
        'real_price_eur' => 0,
        'reseller_price_rub' => 0,
        'reseller_price_eur' => 0,
        'price_rub' => 0,
        'price_eur' => 0,
        'price_usd' => 0,
        'profit_rub' => 0,
        'profit_eur' => 0,
        'time' => $correct['time'],
        'date' => $correct['date'],
        'hour' => $correct['hour'],
        'stream_id' => $correct['stream_id'],
        'source_id' => $correct['source_id'],
        'user_id' => $correct['user_id'],
        'to_stream_id' => $correct['to_stream_id'],
        'to_source_id' => $correct['to_source_id'],
        'to_user_id' => $correct['to_user_id'],
        'landing_id' => $correct['landing_id'],
        'operator_id' => $correct['operator_id'],
        'platform_id' => $correct['platform_id'],
        'landing_pay_type_id' => $correct['landing_pay_type_id'],
        'provider_id' => $correct['provider_id'],
        'country_id' => $correct['country_id'],
        'is_visible_to_partner' => 0,
      ]);

    }
  }

  public function down()
  {
    return true;
  }

}
