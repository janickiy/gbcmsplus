<?php

use console\components\Migration;

class m180508_121509_remove_buyout_correct extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  const LOG = 'buyout_correct_history';
  const LOG_REMOVED = 'buyout_correct_history_removed';
  const CONDITIONS = 'buyout_correct_conditions';

  public function up()
  {
    $this->removePermission('PromoCanViewPersonalBuyoutWidget');

    $this->removePermission('PromoPersonalBuyoutsController');
    $this->removePermission('PromoPersonalBuyoutsCreateModal');
    $this->removePermission('PromoPersonalBuyoutsDelete');
    $this->removePermission('PromoPersonalBuyoutsIndex');
    $this->removePermission('PromoPersonalBuyoutsUpdateModal');

    $this->renameTable(self::LOG, self::LOG_REMOVED);
    $this->dropTable(self::CONDITIONS);
  }

  public function down()
  {
    $this->createPermission('PromoCanViewPersonalBuyoutWidget', 'Просмотр виджета личных выкупов', 'PromoPermissions');

    $this->createPermission('PromoPersonalBuyoutsController', 'Контроллер PersonalBuyouts', 'PromoModule');
    $this->createPermission('PromoPersonalBuyoutsCreateModal', 'Создание условия выкупа модалка', 'PromoPersonalBuyoutsController');
    $this->createPermission('PromoPersonalBuyoutsDelete', 'Удаление условия выкупа', 'PromoPersonalBuyoutsController');
    $this->createPermission('PromoPersonalBuyoutsIndex', 'Просмотр списка условий выкупа', 'PromoPersonalBuyoutsController');
    $this->createPermission('PromoPersonalBuyoutsUpdateModal', 'Редактирование условия выкупа модалка', 'PromoPersonalBuyoutsController');

    $this->createTable(self::CONDITIONS, [
      'id' => 'mediumint(5) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'investor_id' => 'mediumint(5) unsigned DEFAULT NULL',
      'partner_id' => 'mediumint(5) unsigned DEFAULT NULL',
      'operator_id' => 'mediumint(5) unsigned DEFAULT NULL',
      'landing_id' => 'mediumint(5) unsigned DEFAULT NULL',
      'percent' => 'decimal(5,2) NOT NULL',
      'created_by' => 'mediumint(5) unsigned NOT NULL',
      'created_at' => 'int(10) unsigned NOT NULL',
      'updated_at' => 'int(10) unsigned DEFAULT NULL'
    ]);

    $this->addForeignKey(self::CONDITIONS . '_investor_id_fk', self::CONDITIONS, 'investor_id', 'users', 'id');
    $this->addForeignKey(self::CONDITIONS . '_partner_id_fk', self::CONDITIONS, 'partner_id', 'users', 'id');
    $this->addForeignKey(self::CONDITIONS . '_operator_id_fk', self::CONDITIONS, 'operator_id', 'operators', 'id');
    $this->addForeignKey(self::CONDITIONS . '_landing_id_fk', self::CONDITIONS, 'landing_id', 'landings', 'id');

    $this->renameTable(self::LOG_REMOVED, self::LOG);
  }
}
