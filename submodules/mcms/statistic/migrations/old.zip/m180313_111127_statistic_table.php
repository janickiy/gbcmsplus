<?php

use console\components\Migration;

class m180313_111127_statistic_table extends Migration
{
  const TABLE = 'statistic';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    // статистика по переходам
    $this->createTable(self::TABLE, [
      'count_ons_revshare' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'count_ons_cpa' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'count_ons_rejected' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',

      'count_offs_revshare' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'count_offs_rejected' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'count_offs_sold' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',

      'count_offs24_revshare' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'count_offs24_rejected' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'count_offs24_sold' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',

      'count_rebills_revshare' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'count_rebills_rejected' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'count_rebills_sold' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',

      'count_rebills24_revshare' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'count_rebills24_rejected' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'count_rebills24_sold' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',

      'res_revshare_profit_rub' => 'DECIMAL(9, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'res_revshare_profit_usd' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'res_revshare_profit_eur' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',

      'res_rejected_profit_rub' => 'DECIMAL(9, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'res_rejected_profit_usd' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'res_rejected_profit_eur' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',

      'res_sold_profit_rub' => 'DECIMAL(9, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'res_sold_profit_usd' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'res_sold_profit_eur' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',

      'partner_revshare_profit_rub' => 'DECIMAL(9, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'partner_revshare_profit_usd' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'partner_revshare_profit_eur' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',

      'partner_revshare_profit24_rub' => 'DECIMAL(9, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'partner_revshare_profit24_usd' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'partner_revshare_profit24_eur' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',

      'partner_rejected_profit24_rub' => 'DECIMAL(9, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'partner_rejected_profit24_usd' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'partner_rejected_profit24_eur' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',

      'partner_sold_profit24_rub' => 'DECIMAL(9, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'partner_sold_profit24_usd' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'partner_sold_profit24_eur' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',

      'partner_sold_profit_rub' => 'DECIMAL(9, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'partner_sold_profit_usd' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'partner_sold_profit_eur' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',

      'partner_rejected_profit_rub' => 'DECIMAL(9, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'partner_rejected_profit_usd' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',
      'partner_rejected_profit_eur' => 'DECIMAL(6, 2) UNSIGNED DEFAULT "0" NOT NULL',

      'date' => 'DATE NOT NULL',
      'hour' => 'TINYINT(1) UNSIGNED NOT NULL',
      'source_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED DEFAULT "0" NOT NULL',
      'is_fake' => 'TINYINT(1) UNSIGNED DEFAULT "0" NOT NULL',

      'currency_id' => 'TINYINT(1) UNSIGNED NOT NULL',
      'user_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'stream_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'country_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
      'provider_id' => 'MEDIUMINT(5) UNSIGNED DEFAULT "0" NOT NULL',
    ], $tableOptions);

    $this->addPrimaryKey('statistic_pk', self::TABLE, [
      'date',
      'hour',
      'source_id',
      'landing_id',
      'operator_id',
      'platform_id',
      'landing_pay_type_id',
      'is_fake',
    ]);
  }

  public function down()
  {
    $this->dropTable(static::TABLE);
  }
}
