<?php

use console\components\Migration;

class m160925_141509_analytics_perm extends Migration
{
  use \mcms\common\traits\PermissionGroupMigration;

  public function init()
  {
    parent::init();

    $this->groupPermissionName = 'StatisticModule';
    $this->groupPermissionDescription = 'Module Statistic';
    $this->groupPermissionDefaultRole = ['investor'];

    $this->groupPermissionControllers = [
      'StatisticAnalyticsController' => [
        'description' => 'Analytics controller [group]',
        'permissions' => [
          ['StatisticAnalyticsIndex']
        ]
      ],
    ];
  }
}
