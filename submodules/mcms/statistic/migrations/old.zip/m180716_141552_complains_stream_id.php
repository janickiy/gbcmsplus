<?php

use console\components\Migration;

class m180716_141552_complains_stream_id extends Migration
{
  public function up()
  {
    $this->alterColumn('complains', 'stream_id', "MEDIUMINT(5) UNSIGNED NULL DEFAULT '0'");
  }

  public function down()
  {
    $this->alterColumn('complains', 'stream_id', "MEDIUMINT(5) UNSIGNED NOT NULL DEFAULT '0'");
  }

}
