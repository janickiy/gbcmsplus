<?php

use rgk\settings\models\Setting;
use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m180515_144644_stop_buyout_offs extends Migration
{

  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
  }

  public function up()
  {
    $this->settingsBuilder->createSetting(
      ['en' => 'Allow buyout subscriptions with rebills that have been unsubscribed', 'ru' => 'Выкупать подписки с ребиллом, даже если есть отписка'],
      [],
      'settings.buyout.is_allow_buyout_with_offs',
      ['EditModuleSettingsStatistic'],
      Setting::TYPE_BOOLEAN,
      'app.common.group_buyouts_rebills',
      true,
      [['boolean']]
    );
  }

  public function down()
  {
    $this->settingsBuilder->removeSetting('settings.buyout.is_allow_buyout_with_offs');
  }

}
