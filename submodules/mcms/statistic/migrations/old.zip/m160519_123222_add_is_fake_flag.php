<?php

use console\components\Migration;

class m160519_123222_add_is_fake_flag extends Migration
{

  const FLAG = 'is_fake';

  public function up()
  {

    $approve = \mcms\common\helpers\Console::confirm('Эту миграцию должен выполнить админ. Пропустить миграцию?');

    if ($approve)  return true;

    $this->addColumn('search_subscriptions', self::FLAG, 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0;');
    $this->addColumn('subscriptions', self::FLAG, 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0;');
    $this->addColumn('subscription_offs', self::FLAG, 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0;');
    $this->addColumn('subscriptions_day_group', self::FLAG, 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0;');
    $this->addColumn('subscriptions_day_hour_group', self::FLAG, 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0;');


    $this->createIndex('subscriptions_group_by_hour_index', 'subscriptions', [
      'date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'hour', 'landing_pay_type_id', 'is_cpa', self::FLAG
    ]);

    $this->dropIndex('subscriptions_group_by_hour', 'subscriptions');

    $this->createIndex('subscription_offs_group_by_hour_index', 'subscription_offs', [
      'date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'hour', 'is_cpa', self::FLAG,
    ]);

    $this->dropIndex('subscription_offs_group_by_hour', 'subscription_offs');


    $this->createIndex('tmp_uq_index', 'subscriptions_day_hour_group', ['date','hour','source_id','landing_id','operator_id','platform_id','landing_pay_type_id','is_cpa', 'is_fake'], true);

    $this->db
      ->createCommand('ALTER TABLE subscriptions_day_hour_group DROP PRIMARY KEY, ADD PRIMARY KEY(`date`,`hour`,`source_id`,`landing_id`,`operator_id`,`platform_id`,`landing_pay_type_id`,`is_cpa`, `is_fake`);')
      ->execute();

    $this->dropIndex('tmp_uq_index', 'subscriptions_day_hour_group');


    

    $this->createIndex('tmp_uq_index', 'subscriptions_day_group', ['date','source_id','landing_id','operator_id','platform_id','landing_pay_type_id','is_cpa', 'is_fake'], true);

    $this->db
      ->createCommand('ALTER TABLE subscriptions_day_group DROP PRIMARY KEY, ADD PRIMARY KEY(`date`,`source_id`,`landing_id`,`operator_id`,`platform_id`,`landing_pay_type_id`,`is_cpa`, `is_fake`);')
      ->execute();

    $this->dropIndex('tmp_uq_index', 'subscriptions_day_group');


    $this->createIndex('subscriptions_ss_group_index', 'subscriptions', ['time', 'hit_id', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'landing_pay_type_id', 'is_cpa', 'currency_id', 'is_fake']);
    $this->dropIndex('subscriptions_ss_group', 'subscriptions');

    /*
      ALTER TABLE `search_subscriptions` ADD `is_fake` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0;

      ALTER TABLE `subscriptions` ADD `is_fake` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0;

      ALTER TABLE `subscription_offs` ADD `is_fake` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0;

      ALTER TABLE `subscriptions_day_group` ADD `is_fake` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0;

      ALTER TABLE `subscriptions_day_hour_group` ADD `is_fake` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0;

      ALTER TABLE `subscriptions` ADD INDEX `subscriptions_group_by_hour_index` (`date`, `source_id`, `landing_id`, `operator_id`, `platform_id`, `hour`, `landing_pay_type_id`, `is_cpa`, `is_fake`);

      DROP INDEX `subscriptions_group_by_hour` ON `subscriptions`;

      ALTER TABLE `subscription_offs` ADD INDEX `subscription_offs_group_by_hour_index` (`date`, `source_id`, `landing_id`, `operator_id`, `platform_id`, `hour`, `is_cpa`, `is_fake`);

      DROP INDEX `subscription_offs_group_by_hour` ON `subscription_offs`;

      ALTER TABLE `subscriptions_day_hour_group` ADD UNIQUE INDEX `tmp_uq_index` (`date`, `hour`, `source_id`, `landing_id`, `operator_id`, `platform_id`, `landing_pay_type_id`, `is_cpa`, `is_fake`);

      ALTER TABLE subscriptions_day_hour_group DROP PRIMARY KEY, ADD PRIMARY KEY(`date`,`hour`,`source_id`,`landing_id`,`operator_id`,`platform_id`,`landing_pay_type_id`,`is_cpa`, `is_fake`);

      DROP INDEX `tmp_uq_index` ON `subscriptions_day_hour_group`;

      ALTER TABLE `subscriptions_day_group` ADD UNIQUE INDEX `tmp_uq_index` (`date`, `source_id`, `landing_id`, `operator_id`, `platform_id`, `landing_pay_type_id`, `is_cpa`, `is_fake`);

      ALTER TABLE subscriptions_day_group DROP PRIMARY KEY, ADD PRIMARY KEY(`date`,`source_id`,`landing_id`,`operator_id`,`platform_id`,`landing_pay_type_id`,`is_cpa`, `is_fake`);

      DROP INDEX `tmp_uq_index` ON `subscriptions_day_group`;

      ALTER TABLE `subscriptions` ADD INDEX `subscriptions_ss_group_index` (`time`, `hit_id`, `source_id`, `landing_id`, `operator_id`, `platform_id`, `landing_pay_type_id`, `is_cpa`, `currency_id`, `is_fake`);

      DROP INDEX `subscriptions_ss_group` ON `subscriptions`;
    */

  }

  public function down()
  {
    $this->dropColumn('search_subscriptions', self::FLAG);
    $this->dropColumn('subscriptions', self::FLAG);
    $this->dropColumn('subscription_offs', self::FLAG);
    $this->dropColumn('subscriptions_day_group', self::FLAG);
    $this->dropColumn('subscriptions_day_hour_group', self::FLAG);

    $this->createIndex('subscriptions_group_by_hour', 'subscriptions', [
      'date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'hour', 'landing_pay_type_id', 'is_cpa'
    ]);

    $this->dropIndex('subscriptions_group_by_hour_index', 'subscriptions');


    $this->createIndex('subscription_offs_group_by_hour', 'subscription_offs', [
      'date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'hour', 'is_cpa'
    ]);

    $this->dropIndex('subscription_offs_group_by_hour_index', 'subscription_offs');




    $this->createIndex('tmp_uq_index', 'subscriptions_day_hour_group', ['date','hour','source_id','landing_id','operator_id','platform_id','landing_pay_type_id','is_cpa'], true);

    $this->db
      ->createCommand('ALTER TABLE subscriptions_day_hour_group DROP PRIMARY KEY, ADD PRIMARY KEY(`date`,`hour`,`source_id`,`landing_id`,`operator_id`,`platform_id`,`landing_pay_type_id`,`is_cpa`);')
      ->execute();

    $this->dropIndex('tmp_uq_index', 'subscriptions_day_hour_group');


    $this->createIndex('tmp_uq_index', 'subscriptions_day_group', ['date','source_id','landing_id','operator_id','platform_id','landing_pay_type_id','is_cpa'], true);

    $this->db
      ->createCommand('ALTER TABLE subscriptions_day_group DROP PRIMARY KEY, ADD PRIMARY KEY(`date`,`source_id`,`landing_id`,`operator_id`,`platform_id`,`landing_pay_type_id`,`is_cpa`);')
      ->execute();

    $this->dropIndex('tmp_uq_index', 'subscriptions_day_group');


    $this->createIndex('subscriptions_ss_group', 'subscriptions', ['time', 'hit_id', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'landing_pay_type_id', 'is_cpa']);
    $this->dropIndex('subscriptions_ss_group_index', 'subscriptions');

  }
}
