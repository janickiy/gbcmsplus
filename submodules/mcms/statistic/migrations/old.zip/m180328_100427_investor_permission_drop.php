<?php

use console\components\Migration;

class m180328_100427_investor_permission_drop extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->removePermission('StatisticViewSellInvestorPrice');
  }

  public function down()
  {
    $this->createPermission('StatisticViewSellInvestorPrice', 'Просмотр цену выкупа подписки инвестора', 'StatisticView', ['root', 'admin', 'investor']);
  }
}
