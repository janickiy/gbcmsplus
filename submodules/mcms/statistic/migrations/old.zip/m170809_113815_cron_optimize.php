<?php

use console\components\Migration;

class m170809_113815_cron_optimize extends Migration
{
  public function up()
  {
    $approve = \mcms\common\helpers\Console::confirm('Эту миграцию должен выполнить админ. Пропустить миграцию?');
    if ($approve) return true;

    // исправляем неправильный индекс для группировки статистики ребиллов для search_subscription
    $this->dropIndex('subscription_rebills_ss_group', 'subscription_rebills');
    $this->createIndex('subscription_rebills_ss_group', 'subscription_rebills', ['hit_id', 'time', 'source_id','landing_id','operator_id','platform_id','landing_pay_type_id','is_cpa','currency_id', 'provider_id']);
    $this->createIndex('sr_time_source_landing_operator', 'subscription_rebills', ['time', 'source_id','landing_id','operator_id']);


    // исправляем неправильный индекс для группировки статистики hits_day_hour_group
    $this->dropIndex('hits_group_by_hour', 'hits');
    $this->createIndex('hits_group_by_hour', 'hits', ['date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'hour', 'landing_pay_type_id', 'is_cpa', 'is_unique', 'is_tb']);

    // исправляем неправильный индекс для группировки статистики по дням hits_day_group
    $this->dropIndex('hdhg_group_by_day', 'hits_day_hour_group');
    $this->createIndex('hdhg_group_by_day', 'hits_day_hour_group', ['date','source_id','landing_id','operator_id','platform_id', 'landing_pay_type_id', 'is_cpa', 'count_hits','count_uniques','count_tb', 'count_unique_tb']);

    // исправляем неправильный индекс для группировки статистики subscriptions_day_hour_group
    $this->dropIndex('subscription_offs_group_by_hour_index', 'subscription_offs');
    $this->createIndex('subscription_offs_group_by_hour_index', 'subscription_offs', ['date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'hour', 'landing_pay_type_id', 'is_cpa', 'is_fake']);

  }

  public function down()
  {
    $this->dropIndex('subscription_rebills_ss_group', 'subscription_rebills');
    $this->dropIndex('sr_time_source_landing_operator', 'subscription_rebills');
    $this->createIndex('subscription_rebills_ss_group', 'subscription_rebills', ['time','hit_id','source_id','landing_id','operator_id','platform_id','landing_pay_type_id','is_cpa','real_profit_rub','reseller_profit_rub','profit_rub','profit_eur','profit_usd']);

    $this->dropIndex('hits_group_by_hour', 'hits');
    $this->createIndex('hits_group_by_hour', 'hits', ['date', 'source_id', 'landing_id', 'operator_id', 'platform_id', 'landing_pay_type_id', 'hour', 'is_unique', 'is_tb', 'is_cpa']);

    $this->dropIndex('hdhg_group_by_day', 'hits_day_hour_group');
    $this->createIndex('hdhg_group_by_day', 'hits_day_hour_group', ['date','source_id','landing_id','operator_id','platform_id','hour','landing_pay_type_id','count_hits','count_uniques','count_tb','is_cpa']);

    $this->dropIndex('subscription_offs_group_by_hour_index', 'subscription_offs');
    $this->createIndex('subscription_offs_group_by_hour_index', 'subscription_offs', ['date','source_id','landing_id','operator_id','platform_id','hour','is_cpa','is_fake']);
  }

}
