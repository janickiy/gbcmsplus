<?php

use console\components\Migration;

class m180328_144926_tables_rename extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->removePermission('StatisticAnalyticsIndexNew');
    $this->removePermission('StatisticMainIndexNew');

    $this->removePermission('StatisticResellerProfitNoInvestorsController');
    $this->removePermission('StatisticResellerProfitNoInvestorsIndex');
    $this->removePermission('StatisticResellerProfitNoInvestorsUnholdPlan');

    $this->renameTable('reseller_profits', 'reseller_profits_old');
    $this->renameTable('reseller_profits_noinvestors', 'reseller_profits');
  }

  public function down()
  {
    $this->renameTable('reseller_profits', 'reseller_profits_noinvestors');
    $this->renameTable('reseller_profits_old', 'reseller_profits');
  }
}
