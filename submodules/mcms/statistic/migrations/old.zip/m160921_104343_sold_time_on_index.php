<?php

use console\components\Migration;

class m160921_104343_sold_time_on_index extends Migration
{
  public function up()
  {
    $this->createIndex('search_subscriptions_time_on_index', 'search_subscriptions', 'time_on');
  }

  public function down()
  {
    $this->dropIndex('search_subscriptions_time_on_index', 'search_subscriptions');
  }
}
