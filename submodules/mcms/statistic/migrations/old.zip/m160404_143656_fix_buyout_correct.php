<?php

use console\components\Migration;
use mcms\common\helpers\ArrayHelper;
use yii\db\Expression;


class m160404_143656_fix_buyout_correct extends Migration
{

  protected $courses;


  public function up()
  {
    $paymentsModule = Yii::$app->getModule('payments');
    $this->courses = $paymentsModule->api('exchangerCourses')->getCurrencyCourses();

    $promoModule = Yii::$app->getModule('promo');
    $allCurrencies = $promoModule->api('mainCurrencies')->getResult();
    $currencies = ArrayHelper::map($allCurrencies, 'id', 'code');

    $corrects = (new \yii\db\Query())
      ->select('bch.*, ss.currency_id')
      ->from('buyout_correct_history bch')
      ->leftJoin('hits h', 'h.id = bch.hit_id')
      ->leftJoin('search_subscriptions ss', 'ss.hit_id = bch.hit_id')
      ->where('bch.to_source_id <> h.source_id');

    $allCount = $corrects->count();
    echo $allCount . " rows should be handled\n";

    $count = 0;
    foreach ($corrects->each() as $correct) {
      $this->update('hits', [
        'source_id' => $correct['to_source_id'],
        'is_cpa' => 0 // для инвестора это уже ревшар
      ], [
        'id' => $correct['hit_id']
      ]);

      $this->update('search_subscriptions', [
        'source_id' => $correct['to_source_id'],
        'stream_id' => $correct['to_stream_id'],
        'user_id' => $correct['to_user_id'],
        'is_cpa' => 0 // для инвестора это уже ревшар
      ], [
        'hit_id' => $correct['hit_id']
      ]);

      $this->update('subscriptions', [
        'source_id' => $correct['to_source_id'],
        'is_cpa' => 0 // для инвестора это уже ревшар
      ], ['hit_id' => $correct['hit_id']]);

      $this->update('subscription_offs', [
        'source_id' => $correct['to_source_id'],
        'is_cpa' => 0 // для инвестора это уже ревшар
      ], ['hit_id' => $correct['hit_id']]);

      $profitPercents = $promoModule->api('personalProfit', [
        'userId' => $correct['to_user_id'],
        'operatorId' => $correct['operator_id'],
        'landingId' => $correct['landing_id']
      ])->getResult();
      $profitPercent = ArrayHelper::getValue($profitPercents, 'rebill_percent') / 100;
      $originalCurrency = ArrayHelper::getValue($currencies, $correct['currency_id']);
      $profitTemplate = 'reseller_profit_%s * %s * %s';

      $this->update('subscription_rebills', [
        'profit_rub' => new Expression(sprintf(
            $profitTemplate,
            $originalCurrency,
            $profitPercent,
            $this->getCourse($originalCurrency, 'rub')
          )
        ),
        'profit_eur' => new Expression(sprintf(
            $profitTemplate,
            $originalCurrency,
            $profitPercent,
            $this->getCourse($originalCurrency, 'eur')
          )
        ),
        'profit_usd' => new Expression(sprintf(
            $profitTemplate,
            $originalCurrency,
            $profitPercent,
            $this->getCourse($originalCurrency, 'usd')
          )
        ),
        'is_cpa' => 0 // для инвестора это уже ревшар
      ], [
        'hit_id' => $correct['hit_id'],
      ]);

      $count++;

      echo '(' . $count . '/' . $allCount . ")\n";
    }
  }

  public function down()
  {
    echo "m160404_143656_fix_buyout_correct cannot be reverted.\n";
  }

  protected function getCourse($fromCurrency, $toCurrency)
  {
    if ($fromCurrency == $toCurrency) return 1;

    // костыльная замена rub => rur
    $fromCurrency = $fromCurrency == 'rub' ? 'rur' : $fromCurrency;
    $toCurrency = $toCurrency == 'rub' ? 'rur' : $toCurrency;

    $convertType = sprintf('%s_%s', $fromCurrency, $toCurrency);

    return $this->courses->{$convertType};
  }
}
