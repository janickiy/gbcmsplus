<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
 */
class m180822_123238_search_subs_index extends Migration
{
  use PermissionTrait;

  /**
   */
  public function up()
  {
    $approve = \mcms\common\helpers\Console::confirm('Эту миграцию должен выполнить админ. Пропустить миграцию?');
    if ($approve) return true;


    $this->createIndex(
      'search_subscriptions_time_off_index',
      'search_subscriptions',
      ['time_off']
    );

    $this->createIndex(
      'search_subscriptions_time_rebill_index',
      'search_subscriptions',
      ['time_rebill']
    );

  }

  /**
   */
  public function down()
  {
    $this->dropIndex('search_subscriptions_time_off_index', 'search_subscriptions');
    $this->dropIndex('search_subscriptions_time_rebill_index', 'search_subscriptions');
  }
}
