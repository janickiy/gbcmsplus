<?php

use console\components\Migration;

class m160519_144918_fake_off_revshare_filter_permission extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->createOrGetPermission('StatisticFilterByFakeRevshare', 'User can filter by fake revshare subscriptions');

    $this->assignRolesPermission('StatisticFilterByFakeRevshare', ['admin', 'root']);
  }

  public function down()
  {
    $this->revokeRolesPermission('StatisticFilterByFakeRevshare', ['admin', 'root']);
    $this->removePermission('StatisticFilterByFakeRevshare');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
