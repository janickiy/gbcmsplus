<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

/** */
class m171213_082157_new_main_stat extends Migration
{

  use PermissionTrait;

  /** */
  public function up()
  {
    $this->createPermission(
      'StatisticMainController',
      'Контроллер Main',
      'StatisticModule'
    );
    $this->createPermission(
      'StatisticMainIndex',
      'Просмотр основной статистики (новая)',
      'StatisticMainController',
      ['root', 'admin', 'reseller', 'manager']
    );
  }

  /** */
  public function down()
  {
    $this->removePermission('StatisticMainIndex');
    $this->removePermission('StatisticMainController');
  }
}
