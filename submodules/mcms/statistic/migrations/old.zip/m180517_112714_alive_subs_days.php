<?php

use rgk\settings\models\Setting;
use console\components\Migration;

class m180517_112714_alive_subs_days extends Migration
{
  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
  }

  public function up()
  {
    $this->settingsBuilder->updateSettingsOrder('enable_alive_subscriptions', 200);
    $this->settingsBuilder->createSetting(
      [
        'en' => 'For how many previous days do we calculate live subscriptions',
        'ru' => 'За какое кол-во прошлых дней считаем живые подписки'
      ],
      [
        'en' => 'For the specified number of days we consider subscriptions that have shown activity: either by a rebill or subscribed',
        'ru' => 'За указанное кол-во дней считаем подписки, которые проявили активность: либо ребиллом, либо подписались'
      ],
      'count_days_alive_subs_calc',
      ['EditModuleSettingsStatistic'],
      Setting::TYPE_INTEGER,
      'app.common.group_partners',
      10,
      [['integer'], ['required'], ['number', ['min' => 1]]],
      300
    );
  }

  public function down()
  {
    $this->settingsBuilder->removeSetting('count_days_alive_subs_calc');
    $this->settingsBuilder->updateSettingsOrder('enable_alive_subscriptions', 8388607);
  }
}
