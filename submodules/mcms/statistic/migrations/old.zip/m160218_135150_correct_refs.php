<?php

use mcms\common\helpers\ArrayHelper;
use console\components\Migration;

class m160218_135150_correct_refs extends Migration
{
  public function up()
  {
    $this->db->createCommand('update subscriptions s join hits h ON h.id = s.hit_id
      set
        s.source_id = h.source_id,
        s.operator_id = h.operator_id,
        s.landing_id = h.landing_id,
        s.platform_id = h.platform_id,
        s.landing_pay_type_id = h.landing_pay_type_id,
        s.is_cpa = h.is_cpa
      where
        s.source_id <> h.source_id OR
        s.operator_id <> h.operator_id OR
        s.landing_id <> h.landing_id OR
        s.platform_id <> h.platform_id OR
        s.landing_pay_type_id <> h.landing_pay_type_id OR
        s.is_cpa <> h.is_cpa')->execute();
    echo "SUBSCRIPTIONS UPDATED\n";

    $this->db->createCommand('update subscription_offs s join hits h ON h.id = s.hit_id
      set
        s.source_id = h.source_id,
        s.operator_id = h.operator_id,
        s.landing_id = h.landing_id,
        s.platform_id = h.platform_id,
        s.landing_pay_type_id = h.landing_pay_type_id,
        s.is_cpa = h.is_cpa
      where
        s.source_id <> h.source_id OR
        s.operator_id <> h.operator_id OR
        s.landing_id <> h.landing_id OR
        s.platform_id <> h.platform_id OR
        s.landing_pay_type_id <> h.landing_pay_type_id OR
        s.is_cpa <> h.is_cpa')->execute();
    echo "SUBSCRIPTION_OFFS UPDATED\n";

    /** ОБНОВЛЯЕМ РЕБИЛЛЫ */
    $this->correctRebills();

    /** ОБНОВЛЯЕМ ИК */
    $this->correctOnetime();

    Yii::$app->db->createCommand('SET FOREIGN_KEY_CHECKS = 0')->execute();

    Yii::$app->db->createCommand('TRUNCATE TABLE hits_day_group')->execute();
    Yii::$app->db->createCommand('TRUNCATE TABLE subscriptions_day_group')->execute();
    Yii::$app->db->createCommand('TRUNCATE TABLE hits_day_hour_group')->execute();
    Yii::$app->db->createCommand('TRUNCATE TABLE subscriptions_day_hour_group')->execute();
    Yii::$app->db->createCommand('TRUNCATE TABLE search_subscriptions')->execute();
    Yii::$app->db->createCommand('TRUNCATE TABLE statistic_day_user_group')->execute();
    Yii::$app->db->createCommand('TRUNCATE TABLE user_balances_grouped_by_day')->execute();
    Yii::$app->db->createCommand('SET FOREIGN_KEY_CHECKS = 1')->execute();
    echo "TRUNCATED CRON TABLES\n";
//    (new \mcms\statistic\commands\CronController('cron', Yii::$app->getModule('statistic')))->actionIndex();
    echo "CRON SCRIPT EXECUTION COMPLETE\n";
  }

  public function down()
  {
    echo "m160218_135150_correct_refs cannot be reverted.\n";

    return false;
  }

  private function correctRebills()
  {
    $rebillsQuery = (new \yii\db\Query())
      ->select('hits.id, s.real_profit_rub')
      ->from('subscription_rebills s')
      ->innerJoin('hits', 's.hit_id = hits.id')
      ->where('s.source_id <> hits.source_id')
      ->orWhere('s.operator_id <> hits.operator_id')
      ->orWhere('s.landing_id <> hits.landing_id')
      ->orWhere('s.platform_id <> hits.platform_id')
      ->orWhere('s.landing_pay_type_id <> hits.landing_pay_type_id')
      ->orWhere('s.is_cpa <> hits.is_cpa');
    echo $rebillsQuery->count() . " REBILLS FOUND\n";
    foreach($rebillsQuery->batch(10) as $hits){
      $hitsInfo = $this->getHitsInformation(ArrayHelper::getColumn($hits, 'id'));
      foreach ($hitsInfo as $hit) {
        $realProfit = ArrayHelper::map($hits, 'id', 'real_profit_rub')[$hit['id']];
        $resellerProfit = $this->getResellerProfit($realProfit, $hit['user_id'], $hit['operator_id'], $hit['landing_id']);
        $partnerProfit = $this->getUserProfit($resellerProfit, $hit['user_id'], $hit['operator_id'], $hit['landing_id']);

        $exchangerCurrencyValues = $this->fromRub($partnerProfit);

        $this->update('subscription_rebills', [
          'default_profit' => $hit['default_currency_rebill_price'],
          'default_profit_currency' => $hit['default_currency_id'],
          'real_profit_rub' => $realProfit,
          'reseller_profit_rub' => $resellerProfit,
          'profit_rub' => $partnerProfit,
          'profit_eur' => $exchangerCurrencyValues['eur'],
          'profit_usd' => $exchangerCurrencyValues['usd'],
          'landing_id' => $hit['landing_id'],
          'source_id' => $hit['source_id'],
          'operator_id' => $hit['operator_id'],
          'platform_id' => $hit['platform_id'],
          'landing_pay_type_id' => $hit['landing_pay_type_id'],
          'is_cpa' => $hit['is_cpa']
        ], ['hit_id' => $hit['id']]);
      }

      echo ">> BATCH(10) REBILLS CONVERTED\n";
    }
  }

  private function getHitsInformation($hitIds)
  {
    $query = (new \yii\db\Query())
      ->select([
        '`hits`.id',
        '`hits`.`source_id`',
        '`hits`.`operator_id`',
        '`hits`.`landing_id`',
        '`hits`.`platform_id`',
        '`hits`.`landing_pay_type_id`',
        '`hits`.`time`',
        '`hits`.`date`',
        '`hits`.`is_cpa`',
        '`hit_params`.`label1`',
        '`hit_params`.`label2`',
        '`hit_params`.`referer`',
        '`hit_params`.`ip`',
        '`sources`.`trafficback_url`',
        '`sources`.user_id',
        '`sources`.stream_id',
        '`landings`.provider_id',
        '`operators`.country_id',
        '`landing_operators`.default_currency_id',
        '`landing_operators`.default_currency_rebill_price',
        '`landing_operators`.rebill_price_usd',
        '`landing_operators`.rebill_price_eur',
        '`landing_operators`.rebill_price_rub'
      ])
      ->from('`hits`')
      ->innerJoin('hit_params', '`hits`.`id` = `hit_params`.`hit_id`')
      ->innerJoin('sources', '`sources`.`id` = `hits`.`source_id`')
      ->innerJoin('landings', '`landings`.id = `hits`.`landing_id`')
      ->innerJoin('operators', '`operators`.id = `hits`.`operator_id`')
      ->innerJoin('landing_operators', '(`landing_operators`.landing_id = `hits`.`landing_id` AND `landing_operators`.operator_id = `hits`.`operator_id`)')
      ->where(['hits.id' => $hitIds]);

    return $query->all();
  }

  private function getResellerProfit($sum, $userId, $operatorId, $landingId)
  {
    $percents = $this->getProfitApi($userId, $operatorId, $landingId);
    return $sum * $percents['reseller_rebill_percent']/100;
  }

  private function getUserProfit($resellerSum, $userId, $operatorId, $landingId)
  {
    $percents = $this->getProfitApi($userId, $operatorId, $landingId);
    return $resellerSum * $percents['rebill_percent']/100;
  }

  private function getProfitApi($userId, $operatorId = NULL, $landingId = NULL) {
    return Yii::$app->getModule('promo')->api('personalProfit', [
      'userId' => $userId,
      'operatorId' => $operatorId,
      'landingId' => $landingId
    ])->setResultTypeArray()->getResult();
  }

  private function fromRub($sum)
  {
    return Yii::$app->getModule('payments')
      ->api('exchangerCourses')
      ->fromRub($sum);
  }

  private function correctOnetime()
  {
    $onetimeQuery = (new \yii\db\Query())
      ->select('hits.id, s.real_profit_rub')
      ->from('onetime_subscriptions s')
      ->innerJoin('hits', 's.hit_id = hits.id')
      ->where('s.source_id <> hits.source_id')
      ->orWhere('s.operator_id <> hits.operator_id')
      ->orWhere('s.landing_id <> hits.landing_id')
      ->orWhere('s.platform_id <> hits.platform_id')
      ->orWhere('s.landing_pay_type_id <> hits.landing_pay_type_id');
    echo $onetimeQuery->count() . " ONETIME FOUND\n";

    foreach($onetimeQuery->batch(10) as $hits){
      $hitsInfo = $this->getHitsInformation(ArrayHelper::getColumn($hits, 'id'));
      foreach ($hitsInfo as $hit) {
        $realProfit = ArrayHelper::map($hits, 'id', 'real_profit_rub')[$hit['id']];
        $resellerProfit = $this->getResellerProfit($realProfit, $hit['user_id'], $hit['operator_id'], $hit['landing_id']);
        $partnerProfit = $this->getUserProfit($resellerProfit, $hit['user_id'], $hit['operator_id'], $hit['landing_id']);

        $exchangerCurrencyValues = $this->fromRub($partnerProfit);

        $this->update('onetime_subscriptions', [
          'default_profit' => $hit['default_currency_rebill_price'],
          'default_profit_currency' => $hit['default_currency_id'],
          'real_profit_rub' => $realProfit,
          'reseller_profit_rub' => $resellerProfit,
          'profit_rub' => $partnerProfit,
          'profit_eur' => $exchangerCurrencyValues['eur'],
          'profit_usd' => $exchangerCurrencyValues['usd'],
          'landing_id' => $hit['landing_id'],
          'source_id' => $hit['source_id'],
          'operator_id' => $hit['operator_id'],
          'platform_id' => $hit['platform_id'],
          'landing_pay_type_id' => $hit['landing_pay_type_id'],
          'provider_id' => $hit['provider_id'],
          'country_id' => $hit['country_id'],
          'stream_id' => $hit['stream_id'],
          'user_id' => $hit['user_id'],
        ], ['hit_id' => $hit['id']]);
      }

      echo ">> BATCH(10) ONETIME CONVERTED\n";
    }
  }


}
