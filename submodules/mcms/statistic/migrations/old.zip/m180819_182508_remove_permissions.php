<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
*/
class m180819_182508_remove_permissions extends Migration
{
  use PermissionTrait;
  /**
  */
  public function up()
  {
    $this->removePermission('StatisticResellerHoldRulesIndex');
    $this->removePermission('StatisticResellerHoldRulesController');

    $this->removePermission('LoyaltyBonusesViewModal');
    $this->removePermission('LoyaltyBonusesIndex');
    $this->removePermission('LoyaltyBonusesController');
    $this->removePermission('LoyaltyModule');

    $this->renameTable('loyalty_bonuses', 'old_loyalty_bonuses');
    $this->delete('modules', ['module_id' => 'loyalty']);

    $this->renameTable('credit_transactions', 'old_credit_transactions');
    $this->renameTable('credits', 'old_credits');
    $this->delete('modules', ['module_id' => 'credits']);

    $this->removePermission('CreditsModule');
    $this->removePermission('CreditsCreditsController');
    $this->removePermission('CreditsCreditsIndex');
    $this->removePermission('CreditsCreditPaymentsController');
    $this->removePermission('CreditsCreditPaymentsCreateModal');
    $this->removePermission('CreditsCreditPaymentsUpdateModal');
    $this->removePermission('PaymentsEditMgmpSettings');
    $this->removePermission('PaymentsResellerCheckoutCreate');



  }

  /**
  */
  public function down()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createPermission('StatisticResellerHoldRulesController', 'Контроллер правила холдирования профитов реселлера', 'StatisticModule');
    $this->createPermission('StatisticResellerHoldRulesIndex', 'Просмотр правил холдирования профитов реселлера', 'StatisticResellerHoldRulesController', ['root', 'admin', 'reseller']);

    $this->createPermission('LoyaltyModule', 'Модуль программы лояльности для реселлера');
    $this->createPermission('LoyaltyBonusesController', 'Контроллер бонусов', 'LoyaltyModule', ['root', 'admin']);
    $this->createPermission('LoyaltyBonusesIndex', 'Список бонусов', 'LoyaltyBonusesController');
    $this->createPermission('LoyaltyBonusesViewModal', 'Детальный просмотр бонуса', 'LoyaltyBonusesController');

    $this->renameTable('old_loyalty_bonuses', 'loyalty_bonuses');


    $this->insert('modules', [
      'module_id' => 'loyalty',
      'name' => 'loyalty.main.loyalty',
      'is_disabled' => 0,
      'created_at' => time(),
      'updated_at' => time(),
    ]);

    $this->insert('modules', [
      'module_id' => 'credits',
      'name' => 'credits.main.credits',
      'is_disabled' => 0,
      'created_at' => time(),
      'updated_at' => time(),
    ]);


    $this->createPermission('CreditsModule', 'Модуль Credits');
    $this->createPermission('CreditsCreditsController', 'Контроллер кредитов', 'CreditsModule');
    $this->createPermission('CreditsCreditsIndex', 'Просмотр кредитов', 'CreditsCreditsController', ['root', 'admin', 'reseller']);
    $this->createPermission('CreditsCreditPaymentsController', 'Контроллер выплат по кредитам', 'CreditsModule', ['root', 'admin', 'reseller']);
    $this->createPermission('CreditsCreditPaymentsCreateModal', 'Создание выплаты', 'CreditsCreditPaymentsController', ['root', 'admin', 'reseller']);
    $this->createPermission('CreditsCreditPaymentsUpdateModal', 'Изменение выплаты', 'CreditsCreditPaymentsController', ['root', 'admin', 'reseller']);
    $this->createPermission('PaymentsEditMgmpSettings', 'Редактирование настроек MGMP', 'PaymentsSettings', ['root' ,'admin']);
    $this->createPermission('PaymentsResellerCheckoutCreate', 'Создание записи в логе', 'PaymentsResellerCheckoutController');

    $this->renameTable('old_credit_transactions', 'credit_transactions');
    $this->renameTable('old_credits', 'credits');


  }
}
