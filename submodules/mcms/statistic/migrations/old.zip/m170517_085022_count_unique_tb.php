<?php

use console\components\Migration;

class m170517_085022_count_unique_tb extends Migration
{
  public function up()
  {
    $this->addColumn('hits_day_hour_group', 'count_unique_tb', 'mediumint(5) unsigned NOT NULL DEFAULT 0 after count_tb');
    $this->addColumn('hits_day_group', 'count_unique_tb', 'mediumint(5) unsigned NOT NULL DEFAULT 0 after count_tb');
  }

  public function down()
  {
    $this->dropColumn('hits_day_group', 'count_unique_tb');
    $this->dropColumn('hits_day_hour_group', 'count_unique_tb');
  }

}
