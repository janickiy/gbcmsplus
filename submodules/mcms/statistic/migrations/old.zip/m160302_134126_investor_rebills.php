<?php

use console\components\Migration;

class m160302_134126_investor_rebills extends Migration
{

  public function up()
  {

    $counter = 1;

    $courses = Yii::$app->getModule('payments')->api('exchangerCourses')->getCurrencyCourses();

    $investors = Yii::$app->getModule('users')->api('usersByRoles', ['investor'])->getResult();

    $promoModule = Yii::$app->getModule('promo');

    foreach ($investors as $investor) {

      $landingOperatorsQuery = (new \yii\db\Query())
        ->select(['operator_id', 'landing_id'])
        ->from('subscription_rebills r')
        ->innerJoin('sources s', 'r.source_id = s.id AND s.user_id = :investor_id', [':investor_id' => $investor['id']])
        ->groupBy(['operator_id', 'landing_id']);

      foreach ($landingOperatorsQuery->batch() as $landingOperatorsArr) {
        foreach ($landingOperatorsArr as $landingOperator) {
          $investorProfit = $promoModule->api('personalProfit', [
            'userId' => $investor['id'],
            'operatorId' => $landingOperator['operator_id'],
            'landingId' => $landingOperator['landing_id']
          ])->getResult();

          $resellerProfitPercent = ($investorProfit['reseller_rebill_percent'] / 100);

          $partnerProfitPercent = $resellerProfitPercent * ($investorProfit['rebill_percent'] / 100);

          Yii::$app->db->createCommand('UPDATE subscription_rebills r
            INNER JOIN sources s ON s.id = r.source_id AND s.user_id = :investor_id
            SET
              r.reseller_profit_rub = real_profit_rub * :resellerPercent,
              r.profit_rub = real_profit_rub * :partnerPercent,
              r.profit_usd = real_profit_rub * :partnerPercent * :rur_usd,
              r.profit_eur = real_profit_rub * :partnerPercent * :rur_eur
            WHERE r.landing_id = :landing_id AND r.operator_id = :operator_id AND s.user_id = :investor_id
          ', [
            ':investor_id' => $investor['id'],
            ':operator_id' => $landingOperator['operator_id'],
            ':landing_id' => $landingOperator['landing_id'],
            ':resellerPercent' => $resellerProfitPercent,
            ':partnerPercent' => $partnerProfitPercent,
            ':rur_usd' => $courses->rur_usd,
            ':rur_eur' => $courses->rur_eur
          ])->execute();

          // Эти таблицы обновятся в кроне:
          // subscriptions_day_hour_group, subscriptions_day_group, statistic_day_user_group, statistic_day_user_group, user_balances_grouped_by_day

          echo sprintf("[%s] OK: investor=%s operator=%s landing=%s\n",
            $counter, $investor['id'], $landingOperator['operator_id'], $landingOperator['landing_id']
          );
          $counter++;
        }
      }
    }
  }

  public function down()
  {
    echo "m160302_134126_investor_rebills cannot be reverted.\n";
  }
}
