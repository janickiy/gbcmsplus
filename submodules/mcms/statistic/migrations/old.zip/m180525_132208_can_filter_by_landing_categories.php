<?php

use console\components\Migration;

class m180525_132208_can_filter_by_landing_categories extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  const PERMISSION = 'StatisticFilterByLandingCategories';

  public function up()
  {
    $this->createPermission(self::PERMISSION, 'Просмотр фильтра по категориям лендингов', 'StatisticFilter', ['admin', 'root', 'reseller']);
  }

  public function down()
  {
    $this->removePermission(self::PERMISSION);
  }
}
