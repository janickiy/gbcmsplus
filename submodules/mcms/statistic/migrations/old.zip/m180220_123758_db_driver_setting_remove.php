<?php

use rgk\settings\models\Setting;
use console\components\Migration;

class m180220_123758_db_driver_setting_remove extends Migration
{
  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;

  const SETTING = 'driver';

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
  }

  public function up()
  {
    $this->settingsBuilder->removeSetting(self::SETTING);
  }

  public function down()
  {
    $title = ['ru' => 'Тип драйвера базы данных', 'en' => 'Database driver type'];
    $permissions = ['EditModuleSettingsStatistic'];
    $category = 'app.common.group_system';
    $validators = [["required"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTING, $permissions, Setting::TYPE_OPTIONS, $category, 'mysql', $validators);
  }
}
