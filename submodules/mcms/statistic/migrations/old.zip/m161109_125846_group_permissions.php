<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m161109_125846_group_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->removeChildPermission('StatisticFilterBySources', 'StatisticStatFiltersSources');
    $this->removeChildPermission('StatisticFilterByStreams', 'StatisticStatFiltersStreams');
    $this->removeChildPermission('StatisticFilterByUsers', 'StatisticStatFiltersUsers');

    $this->assignRolesPermission('StatisticStatFiltersSources', ['root', 'admin', 'reseller', 'investor', 'partner']);
    $this->assignRolesPermission('StatisticStatFiltersStreams', ['root', 'admin', 'reseller', 'investor', 'partner']);
    $this->assignRolesPermission('StatisticStatFiltersUsers', ['root', 'admin', 'reseller', 'investor']);
  }

  public function down()
  {
    $this->authManager->addChild($this->getPermission('StatisticFilterBySources'), $this->getPermission('StatisticStatFiltersSources'));
    $this->authManager->addChild($this->getPermission('StatisticFilterByStreams'), $this->getPermission('StatisticStatFiltersStreams'));
    $this->authManager->addChild($this->getPermission('StatisticFilterByUsers'), $this->getPermission('StatisticStatFiltersUsers'));

    $this->revokeRolesPermission('StatisticStatFiltersSources', ['root', 'admin', 'reseller', 'investor', 'partner']);
    $this->revokeRolesPermission('StatisticStatFiltersStreams', ['root', 'admin', 'reseller', 'investor', 'partner']);
    $this->revokeRolesPermission('StatisticStatFiltersUsers', ['root', 'admin', 'reseller', 'investor']);


  }
}
