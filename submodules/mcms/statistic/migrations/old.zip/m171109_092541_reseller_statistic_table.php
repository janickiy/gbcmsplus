<?php

use console\components\Migration;

class m171109_092541_reseller_statistic_table extends Migration
{
  const RESELLER_STATISTIC_TABLE = 'reseller_profit_statistics';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET latin1 ENGINE=InnoDB';
    }

    $this->createTable(self::RESELLER_STATISTIC_TABLE, [
      'rebills_reseller_profit' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'onetime_reseller_profit' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'rebills_profit' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'onetime_profit' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'sold_profit' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'sold_real_profit' => 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0',
      'currency_id' => 'TINYINT(1) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'landing_pay_type_id' => 'TINYINT(1) UNSIGNED NOT NULL',
      'provider_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'country_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'operator_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'stream_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'source_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'platform_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
    ], $tableOptions);

    $this->addPrimaryKey(self::RESELLER_STATISTIC_TABLE . '_pk', self::RESELLER_STATISTIC_TABLE, [
      'date',
      'landing_pay_type_id',
      'operator_id',
      'source_id',
      'landing_id',
      'platform_id',
    ]);
  }

  public function down()
  {
    $this->dropTable(self::RESELLER_STATISTIC_TABLE);
  }
}
