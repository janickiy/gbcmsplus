<?php

use console\components\Migration;

class m170825_092805_cron_optimize_columns extends Migration
{
  public function up()
  {
    $this->alterColumn('search_subscriptions', 'time_off', 'int(10) unsigned DEFAULT 0');
    $this->alterColumn('search_subscriptions', 'time_on', 'int(10) unsigned DEFAULT 0');
    $this->alterColumn('search_subscriptions', 'time_rebill', 'int(10) unsigned DEFAULT 0');
    $this->alterColumn('search_subscriptions', 'last_time', 'int(10) unsigned DEFAULT 0');
    $this->alterColumn('search_subscriptions', 'count_rebills', 'mediumint(5) unsigned DEFAULT 0');
    $this->alterColumn('search_subscriptions', 'sum_real_profit_rub', 'decimal(6,2) unsigned DEFAULT 0');
    $this->alterColumn('search_subscriptions', 'sum_real_profit_eur', 'decimal(6,2) unsigned DEFAULT 0');
    $this->alterColumn('search_subscriptions', 'sum_real_profit_usd', 'decimal(6,2) unsigned DEFAULT 0');
    $this->alterColumn('search_subscriptions', 'sum_reseller_profit_rub', 'decimal(6,2) unsigned DEFAULT 0');
    $this->alterColumn('search_subscriptions', 'sum_reseller_profit_eur', 'decimal(6,2) unsigned DEFAULT 0');
    $this->alterColumn('search_subscriptions', 'sum_reseller_profit_usd', 'decimal(6,2) unsigned DEFAULT 0');
    $this->alterColumn('search_subscriptions', 'sum_profit_rub', 'decimal(6,2) unsigned DEFAULT 0');
    $this->alterColumn('search_subscriptions', 'sum_profit_eur', 'decimal(6,2) unsigned DEFAULT 0');
    $this->alterColumn('search_subscriptions', 'sum_profit_usd', 'decimal(6,2) unsigned DEFAULT 0');
    $this->alterColumn('search_subscriptions', 'phone', 'varchar(16) DEFAULT NULL');
    $this->alterColumn('search_subscriptions', 'currency_id', 'tinyint(1) unsigned DEFAULT 0');

//    удалим из subscriptions_day_hour_group и subscriptions_day_group следующие колонки
//    count_rebills_date_by_date
//    sum_profit_rub_date_by_date
//    sum_profit_eur_date_by_date
//    sum_profit_usd_date_by_date

    $this->dropColumn('subscriptions_day_hour_group', 'count_rebills_date_by_date');
    $this->dropColumn('subscriptions_day_hour_group', 'sum_profit_rub_date_by_date');
    $this->dropColumn('subscriptions_day_hour_group', 'sum_profit_eur_date_by_date');
    $this->dropColumn('subscriptions_day_hour_group', 'sum_profit_usd_date_by_date');

    $this->dropColumn('subscriptions_day_group', 'count_rebills_date_by_date');
    $this->dropColumn('subscriptions_day_group', 'sum_profit_rub_date_by_date');
    $this->dropColumn('subscriptions_day_group', 'sum_profit_eur_date_by_date');
    $this->dropColumn('subscriptions_day_group', 'sum_profit_usd_date_by_date');


//    удалим из invest_subscriptions_day_hour_group и invest_subscriptions_day_group следующие колонки
//    count_rebills_date_by_date
//    sum_profit_rub_date_by_date
//    sum_profit_eur_date_by_date
//    sum_profit_usd_date_by_date

    $this->dropColumn('invest_subscriptions_day_hour_group', 'count_rebills_date_by_date');
    $this->dropColumn('invest_subscriptions_day_hour_group', 'sum_profit_rub_date_by_date');
    $this->dropColumn('invest_subscriptions_day_hour_group', 'sum_profit_eur_date_by_date');
    $this->dropColumn('invest_subscriptions_day_hour_group', 'sum_profit_usd_date_by_date');

    $this->dropColumn('invest_subscriptions_day_group', 'count_rebills_date_by_date');
    $this->dropColumn('invest_subscriptions_day_group', 'sum_profit_rub_date_by_date');
    $this->dropColumn('invest_subscriptions_day_group', 'sum_profit_eur_date_by_date');
    $this->dropColumn('invest_subscriptions_day_group', 'sum_profit_usd_date_by_date');

//  и добавим их в statistic_data и invest_statistic_data

    $this->addColumn('statistic_data_hour_group', 'count_rebills_date_by_date', 'MEDIUMINT(5) UNSIGNED NOT NULL AFTER count_scope_offs');
    $this->addColumn('statistic_data_hour_group', 'sum_profit_rub_date_by_date', 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0 AFTER count_rebills_date_by_date');
    $this->addColumn('statistic_data_hour_group', 'sum_profit_eur_date_by_date', 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0 AFTER sum_profit_rub_date_by_date');
    $this->addColumn('statistic_data_hour_group', 'sum_profit_usd_date_by_date', 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0 AFTER sum_profit_eur_date_by_date');

    $this->addColumn('invest_statistic_data_hour_group', 'count_rebills_date_by_date', 'MEDIUMINT(5) UNSIGNED NOT NULL AFTER count_scope_offs');
    $this->addColumn('invest_statistic_data_hour_group', 'sum_profit_rub_date_by_date', 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0 AFTER count_rebills_date_by_date');
    $this->addColumn('invest_statistic_data_hour_group', 'sum_profit_eur_date_by_date', 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0 AFTER sum_profit_rub_date_by_date');
    $this->addColumn('invest_statistic_data_hour_group', 'sum_profit_usd_date_by_date', 'DECIMAL(9,2) UNSIGNED NOT NULL DEFAULT 0 AFTER sum_profit_eur_date_by_date');


  }

  public function down()
  {

    $this->addColumn('subscriptions_day_hour_group', 'count_rebills_date_by_date', 'mediumint(5) unsigned DEFAULT 0');
    $this->addColumn('subscriptions_day_hour_group', 'sum_profit_rub_date_by_date', 'decimal(9,2) unsigned NOT NULL DEFAULT \'0.00\'');
    $this->addColumn('subscriptions_day_hour_group', 'sum_profit_eur_date_by_date', 'decimal(9,2) unsigned NOT NULL DEFAULT \'0.00\'');
    $this->addColumn('subscriptions_day_hour_group', 'sum_profit_usd_date_by_date', 'decimal(9,2) unsigned NOT NULL DEFAULT \'0.00\'');

    $this->addColumn('subscriptions_day_group', 'count_rebills_date_by_date', 'mediumint(5) unsigned DEFAULT 0');
    $this->addColumn('subscriptions_day_group', 'sum_profit_rub_date_by_date', 'decimal(9,2) unsigned NOT NULL DEFAULT \'0.00\'');
    $this->addColumn('subscriptions_day_group', 'sum_profit_eur_date_by_date', 'decimal(9,2) unsigned NOT NULL DEFAULT \'0.00\'');
    $this->addColumn('subscriptions_day_group', 'sum_profit_usd_date_by_date', 'decimal(9,2) unsigned NOT NULL DEFAULT \'0.00\'');


    $this->addColumn('invest_subscriptions_day_hour_group', 'count_rebills_date_by_date', 'mediumint(5) unsigned DEFAULT 0');
    $this->addColumn('invest_subscriptions_day_hour_group', 'sum_profit_rub_date_by_date', 'decimal(9,2) unsigned NOT NULL DEFAULT \'0.00\'');
    $this->addColumn('invest_subscriptions_day_hour_group', 'sum_profit_eur_date_by_date', 'decimal(9,2) unsigned NOT NULL DEFAULT \'0.00\'');
    $this->addColumn('invest_subscriptions_day_hour_group', 'sum_profit_usd_date_by_date', 'decimal(9,2) unsigned NOT NULL DEFAULT \'0.00\'');

    $this->addColumn('invest_subscriptions_day_group', 'count_rebills_date_by_date', 'mediumint(5) unsigned DEFAULT 0');
    $this->addColumn('invest_subscriptions_day_group', 'sum_profit_rub_date_by_date', 'decimal(9,2) unsigned NOT NULL DEFAULT \'0.00\'');
    $this->addColumn('invest_subscriptions_day_group', 'sum_profit_eur_date_by_date', 'decimal(9,2) unsigned NOT NULL DEFAULT \'0.00\'');
    $this->addColumn('invest_subscriptions_day_group', 'sum_profit_usd_date_by_date', 'decimal(9,2) unsigned NOT NULL DEFAULT \'0.00\'');

    $this->dropColumn('statistic_data_hour_group', 'count_rebills_date_by_date');
    $this->dropColumn('statistic_data_hour_group', 'sum_profit_rub_date_by_date');
    $this->dropColumn('statistic_data_hour_group', 'sum_profit_eur_date_by_date');
    $this->dropColumn('statistic_data_hour_group', 'sum_profit_usd_date_by_date');

    $this->dropColumn('invest_statistic_data_hour_group', 'count_rebills_date_by_date');
    $this->dropColumn('invest_statistic_data_hour_group', 'sum_profit_rub_date_by_date');
    $this->dropColumn('invest_statistic_data_hour_group', 'sum_profit_eur_date_by_date');
    $this->dropColumn('invest_statistic_data_hour_group', 'sum_profit_usd_date_by_date');

  }
}
