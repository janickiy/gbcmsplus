<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

class m170816_184918_statistic_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticDetailSellReturn', 'Возврат партнеру продажи', 'StatisticDetailController', ['admin', 'root', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('StatisticDetailSellReturn');
  }

}
