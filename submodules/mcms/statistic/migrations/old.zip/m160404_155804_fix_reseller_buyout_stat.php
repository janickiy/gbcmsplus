<?php

use console\components\Migration;

class m160404_155804_fix_reseller_buyout_stat extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  const PERMISSION = 'StatisticViewBuyoutPriceInsteadProfit';

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->createOrGetPermission(self::PERMISSION, 'View buyout price instead of profit');
    $this->assignRolesPermission(self::PERMISSION, ['root', 'admin', 'reseller']);

  }

  public function down()
  {
    $this->removePermission(self::PERMISSION);
  }
}
