<?php

use console\components\Migration;
use yii\db\Expression;

class m160330_082153_ik_correct extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  const P_PROFIT = 'personal_profit';
  const ONETIME = 'onetime_subscriptions';
  const VIEW_HIDDEN = 'StatisticViewHiddenOnetimeSubscriptions';

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    parent::init();
  }

  public function up()
  {
    $this->renameColumn(self::P_PROFIT, 'buyout_profit', 'cpa_profit');
    $this->addColumn(self::ONETIME, 'is_visible_to_partner', 'tinyint(1) unsigned NOT NULL DEFAULT \'1\' COMMENT \'корректировка\'');
    $this->addColumn(self::ONETIME, 'calc_profit_rub', 'decimal(6,2) unsigned NOT NULL DEFAULT \'0\' COMMENT \'расчитанный профит партнера без учета корректировки\' after profit_usd');
    $this->addColumn(self::ONETIME, 'calc_profit_eur', 'decimal(6,2) unsigned NOT NULL DEFAULT \'0\' COMMENT \'расчитанный профит партнера без учета корректировки\' after calc_profit_rub');
    $this->addColumn(self::ONETIME, 'calc_profit_usd', 'decimal(6,2) unsigned NOT NULL DEFAULT \'0\' COMMENT \'расчитанный профит партнера без учета корректировки\' after calc_profit_eur');
    $this->update(self::ONETIME, [
      'calc_profit_rub' => new Expression('profit_rub'),
      'calc_profit_eur' => new Expression('profit_eur'),
      'calc_profit_usd' => new Expression('profit_usd')
    ]);

    $this->createOrGetPermission(self::VIEW_HIDDEN, 'Can view onetime_subscriptions that are hidden for partner');
    $this->assignRolesPermission(self::VIEW_HIDDEN, ['root', 'reseller', 'admin', 'investor']);
  }

  public function down()
  {
    $this->removePermission(self::VIEW_HIDDEN);

    $this->dropColumn(self::ONETIME, 'calc_profit_usd');
    $this->dropColumn(self::ONETIME, 'calc_profit_eur');
    $this->dropColumn(self::ONETIME, 'calc_profit_rub');
    $this->dropColumn(self::ONETIME, 'is_visible_to_partner');
    $this->renameColumn(self::P_PROFIT, 'cpa_profit', 'buyout_profit');
  }
}
