<?php

use console\components\Migration;

class m180316_115907_new_stat_action extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission(
      'StatisticMainIndexNew',
      'Просмотр основной статистики (без инвесторов)',
      'StatisticMainController',
      ['root']
    );

    $this->createPermission(
      'StatisticAnalyticsIndexNew',
      'Просмотр аналитики (без инвесторов)',
      'StatisticMainController',
      ['root']
    );
  }

  public function down()
  {
    $this->removePermission('StatisticMainIndexNew');
    $this->removePermission('StatisticAnalyticsIndexNew');
  }
}
