<?php

use console\components\Migration;

class m151221_143223_detail_view extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->createOrGetPermission('StatisticDetailSubscriptionDetail', 'View detail info by subscription');
    $this->assignRolesPermission('StatisticDetailSubscriptionDetail', ['root', 'admin', 'investor']);

    $this->createOrGetPermission('StatisticDetailSellsDetail', 'View detail info by sold subscription');
    $this->assignRolesPermission('StatisticDetailSellsDetail', ['root', 'admin', 'investor']);

    $this->createOrGetPermission('StatisticDetailIkDetail', 'View detail info by onetime subscription');
    $this->assignRolesPermission('StatisticDetailIkDetail', ['root', 'admin', 'investor']);


  }

  public function down()
  {
    $this->removePermission('StatisticDetailSubscriptionDetail');
    $this->removePermission('StatisticDetailSellsDetail');
    $this->removePermission('StatisticDetailIkDetail');
  }

  protected function removePermission($name)
  {
    $permission = $this->authManager->getPermission($name);
    if ($permission) {
      $this->authManager->remove($permission);
    }
  }
}
