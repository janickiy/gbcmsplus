<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170705_082546_postback_rules extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticPostbackController', 'Контроллер постбеков', 'StatisticModule');
    $this->createPermission('StatisticPostbackIndex', 'Просмотр списка постбеков', 'StatisticPostbackController', ['root', 'admin']);
  }

  public function down()
  {
    $this->removePermission('StatisticPostbackIndex');
    $this->removePermission('StatisticPostbackController');
  }
}
