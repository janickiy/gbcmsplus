<?php

use console\components\Migration;

class m151217_154015_statistic_detailt_hour extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Statistic';
    $this->permissions = [
      'Default' => [
        ['hour', 'can view hour default statictic', ['admin', 'root', 'reseller']]
      ]
    ];
  }


}
