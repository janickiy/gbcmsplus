<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
 */
class m180820_093515_remove_reseller_profits extends Migration
{
  use PermissionTrait;

  /**
   */
  public function up()
  {
    $this->delete('reseller_profits', 'date > :date', [':date' => '2018-08-15']);
  }

  /**
   */
  public function down()
  {
    echo "m180820_093515_remove_reseller_profits cannot be reverted.\n";

    return true;
  }
}
