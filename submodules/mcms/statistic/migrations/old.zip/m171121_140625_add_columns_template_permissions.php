<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

class m171121_140625_add_columns_template_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticDefaultCreateColumnsTemplate', 'Создание шаблона для столбцов таблицы', 'StatisticDefaultIndex', ['admin', 'root', 'reseller', 'investor']);
    $this->createPermission('StatisticDefaultUpdateColumnsTemplate', 'Изменение шаблона для столбцов таблицы', 'StatisticDefaultIndex', ['admin', 'root', 'reseller', 'investor']);
  }

  public function down()
  {
    $this->removePermission('StatisticDefaultCreateColumnsTemplate');
    $this->removePermission('StatisticDefaultUpdateColumnsTemplate');
  }
}
