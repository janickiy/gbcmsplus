<?php

use console\components\Migration;

class m160318_061354_fix_sold_is_cpa extends Migration
{
  public function up()
  {
    $this->db->createCommand('UPDATE subscriptions s JOIN sold_subscriptions ss ON ss.hit_id=s.hit_id SET s.is_cpa=0 WHERE s.is_cpa=1;')->execute();
    $this->db->createCommand('UPDATE hits h JOIN sold_subscriptions ss ON ss.hit_id=h.id SET h.is_cpa=0 WHERE h.is_cpa=1;')->execute();
    $this->db->createCommand('UPDATE subscription_rebills sr JOIN sold_subscriptions ss ON ss.hit_id=sr.hit_id SET sr.is_cpa=0 WHERE sr.is_cpa=1;')->execute();
    $this->db->createCommand('UPDATE subscription_offs so JOIN sold_subscriptions ss ON ss.hit_id=so.hit_id SET so.is_cpa=0 WHERE so.is_cpa=1;')->execute();
    $this->db->createCommand('UPDATE search_subscriptions s JOIN sold_subscriptions ss ON ss.hit_id=s.hit_id SET s.is_cpa=0 WHERE s.is_cpa=1;')->execute();
  }

  public function down()
  {
    echo "m160318_061354_fix_sold_is_cpa cannot be reverted.\n";
  }
}
