<?php

use console\components\Migration;

class m160106_082758_investor_rights extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->revokeRolesPermission('StatisticFilterByUsers', ['investor']);

    $this->createOrGetPermission('StatisticViewSellInvestorPrice', 'View investor buyout price of subscriptions');
    $this->assignRolesPermission('StatisticViewSellInvestorPrice', ['root', 'admin', 'investor']);

    $this->createOrGetPermission('StatisticViewSellPartnerPrice', 'View partners sell price of subscriptions');
    $this->assignRolesPermission('StatisticViewSellPartnerPrice', ['root', 'admin', 'reseller', 'partner']);
  }

  public function down()
  {
    $this->removePermission('StatisticViewSellPartnerPrice');
    $this->removePermission('StatisticViewSellInvestorPrice');
    $this->assignRolesPermission('StatisticFilterByUsers', ['investor']);
  }
}
