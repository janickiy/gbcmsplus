<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

class m171123_143443_action_get_columns_template_permission extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('StatisticDefaultGetColumnsTemplate', 'Получение списка шаблонов', 'StatisticDefaultIndex', ['admin', 'root', 'reseller', 'investor']);
  }

  public function down()
  {
    $this->removePermission('StatisticDefaultGetColumnsTemplate');
  }
}
