<?php

use yii\db\Schema;
use console\components\Migration;

class m160211_213833_hits_day_group_country_id_index extends Migration
{
  public function up()
  {
    $this->createIndex('hdg_country_id', 'hits_day_group', 'country_id');
  }

  public function down()
  {
    $this->dropIndex('hdg_country_id', 'hits_day_group');
  }

}
