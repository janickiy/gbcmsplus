<?php

use console\components\Migration;

class m161226_102253_hit_info_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function up()
  {
    $this->createPermission('StatisticDetailHit', 'Просмотр детальной информации о хитах', 'StatisticDetailController', ['root', 'admin', 'reseller', 'manager', 'investor']);
  }

  public function down()
  {
    $this->removePermission('StatisticDetailHit');
  }
}
