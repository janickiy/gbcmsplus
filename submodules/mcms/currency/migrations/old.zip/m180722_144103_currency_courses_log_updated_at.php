<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
 */
class m180722_144103_currency_courses_log_updated_at extends Migration
{
  use PermissionTrait;

  /**
   */
  public function up()
  {
    $this->addColumn('currency_courses_log', 'updated_at', 'INT(10) UNSIGNED NOT NULL');
  }

  /**
   */
  public function down()
  {
    $this->dropColumn('currency_courses_log', 'updated_at');
  }
}
