<?php

use yii\db\Migration;

class m180724_074754_add_column extends Migration
{
  public function up()
  {
    $this->dropColumn('currencies', 'created_by');
    $this->dropColumn('currencies', 'is_fixed');
    $this->addColumn('currencies', 'to_rub', 'decimal(13, 9) unsigned default \'1\' not null AFTER symbol');
    $this->addColumn('currencies', 'to_usd', 'decimal(13, 9) unsigned default \'1\' not null AFTER to_rub');
    $this->addColumn('currencies', 'to_eur', 'decimal(13, 9) unsigned default \'1\' not null AFTER to_usd');
    $this->addColumn('currencies', 'partner_percent_rub', 'decimal(4, 2) unsigned default \'0\' not null AFTER to_eur');
    $this->addColumn('currencies', 'partner_percent_usd', 'decimal(4, 2) unsigned default \'0\' not null AFTER partner_percent_rub');
    $this->addColumn('currencies', 'partner_percent_eur', 'decimal(4, 2) unsigned default \'0\' not null AFTER partner_percent_usd');
    $this->createIndex('currencies_code_uq', 'currencies', 'code', true);
    $this->alterColumn('currencies', 'symbol', 'varchar(30)');
  }

  public function down()
  {
    $this->alterColumn('currencies', 'symbol', 'varchar(30) not null');
    $this->dropIndex('currencies_code_uq', 'currencies');
    $this->dropColumn('currencies', 'to_rub');
    $this->dropColumn('currencies', 'partner_percent_rub');
    $this->dropColumn('currencies', 'to_usd');
    $this->dropColumn('currencies', 'partner_percent_usd');
    $this->dropColumn('currencies', 'to_eur');
    $this->dropColumn('currencies', 'partner_percent_eur');
    $this->addColumn('currencies', 'is_fixed', 'tinyint(1) unsigned default \'0\' not null');
    $this->addColumn('currencies', 'created_by', 'mediumint(5) unsigned AFTER symbol');
  }
}
