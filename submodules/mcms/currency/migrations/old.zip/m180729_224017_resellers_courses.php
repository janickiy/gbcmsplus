<?php

use mcms\currency\components\UpdateCourses;
use yii\db\Migration;

class m180729_224017_resellers_courses extends Migration
{
  const TABLE = 'currencies';
  const TABLE_LOG = 'currency_courses_log';

  public function up()
  {
    $this->addColumn(self::TABLE, 'custom_to_rub', 'decimal(13, 9) unsigned AFTER to_eur');
    $this->addColumn(self::TABLE, 'custom_to_usd', 'decimal(13, 9) unsigned AFTER custom_to_rub');
    $this->addColumn(self::TABLE, 'custom_to_eur', 'decimal(13, 9) unsigned AFTER custom_to_usd');

    $this->addColumn(self::TABLE_LOG, 'custom_to_rub', 'decimal(13, 9) unsigned AFTER to_eur');
    $this->addColumn(self::TABLE_LOG, 'custom_to_usd', 'decimal(13, 9) unsigned AFTER custom_to_rub');
    $this->addColumn(self::TABLE_LOG, 'custom_to_eur', 'decimal(13, 9) unsigned AFTER custom_to_usd');

    // Обновление курсов валют из http://geoapi.rgktools.com/api/currency-layer/
    (new UpdateCourses())->execute();
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'custom_to_rub');
    $this->dropColumn(self::TABLE, 'custom_to_usd');
    $this->dropColumn(self::TABLE, 'custom_to_eur');

    $this->dropColumn(self::TABLE_LOG, 'custom_to_rub');
    $this->dropColumn(self::TABLE_LOG, 'custom_to_usd');
    $this->dropColumn(self::TABLE_LOG, 'custom_to_eur');
  }
}
