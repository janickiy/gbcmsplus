<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
*/
class m180829_091634_currency_notify_email_categories extends Migration
{
  use PermissionTrait;

  /**
  */
  public function up()
  {
    $reseller = Yii::$app->getModule('users')->api('usersByRoles', ['reseller'])->getResult();
    $resellerId = current($reseller)['id'];
    $currencyModuleId = Yii::$app->db->createCommand('SELECT id FROM modules WHERE module_id = :module_id', [
      ':module_id' => "currency"
    ])->queryScalar();

    $userParams = (new \yii\db\Query())
      ->select(['id', 'notify_browser_categories', 'notify_email_categories'])
      ->from('user_params')
      ->where(['user_id' => $resellerId])->one();


    $emailCategories = unserialize($userParams['notify_email_categories']);
    $browserCategories = unserialize($userParams['notify_browser_categories']);
    $emailCategories[] = $currencyModuleId;
    $browserCategories[] = $currencyModuleId;

    Yii::$app->db->createCommand('
          UPDATE user_params
          SET notify_browser_categories = :notify_browser_categories,
          notify_email_categories = :notify_email_categories
          WHERE user_id = :user_id', [
      ':notify_browser_categories' => serialize($emailCategories),
      ':notify_email_categories' => serialize($browserCategories),
      ':user_id' => $resellerId,
    ])->execute();
  }

  /**
  */
  public function down()
  {
    echo "m180829_091634_currency_notify_email_categories cannot be reverted.\n";

    return true;
  }
}
