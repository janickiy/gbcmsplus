<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
 */
class m180816_100944_currency_permissions extends Migration
{
  use PermissionTrait;

  /**
   */
  public function up()
  {
    $this->createPermission('CurrencyDefaultValidateCustomCourse',
      'Валидация кастомного курса',
      'CurrencyDefaultController',
      ['reseller']
    );

  }

  /**
   */
  public function down()
  {
    $this->removePermission('CurrencyDefaultValidateCustomCourse');
  }
}
