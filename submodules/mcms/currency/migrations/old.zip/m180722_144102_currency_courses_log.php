<?php

use yii\db\Migration;

class m180722_144102_currency_courses_log extends Migration
{
  const TABLE = 'currency_courses_log';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::TABLE, [
      'currency_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'to_rub' => 'DECIMAL(13, 9) UNSIGNED DEFAULT 1 NOT NULL',
      'to_usd' => 'DECIMAL(13, 9) UNSIGNED DEFAULT 1 NOT NULL',
      'to_eur' => 'DECIMAL(13, 9) UNSIGNED DEFAULT 1 NOT NULL',
      'partner_percent_rub' => 'DECIMAL(4, 2) UNSIGNED DEFAULT 0 NOT NULL',
      'partner_percent_usd' => 'DECIMAL(4, 2) UNSIGNED DEFAULT 0 NOT NULL',
      'partner_percent_eur' => 'DECIMAL(4, 2) UNSIGNED DEFAULT 0 NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
    ], $tableOptions);
  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }
}