<?php

use console\components\Migration;
use mcms\currency\components\events\CustomCourseBecameUnprofitable;
use mcms\notifications\models\Notification;
use rgk\utils\traits\PermissionTrait;
use yii\helpers\ArrayHelper;

/**
*/
class m180811_100007_bad_course_notification extends Migration
{
  use PermissionTrait;
  /**
  */
  public function up()
  {
    $currencyModuleId = Yii::$app->db->createCommand('SELECT id FROM modules WHERE module_id = "currency"')->queryScalar();

    $this->createNotification([
      'module_id' => $currencyModuleId,
      'event' => CustomCourseBecameUnprofitable::className(),
      'type' => Notification::NOTIFICATION_TYPE_EMAIL,
      'header' => [
        'ru' => 'Курс {currency.course} стал невыгодным',
        'en' => 'Course {currency.course} became unprofitable',
      ],
      'template' => [
        'ru' => 'Оригинальный курс с наложеным процентом - {currency.original_course}, кастомный курс - {currency.custom_course}.',
        'en' => 'Original course with additional percent - {currency.original_course}, custom course - {currency.custom_course}.'
      ],
      'from' => [
        'ru' => '{noreply_email}',
        'en' => '{noreply_email}'
      ],
      'is_important' => true,
      'roles' => ['reseller'],
    ]);

  }

  /**
  */
  public function down()
  {
    $this->delete('notifications', [
      'event' => CustomCourseBecameUnprofitable::className(),
    ]);
  }

  private function createNotification(array $notification)
  {
    $this->insert('notifications', [
      'module_id' => ArrayHelper::getValue($notification, 'module_id'),
      'event' => ArrayHelper::getValue($notification, 'event'),
      'notification_type' => ArrayHelper::getValue($notification, 'type'),
      'is_disabled' => 0,
      'use_owner' => ArrayHelper::getValue($notification, 'use_owner', false),
      'is_important' => ArrayHelper::getValue($notification, 'is_important', false),
      'created_at' => time(),
      'updated_at' => time(),
      'is_system' => 0,
      'emails' => '',
      'from' => serialize(ArrayHelper::getValue($notification, 'from')),
      'template' => serialize(ArrayHelper::getValue($notification, 'template')),
      'header' => serialize(ArrayHelper::getValue($notification, 'header')),
      'is_news' => 0,
      'emails_language' => 'ru'
    ]);
    $roles = ArrayHelper::getValue($notification, 'roles', []);

    $id = $this->db->getLastInsertID();
    foreach ($roles as $role) {
      $this->insert('notifications_auth_item', [
        'auth_item_name' => $role,
        'notification_id' => $id
      ]);
    }
  }

}
