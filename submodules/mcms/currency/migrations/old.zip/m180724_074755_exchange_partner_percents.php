<?php

use rgk\settings\components\SettingsManager;
use yii\db\Migration;

class m180724_074755_exchange_partner_percents extends Migration
{
  const SETTING = 'settings.payments.exchange_percent_';
  const TABLE = 'currencies';

  private static $courses = [
    'usd_rur',
    'rur_usd',
    'usd_eur',
    'eur_usd',
    'eur_rur',
    'rur_eur',
  ];

  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;
  /** @var  SettingsManager */
  public $settings;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
    $this->settings = Yii::$app->get('settingsManager');
  }

  public function up()
  {
    foreach (self::$courses as $course) {
      $value = $this->settings->getValueByKey(self::SETTING . $course);
      $currency = explode('_', str_replace('rur', 'rub', $course));
      $this->update(self::TABLE, ['partner_percent_' . $currency[1] => $value], ['code' => $currency[0]]);
      //TODO раскомментить когда сделаем использование новых процентов
      //$this->settingsBuilder->removeSetting(self::SETTING . $course);
    }
  }

  public function down()
  {
    foreach (self::$courses as $order => $course) {
      $courseTitle = strtoupper(str_replace('_', '/', $course));
      $title = ['ru' => 'Процент комиссии при конвертации ' . $courseTitle, 'en' => 'Exchange percent commission ' . $courseTitle];
      $permissions = ['EditModuleSettingsPayments'];
      $category = 'app.common.form_group_payments_main';
      $validators = [['number', ['min' => 0, 'max' => 20]], ['double']];
     //TODO раскомментить когда сделаем использование новых процентов
     // $this->settingsBuilder->createSetting($title, [], self::SETTING . $course, $permissions, Setting::TYPE_FLOAT, $category, 2, $validators, $order);
    }
  }
}
