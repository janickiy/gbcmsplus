<?php

use rgk\utils\traits\PermissionTrait;
use yii\db\Migration;

class m180724_083626_crud_permissions extends Migration
{

  use PermissionTrait;

  public function up()
  {
    $this->insert('modules', [
      'module_id' => 'currency',
      'name' => 'currency.main.module',
      'created_at' => time(),
      'updated_at' => time(),
    ]);

    $this->createPermission('CurrencyModule', 'Модуль Currency');
    $this->createPermission('CurrencyDefaultController', 'Контроллер Default', 'CurrencyModule', ['root', 'admin']);
    $this->createPermission('CurrencyDefaultIndex', 'Просмотр списка валют', 'CurrencyDefaultController', ['reseller']);
    $this->createPermission('CurrencyDefaultUpdateModal', 'Редактирование валюты', 'CurrencyDefaultController', ['reseller']);

    $this->removePermission('PromoCurrenciesCreate');
    $this->removePermission('PromoCurrenciesCreateModal');
    $this->removePermission('PromoCurrenciesDelete');
    $this->removePermission('PromoCurrenciesIndex');
    $this->removePermission('PromoCurrenciesUpdate');
    $this->removePermission('PromoCurrenciesUpdateModal');
    $this->removePermission('PromoCurrenciesView');
    $this->removePermission('PromoCurrenciesViewModal');
  }

  public function down()
  {
    $this->createPermission('PromoCurrenciesCreate', 'Создание валюты', 'PromoCurrenciesController', ['root', 'admin']);
    $this->createPermission('PromoCurrenciesCreateModal', 'Создание валюты модалка', 'PromoCurrenciesController', ['root', 'admin']);
    $this->createPermission('PromoCurrenciesDelete', 'Удаление валюты', 'PromoCurrenciesController', ['root', 'admin']);
    $this->createPermission('PromoCurrenciesIndex', 'Просмотр списка валют', 'PromoCurrenciesController', ['root', 'admin']);
    $this->createPermission('PromoCurrenciesUpdate', 'Редактирование валюты', 'PromoCurrenciesController', ['root', 'admin']);
    $this->createPermission('PromoCurrenciesUpdateModal', 'Редактирование валюты модалка', 'PromoCurrenciesController', ['root', 'admin']);
    $this->createPermission('PromoCurrenciesView', 'Просмотр валюты', 'PromoCurrenciesController', ['root', 'admin']);
    $this->createPermission('PromoCurrenciesViewModal', 'Просмотр валюты модалка', 'PromoCurrenciesController', ['root', 'admin']);

    $this->removePermission('CurrencyDefaultUpdateModal');
    $this->removePermission('CurrencyDefaultIndex');
    $this->removePermission('CurrencyDefaultController');
    $this->removePermission('CurrencyModule');

    $this->delete('modules', ['module_id' => 'currency']);
  }
}
