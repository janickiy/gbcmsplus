<?php

use console\components\Migration;

class m180329_092702_remove_investors extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->removePermission('PartnersStatisticIndexNew');
  }

  public function down()
  {

  }
}
