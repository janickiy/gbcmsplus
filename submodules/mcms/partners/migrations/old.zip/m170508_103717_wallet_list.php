<?php

use console\components\Migration;

class m170508_103717_wallet_list extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('PartnersPaymentsWalletsList', 'Получение списка кошельков для ПС', 'PartnersPaymentsController', ['partner']);
  }

  public function down()
  {
    $this->removePermission('PartnersPaymentsWalletsList');
  }
}
