<?php

use admin\migrations\dbfix\SettingsTransferTrait;
use console\components\Migration;

class m160208_214716_new_settings extends Migration
{
  use SettingsTransferTrait;

  const SETTINGS_TEMPLATE = 'settings.template';

  const SETTINGS_FOOTER_MAIN_QUESTION_SKYPE = 'settings.footer.main_questions_skype';
  const SETTINGS_FOOTER_MAIN_QUESTION_EMAIL = 'settings.footer.main_questions_email';
  const SETTINGS_FOOTER_MAIN_QUESTION_ICQ = 'settings.footer.main_questions_icq';
  const SETTINGS_FOOTER_MAIN_QUESTION_TELEGRAM = 'settings.footer.main_questions_telegram';
  const SETTINGS_FOOTER_TECH_SUPPORT_SKYPE = 'settings.footer.tech_support_skype';
  const SETTINGS_FOOTER_TECH_SUPPORT_EMAIL = 'settings.footer.tech_support_email';
  const SETTINGS_FOOTER_TECH_SUPPORT_ICQ = 'settings.footer.tech_support_icq';
  const SETTINGS_FOOTER_TECH_SUPPORT_TELEGRAM = 'settings.footer.tech_support_telegram';
  const SETTINGS_FOOTER_COPYRIGHT = 'settings.footer.copyright';
  const SETTINGS_TITLE_TEMPLATE = 'settings.title_template';
  const SETTINGS_LOGO_IMAGE = 'settings.logo_image';
  const SETTINGS_ADMIN_PANEL_LOGO_IMAGE = 'settings.admin_panel_logo_image';
  const SETTINGS_LOGO_PUBLICATION = 'settings.logo_public';
  const SETTINGS_FAVICON = 'settings.favicon';
  const SETTINGS_DEFAULT_STREAM = 'settings.default_stream';
  const SETTINGS_MAX_NUMBER_OF_MONTH = 'settings.max_number_of_month';
  const SETTINGS_META_DESCRIPTION = 'settings.meta_description';
  const SETTINGS_META_KEYWORDS = 'settings.meta_keywords';
  const SETTINGS_LOGO_EMAIL_IMAGE = 'settings.logo_email_image';
  const SETTINGS_COLOR_THEME = 'settings.color_theme';
  const SETTINGS_SERVER_NAME = 'settings.server_name';
  const SETTINGS_PROJECT_NAME = 'settings.project_name';
  const SETTINGS_GOOGLE_ANALYTICS_SCRIPT = 'settings.google_analytics_script';
  const SETTINGS_YANDEX_METRIKA_SCRIPT = 'settings.yandex_metrika_script';
  const SETTINGS_ROBOTS_TXT = 'settings.robots_txt';
  const SETTINGS_EMAIL_TEMPLATE = 'settings.email_template';
  const SETTINGS_PROMO_URL_HTML = 'settings.promo_url_html';
  const SETTINGS_PROMO_URL_ENABLED = 'settings.promo_url_html_enabled';
  const SETTINGS_PROMO_MODAL_ENABLED = 'settings.promo_modal_enabled';
  const SETTINGS_PROMO_MODAL_HEADER_EN = 'settings.promo_modal_header_en';
  const SETTINGS_PROMO_MODAL_HEADER_RU = 'settings.promo_modal_header_ru';
  const SETTINGS_PROMO_MODAL_BODY_EN = 'settings.promo_modal_body_en';
  const SETTINGS_PROMO_MODAL_BODY_RU = 'settings.promo_modal_body_ru';
  const SETTINGS_PROMO_MODAL_SHOW_ONETIME = 'settings_promo_modal_show_onetime';
  const SETTINGS_DISABLE_COLOR_THEME_CHOOSE = 'settings.disable_color_theme_choose';
  const SETTINGS_AUTO_SUBMIT = 'partners.auto_submit';
  const SETTINGS_SHOW_PERSONAL_MANAGER = 'settings.show_personal_manager';
  const PERMISSION_EDIT_MODULE_SETTINGS_PROMO_URL = 'EditModuleSettingsPromoUrl';
  const SETTINGS_ENABLE_ALIVE_SUBSCRIPTIONS = 'enable_alive_subscriptions';

  const MODULE_ID = 'partners';

  const SETTINGS_TABLE = 'rgk_settings';
  const PERMISSIONS_TABLE = 'rgk_settings_permissions';
  const OPTIONS_TABLE = 'rgk_settings_options';
  const VALUES_TABLE = 'rgk_settings_values';

  public function up()
  {
    $this->insertValues();
  }

  public function down()
  {

  }

  private function getRepository()
  {
    return (new admin\migrations\dbfix\Repository())
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setKey(self::SETTINGS_AUTO_SUBMIT)
          ->setName('partners.settings.setting_auto_submit')
          ->setValue(true)
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('partners.settings.enable_alive_subscriptions')
          ->setValue(true)
          ->setKey(self::SETTINGS_ENABLE_ALIVE_SUBSCRIPTIONS)
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.project_name')
          ->setKey(self::SETTINGS_PROJECT_NAME)
          ->setValue('projectname')
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.base_site_url')
          ->setKey(self::SETTINGS_SERVER_NAME)
          ->setValue('http://projectname.com')
          ->setHint('partners.settings.base_site_url-hint')
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.title_template')
          ->setKey(self::SETTINGS_TITLE_TEMPLATE)
          ->setValue('{pageTitle}')
          ->setHint('partners.settings.title_template-hint')
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.footer-main_questions-skype')
          ->setKey(self::SETTINGS_FOOTER_MAIN_QUESTION_SKYPE)
          ->setValue('main_question_skype')
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setFormGroup(['name' => 'app.common.form_group_contacts', 'sort' => 2])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.footer-main_questions-email')
          ->setKey(self::SETTINGS_FOOTER_MAIN_QUESTION_EMAIL)
          ->setValue('main_question@email.ru')
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setFormGroup(['name' => 'app.common.form_group_contacts', 'sort' => 2])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.footer-main_questions-icq')
          ->setKey(self::SETTINGS_FOOTER_MAIN_QUESTION_ICQ)
          ->setValue('543-123')
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setFormGroup(['name' => 'app.common.form_group_contacts', 'sort' => 2])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.footer-main_questions-telegram')
          ->setKey(self::SETTINGS_FOOTER_MAIN_QUESTION_TELEGRAM)
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setFormGroup(['name' => 'app.common.form_group_contacts', 'sort' => 2])
          ->setSort(4)

      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.footer-tech_support-skype')
          ->setKey(self::SETTINGS_FOOTER_TECH_SUPPORT_SKYPE)
          ->setValue('tech_support_skype')
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setFormGroup(['name' => 'app.common.form_group_contacts', 'sort' => 2])
          ->setSort(5)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.footer-tech_support-email')
          ->setKey(self::SETTINGS_FOOTER_TECH_SUPPORT_EMAIL)
          ->setValue('tech_support@email.ru')
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setFormGroup(['name' => 'app.common.form_group_contacts', 'sort' => 2])
          ->setSort(6)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.footer-tech_support-icq')
          ->setKey(self::SETTINGS_FOOTER_TECH_SUPPORT_ICQ)
          ->setValue('543-123')
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setFormGroup(['name' => 'app.common.form_group_contacts', 'sort' => 2])
          ->setSort(7)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.footer-tech_support-telegram')
          ->setKey(self::SETTINGS_FOOTER_TECH_SUPPORT_TELEGRAM)
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setFormGroup(['name' => 'app.common.form_group_contacts', 'sort' => 2])
          ->setSort(8)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.footer-copyright')
          ->setKey(self::SETTINGS_FOOTER_COPYRIGHT)
          ->setValue('copyright.ru')
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setSort(4)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.default_stream')
          ->setKey(self::SETTINGS_DEFAULT_STREAM)
          ->setValue('Default')
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\Integer())
          ->setName('partners.settings.max_number_of_month')
          ->setKey(self::SETTINGS_MAX_NUMBER_OF_MONTH)
          ->setValue(6)
          ->setGroup(['name' => 'app.common.group_statistic', 'sort' => 8])
          ->setSort(2)
      )->set(
        (new admin\migrations\dbfix\Boolean())
          ->setKey(self::SETTINGS_SHOW_PERSONAL_MANAGER)
          ->setName('partners.settings.show_personal_manager')
          ->setValue(false)
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\FileUpload('partners'))
          ->setName('partners.settings.logo_image')
          ->setKey(self::SETTINGS_LOGO_IMAGE)
          ->setImageValidation([
            'extensions'    => ['jpeg', 'jpg', 'png', 'gif', 'svg'],
          ])
          ->setUploadDir('@uploadPath/{moduleId}/{attributeName}')
          ->setUploadUrl('@uploadUrl/{moduleId}/{attributeName}')
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
          ->setFormGroup(['name' => 'app.common.form_group_pp_styles', 'sort' => 1])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\FileUpload('partners'))
          ->setName('partners.settings.admin_panel_logo_image')
          ->setKey(self::SETTINGS_ADMIN_PANEL_LOGO_IMAGE)
          ->setImageValidation([
            'extensions'    => ['jpeg', 'jpg', 'png', 'gif', 'svg'],
          ])
          ->setUploadDir('@uploadPath/{moduleId}/{attributeName}')
          ->setUploadUrl('@uploadUrl/{moduleId}/{attributeName}')
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setSort(5)
      )
      ->set(
        (new admin\migrations\dbfix\FileUpload('partners'))
          ->setName('partners.settings.favicon')
          ->setKey(self::SETTINGS_FAVICON)
          ->setImageValidation([
            'extensions'    => ['ico', 'png'],
          ])
          ->setUploadDir('@uploadPath/{moduleId}/{attributeName}')
          ->setUploadUrl('@uploadUrl/{moduleId}/{attributeName}')
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setFormGroup(['name' => 'app.common.form_group_lp_parameters', 'sort' => 1])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\FileUpload('partners'))
          ->setName('partners.settings.logo_email_image')
          ->setKey(self::SETTINGS_LOGO_EMAIL_IMAGE)
          ->setImageValidation([
            'extensions'    => ['jpeg', 'jpg', 'png'],
          ])
          ->setUploadDir('@uploadPath/{moduleId}/{attributeName}')
          ->setUploadUrl('@uploadUrl/{moduleId}/{attributeName}')
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
          ->setFormGroup(['name' => 'app.common.form_group_pp_styles', 'sort' => 1])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('partners.settings.disable_color_theme_choose')
          ->setKey(self::SETTINGS_DISABLE_COLOR_THEME_CHOOSE)
          ->setValue(false)
          ->setHint('partners.settings.disable_color_theme_choose-hint')
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
          ->setFormGroup(['name' => 'app.common.form_group_pp_styles', 'sort' => 1])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\Lists())
          ->setName('partners.settings.color_theme')
          ->setKey(self::SETTINGS_COLOR_THEME)
          ->setOptions([
            'cerulean' => 'partners.profile.cerulean',
            'blue' => 'partners.profile.blue',
            'amethyst' => 'partners.profile.amethyst',
            'alizarin' => 'partners.profile.alizarin',
            'orange' => 'partners.profile.orange',
            'green' => 'partners.profile.green',
            'grey' => 'partners.profile.grey',
          ])
          ->setValue('cerulean')
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
          ->setFormGroup(['name' => 'app.common.form_group_pp_styles', 'sort' => 1])
          ->setSort(4)
      )
      ->set(
        (new admin\migrations\dbfix\FileUpload('partners'))
          ->setName('partners.settings.logo_publication')
          ->setKey(self::SETTINGS_LOGO_PUBLICATION)
          ->setImageValidation([
            'extensions'    => ['jpeg', 'jpg', 'png', 'gif', 'svg'],
          ])
          ->setUploadDir('@uploadPath/{moduleId}/{attributeName}')
          ->setUploadUrl('@uploadUrl/{moduleId}/{attributeName}')
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setFormGroup(['name' => 'app.common.form_group_lp_parameters', 'sort' => 1])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\Text())
          ->setName('partners.settings.google_analytics_script')
          ->setKey(self::SETTINGS_GOOGLE_ANALYTICS_SCRIPT)
          ->setValue('')
          ->setHint('partners.settings.google_analytics_script-hint')
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setFormGroup(['name' => 'app.common.form_group_lp_parameters', 'sort' => 1])
          ->setSort(4)
      )
      ->set(
        (new admin\migrations\dbfix\Text())
          ->setName('partners.settings.yandex_metrika_script')
          ->setKey(self::SETTINGS_YANDEX_METRIKA_SCRIPT)
          ->setValue('')
          ->setHint('partners.settings.yandex_metrika_script-hint')
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setFormGroup(['name' => 'app.common.form_group_lp_parameters', 'sort' => 1])
          ->setSort(5)
      )
      ->set(
        (new admin\migrations\dbfix\Text())
          ->setName('partners.settings.robots_txt')
          ->setKey(self::SETTINGS_ROBOTS_TXT)
          ->setValue(
            file_exists(Yii::getAlias('@rootPath') . '/web/robots.txt')
              ? file_get_contents(Yii::getAlias('@rootPath') . '/web/robots.txt')
              : ''
          )
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_project', 'sort' => 4])
          ->setFormGroup(['name' => 'app.common.form_group_lp_parameters', 'sort' => 1])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('partners.settings.promo_url_html_enabled')
          ->setKey(self::SETTINGS_PROMO_URL_ENABLED)
          ->setValue(false)
          ->setPermissions([self::PERMISSION_EDIT_MODULE_SETTINGS_PROMO_URL])
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
          ->setFormGroup(['name' => 'app.common.form_group_promo_link', 'sort' => 3])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\Text())
          ->setName('partners.settings.promo_url_html')
          ->setKey(self::SETTINGS_PROMO_URL_HTML)
          ->setValue('')
          ->setValidators([['string']])
          ->setPermissions([self::PERMISSION_EDIT_MODULE_SETTINGS_PROMO_URL])
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
          ->setFormGroup(['name' => 'app.common.form_group_promo_link', 'sort' => 3])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('partners.settings.promo_modal_enabled')
          ->setKey(self::SETTINGS_PROMO_MODAL_ENABLED)
          ->setValue(false)
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
          ->setFormGroup(['name' => 'app.common.form_group_promo_modal', 'sort' => 2])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.promo_modal_header_en')
          ->setKey(self::SETTINGS_PROMO_MODAL_HEADER_EN)
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
          ->setFormGroup(['name' => 'app.common.form_group_promo_modal', 'sort' => 2])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('partners.settings.promo_modal_header_ru')
          ->setKey(self::SETTINGS_PROMO_MODAL_HEADER_RU)
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
          ->setFormGroup(['name' => 'app.common.form_group_promo_modal', 'sort' => 2])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\Text())
          ->setName('partners.settings.promo_modal_body_en')
          ->setKey(self::SETTINGS_PROMO_MODAL_BODY_EN)
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
          ->setFormGroup(['name' => 'app.common.form_group_promo_modal', 'sort' => 2])
          ->setSort(4)
      )
      ->set(
        (new admin\migrations\dbfix\Text())
          ->setName('partners.settings.promo_modal_body_ru')
          ->setKey(self::SETTINGS_PROMO_MODAL_BODY_RU)
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_partners', 'sort' => 5])
          ->setFormGroup(['name' => 'app.common.form_group_promo_modal', 'sort' => 2])
          ->setSort(5)
      );
  }
}
