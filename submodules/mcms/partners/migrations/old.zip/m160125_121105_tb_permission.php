<?php

use yii\db\Schema;
use console\components\Migration;

class m160125_121105_tb_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'Statistic' => [
        ['tb', 'Can view tb statistic', ['partner']],
      ],
    ];
  }
}
