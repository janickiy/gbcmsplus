<?php

use yii\db\Schema;
use console\components\Migration;
use mcms\partners\Module;

class m160226_081744_partners_settins_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;


  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
      $this->createOrGetPermission('CanResellerEditSettingsPartners', 'Can reseller edit settings');
      $this->assignRolesPermission('CanResellerEditSettingsPartners', ['reseller']);
  }

  public function down()
  {
    $this->removePermission('CanResellerEditSettingsPartners');
  }
}
