<?php

use console\components\Migration;

class m170209_080751_perm_wallet extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('PartnersPaymentsWalletForm', 'Редактирование кошелька', 'PartnersPaymentsController', ['partner']);
    $this->removePermission('PartnersProfileFinance');
    $this->createPermission('PartnersPaymentsUploadWalletFiles', 'Загрузка файлов для кошельков', 'PartnersPaymentsController', ['partner']);
    $this->createPermission('PartnersPaymentsDeleteWalletFiles', 'Удаление файлов для кошельков', 'PartnersPaymentsController', ['partner']);
  }

  public function down()
  {
    $this->createPermission('PartnersProfileFinance', 'Просмотр финансовых настроек в профиле партнера', 'PartnersPaymentsController', ['partner']);
    $this->removePermission('PartnersPaymentsWalletForm');
    $this->removePermission('PartnersPaymentsUploadWalletFiles');
    $this->removePermission('PartnersPaymentsDeleteWalletFiles');
  }
}
