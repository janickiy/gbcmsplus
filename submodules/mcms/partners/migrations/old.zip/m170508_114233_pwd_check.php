<?php

use console\components\Migration;

class m170508_114233_pwd_check extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('PartnersPaymentsPasswordCheck', 'Проверка пароля для изменения настроек кошельков', 'PartnersPaymentsController', ['partner']);
  }

  public function down()
  {
    $this->removePermission('PartnersPaymentsPasswordCheck');
  }
}
