<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m170120_084239_votes extends Migration
{
  use PermissionMigration;

  public function up()
    {
      $this->createPermission('PartnersVotesController', 'Контроллер Votes', 'PartnersModule');
      $this->createPermission('PartnersVotesVote', 'Отдать голос', 'PartnersVotesController', ['partner']);
    }

    public function down()
    {
      $this->removePermission('PartnersVotesController');
      $this->removePermission('PartnersVotesVote');
    }
}
