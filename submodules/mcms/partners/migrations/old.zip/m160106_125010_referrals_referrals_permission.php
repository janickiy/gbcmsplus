<?php

use console\components\Migration;

class m160106_125010_referrals_referrals_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'Referrals' => [
        ['referrals', 'View referrals grouped data', [
            'root', 'admin', 'partner'
          ]
        ],
      ],
    ];
  }
}