<?php

use console\components\Migration;

/**
 * Class m171102_143224_cheque_download
 */
class m171102_143224_cheque_download extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  /**
   *
   */
  public function up()
  {
    $this->createPermission(
      'PartnersPaymentsDownloadCheque',
      'Скачивание квитанции выплаты в ПП',
      'PartnersPaymentsController',
      ['partner']
    );
    $this->createPermission(
      'PartnersPaymentsDownloadInvoice',
      'Скачивание акта выплаты в ПП',
      'PartnersPaymentsController',
      ['partner']
    );
    $this->revokeRolesPermission('PaymentsPaymentsDownloadCheque', ['partner']);
    $this->revokeRolesPermission('PaymentsPaymentsDownloadInvoice', ['partner']);
  }

  /**
   */
  public function down()
  {
    $this->removePermission('PartnersPaymentsDownloadCheque');
    $this->removePermission('PartnersPaymentsDownloadInvoice');
    $this->assignRolesPermission('PaymentsPaymentsDownloadCheque', ['partner']);
    $this->assignRolesPermission('PaymentsPaymentsDownloadInvoice', ['partner']);
  }
}
