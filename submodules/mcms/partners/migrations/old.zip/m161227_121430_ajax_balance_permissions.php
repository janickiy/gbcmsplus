<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m161227_121430_ajax_balance_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission(
      'PartnersStatisticGetBalance',
      'Получение баланса партнера',
      'PartnersStatisticController',
      ['partner']
    );
  }

  public function down()
  {
    $this->removePermission('PartnersStatisticGetBalance');
  }
}
