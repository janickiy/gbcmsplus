<?php

use yii\db\Schema;
use console\components\Migration;

class m160205_104600_support_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'Support' => [
        ['read', 'Can set ticket as read', ['partner']],
      ],
    ];
  }
}
