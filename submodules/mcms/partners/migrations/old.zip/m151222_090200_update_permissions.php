<?php

use console\components\Migration;

class m151222_090200_update_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'Support' => [
        ['close', 'Can close ticket', ['partner'],
          [
            'SupportOwnTicketRule' => \mcms\support\components\rbac\OwnTicketRule::className(),
          ]
        ],
      ],      
    ];
  }
}
