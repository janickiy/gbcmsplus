<?php

use yii\db\Schema;
use console\components\Migration;

class m160128_185513_promo_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'Promo' => [
        ['index', 'Can view promo index page', ['partner']],
      ],
    ];
  }

}
