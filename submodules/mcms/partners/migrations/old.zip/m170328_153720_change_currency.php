<?php

use console\components\Migration;

class m170328_153720_change_currency extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('PartnersPaymentsChangeCurrency', 'Модалка смены валюты', 'PartnersPaymentsController', ['partner']);
  }

  public function down()
  {
    $this->removePermission('PartnersPaymentsChangeCurrency');
  }
}
