<?php

use console\components\Migration;

class m160407_114141_update_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'Links' => [
        ['landing-statuses', 'Can view landing statuses', ['partner']],
      ],
    ];
  }
}
