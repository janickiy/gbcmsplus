<?php

use yii\db\Schema;
use console\components\Migration;

class m160210_102242_refactor extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;

    $this->moduleName = 'Partners';
    $this->permissions = [
      'Payments' => [
        ['requestEarlyPayment', 'Can require early payment', ['admin', 'root', 'partner']],
      ]
    ];
  }

}
