<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170912_125459_postback_settings extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PartnersProfilePostbackSettings', 'Настройки постбека', 'PartnersProfileController', ['partner']);
    $this->createPermission('PartnersProfilePostbackUrlSpread', 'Использовать глобальный постбек URL во всех источниках', 'PartnersProfileController', ['partner']);

    $this->addColumn('user_promo_settings', 'postback_url', 'VARCHAR(512) NULL DEFAULT NULL');
    $this->addColumn('sources', 'use_global_postback_url', 'TINYINT(1) NOT NULL DEFAULT 0 AFTER postback_url');
  }

  public function down()
  {
    $this->removePermission('PartnersProfilePostbackSettings');
    $this->removePermission('PartnersProfilePostbackUrlSpread');

    $this->dropColumn('user_promo_settings', 'postback_url');
    $this->dropColumn('sources', 'use_global_postback_url');
  }
}
