<?php

use console\components\Migration;

class m160318_134259_update_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'Links' => [
        ['test-postback-url', 'Can test postback url', ['partner']],
      ],
    ];
  }
}
