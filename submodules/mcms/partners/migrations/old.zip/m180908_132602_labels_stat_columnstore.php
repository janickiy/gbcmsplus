<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
*/
class m180908_132602_labels_stat_columnstore extends Migration
{
  use PermissionTrait;
  /**
  */
  public function up()
  {
    $this->createPermission('PartnersStatisticLabelTmp', 'временное решение', 'PartnersStatisticController', ['partner']);
  }

  /**
  */
  public function down()
  {
    $this->removePermission('PartnersStatisticLabelTmp');
  }
}
