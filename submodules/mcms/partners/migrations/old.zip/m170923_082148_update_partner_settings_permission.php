<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170923_082148_update_partner_settings_permission extends Migration
{
  use PermissionTrait;
  
  public function up()
  {
    $this->createPermission(
      'PartnersProfileUpdatePartnerPaymentsSettings',
      'Обновление настроек выплат',
      'PartnersProfileController',
      ['partner']
    );
  }
  
  public function down()
  {
    $this->removePermission('PartnersProfileUpdatePartnerPaymentsSettings');
  }
}
