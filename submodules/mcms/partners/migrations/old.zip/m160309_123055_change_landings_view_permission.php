<?php

use console\components\Migration;

class m160309_123055_change_landings_view_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'Links' => [
        ['change-landings-view', 'Can change landings grid view', ['partner']],
      ],
    ];
  }
}
