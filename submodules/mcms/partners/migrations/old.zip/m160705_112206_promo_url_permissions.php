<?php

use console\components\Migration;

class m160705_112206_promo_url_permissions extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->createOrGetPermission('EditModuleSettingsPromoUrl', 'Can user edit promo url settings');
    $this->assignRolesPermission('EditModuleSettingsPromoUrl', ['admin', 'root']);
  }

  public function down()
  {
   $this->revokeRolesPermission('EditModuleSettingsPromoUrl', ['admin', 'root']);
   $this->removePermission('EditModuleSettingsPromoUrl');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
