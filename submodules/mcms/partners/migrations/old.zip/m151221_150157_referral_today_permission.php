<?php

use console\components\Migration;

class m151221_150157_referral_today_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'Referrals' => [
        ['today', 'View referrals today statistic', [
            'root', 'admin', 'partner'
          ]
        ],
      ],
    ];
  }
}