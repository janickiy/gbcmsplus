<?php

use console\components\Migration;

class m151130_074610_init_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'Default' => [
        ['profile', 'Can view profile', ['admin', 'root', 'partner']],
        ['password', 'Can change password', ['admin', 'root', 'partner']],
      ],
      'Links' => [
        ['index', 'Can view list links', ['admin', 'root', 'partner']],
        ['add', 'Can add link', ['admin', 'root', 'partner']],
        ['landingList', 'Can view landing list', ['admin', 'root', 'partner']],
        ['formHandle', 'Can link form handle', ['admin', 'root', 'partner']],
        ['landingRequest', 'Can landing request', ['admin', 'root', 'partner']],
        ['getLink', 'Can get link', ['admin', 'root', 'partner']],
        ['delete', 'Can delete link', ['admin', 'root', 'partner']],
      ],
      'Sources' => [
        ['index', 'Can view list sources', ['admin', 'root', 'partner']],
        ['add', 'Can add source', ['admin', 'root', 'partner']],
        ['formHandle', 'Can form handle', ['admin', 'root', 'partner']],
        ['delete', 'Can delete', ['admin', 'root', 'partner']],
        ['code', 'Can get code', ['admin', 'root', 'partner']],
        ['settings', 'Can get settings', ['admin', 'root', 'partner']],
        ['edit', 'Can edit source', ['admin', 'root', 'partner']],
      ],
      'Notification' => [
        ['index', 'Can view list notification', ['admin', 'root', 'partner']],
        ['clear', 'Can clear notifications', ['admin', 'root', 'partner']],
        ['getList', 'Can get notification list', ['admin', 'root', 'partner']],
      ],
      'Support' => [
        ['index', 'Can view list tickets', ['admin', 'root', 'partner']],
        ['close', 'Can close ticket', ['admin', 'root', 'partner']],
        ['create', 'Can create ticket', ['admin', 'root', 'partner']],
        ['sendMessage', 'Can send message', ['admin', 'root', 'partner']],
        ['uploadFile', 'Can upload file', ['admin', 'root', 'partner']],
        ['deleteFile', 'Can delete file', ['admin', 'root', 'partner']],
      ],
      'Payments' => [
        ['balance', 'Can view balance', ['admin', 'root', 'partner']],
        ['payments', 'Can view payments', ['admin', 'root', 'partner']],
      ]
    ];
  }

}
