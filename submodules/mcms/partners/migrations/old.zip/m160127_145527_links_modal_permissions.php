<?php

use yii\db\Schema;
use console\components\Migration;

class m160127_145527_links_modal_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'Links' => [
        ['landingModal', 'Can get modal windows for landings', ['partner']],
        ['requestModal', 'Can get modal windows for requests', ['partner']],
      ],
    ];
  }
}
