<?php

use yii\db\Schema;
use console\components\Migration;

class m160129_121622_notification_add_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Partners';
    $this->permissions = [
      'Notification' => [
        ['readAll', 'Can read all browser notifications', ['admin', 'root', 'partner']],
      ],
    ];
  }


}
