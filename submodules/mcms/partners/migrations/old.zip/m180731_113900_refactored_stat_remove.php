<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
*/
class m180731_113900_refactored_stat_remove extends Migration
{
  use PermissionTrait;

  /**
  */
  public function up()
  {
    $this->removePermission('PartnersStatisticRefactor');
  }

  /**
  */
  public function down()
  {
    $this->createPermission('PartnersStatisticRefactor', 'временное решение', 'PartnersStatisticController', ['partner']);
  }
}
