<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170420_071038_enable_convert_balance_permission extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission(
      'PartnersPaymentsConvertBalance',
      'Конвертация баланса при смене валюты',
      'PartnersPaymentsController',
      ['partner']
    );
  }

  public function down()
  {
    $this->removePermission('PartnersPaymentsConvertBalance');

  }
}
