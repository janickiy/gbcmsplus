<?php

use console\components\Migration;

class m170507_125932_rm_alive_subs extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->removePermission('PartnersStatisticGetPartnersAliveSubscriptions');
  }

  public function down()
  {
    $this->createPermission('PartnersStatisticGetPartnersAliveSubscriptions', 'Получение живых подписок', 'PartnersStatisticController', ['partner']);
  }
}
