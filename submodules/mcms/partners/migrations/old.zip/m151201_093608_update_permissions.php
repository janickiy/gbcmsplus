<?php

use console\components\Migration;

class m151201_093608_update_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;

    $this->moduleName = 'Partners';
    $this->permissions = [
      'Statistic' => [
        ['index', 'Can view main statistic', ['partner', 'investor', 'admin', 'root']]
      ]
    ];
  }


}
