<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170816_165042_add_export_postbakcs_permission extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission(
      'PartnersLinksExportPostbacks',
      'Экспорт постбеков по потоку',
      'PartnersLinksController',
      ['partner']
    );
  }

  public function down()
  {
    $this->removePermission('PartnersLinksExportPostbacks');
  }
}
