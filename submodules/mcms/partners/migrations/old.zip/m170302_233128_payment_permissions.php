<?php

use console\components\Migration;

class m170302_233128_payment_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('PartnersPaymentsDeleteWallet', 'Удаление кошелька', 'PartnersPaymentsController', ['partner']);
  }

  public function down()
  {
    $this->removePermission('PartnersPaymentsDeleteWallet');
  }
}
