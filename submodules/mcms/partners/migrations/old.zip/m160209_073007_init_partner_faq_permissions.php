<?php

use yii\db\Schema;
use console\components\Migration;

class m160209_073007_init_partner_faq_permissions extends Migration
{
    use \mcms\common\traits\PermissionMigration;

    /**
     * @inheritDoc
     */
    public function init()
    {
        parent::init();
        $this->moduleName = 'Partners';
        $this->authManager = Yii::$app->getAuthManager();
        $this->permissions = [
          'Faq' => [
            ['index', 'Can view faq', ['partner']],
          ],
        ];
    }
}
