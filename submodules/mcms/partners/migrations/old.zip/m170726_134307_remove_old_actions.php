<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170726_134307_remove_old_actions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->removePermission('PartnersStatisticDetailIk');
    $this->removePermission('PartnersStatisticDetailInfoIk');
    $this->removePermission('PartnersStatisticDetailInfoSells');
    $this->removePermission('PartnersStatisticDetailInfoSubscriptions');
    $this->removePermission('PartnersStatisticDetailSells');
    $this->removePermission('PartnersStatisticDetailSubscriptions');
  }

  public function down()
  {
    $this->createPermission('PartnersStatisticDetailIk', 'Просмотр детальной статистики по IK', 'PartnersStatisticController', ['partner']);
    $this->createPermission('PartnersStatisticDetailInfoIk', 'Просмотр детальной информации по IK', 'PartnersStatisticController', ['partner']);
    $this->createPermission('PartnersStatisticDetailInfoSells', 'Просмотр детальной информации по продажам', 'PartnersStatisticController', ['partner']);
    $this->createPermission('PartnersStatisticDetailInfoSubscriptions', 'Просмотр детальной информации по подпискам', 'PartnersStatisticController', ['partner']);
    $this->createPermission('PartnersStatisticDetailSells', 'Просмотр детальной статистики по продажам', 'PartnersStatisticController', ['partner']);
    $this->createPermission('PartnersStatisticDetailSubscriptions', 'Просмотр детальной статистики по подпискам', 'PartnersStatisticController', ['partner']);
  }
}
