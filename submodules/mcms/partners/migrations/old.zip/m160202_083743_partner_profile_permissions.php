<?php

use yii\db\Schema;
use console\components\Migration;

class m160202_083743_partner_profile_permissions extends Migration
{
    use \mcms\common\traits\PermissionMigration;

    /**
     * @inheritDoc
     */
    public function init()
    {
        parent::init();
        $this->moduleName = 'Partners';
        $this->authManager = Yii::$app->getAuthManager();
        $this->permissions = [
          'Profile' => [
            ['index', 'Can view profile', ['partner']],
            ['finance', 'Can view finance settings in partners profile', ['partner']],
          ],
        ];
    }
}
