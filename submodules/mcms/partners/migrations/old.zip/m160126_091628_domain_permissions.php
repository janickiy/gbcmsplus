<?php

use yii\db\Schema;
use console\components\Migration;

class m160126_091628_domain_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'Domains' => [
        ['index', 'Can view domains', ['partner']],
        ['add', 'Can add domains', ['partner']],
      ],
    ];
  }
}
