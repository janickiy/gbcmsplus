<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170510_135958_enable_settings_wallet_types_action extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission(
      'PartnersPaymentsSettingsWalletTypes',
      'Подгрузка платежных систем, в зависимости от выбранной валюты',
      'PartnersPaymentsController',
      ['partner']
    );
  }

  public function down()
  {
    $this->removePermission('PartnersPaymentsSettingsWalletTypes');

  }
}
