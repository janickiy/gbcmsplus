<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m180716_102459_refactored_stat extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PartnersStatisticRefactor', 'временное решение', 'PartnersStatisticController', ['partner']);
  }

  public function down()
  {
    $this->removePermission('PartnersStatisticRefactor');
  }

}
