<?php

use console\components\Migration;

class m151202_033710_init_payments_migrations extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;

    $this->moduleName = 'Partners';
    $this->permissions = [
      'Payments' => [
        ['requireEarlyPayment', 'Can require early payment', ['admin', 'root', 'partner']],
        ['settings', 'Can edit payment settings', ['admin', 'root', 'partner']],
      ]
    ];
  }
}
