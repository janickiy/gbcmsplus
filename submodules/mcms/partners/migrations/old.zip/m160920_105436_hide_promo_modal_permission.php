<?php

use console\components\Migration;

class m160920_105436_hide_promo_modal_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'Default' => [
        ['hide-promo-modal', 'Can hide promo modal', ['partner']],
      ],
    ];
  }
}
