<?php

use console\components\Migration;

/**
 */
class m180327_151134_new_stat_model extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  /**
   */
  public function up()
  {
    $this->createPermission('PartnersStatisticIndexNew', 'Тест новой статы партнеру', 'PartnersStatisticController', ['partner']);
  }

  /**
   */
  public function down()
  {
    $this->removePermission('PartnersStatisticIndexNew');
  }

}
