<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

class m171102_132147_view_complains_action_permission extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PartnersStatisticComplains', 'Просмотр статистики по жалобам', 'PartnersStatisticController', ['partner']);
  }

  public function down()
  {
    $this->removePermission('PartnersStatisticComplains');
  }
}
