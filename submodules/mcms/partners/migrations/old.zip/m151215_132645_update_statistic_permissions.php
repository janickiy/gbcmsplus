<?php

use console\components\Migration;

class m151215_132645_update_statistic_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'Statistic' => [
        ['detailSubscriptions', 'View detail subscriptions statistic', [
          'root', 'admin', 'reseller', 'partner', 'investor'
        ]],
        ['detailIk', 'View detail ik statistic', [
          'root', 'admin', 'reseller', 'partner', 'investor'
        ]],
        ['detailSells', 'View detail sells statistic', [
          'root', 'admin', 'reseller', 'partner', 'investor'
        ]],
        ['detailInfoSubscriptions', 'View detail subscriptions info', ['root', 'admin', 'reseller']],
        ['detailInfoIk', 'View detail ik info', ['root', 'admin', 'reseller']],
        ['detailInfoSells', 'View detail sells info', ['root', 'admin', 'reseller']],
      ],
    ];
  }
}
