<?php

use rgk\settings\models\Setting;
use console\components\Migration;

class m180413_121036_remove_avatar extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->removePermission('PartnersProfileUpload');
    $this->removePermission('UsersUsersUpload');

    Yii::$app->settingsBuilder->removeSetting('partner_default_avatar');
    Yii::$app->settingsBuilder->removeSetting('support_default_avatar');

    $this->dropColumn('user_params', 'avatar');
  }

  public function down()
  {
    $this->createPermission('PartnersProfileUpload', 'Загрузка аватара', 'PartnersProfileController', ['partner']);
    $this->createPermission('UsersUsersUpload', 'Загрузка аватара', 'PartnersProfileController', ['root', 'admin', 'manager', 'reseller']);

    Yii::$app->settingsBuilder->createSetting(
      ['ru' => 'Аватар пользователя по-умолчанию', 'en' => 'User default avatar'],
      [
        'ru' => '<div><a href="/img/avatar.png" target="_blank" data-pjax="0">View default file</a></div>',
        'en' => '<div><a href="/img/avatar.png" target="_blank" data-pjax="0">View default file</a></div>'
      ],
      'partner_default_avatar',
      ['EditModuleSettingsUsers'],
      Setting::TYPE_FILE,
      'app.common.form_group_avatars',
      '/img/avatar.png',
      [['file', ['extensions' => ['jpeg', 'jpg', 'png', 'gif']]]]
    );
    Yii::$app->settingsBuilder->createSetting(
      ['ru' => 'Аватар саппорта по-умолчанию', 'en' => 'Support default avatar'],
      [
        'ru' => '<div><a href="/img/support.png" target="_blank" data-pjax="0">View default file</a></div>',
        'en' => '<div><a href="/img/support.png" target="_blank" data-pjax="0">View default file</a></div>'
      ],
      'support_default_avatar',
      ['EditModuleSettingsUsers'],
      Setting::TYPE_FILE,
      'app.common.form_group_avatars',
      '/img/support.png',
      [['file', ['extensions' => ['jpeg', 'jpg', 'png', 'gif']]]]
    );

    $this->addColumn('user_params', 'avatar', 'VARCHAR(255)');
  }
}
