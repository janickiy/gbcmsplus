<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m171009_080906_link_add_steps_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission(
      'PartnersLinksAddStep1',
      'Первый шаг создания ссылки',
      'PartnersLinksAdd',
      ['partner']
    );

    $this->createPermission(
      'PartnersLinksAddStep2',
      'Второй шаг создания ссылки',
      'PartnersLinksAdd',
      ['partner']
    );

    $this->createPermission(
      'PartnersLinksAddStep3',
      'Третий шаг создания ссылки',
      'PartnersLinksAdd',
      ['partner']
    );
  }

  public function down()
  {
    $this->removePermission('PartnersLinksAddStep1');
    $this->removePermission('PartnersLinksAddStep2');
    $this->removePermission('PartnersLinksAddStep3');
  }
}
