<?php

use console\components\Migration;

class m180515_132700_smart_links extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('PartnersSmartLinksController', 'Контроллер PartnersSmartLinks', 'PartnersModule');
    $this->createPermission('PartnersSmartLinksActivate', 'Активация смарт ссылок', 'PartnersSmartLinksController', ['partner']);
    $this->createPermission('PartnersSmartLinksUpdate', 'Редактирование смарт ссылок', 'PartnersSmartLinksController', ['partner']);

  }

  public function down()
  {
    $this->removePermission('PartnersSmartLinksActivate');
    $this->removePermission('PartnersSmartLinksController');
  }
}
