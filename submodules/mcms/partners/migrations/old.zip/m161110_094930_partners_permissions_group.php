<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

/**
 * Группировка прав модуля Партнеры
 */
class m161110_094930_partners_permissions_group extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('PartnersModule');

    // Разрешения
    $this->createPermission('PartnersPermissions', null, 'PartnersModule');

    // Контроллеры
    $this->createPermission('PartnersDefaultController', null, 'PartnersModule');
    $this->addChildPermission('PartnersDefaultController', 'PartnersDefaultHidePromoModal');
    $this->addChildPermission('PartnersDefaultController', 'PartnersDefaultPassword');
    $this->addChildPermission('PartnersDefaultController', 'PartnersDefaultProfile');

    $this->createPermission('PartnersDomainsController', null, 'PartnersModule');
    $this->addChildPermission('PartnersDomainsController', 'PartnersDomainsAdd');
    $this->addChildPermission('PartnersDomainsController', 'PartnersDomainsIndex');

    $this->createPermission('PartnersFaqController', null, 'PartnersModule');
    $this->addChildPermission('PartnersFaqController', 'PartnersFaqIndex');

    $this->createPermission('PartnersLinksController', null, 'PartnersModule');
    $this->addChildPermission('PartnersLinksController', 'PartnersLinksAdd');
    $this->addChildPermission('PartnersLinksController', 'PartnersLinksChangeLandingsView');
    $this->addChildPermission('PartnersLinksController', 'PartnersLinksCopy');
    $this->addChildPermission('PartnersLinksController', 'PartnersLinksDelete');
    $this->addChildPermission('PartnersLinksController', 'PartnersLinksFormHandle');
    $this->addChildPermission('PartnersLinksController', 'PartnersLinksGetLink');
    $this->addChildPermission('PartnersLinksController', 'PartnersLinksIndex');
    $this->addChildPermission('PartnersLinksController', 'PartnersLinksIpList');
    $this->addChildPermission('PartnersLinksController', 'PartnersLinksLandingList');
    $this->addChildPermission('PartnersLinksController', 'PartnersLinksLandingModal');
    $this->addChildPermission('PartnersLinksController', 'PartnersLinksLandingRequest');
    $this->addChildPermission('PartnersLinksController', 'PartnersLinksLandingStatuses');
    $this->addChildPermission('PartnersLinksController', 'PartnersLinksRequestModal');
    $this->addChildPermission('PartnersLinksController', 'PartnersLinksTestPostbackUrl');

    $this->createPermission('PartnersNotificationController', null, 'PartnersModule');
    $this->addChildPermission('PartnersNotificationController', 'PartnersNotificationClear');
    $this->addChildPermission('PartnersNotificationController', 'PartnersNotificationGetList');
    $this->addChildPermission('PartnersNotificationController', 'PartnersNotificationIndex');
    $this->addChildPermission('PartnersNotificationController', 'PartnersNotificationReadAll');

    $this->createPermission('PartnersPaymentsController', null, 'PartnersModule');
    $this->addChildPermission('PartnersPaymentsController', 'PartnersPaymentsBalance');
    $this->addChildPermission('PartnersPaymentsController', 'PartnersPaymentsDisableAutoPayments');
    $this->addChildPermission('PartnersPaymentsController', 'PartnersPaymentsEnableAutoPayments');
    $this->addChildPermission('PartnersPaymentsController', 'PartnersPaymentsPayments');
    $this->addChildPermission('PartnersPaymentsController', 'PartnersPaymentsRequestEarlyPayment');
    $this->addChildPermission('PartnersPaymentsController', 'PartnersPaymentsRequireEarlyPayment');
    $this->addChildPermission('PartnersPaymentsController', 'PartnersPaymentsSettings');

    $this->createPermission('PartnersProfileController', null, 'PartnersModule');
    $this->addChildPermission('PartnersProfileController', 'PartnersProfileFinance');
    $this->addChildPermission('PartnersProfileController', 'PartnersProfileIndex');
    $this->addChildPermission('PartnersProfileController', 'PartnersProfileNotifications');
    $this->addChildPermission('PartnersProfileController', 'PartnersProfileSaveNotificationsSettings');
    $this->addChildPermission('PartnersProfileController', 'PartnersProfileUpload');

    $this->createPermission('PartnersPromoController', null, 'PartnersModule');
    $this->addChildPermission('PartnersPromoController', 'PartnersPromoIndex');

    $this->createPermission('PartnersReferralsController', null, 'PartnersModule');
    $this->addChildPermission('PartnersReferralsController', 'PartnersReferralsIncome');
    $this->addChildPermission('PartnersReferralsController', 'PartnersReferralsReferrals');
    $this->addChildPermission('PartnersReferralsController', 'PartnersReferralsToday');

    $this->createPermission('PartnersSourcesController', null, 'PartnersModule');
    $this->addChildPermission('PartnersSourcesController', 'PartnersSourcesAdd');
    $this->addChildPermission('PartnersSourcesController', 'PartnersSourcesCode');
    $this->addChildPermission('PartnersSourcesController', 'PartnersSourcesDelete');
    $this->addChildPermission('PartnersSourcesController', 'PartnersSourcesEdit');
    $this->addChildPermission('PartnersSourcesController', 'PartnersSourcesFormHandle');
    $this->addChildPermission('PartnersSourcesController', 'PartnersSourcesIndex');
    $this->addChildPermission('PartnersSourcesController', 'PartnersSourcesSettings');

    $this->createPermission('PartnersStatisticController', null, 'PartnersModule');
    $this->addChildPermission('PartnersStatisticController', 'PartnersStatisticDetailIk');
    $this->addChildPermission('PartnersStatisticController', 'PartnersStatisticDetailInfoIk');
    $this->addChildPermission('PartnersStatisticController', 'PartnersStatisticDetailInfoSells');
    $this->addChildPermission('PartnersStatisticController', 'PartnersStatisticDetailInfoSubscriptions');
    $this->addChildPermission('PartnersStatisticController', 'PartnersStatisticDetailSells');
    $this->addChildPermission('PartnersStatisticController', 'PartnersStatisticDetailSubscriptions');
    $this->addChildPermission('PartnersStatisticController', 'PartnersStatisticHour');
    $this->addChildPermission('PartnersStatisticController', 'PartnersStatisticIndex');
    $this->addChildPermission('PartnersStatisticController', 'PartnersStatisticLabel');
    $this->addChildPermission('PartnersStatisticController', 'PartnersStatisticTb');

    $this->createPermission('PartnersSupportController', null, 'PartnersModule');
    $this->addChildPermission('PartnersSupportController', 'PartnersSupportClose');
    $this->addChildPermission('PartnersSupportController', 'PartnersSupportCreate');
    $this->addChildPermission('PartnersSupportController', 'PartnersSupportDeleteFile');
    $this->addChildPermission('PartnersSupportController', 'PartnersSupportIndex');
    $this->addChildPermission('PartnersSupportController', 'PartnersSupportMessages');
    $this->addChildPermission('PartnersSupportController', 'PartnersSupportRead');
    $this->addChildPermission('PartnersSupportController', 'PartnersSupportSendMessage');
    $this->addChildPermission('PartnersSupportController', 'PartnersSupportUploadFile');
  }

  public function down()
  {
    $this->removePermission('PartnersModule');
    $this->removePermission('PartnersPermissions');
    $this->removePermission('PartnersDefaultController');
    $this->removePermission('PartnersDomainsController');
    $this->removePermission('PartnersFaqController');
    $this->removePermission('PartnersLinksController');
    $this->removePermission('PartnersNotificationController');
    $this->removePermission('PartnersPaymentsController');
    $this->removePermission('PartnersProfileController');
    $this->removePermission('PartnersPromoController');
    $this->removePermission('PartnersReferralsController');
    $this->removePermission('PartnersSourcesController');
    $this->removePermission('PartnersStatisticController');
    $this->removePermission('PartnersSupportController');
  }
}
