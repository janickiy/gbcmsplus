<?php

use console\components\Migration;

class m151215_095439_update_statistic_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'Statistic' => [
        ['index', 'View main statistic by hour', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['hour', 'View main statistic by hour', [
          'admin',
          'partner',
          'reseller',
          'root',
          'investor',
        ]],
        ['detailSubscriptions', 'View detail subscriptions statistic', [
          'root', 'admin', 'reseller'
        ]],
        ['detailIk', 'View detail ik statistic', ['root', 'admin', 'reseller']],
        ['detailSells', 'View detail sells statistic', ['root', 'admin', 'reseller']],
        ['detailInfoSubscriptions', 'View detail subscriptions info', ['root', 'admin', 'reseller']],
        ['detailInfoIk', 'View detail ik info', ['root', 'admin', 'reseller']],
        ['detailInfoSells', 'View detail sells info', ['root', 'admin', 'reseller']],
      ]
    ];
  }


}
