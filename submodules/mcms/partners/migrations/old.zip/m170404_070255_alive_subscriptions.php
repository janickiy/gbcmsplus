<?php

use console\components\Migration;

class m170404_070255_alive_subscriptions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;
  public function up()
  {
    $this->createPermission('PartnersStatisticGetPartnersAliveSubscriptions', 'Получение живых подписок', 'PartnersStatisticController', ['partner']);
  }

  public function down()
  {
    $this->removePermission('PartnersStatisticGetPartnersAliveSubscriptions');
  }
}
