<?php

use console\components\Migration;

class m151210_084042_update_payments_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->getAuthManager();

    $this->permissions = [
      'Payments' => [
        ['balance', 'Can view balance', ['partner']],
        ['payments', 'Can view payments', ['partner']],
        ['requireEarlyPayment', 'Can require early payment', ['partner']],
        ['settings', 'Can edit payment settings', ['partner']],
      ]
    ];
  }
}
