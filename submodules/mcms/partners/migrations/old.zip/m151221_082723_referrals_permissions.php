<?php

use console\components\Migration;

class m151221_082723_referrals_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Partners';
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'Referrals' => [
        ['income', 'View referrals income', [
            'root', 'admin', 'partner'
          ]
        ],
      ],
    ];
  }
}