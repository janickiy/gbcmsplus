<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

/**
 * @class m161110_094940_partners_permissions_revoke
 */
class m161110_094940_partners_permissions_revoke extends Migration
{
  use PermissionMigration;

  /**
   * @inheritdoc
   */
  public function up()
  {
    $this->revokeRolesPermission('PartnersReferralsIncome', ['admin', 'root']);
  }

  /**
   * @inheritdoc
   */
  public function down()
  {
    $this->assignRolesPermission('PartnersReferralsIncome', ['admin', 'root']);
  }
}
