<?php

use console\components\Migration;

class m151123_153900_init_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Logs';
    $this->permissions = [
      'Default' => [
        ['index', 'List logs', ['admin', 'root']]
      ]
    ];
  }
}
