<?php

use console\components\Migration;

class m151007_123257_create_table extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable('logs', [
      'id'               => 'int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'label'            => $this->string(255)->notNull(),
      'data'             => $this->text(),
      'created_at'       => 'int(10) UNSIGNED NOT NULL',
      'sent_to_graphite' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);

    $this->createIndex('logs_label_index', 'logs', 'label');
    $this->createIndex('logs_sent_to_graphite_index', 'logs', 'sent_to_graphite');

  }

  public function down()
  {
    $this->dropTable('logs');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
