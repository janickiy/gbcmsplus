<?php

use admin\migrations\dbfix\SettingsTransferTrait;
use console\components\Migration;

class m160208_214714_new_settings extends Migration
{
  use SettingsTransferTrait;

  const SETTINGS_ENABLE_LOG = 'settings.enable_log';

  const MODULE_ID = 'logs';

  const SETTINGS_TABLE = 'rgk_settings';
  const PERMISSIONS_TABLE = 'rgk_settings_permissions';
  const OPTIONS_TABLE = 'rgk_settings_options';
  const VALUES_TABLE = 'rgk_settings_values';

  public function up()
  {
    $this->insertValues();
  }

  public function down()
  {

  }

  private function getRepository()
  {
    return (new admin\migrations\dbfix\Repository())
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('logs.settings.enable_log')
          ->setValue(true)
          ->setKey(self::SETTINGS_ENABLE_LOG)
          ->setGroup(['name' => 'app.common.group_system', 'sort' => 1])
          ->setSort(2)
      );
  }
}
