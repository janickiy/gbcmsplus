<?php

use console\components\Migration;

class m161005_143054_model_logs extends Migration
{
  const TABLE = 'model_logs';
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable('{{%' . self::TABLE . '}}', [
      'id' => 'int(10) UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT',
      'class' => $this->string(100)->notNull(),
      'pk' => $this->string(30)->notNull(),
      'operation_type' => 'TINYINT(1) UNSIGNED NOT NULL COMMENT \'1-insert, 2-update, 3-delete\'',
      'old_attributes' => $this->text(),
      'new_attributes' => $this->text(),
      'created_at' => $this->integer(10)->unsigned()->notNull(),
      'date' => 'date NOT NULL',
      'user_id' => $this->integer(10)->unsigned()->notNull()
    ], $tableOptions);
    $this->createIndex(self::TABLE . '_class_pk_index', '{{%' . self::TABLE . '}}', ['class', 'pk']);
    $this->createIndex(self::TABLE . '_date_user_id_index', '{{%' . self::TABLE . '}}', ['date', 'user_id']);
  }
  public function down()
  {
    $this->dropTable('{{%' . self::TABLE . '}}');
  }
}
