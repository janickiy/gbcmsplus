<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m161109_127946_group_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('LogsModule', null);
    $this->createPermission('LogsDefaultController', null, 'LogsModule');
    $this->addChildPermission('LogsDefaultController', 'LogsDefaultIndex');
    $this->addChildPermission('LogsDefaultController', 'LogsDefaultViewModal');
  }

  public function down()
  {
    $this->removePermission('LogsDefaultController');
    $this->removePermission('LogsModule');
  }
}
