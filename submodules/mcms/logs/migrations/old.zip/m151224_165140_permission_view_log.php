<?php

use console\components\Migration;

class m151224_165140_permission_view_log extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Logs';
    $this->permissions = [
      'Default' => [
        ['view-modal', 'Can view log details', ['admin', 'root']]
      ]
    ];
  }
}
