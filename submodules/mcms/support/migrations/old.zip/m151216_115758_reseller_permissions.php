<?php

use console\components\Migration;

class m151216_115758_reseller_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Support';
    $this->authManager = Yii::$app->getAuthManager();
    $this->rules = [];
    $this->roles = [];

    $this->permissions = [
      'Tickets' => [
        ['findUser', 'Can find user in ticket', ['reseller']],
        ['list', 'Can list tickets', ['reseller']],
        ['edit', 'Can edit ticket', ['reseller']],
        ['create', 'Can create ticket', ['reseller']],
        ['view', 'Can view ticket', ['reseller']],
        ['close', 'Can close ticket', ['reseller'],
          [
            'SupportOwnTicketRule' => \mcms\support\components\rbac\OwnTicketRule::className(),
            'SupportDelegatedTicketRule' => \mcms\support\components\rbac\DelegatedTicketRule::className()
          ]
        ],
        ['open', 'Can open ticket', ['reseller'], [
          'SupportDelegatedTicketRule' => \mcms\support\components\rbac\DelegatedTicketRule::className()
        ]],
        ['delegate', 'Can delegate ticket', ['reseller']],
      ],
      'TicketTexts' => [
        ['edit', 'Can edit ticket text', ['reseller'],
          [
            'SupportOwnTicketTextRule' => \mcms\support\components\rbac\OwnTicketTextRule::className(),
          ]
        ],
      ],

    ];
  }
}
