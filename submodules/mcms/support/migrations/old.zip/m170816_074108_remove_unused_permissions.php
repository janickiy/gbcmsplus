<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170816_074108_remove_unused_permissions extends Migration
{
  use PermissionTrait;
  
  public function up()
  {
    $this->removePermission('SupportTicketsFindUser');
    $this->removePermission('SupportTicketTextsEdit');
    $this->removePermission('SupportPermissions');
    $this->removePermission('SupportTicketsEdit');
  }
  
  public function down()
  {
    $this->createPermission('SupportPermissions', 'Разрешения модуля Support', 'SupportModule');
    $this->createPermission('SupportTicketsFindUser', 'Поиск пользователя в тикете', 'SupportPermissions');
    $this->createPermission('SupportTicketTextsEdit', 'Редактирование текста тикета', 'SupportPermissions');
    $this->createPermission('SupportTicketsEdit', 'Редактирование тикета', 'SupportTicketsController');
  }
}
