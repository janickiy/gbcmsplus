<?php

use console\components\Migration;

class m151222_085422_update_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->getAuthManager();
  }

  public function up()
  {
    $this->revokeRolesPermission('SupportTicketsView', ['partner']);
    $this->revokeRolesPermission('SupportTicketsCreate', ['partner']);
    $this->revokeRolesPermission('SupportTicketsClose', ['partner']);
  }

  public function down()
  {
    $this->assignRolesPermission('SupportTicketsView', ['partner']);
    $this->assignRolesPermission('SupportTicketsCreate', ['partner']);
    $this->assignRolesPermission('SupportTicketsClose', ['partner']);
  }

}
