<?php

use console\components\Migration;

class m151118_091511_init_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Support';
    $this->authManager = Yii::$app->getAuthManager();
    $this->rules = [];
    $this->roles = [];

    $this->permissions = [
      'Categories' => [
        ['list', 'Can view categories List', ['admin', 'root']],
        ['update', 'Can update category', ['admin', 'root']],
        ['create', 'Can create category', ['admin', 'root']],
        ['enable', 'Can enable category', ['admin', 'root']],
        ['disable', 'Can disabled category', ['admin', 'root']],
      ],
      'Tickets' => [
        ['findUser', 'Can find user in ticket', ['admin', 'root']],
        ['list', 'Can list tickets', ['admin', 'root']],
        ['edit', 'Can edit ticket', ['admin', 'root']],
        ['create', 'Can create ticket', ['admin', 'root', 'partner']],
        ['view', 'Can view ticket', ['admin', 'root', 'partner']],
        ['close', 'Can close ticket', ['admin', 'root', 'partner'],
          [
            'SupportOwnTicketRule' => \mcms\support\components\rbac\OwnTicketRule::className(),
            'SupportDelegatedTicketRule' => \mcms\support\components\rbac\DelegatedTicketRule::className()
          ]
        ],
        ['open', 'Can open ticket', ['admin', 'root'], [
          'SupportDelegatedTicketRule' => \mcms\support\components\rbac\DelegatedTicketRule::className()
        ]],
        ['delegate', 'Can delegate ticket', ['admin', 'root']],
      ],
      'TicketTexts' => [
        ['edit', 'Can edit ticket text', ['admin', 'root', 'partner'],
          [
            'SupportOwnTicketTextRule' => \mcms\support\components\rbac\OwnTicketTextRule::className(),
          ]
        ],
      ],

    ];
  }
}
