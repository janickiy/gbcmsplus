<?php

use console\components\Migration;

class m151218_102651_support_initail_categories extends Migration
{
  public function up()
  {
    (new \mcms\support\models\SupportCategory([
      'is_disabled' => 0,
      'name' => [
        'ru' => 'Вопросы',
        'en' => 'Questions'
      ]
    ]))->save();

    (new \mcms\support\models\SupportCategory([
      'is_disabled' => 0,
      'name' => [
        'ru' => 'Баги',
        'en' => 'Bugs'
      ]
    ]))->save();

    (new \mcms\support\models\SupportCategory([
      'is_disabled' => 0,
      'name' => [
        'ru' => 'Пожелания',
        'en' => 'Wishes'
      ]
    ]))->save();

    (new \mcms\support\models\SupportCategory([
      'is_disabled' => 0,
      'name' => [
        'ru' => 'Предложения',
        'en' => 'Suggestions'
      ]
    ]))->save();
  }

  public function down()
  {
    //nothing
  }
}
