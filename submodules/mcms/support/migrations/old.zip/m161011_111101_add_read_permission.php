<?php

use console\components\Migration;

class m161011_111101_add_read_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->moduleName = 'Support';
    $this->authManager = Yii::$app->getAuthManager();
    $this->permissions = [
      'Tickets' => [
        ['read', 'Can mark a ticket as read', ['root', 'admin']],
      ],
    ];
  }
}
