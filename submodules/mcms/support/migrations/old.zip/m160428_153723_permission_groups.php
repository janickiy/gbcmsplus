<?php

use console\components\Migration;

class m160428_153723_permission_groups extends Migration
{
  /** @var  \yii\rbac\ManagerInterface */
  private $authManager;
  private $groupPermission = [
    'name' =>  'SupportModule',
    'description' => 'Module Support',
  ]
  ;
  private $groupPermissionControllers = [
    'Support Categories Controller' => [
      'description' => 'Support Categories Controller',
      'permissions' => [
        'SupportCategoriesCreate',
        'SupportCategoriesDisable',
        'SupportCategoriesEnable',
        'SupportCategoriesList',
        'SupportCategoriesUpdate',
      ]
    ],
    'Support Tickets Controller' => [
      'description' => 'Support Tickets Controller',
      'permissions' => [
        'SupportTicketsClose',
        'SupportTicketsCreate',
        'SupportTicketsDelegate',
        'SupportTicketsEdit',
        'SupportTicketsFindUser',
        'SupportTicketsList',
        'SupportTicketsOpen',
        'SupportTicketsView',
        'SupportTicketTextsEdit',
      ]
    ],
  ];

  public function init()
  {
    parent::init();
    $this->authManager = \Yii::$app->authManager;
  }

  public function up()
  {
    foreach ($this->groupPermissionControllers as $controllerName => $controllerData) {
      $controllerPermission = $this->createOrGetPermission($controllerName, $controllerData['description']);
      foreach($controllerData['permissions'] as $childPermissionName) {
        $childPermission = $this->authManager->getPermission($childPermissionName);
        if ($childPermission && !$this->authManager->hasChild($controllerPermission, $childPermission)) {
          $this->authManager->addChild($controllerPermission, $childPermission);
        }
      }
      $groupPermission = $this->createOrGetPermission($this->groupPermission['name'], $this->groupPermission['description']);
      $this->authManager->addChild($groupPermission, $controllerPermission);
    }
  }

  public function down()
  {
    $permission = $this->authManager->getPermission($this->groupPermission);
    $this->authManager->remove($permission);
    foreach ($this->groupPermissionControllers as $controllerName => $controllerData) {
      $controllerPermission = $this->authManager->getPermission($controllerName);
      $this->authManager->remove($controllerPermission);
    }
  }

  public function createOrGetPermission($permissionName, $permissionDescription)
  {
    $permission = $this->authManager->getPermission($permissionName);
    if (!$permission) {
      $permission = $this->authManager->createPermission($permissionName);
      $permission->description = $permissionDescription;
      $this->authManager->add($permission);
    }
    return $permission;
  }
}
