<?php

use console\components\Migration;

class m151210_133936_support_name extends Migration
{
  const TABLE = 'support';

  public function up()
  {
    $this->addColumn(self::TABLE, 'name', \yii\db\Schema::TYPE_STRING);
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'name');
  }
}
