<?php

use console\components\Migration;
use yii\helpers\FileHelper;
use yii\helpers\Console;
use yii\db\Query;
use mcms\support\models\SupportText;

class m160324_111311_images_directory_url_fix extends Migration
{

  protected $path = '@uploadPath/support/message/{id}/';
  protected $basePath = '@uploadPath/../';

  public function up()
  {
    $this->path = Yii::getAlias($this->path);

    foreach (SupportText::find()->each() as $supportText) {
      Console::stdout(PHP_EOL . 'Support text #' . $supportText->id . PHP_EOL);

      // Нет изображений
      if (empty($supportText->images)) {
        Console::stdout('No images has been found' . PHP_EOL);
        continue;
      }

      // Проверяем, существует ли изображение по адреcу
      $imagePath = FileHelper::normalizePath(Yii::getAlias($this->basePath . $supportText->images));
      Console::stdout('Path = ' . $imagePath . PHP_EOL);

      // Директория, куда в теории должны заливаться изображения из админки
      $dirPath = strtr($this->path, ['{id}' => $supportText->id]);

      // Если файл существует, переносим его
      // Такое должно быть только в партнеском кабинете
      if (file_exists($imagePath)) {
        Console::stdout('Image is already existing' . PHP_EOL);
        $fileName = basename($imagePath);

        FileHelper::createDirectory($dirPath);
        rename($imagePath, $dirPath . $fileName);
        Console::stdout('Image has been moved to ' . $dirPath . PHP_EOL);
      } else {
        // Проверка наличии директории
        Console::stdout('Checking directory ' . $dirPath . ' for images' . PHP_EOL);
        if (!(file_exists($dirPath) && is_dir($dirPath))) {
          Console::stdout('Directory does not exists' . PHP_EOL);
          continue;
        }

        // Проверка наличия файлов
        $files = FileHelper::findFiles($dirPath);
        if (empty($files)) {
          Console::stdout('Files haven\'t been found' . PHP_EOL);
          continue;
        }

        // Получаем название файла
        $fileName = basename($files[0]);
      }

      SupportText::updateAll(['images' => $fileName], ['id' => $supportText->id]);
      Console::stdout('Image has been updated' . PHP_EOL);
    }
  }

  public function down()
  {

  }

}
