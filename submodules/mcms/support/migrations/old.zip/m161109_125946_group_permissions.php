<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m161109_125946_group_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('SupportPermissions', null, 'SupportModule');
    $this->createPermission('SupportTicketsController', null, 'SupportModule');
    $this->createPermission('SupportCategoriesController', null, 'SupportModule');

    $this->removePermission('Support Tickets Controller');
    $this->removePermission('Support Categories Controller');

    $this->addChildPermission('SupportPermissions', 'SupportTicketsFindUser');
    $this->addChildPermission('SupportPermissions', 'SupportTicketTextsEdit');

    $this->addChildPermission('SupportTicketsController', 'SupportTicketsRead');

    $this->addChildPermission('SupportCategoriesController', 'SupportCategoriesCreate');
    $this->addChildPermission('SupportCategoriesController', 'SupportCategoriesDisable');
    $this->addChildPermission('SupportCategoriesController', 'SupportCategoriesEnable');
    $this->addChildPermission('SupportCategoriesController', 'SupportCategoriesList');
    $this->addChildPermission('SupportCategoriesController', 'SupportCategoriesUpdate');

    $this->addChildPermission('SupportTicketsController', 'SupportTicketsClose');
    $this->addChildPermission('SupportTicketsController', 'SupportTicketsCreate');
    $this->addChildPermission('SupportTicketsController', 'SupportTicketsDelegate');
    $this->addChildPermission('SupportTicketsController', 'SupportTicketsEdit');
    $this->addChildPermission('SupportTicketsController', 'SupportTicketsList');
    $this->addChildPermission('SupportTicketsController', 'SupportTicketsOpen');
    $this->addChildPermission('SupportTicketsController', 'SupportTicketsView');


  }

  public function down()
  {
    $this->removePermission('SupportTicketsController');
    $this->removePermission('SupportCategoriesController');
    $this->removePermission('SupportPermissions');

    $this->createPermission('Support Tickets Controller', null, 'SupportModule');
    $this->createPermission('Support Categories Controller', null, 'SupportModule');

    $this->addChildPermission('Support Tickets Controller', 'SupportTicketsFindUser');
    $this->addChildPermission('Support Tickets Controller', 'SupportTicketTextsEdit');

    $this->addChildPermission('Support Categories Controller', 'SupportCategoriesCreate');
    $this->addChildPermission('Support Categories Controller', 'SupportCategoriesDisable');
    $this->addChildPermission('Support Categories Controller', 'SupportCategoriesEnable');
    $this->addChildPermission('Support Categories Controller', 'SupportCategoriesList');
    $this->addChildPermission('Support Categories Controller', 'SupportCategoriesUpdate');

    $this->addChildPermission('Support Tickets Controller', 'SupportTicketsClose');
    $this->addChildPermission('Support Tickets Controller', 'SupportTicketsCreate');
    $this->addChildPermission('Support Tickets Controller', 'SupportTicketsDelegate');
    $this->addChildPermission('Support Tickets Controller', 'SupportTicketsEdit');
    $this->addChildPermission('Support Tickets Controller', 'SupportTicketsList');
    $this->addChildPermission('Support Tickets Controller', 'SupportTicketsOpen');
    $this->addChildPermission('Support Tickets Controller', 'SupportTicketsView');
  }
}
