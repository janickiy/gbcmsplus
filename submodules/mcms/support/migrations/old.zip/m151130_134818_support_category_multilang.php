<?php

use console\components\Migration;

class m151130_134818_support_category_multilang extends Migration
{
    const TABLE = 'support_categories';

    public function up()
    {
        $this->addColumn(self::TABLE, 'name', \yii\db\Schema::TYPE_STRING);
    }

    public function down()
    {
        $this->dropColumn(self::TABLE, 'name');
    }
}
