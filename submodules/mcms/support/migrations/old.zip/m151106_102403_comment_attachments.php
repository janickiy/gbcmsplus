<?php

use console\components\Migration;

class m151106_102403_comment_attachments extends Migration
{

  const TABLE = 'support_texts';

  public function up()
  {
    $this->addColumn(self::TABLE, 'images', \yii\db\Schema::TYPE_TEXT);
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'images');
  }
}
