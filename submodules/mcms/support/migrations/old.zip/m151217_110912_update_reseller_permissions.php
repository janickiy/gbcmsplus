<?php

use console\components\Migration;

class m151217_110912_update_reseller_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->moduleName = 'Support';
    $this->authManager = Yii::$app->getAuthManager();
    $this->rules = [];
    $this->roles = [];



    $this->permissions = [
      'Tickets' => [
        ['view', 'Can view ticket', ['reseller']],
      ],

    ];
  }
}
