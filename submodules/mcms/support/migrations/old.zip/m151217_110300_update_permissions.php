<?php

use console\components\Migration;

class m151217_110300_update_permissions extends Migration
{
  protected $authManager;
  protected $roles;

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    $this->roles = [
      $this->authManager->getRole('admin'),
      $this->authManager->getRole('root'),
    ];
  }

  public function up()
  {
    $this->assign('SupportCanViewBlackList');
  }

  public function down()
  {
    $this->revoke('SupportCanViewBlackList');
  }

  protected function revoke($name)
  {
    $permission = $this->authManager->getPermission($name);
    foreach($this->roles as $role) {
      if ($permission && $this->authManager->hasChild($role, $permission)) {
        $this->authManager->removeChild($this->resellerRole, $permission);
      }
    }
  }

  protected function assign($name)
  {
    $permission = $this->authManager->getPermission($name);
    foreach($this->roles as $role) {
      if ($permission && !$this->authManager->hasChild($role, $permission)) {
        $this->authManager->addChild($this->resellerRole, $permission);
      }
    }
  }
}
