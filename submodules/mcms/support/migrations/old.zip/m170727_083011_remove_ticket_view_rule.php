<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170727_083011_remove_ticket_view_rule extends Migration
{
  use PermissionTrait;
  const RULE = 'SupportResellerViewTicketRule';

  public function up()
  {
    if (!$this->authManager->getPermission(self::RULE)) return true;
    $this->removePermission(self::RULE);
  }

  public function down()
  {

  }
}
