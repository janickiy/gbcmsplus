<?php

use console\components\Migration;

class m151007_124938_create_support_tables extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable('support_categories', [
      'id' => 'TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'is_disabled' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => 'int(10) UNSIGNED NOT NULL',
      'updated_at' => 'int(10) UNSIGNED NOT NULL',
    ], $tableOptions);

    $this->createIndex('support_categories_is_disabled_index', 'support_categories', 'is_disabled');

    $this->createTable('support_categories_roles', [
      'role' => \yii\db\Schema::TYPE_STRING . '(64) NOT NULL',
      'support_category_id' => 'TINYINT(3) UNSIGNED NOT NULL'
    ], $tableOptions);

    $this->addPrimaryKey(
      'support_categories_roles_role_support_category_id_pk',
      'support_categories_roles',
      ['role', 'support_category_id']
    );

    $this->addForeignKey(
      'support_categories_roles_role_fk',
      'support_categories_roles',
      'role',
      'auth_item',
      'name',
      'CASCADE',
      'CASCADE'
    );

    $this->addForeignKey(
      'support_categories_roles_support_category_id_fk',
      'support_categories_roles',
      'support_category_id',
      'support_categories',
      'id',
      'CASCADE',
      'CASCADE'
    );

    $this->createTable('support', [
      'id' => 'int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'support_category_id' => 'TINYINT(3) UNSIGNED',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'delegated_to' => 'MEDIUMINT(5) UNSIGNED',
      'is_opened' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'has_unread_messages' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => 'int(10) UNSIGNED NOT NULL',
      'updated_at' => 'int(10) UNSIGNED NOT NULL',
    ], $tableOptions);

    $this->addForeignKey(
      'support_support_category_id_fk',
      'support',
      'support_category_id',
      'support_categories',
      'id',
      'SET NULL',
      'CASCADE'
    );

    $this->addForeignKey(
      'support_created_by_fk',
      'support',
      'created_by',
      'users',
      'id',
      'CASCADE',
      'CASCADE'
    );

    $this->addForeignKey(
      'support_delegated_to_fk',
      'support',
      'delegated_to',
      'users',
      'id',
      'SET NULL',
      'CASCADE'
    );

    $this->createTable('support_history', [
      'id' => 'int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'support_id' => 'int(10) UNSIGNED NOT NULL',
      'support_category_id' => 'TINYINT(3) UNSIGNED',
      'delegated_to' => 'MEDIUMINT(5) UNSIGNED',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NULL',
      'is_opened' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => 'int(10) UNSIGNED NOT NULL',
      'updated_at' => 'int(10) UNSIGNED NOT NULL',
    ], $tableOptions);

    $this->createIndex(
      'support_history_support_id_created_at_index',
      'support_history',
      ['support_id', 'created_at']
    );

    $this->addForeignKey(
      'support_history_created_by_fk',
      'support_history',
      'created_by',
      'users',
      'id',
      'SET NULL',
      'CASCADE'
    );

    $this->addForeignKey(
      'support_history_support_category_id_fk',
      'support_history',
      'support_category_id',
      'support_categories',
      'id',
      'SET NULL',
      'CASCADE'
    );


    $this->addForeignKey(
      'support_history_delegated_to_fk',
      'support_history',
      'delegated_to',
      'users',
      'id',
      'SET NULL',
      'CASCADE'
    );

    $this->addForeignKey(
      'support_history_support_id_fk',
      'support_history',
      'support_id',
      'support',
      'id',
      'CASCADE',
      'CASCADE'
    );

    $this->createTable('support_texts', [
      'id' => 'int(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'support_id' => 'int(10) UNSIGNED NOT NULL',
      'from_user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'text' => \yii\db\Schema::TYPE_TEXT,
      'created_at' => 'int(10) UNSIGNED NOT NULL',
      'updated_at' => 'int(10) UNSIGNED NOT NULL',
    ], $tableOptions);

    $this->addForeignKey(
      'support_texts_support_id_fk',
      'support_texts',
      'support_id',
      'support',
      'id',
      'CASCADE',
      'CASCADE'
    );

    $this->addForeignKey(
      'support_texts_from_user_id_fk',
      'support_texts',
      'from_user_id',
      'users',
      'id',
      'CASCADE',
      'CASCADE'
    );

    $this->createIndex(
      'support_texts_support_id_created_at_index',
      'support_texts',
      ['support_id', 'created_at']
    );
  }

  public function down()
  {
    /** support_texts */
    $this->dropForeignKey('support_texts_from_user_id_fk', 'support_texts');
    $this->dropForeignKey('support_texts_support_id_fk', 'support_texts');
    $this->dropIndex('support_texts_support_id_created_at_index', 'support_texts');
    $this->dropTable('support_texts');

    /** support_history */
    $this->dropForeignKey('support_history_support_id_fk', 'support_history');
    $this->dropForeignKey('support_history_delegated_to_fk', 'support_history');
    $this->dropIndex('support_history_support_id_created_at_index', 'support_history');
    $this->dropTable('support_history');

    /** support */
    $this->dropForeignKey('support_delegated_to_fk', 'support');
    $this->dropForeignKey('support_created_by_fk', 'support');
    $this->dropForeignKey('support_support_category_id_fk', 'support');
    $this->dropTable('support');

    /** support_categories_roles */
    $this->dropForeignKey('support_categories_roles_role_fk', 'support_categories_roles');
    $this->dropForeignKey('support_categories_roles_support_category_id_fk', 'support_categories_roles');
    $this->dropTable('support_categories_roles');

    /** support_categories */
    $this->dropIndex('support_categories_is_disabled_index', 'support_categories');
    $this->dropTable('support_categories');
  }
}
