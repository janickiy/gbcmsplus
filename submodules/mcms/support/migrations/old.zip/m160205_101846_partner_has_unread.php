<?php

use yii\db\Schema;
use console\components\Migration;

class m160205_101846_partner_has_unread extends Migration
{

  const TABLE = 'support';

  public function up()
  {
    $this->addColumn(self::TABLE, 'owner_has_unread_messages', 'tinyint(1) unsigned NOT NULL DEFAULT \'0\' AFTER has_unread_messages');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'owner_has_unread_messages');
  }
}
