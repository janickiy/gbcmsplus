<?php

use console\components\Migration;

class m170124_121502_rename_module extends Migration
{
  public function up()
  {
    $this->update('modules',
      [ 'name' => 'support.main.module_breadcrumbs_name', ],
      [ 'module_id' => 'support', ]
    );
  }

  public function down()
  {
    $this->update('modules',
      [ 'name' => 'app.common.module_support', ],
      [ 'module_id' => 'support', ]
    );
  }
}
