<?php

use yii\db\Schema;
use console\components\Migration;

class m160205_110357_last_text_created_at extends Migration
{
  const TABLE = 'support';

  public function up()
  {
    $this->addColumn(self::TABLE, 'last_text_created_at', 'int(10) unsigned DEFAULT NULL AFTER updated_at');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'last_text_created_at');
  }
}
