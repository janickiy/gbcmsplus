<?php

use console\components\Migration;

class m170616_132828_qiwi_percent_update extends Migration
{
  public function up()
  {
    $this->update('wallets', ['profit_percent' => '-1.5'], ['code' => 'qiwi']);
  }

  public function down()
  {

  }
}
