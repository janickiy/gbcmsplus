<?php

use console\components\Migration;


/**
 * Class m170711_145240_del_res_checkout
 */
class m170711_145240_del_res_checkout extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  /**
   *
   */
  public function up()
  {
    $this->dropTable('reseller_checkout');
    $this->dropTable('reseller_checkout_investors');
  }

  /**
   *
   */
  public function down()
  {
    $this->db->createCommand('CREATE TABLE `reseller_checkout` (
  `week_start` date NOT NULL DEFAULT \'0000-00-00\',
  `rub` decimal(9,2) unsigned NOT NULL DEFAULT \'0.00\',
  `usd` decimal(8,2) unsigned NOT NULL DEFAULT \'0.00\',
  `eur` decimal(8,2) unsigned NOT NULL DEFAULT \'0.00\',
  PRIMARY KEY (`week_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci')->execute();
    $this->db->createCommand('CREATE TABLE `reseller_checkout_investors` (
  `week_start` date NOT NULL DEFAULT \'0000-00-00\',
  `investor_id` smallint(5) unsigned NOT NULL,
  `sum` decimal(8,2) unsigned NOT NULL DEFAULT \'0.00\',
  `currency` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`week_start`,`investor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci')->execute();
  }
}
