<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

class m170712_153908_payments_permissions extends Migration
{

  use PermissionTrait;

  public function up()
  {
    $this->createPermission('canViewAllPayments', 'Просматривать все выплаты', 'PaymentsPermissions', ['root', 'admin']);
    $this->createPermission('canViewPartnerPayments', 'Просматривать выплаты партнеров', 'PaymentsPermissions', ['reseller']);
    $this->createPermission('canEditAllPayments', 'Редактировать все выплаты', 'PaymentsPermissions', ['root', 'admin']);
    $this->createPermission('canEditPartnerPayments', 'Редактировать выплаты партнеров', 'PaymentsPermissions', ['reseller']);
  }

  public function down()
  {
    $this->removePermission('canViewAllPayments');
    $this->removePermission('canViewPartnerPayments');
    $this->removePermission('canEditAllPayments');
    $this->removePermission('canEditPartnerPayments');
  }
}
