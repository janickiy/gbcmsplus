<?php

use console\components\Migration;

class m160104_103303_user_settings_rename_is_hold_autopay extends Migration
{
    public function up()
    {
      $this->renameColumn('user_payment_settings', 'is_forced_autopay_enabled', 'is_hold_autopay_enabled');
    }

    public function down()
    {
      $this->renameColumn('user_payment_settings', 'is_hold_autopay_enabled', 'is_forced_autopay_enabled');
    }
}
