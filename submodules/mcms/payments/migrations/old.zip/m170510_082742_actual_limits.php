<?php

use console\components\Migration;

class m170510_082742_actual_limits extends Migration
{
  public function up()
  {
    $this->update('wallets', [
      'rub_min_payout_sum' => 1000,
      'usd_min_payout_sum' => 20,
      'eur_min_payout_sum' => 20,
      'is_multiple' => 1,

      'rub_max_payout_sum' => null,
      'rub_payout_limit_daily' => null,
      'rub_payout_limit_monthly' => null,
      'usd_max_payout_sum' => null,
      'usd_payout_limit_daily' => null,
      'usd_payout_limit_monthly' => null,
      'eur_max_payout_sum' => null,
      'eur_payout_limit_daily' => null,
      'eur_payout_limit_monthly' => null,

    ], [
      'code' => 'webmoney'
    ]);
    $this->update('wallets', [
      'rub_min_payout_sum' => 100,
      'usd_min_payout_sum' => 5,
      'eur_min_payout_sum' => 5,
      'rub_max_payout_sum' => 50000,
      'rub_payout_limit_daily' => 200000,
      'rub_payout_limit_monthly' => 500000,
      'is_multiple' => 1,

      'usd_max_payout_sum' => null,
      'usd_payout_limit_daily' => null,
      'usd_payout_limit_monthly' => null,
      'eur_max_payout_sum' => null,
      'eur_payout_limit_daily' => null,
      'eur_payout_limit_monthly' => null,
    ], [
      'code' => 'yandex-money'
    ]);
    $this->update('wallets', [
      'rub_min_payout_sum' => 100,
      'usd_min_payout_sum' => 1,
      'eur_min_payout_sum' => 1,
      'is_multiple' => 1,
      'rub_max_payout_sum' => null,
      'rub_payout_limit_daily' => null,
      'rub_payout_limit_monthly' => null,
      'usd_max_payout_sum' => null,
      'usd_payout_limit_daily' => null,
      'usd_payout_limit_monthly' => null,
      'eur_max_payout_sum' => null,
      'eur_payout_limit_daily' => null,
      'eur_payout_limit_monthly' => null,
    ], [
      'code' => 'epayments'
    ]);
    $this->update('wallets', [
      'rub_min_payout_sum' => 100,
      'usd_min_payout_sum' => 100,
      'eur_min_payout_sum' => 100,
      'is_multiple' => 1,
      'rub_max_payout_sum' => null,
      'rub_payout_limit_daily' => null,
      'rub_payout_limit_monthly' => null,
      'usd_max_payout_sum' => null,
      'usd_payout_limit_daily' => null,
      'usd_payout_limit_monthly' => null,
      'eur_max_payout_sum' => null,
      'eur_payout_limit_daily' => null,
      'eur_payout_limit_monthly' => null,
    ], [
      'code' => 'paypal'
    ]);
    $this->update('wallets', [
      'rub_min_payout_sum' => 100,
      'usd_min_payout_sum' => 100,
      'eur_min_payout_sum' => 100,
      'is_multiple' => 1,
      'rub_max_payout_sum' => null,
      'rub_payout_limit_daily' => null,
      'rub_payout_limit_monthly' => null,
      'usd_max_payout_sum' => null,
      'usd_payout_limit_daily' => null,
      'usd_payout_limit_monthly' => null,
      'eur_max_payout_sum' => null,
      'eur_payout_limit_daily' => null,
      'eur_payout_limit_monthly' => null,
    ], [
      'code' => 'paxum'
    ]);
    $this->update('wallets', [
      'rub_min_payout_sum' => 0,
      'usd_min_payout_sum' => 100,
      'eur_min_payout_sum' => 100,
      'is_multiple' => 1,
      'rub_max_payout_sum' => null,
      'rub_payout_limit_daily' => null,
      'rub_payout_limit_monthly' => null,
      'usd_max_payout_sum' => null,
      'usd_payout_limit_daily' => null,
      'usd_payout_limit_monthly' => null,
      'eur_max_payout_sum' => null,
      'eur_payout_limit_daily' => null,
      'eur_payout_limit_monthly' => null,
    ], [
      'code' => 'wireiban'
    ]);
    $this->update('wallets', [
      'rub_min_payout_sum' => 5000,
      'usd_min_payout_sum' => 100,
      'eur_min_payout_sum' => 100,
      'rub_max_payout_sum' => 50000,
      'rub_payout_limit_daily' => 50000,
      'rub_payout_limit_monthly' => 500000,
      'usd_max_payout_sum' => 2000,
      'usd_payout_limit_daily' => 2000,
      'usd_payout_limit_monthly' => 10000,
      'eur_max_payout_sum' => 2000,
      'eur_payout_limit_daily' => 2000,
      'eur_payout_limit_monthly' => 10000,
      'is_multiple' => 1,
    ], [
      'code' => 'card'
    ]);
    $this->update('wallets', [
      'rub_min_payout_sum' => 30000,
      'usd_min_payout_sum' => 0,
      'eur_min_payout_sum' => 0,
      'is_multiple' => 1,
      'rub_max_payout_sum' => null,
      'rub_payout_limit_daily' => null,
      'rub_payout_limit_monthly' => null,
      'usd_max_payout_sum' => null,
      'usd_payout_limit_daily' => null,
      'usd_payout_limit_monthly' => null,
      'eur_max_payout_sum' => null,
      'eur_payout_limit_daily' => null,
      'eur_payout_limit_monthly' => null,
    ], [
      'code' => 'private-person'
    ]);
    $this->update('wallets', [
      'rub_min_payout_sum' => 50000,
      'usd_min_payout_sum' => 0,
      'eur_min_payout_sum' => 0,
      'is_multiple' => 1,
      'rub_max_payout_sum' => null,
      'rub_payout_limit_daily' => null,
      'rub_payout_limit_monthly' => null,
      'usd_max_payout_sum' => null,
      'usd_payout_limit_daily' => null,
      'usd_payout_limit_monthly' => null,
      'eur_max_payout_sum' => null,
      'eur_payout_limit_daily' => null,
      'eur_payout_limit_monthly' => null,
    ], [
      'code' => 'juridical-person'
    ]);
    $this->update('wallets', [
      'rub_min_payout_sum' => 100,
      'usd_min_payout_sum' => 0,
      'eur_min_payout_sum' => 0,
      'rub_max_payout_sum' => 50000,
      'rub_payout_limit_daily' => 200000,
      'rub_payout_limit_monthly' => 500000,
      'is_multiple' => 1,
      'usd_max_payout_sum' => null,
      'usd_payout_limit_daily' => null,
      'usd_payout_limit_monthly' => null,
      'eur_max_payout_sum' => null,
      'eur_payout_limit_daily' => null,
      'eur_payout_limit_monthly' => null,
    ], [
      'code' => 'qiwi'
    ]);

  }

  public function down()
  {
    return true;
  }
}
