<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m170206_130318_payment_settings_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('PaymentsUsersWalletModal', 'Модалка создания/редактирования кошельков', 'PaymentsUsersController', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('PaymentsUsersWalletModal');
  }
}
