<?php

use console\components\Migration;

class m151221_135522_user_balance_invoice_index extends Migration
{
  public function up()
  {
    $this->createIndex('user_balance_invoices_user_id_index', 'user_balance_invoices', 'user_id');
  }

  public function down()
  {
    $this->dropIndex('user_balance_invoices_user_id_index', 'user_balance_invoices');
  }
}
