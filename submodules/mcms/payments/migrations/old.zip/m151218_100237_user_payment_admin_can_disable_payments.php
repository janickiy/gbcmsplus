<?php

use console\components\Migration;

class m151218_100237_user_payment_admin_can_disable_payments extends Migration
{
use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Users' => [
        ['DisableUserPayments', 'Can disable user payments', ['root', 'admin']],
      ],
    ];
  }
}
