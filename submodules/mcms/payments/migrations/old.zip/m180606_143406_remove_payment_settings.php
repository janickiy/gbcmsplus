<?php

use rgk\settings\models\Setting;
use console\components\Migration;

class m180606_143406_remove_payment_settings extends Migration
{
  const SETTINGS_AUTOPAY_ENABLED_SUBSCRIPTION_COUNT = 'settings.subscription_count_autopay_enabled';
  const SETTINGS_NUMBER_OF_WEEKS = 'settings.number_of_weeks';
  const SETTINGS_GENERATE_PAYMENTS_DAY = 'settings.generate.payments.day';
  const SETTINGS_MIN_PAYOUT_SUM_RUB = 'settings.min.payout.sum.rub';
  const SETTINGS_MIN_PAYOUT_SUM_EUR = 'settings.min.payout.sum.eur';
  const SETTINGS_MIN_PAYOUT_SUM_USD = 'settings.min.payout.sum.usd';
  const SETTINGS_IS_GENERATE_REGULAR_PAYMENTS_RESELLERS = 'settings.payments.is.generate.regular.payments.resellers';

  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;


  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
  }

  public function up()
  {
    $this->settingsBuilder->removeSetting(self::SETTINGS_AUTOPAY_ENABLED_SUBSCRIPTION_COUNT);
    $this->settingsBuilder->removeSetting(self::SETTINGS_NUMBER_OF_WEEKS);
    $this->settingsBuilder->removeSetting(self::SETTINGS_GENERATE_PAYMENTS_DAY);
    $this->settingsBuilder->removeSetting(self::SETTINGS_MIN_PAYOUT_SUM_RUB);
    $this->settingsBuilder->removeSetting(self::SETTINGS_MIN_PAYOUT_SUM_USD);
    $this->settingsBuilder->removeSetting(self::SETTINGS_MIN_PAYOUT_SUM_EUR);
    $this->settingsBuilder->removeSetting(self::SETTINGS_IS_GENERATE_REGULAR_PAYMENTS_RESELLERS);


  }

  public function down()
  {
    $title = ['ru' => 'Количество активных подписок, после которых доступна опция автовыплат', 'en' => 'The number of active subscriptions, after which the autopay option is available'];
    $permissions = ['EditModuleSettingsPayments'];
    $category = 'app.common.group_payments';
    $validators = [["required"],["integer"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTINGS_AUTOPAY_ENABLED_SUBSCRIPTION_COUNT, $permissions, Setting::TYPE_INTEGER, $category, 1000, $validators, 2);

    $title = ['ru' => 'Количество недель для рассчета реселлера', 'en' => 'Number of weeks for reseller checkout'];
    $permissions = ['EditModuleSettingsPayments'];
    $category = 'app.common.group_payments';
    $validators = [["required"],["integer"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTINGS_NUMBER_OF_WEEKS, $permissions, Setting::TYPE_INTEGER, $category, 10, $validators,3);


    $title = ['ru' => 'День создания штатных выплат', 'en' => 'Day of the creation of regular payments'];
    $permissions = ['EditModuleSettingsPayments'];
    $category = 'app.common.form_group_payments_payments';
    $validators = [["required"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTINGS_GENERATE_PAYMENTS_DAY, $permissions, Setting::TYPE_LISTS, $category, 4, $validators,1);

    $this->settingsBuilder->createOption(['ru' => 'Понедельник', 'en' => 'Monday'], self::SETTINGS_GENERATE_PAYMENTS_DAY, 1);
    $this->settingsBuilder->createOption(['ru' => 'Вторник', 'en' => 'Tuesday'], self::SETTINGS_GENERATE_PAYMENTS_DAY, 1);
    $this->settingsBuilder->createOption(['ru' => 'Среда', 'en' => 'Wednesday'], self::SETTINGS_GENERATE_PAYMENTS_DAY, 1);
    $this->settingsBuilder->createOption(['ru' => 'Четверг', 'en' => 'Thursday'], self::SETTINGS_GENERATE_PAYMENTS_DAY, 1);
    $this->settingsBuilder->createOption(['ru' => 'Пятница', 'en' => 'Friday'], self::SETTINGS_GENERATE_PAYMENTS_DAY, 1);
    $this->settingsBuilder->createOption(['ru' => 'Воскресенье', 'en' => 'Sunday'], self::SETTINGS_GENERATE_PAYMENTS_DAY, 1);

    $title = ['ru' => 'Минимальная сумма для выплат (Р)', 'en' => 'The minimum amount for payment (P)'];
    $permissions = ['EditModuleSettingsPayments'];
    $category = 'app.common.form_group_payments_payments';
    $validators = [["required"],["double"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTINGS_MIN_PAYOUT_SUM_RUB, $permissions, Setting::TYPE_FLOAT, $category, 100, $validators,2);

    $title = ['ru' => 'Минимальная сумма для выплат ($)', 'en' => 'The minimum amount for payment ($)'];
    $permissions = ['EditModuleSettingsPayments'];
    $category = 'app.common.form_group_payments_payments';
    $validators = [["required"],["double"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTINGS_MIN_PAYOUT_SUM_USD, $permissions, Setting::TYPE_FLOAT, $category, 2, $validators,3);

    $title = ['ru' => 'Минимальная сумма для выплат (€)', 'en' => 'The minimum amount for payment (€)'];
    $permissions = ['EditModuleSettingsPayments'];
    $category = 'app.common.form_group_payments_payments';
    $validators = [["required"],["double"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTINGS_MIN_PAYOUT_SUM_EUR, $permissions, Setting::TYPE_FLOAT, $category, 2, $validators,4);

    $title = ['ru' => 'Генерировать штатные выплаты реселлеру', 'en' => 'Generate regular payments reseller'];
    $permissions = ['EditModuleSettingsPayments'];
    $category = 'app.common.form_group_payments_payments';
    $validators = [["required"],["boolean"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTINGS_IS_GENERATE_REGULAR_PAYMENTS_RESELLERS, $permissions, Setting::TYPE_BOOLEAN, $category, 0, $validators,5);

  }
}
