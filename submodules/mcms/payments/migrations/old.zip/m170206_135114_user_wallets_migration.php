<?php

use mcms\common\helpers\ArrayHelper;
use console\components\Migration;
use yii\db\Query;
use yii\helpers\Json;

class m170206_135114_user_wallets_migration extends Migration
{
  const USER_PAYMENT_SETTINGS = 'user_payment_settings';
  const USER_WALLETS = 'user_wallets';

  public function up()
  {
    $values = [];
    foreach ((new Query())->from(self::USER_PAYMENT_SETTINGS)->each() as $setting) {
      if (empty($setting['wallet_type'])) continue;

      // Если wallet_type в JSON, значит в user_wallets переносится несколько записей
      foreach (Json::decode($setting['wallet_type']) as $currency => $walletType) {
        // EPayServices и Neteller пропускаем
        if (in_array($walletType, [4, 9])) continue;

        $values[] = [
          'user_id' => $setting['user_id'],
          'currency' => $currency,
          'wallet_type' => $walletType,
          'wallet_account' => $this->getWalletAccountData($setting['wallet_account'], $currency),
        ];
      }
    }

    if (!empty($values)) {
      $this->execute('SET FOREIGN_KEY_CHECKS = 0');
      $this->batchInsert(self::USER_WALLETS, ['user_id', 'currency', 'wallet_type', 'wallet_account'], $values);
      $this->execute('SET FOREIGN_KEY_CHECKS = 1');
    }

    $this->renameColumn(self::USER_PAYMENT_SETTINGS, 'wallet_type', 'old_wallet_type');
    $this->renameColumn(self::USER_PAYMENT_SETTINGS, 'wallet_account', 'old_wallet_account');
  }

  public function down()
  {
    $this->renameColumn(self::USER_PAYMENT_SETTINGS, 'old_wallet_type', 'wallet_type');
    $this->renameColumn(self::USER_PAYMENT_SETTINGS, 'old_wallet_account', 'wallet_account');

    $this->execute('TRUNCATE ' . self::USER_WALLETS);
  }

  private function getWalletAccountData($walletAccount, $currency)
  {
    // Декодируем старый JSON, извлекаем данные в нужной валюте и снова кодируем
    $walletAccount = ArrayHelper::getValue(Json::decode($walletAccount), $currency);
    return $walletAccount ? Json::encode($walletAccount) : null;
  }
}