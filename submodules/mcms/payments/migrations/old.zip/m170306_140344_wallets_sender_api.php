<?php

use console\components\Migration;

class m170306_140344_wallets_sender_api extends Migration
{
  public function up()
  {
    foreach (['rub', 'usd', 'eur'] as $currency) {
      $this->addColumn('wallets', $currency . '_sender_api_code', $this->string(32));
    }

    $this->addColumn('wallets', 'code', $this->string(32)->after('id'));

    $walletCodes = [
      1 => 'webmoney',
      2 => 'yandex-money',
      3 => 'epayments',
      5 => 'paypal',
      6 => 'paxum',
      7 => 'wireiban',
      10 => 'card',
      11 => 'private-person',
      12 => 'juridical-person',
      13 => 'qiwi',
    ];
    foreach ($walletCodes as $walletId => $walletCode) {
      $this->execute('UPDATE wallets SET code = "' . $walletCode . '" WHERE id = ' . $walletId);
    }
  }

  public function down()
  {
    foreach (['rub', 'usd', 'eur'] as $currency) {
      $this->dropColumn('wallets', $currency . '_sender_api_code');
    }

    $this->dropColumn('wallets', 'code');
  }
}
