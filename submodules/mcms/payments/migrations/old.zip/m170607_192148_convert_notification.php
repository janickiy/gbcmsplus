<?php

use mcms\notifications\models\Notification;
use console\components\Migration;
use yii\helpers\ArrayHelper;

class m170607_192148_convert_notification extends Migration
{
  public function up()
  {
    $paymentsModule = Yii::$app->getModule('payments');
    $paymentsModuleEntity = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => $paymentsModule->id])
      ->getResult();

    // Уведомление о конвертации баланса. Прямичком в браузерные уведомления партнера
    $this->createNotification([
      'module_id' => $paymentsModuleEntity->id,
      'event' => \mcms\payments\components\events\UserBalanceConvert::className(),
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Баланс{transfer.hold} сконвертирован',
        'en' => 'Balance{transfer.hold} converted',
      ],
      'template' => [
        'ru' => 'Баланс{transfer.hold} {transfer.amountFrom} {transfer.currencyFrom} сконвертирован в {transfer.amountTo} {transfer.currencyTo}.',
        'en' => 'Balance{transfer.hold} {transfer.amountFrom} {transfer.currencyFrom} converted in {transfer.amountTo} {transfer.currencyTo}.'
      ],
      'use_owner' => true
    ]);
  }

  public function down()
  {
    Notification::find()->andWhere(['event' => 'mcms\payments\components\events\UserBalanceConvert'])->one()->delete();
  }

  /**
   * @see \m160306_181406_update_notifications::createNotification()
   * @param array $notification
   */
  private function createNotification(array $notification)
  {
    $model = new Notification;
    $model->module_id = ArrayHelper::getValue($notification, 'module_id');
    $model->event = ArrayHelper::getValue($notification, 'event');
    $model->notification_type = ArrayHelper::getValue($notification, 'type');
    $model->header = ArrayHelper::getValue($notification, 'header');
    $model->template = ArrayHelper::getValue($notification, 'template');
    $model->use_owner = ArrayHelper::getValue($notification, 'use_owner', false);

    if ($roles = ArrayHelper::getValue($notification, 'roles', [])) {
      $model->setRoles($roles);
    }

    $model->from = ArrayHelper::getValue($notification, 'from');

    $model->save(false);

  }
}
