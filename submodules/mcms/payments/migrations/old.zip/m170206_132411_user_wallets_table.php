<?php

use console\components\Migration;

class m170206_132411_user_wallets_table extends Migration
{
  const USER_WALLETS = 'user_wallets';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(self::USER_WALLETS, [
      'id' => $this->primaryKey(5),
      'user_id' => 'MEDIUMINT(5) unsigned NOT NULL',
      'currency' => $this->string(3),
      // В следующих миграциях на это поле добавлен внешний ключ
      'wallet_type' => $this->integer(2)->notNull(),
      'wallet_account' => $this->text(),
    ], $tableOptions);

    $this->createIndex(self::USER_WALLETS . '_' . 'user_id_currency_wallet_type_uq', self::USER_WALLETS, ['user_id', 'currency', 'wallet_type'], true);
    $this->addForeignKey(self::USER_WALLETS . '_' . 'user_id_fk', self::USER_WALLETS, 'user_id', 'users', 'id', 'CASCADE', 'CASCADE');
  }

  public function down()
  {
    $this->dropTable(self::USER_WALLETS);
  }
}
