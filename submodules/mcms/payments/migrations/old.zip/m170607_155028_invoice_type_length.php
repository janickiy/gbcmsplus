<?php

use console\components\Migration;

class m170607_155028_invoice_type_length extends Migration
{
  public function up()
  {
    $this->alterColumn('user_balance_invoices', 'type', $this->smallInteger(2)->unsigned()->notNull());
  }

  public function down()
  {
    $this->alterColumn('user_balance_invoices', 'type', 'TINYINT(1) unsigned NOT NULL');
  }
}
