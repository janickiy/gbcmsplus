<?php

use console\components\Migration;

class m170321_131134_paxum_api extends Migration
{
  public function up()
  {
    foreach (['usd', 'eur'] as $currency) {
      $this->insert('payment_systems_api', ['name' => 'Paxum ' . $currency, 'code' => 'paxum', 'currency' => $currency]);
    }
  }

  public function down()
  {
    $this->delete('payment_systems_api', ['code' => 'paypal']);
  }
}
