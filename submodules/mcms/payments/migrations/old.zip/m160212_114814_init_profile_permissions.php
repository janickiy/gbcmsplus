<?php

use yii\db\Schema;
use console\components\Migration;

class m160212_114814_init_profile_permissions extends Migration
{
    use \mcms\common\traits\PermissionMigration;

    public function init()
    {
        parent::init();
        $this->authManager = Yii::$app->authManager;
        $this->permissions = [
          'PaymentsInvestor' => [
            ['profile', 'Display investor profile form', ['investor']],
            ['upload', 'Investor can upload avatar image', ['investor']],
          ],
          'PaymentsReseller' => [
            ['profile', 'Display reseller profile form', ['reseller']],
            ['upload', 'Reseller can upload avatar image', ['reseller']],
          ],
          'PaymentsUsers' => [
            ['profile', 'Display admin profile form', ['admin', 'root']],
            ['upload', 'Admin can upload avatar image', ['admin', 'root']],
          ],
        ];
    }
}
