<?php

use console\components\Migration;

class m151223_193751_payments_pay_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Merchant' => [
        ['result', 'Can view merchant result', ['guest']],
        ['success', 'Can view merchant success', ['guest']],
        ['fail', 'Can view merchant fail', ['guest']],
      ],
      'Investor' => [
        ['to-up-investor-balance', 'Can to up investor balance', ['investor']],
        ['merchant', 'Can submit merchant form', ['investor']],
      ],
      'Payments' => [
        ['payout-wm', 'Can payout to wm wallets', ['admin', 'root']],
      ]
    ];
  }


}
