<?php

use console\components\Migration;

/**
 */
class m180116_122112_investor_balance extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  const TABLE = 'user_payment_settings';


  /**
   * @throws \Exception
   */
  public function up()
  {
    $this->dropColumn(self::TABLE, 'is_reinvest_disabled');
    $this->dropColumn(self::TABLE, 'minimum_investor_balance');
    $this->dropColumn(self::TABLE, 'reinvest_transfer_amount');
    $this->dropColumn('user_payment_settings', 'low_balance_notified_at');
    $this->dropColumn('user_payment_settings', 'is_low_balance_notification_disabled');
    $this->dropColumn('user_payment_settings', 'low_balance_notification_limit');
    $this->removePermission('PaymentsUsersChangeReinvestSettings');
    $this->removePermission('PaymentsUsersBalanceInvestorTransfer');
    $this->revokeRolesPermission('CanUserHaveBalance', ['investor']);
  }

  /**
   * @throws \yii\base\Exception
   * @throws \Exception
   */
  public function down()
  {
    $this->addColumn(self::TABLE, 'is_reinvest_disabled', 'TINYINT(1) NOT NULL DEFAULT 1');
    $this->addColumn(self::TABLE, 'minimum_investor_balance', 'decimal(8,2)');
    $this->addColumn(self::TABLE, 'reinvest_transfer_amount', 'decimal(8,2)');
    $this->addColumn(
      'user_payment_settings',
      'is_low_balance_notification_disabled',
      'tinyint(1) UNSIGNED NOT NULL DEFAULT 1'
    );

    $this->addColumn(
      'user_payment_settings',
      'low_balance_notification_limit',
      'int(10) UNSIGNED NOT NULL DEFAULT 0'
    );

    $this->addColumn('user_payment_settings', 'low_balance_notified_at', 'int(10) UNSIGNED DEFAULT NULL');
    $this->createPermission('PaymentsUsersChangeReinvestSettings', 'Просмотр/редактирование настроек реинвестирования', 'PaymentsPermissions', ['admin', 'root', 'investor']);
    $this->createPermission('PaymentsUsersBalanceInvestorTransfer', 'Перевод денег между счетами', 'PaymentsUsersController', ['admin', 'root']);
    $this->assignRolesPermission('CanUserHaveBalance', ['investor']);
  }
}
