<?php

use console\components\Migration;

class m170717_124807_wallet_is_active extends Migration
{
  public function up()
  {
    $this->dropColumn('wallets', 'is_disabled');
    $this->addColumn('wallets', 'is_active', $this->boolean()->defaultValue(true));
  }

  public function down()
  {
    $this->addColumn('wallets', 'is_disabled', $this->boolean()->defaultValue(true));
    $this->dropColumn('wallets', 'is_active');
  }
}
