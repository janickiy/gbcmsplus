<?php

use console\components\Migration;

class m171113_130209_reseller_convert extends Migration
{
  use \rgk\utils\traits\PermissionTrait;
  public function up()
  {
    $this->createPermission('PaymentsResellerInvoicesConvertModal', 'Модалка конвертации баланса реселлера', 'PaymentsResellerInvoicesController', ['root', 'admin', 'reseller']);
    $this->createPermission('PaymentsResellerInvoicesConvert', 'Конвертация валют', 'PaymentsResellerInvoicesController', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('PaymentsResellerInvoicesConvertModal');
    $this->removePermission('PaymentsResellerInvoicesConvert');
  }
}
