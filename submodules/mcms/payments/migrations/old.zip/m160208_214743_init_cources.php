<?php

use yii\db\Schema;
use console\components\Migration;
use mcms\payments\models\ExchangerCourse as ExchangerCourseModel;

class m160208_214743_init_cources extends Migration
{
  public function up()
  {
    $exchangerApi = Yii::$app->getModule('payments')
      ->api('exchangerCourses', ['useCachedResults' => false]);
    ExchangerCourseModel::storeCurrencyCourses($exchangerApi->getCurrencyCourses());
  }

  public function down()
  {
    echo "m160208_214743_init_cources cannot be reverted.\n";
  }
}
