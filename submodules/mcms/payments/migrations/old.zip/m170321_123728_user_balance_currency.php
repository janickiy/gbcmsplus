<?php

use mcms\payments\components\rbac\ChangeCurrencyRule;
use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170321_123728_user_balance_currency extends Migration
{
  public function up()
  {
    $this->addColumn('user_balances_grouped_by_day', 'user_currency', $this->string(3)->notNull()->defaultValue(''));

    $this->db->createCommand('UPDATE user_balances_grouped_by_day st LEFT JOIN user_payment_settings settings ON settings.user_id = st.user_id
SET st.user_currency = IFNULL(settings.currency, \'\');')->execute();

    $this->dropPrimaryKey('date, user_id, type, is_hold', 'user_balances_grouped_by_day');
    $this->addPrimaryKey('date, user_id, type, is_hold, user_currency', 'user_balances_grouped_by_day', 'date, user_id, type, is_hold, user_currency');
  }

  public function down()
  {
    $this->dropPrimaryKey('date, user_id, type, is_hold, user_currency', 'user_balances_grouped_by_day');
    $this->addPrimaryKey('date, user_id, type, is_hold', 'user_balances_grouped_by_day', 'date, user_id, type, is_hold');
    $this->dropColumn('user_balances_grouped_by_day', 'user_currency');
  }
}
