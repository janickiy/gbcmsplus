<?php

use console\components\Migration;

class m151201_222358_user_payment_add_field_early_payment_amount extends Migration
{
  public function up()
  {
    $this->addColumn('user_payments', 'invoice_amount', 'DECIMAL(8,2) NOT NULL AFTER amount');
  }

  public function down()
  {
    $this->dropColumn('user_payments', 'invoice_amount');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
