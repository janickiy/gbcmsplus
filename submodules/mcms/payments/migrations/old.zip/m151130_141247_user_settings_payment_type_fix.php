<?php

use console\components\Migration;

class m151130_141247_user_settings_payment_type_fix extends Migration
{
  public function up()
  {
    $this->dropForeignKey('user_payment_settings_payment_system_type_id_fk', 'user_payment_settings');
    $this->alterColumn(
      'user_payment_settings',
      'payment_system_type_id',
      'TINYINT(1) UNSIGNED DEFAULT NULL'
    );
    $this->addForeignKey(
      'user_payment_settings_payment_system_type_id_fk',
      'user_payment_settings',
      'payment_system_type_id',
      'payment_system_types',
      'id',
      'SET NULL',
      'SET NULL'
    );
    $this->alterColumn(
      'user_payment_settings',
      'payment_system_account',
      $this->string(255)
    );

  }

  public function down()
  {
    $this->dropForeignKey('user_payment_settings_payment_system_type_id_fk', 'user_payment_settings');
    $this->alterColumn(
      'user_payment_settings',
      'payment_system_type_id',
      'TINYINT(1) UNSIGNED NOT NULL'
    );
    $this->addForeignKey(
      'user_payment_settings_payment_system_type_id_fk',
      'user_payment_settings',
      'payment_system_type_id',
      'payment_system_types',
      'id',
      'CASCADE',
      'CASCADE'
    );
    $this->alterColumn(
      'user_payment_settings',
      'payment_system_account',
      $this->string(255)->notNull()
    );
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
