<?php

use console\components\Migration;

class m161115_125017_user_balance_invoices_add_currency_index extends Migration
{
  const USER_BALANCE_INVOICES = 'user_balance_invoices';
  const USER_ID_CURRENCY_INDEX = 'user_id_currency_index';

  public function up()
  {
    $this->createIndex(self::USER_ID_CURRENCY_INDEX, self::USER_BALANCE_INVOICES, ['user_id', 'currency']);
  }

  public function down()
  {
    $this->dropIndex(self::USER_ID_CURRENCY_INDEX, self::USER_BALANCE_INVOICES);
  }
}
