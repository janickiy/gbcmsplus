<?php

use console\components\Migration;

class m170208_071745_bank_pay_systems extends Migration
{
  const TABLE = 'wallets';

  public function safeUp()
  {
    foreach ($this->getPaySystems() as $wallet) $this->insert(self::TABLE, $wallet);
  }

  public function safeDown()
  {
    foreach ($this->getPaySystems() as $wallet) $this->delete(self::TABLE, ['id' => $wallet['id']]);
  }

  public function getPaySystems()
  {
    $wallets = [
      [
        'id' => 10,
        'name' => serialize(['ru' => 'Карта', 'en' => 'Card']),
        'profit_percent' => -3.5,
        'usd_min_payout_sum' => 100,
        'eur_min_payout_sum' => 100,
        'rub_min_payout_sum' => 3000,
      ],
      [
        'id' => 11,
        'name' => serialize(['ru' => 'ИП', 'en' => 'Private person']),
        'profit_percent' => 6,
        'usd_min_payout_sum' => 0,
        'eur_min_payout_sum' => 0,
        'rub_min_payout_sum' => 30000,
      ],
      [
        'id' => 12,
        'name' => serialize(['ru' => 'Юр. лицо', 'en' => 'Juridical person']),
        'profit_percent' => 8,
        'usd_min_payout_sum' => 0,
        'eur_min_payout_sum' => 0,
        'rub_min_payout_sum' => 50000,
      ],
      [
        'id' => 13,
        'name' => serialize(['ru' => 'Qiwi', 'en' => 'Qiwi']),
        'profit_percent' => -1.5,
        'usd_min_payout_sum' => 0,
        'eur_min_payout_sum' => 0,
        'rub_min_payout_sum' => 100,
      ],
    ];

    return $wallets;
  }
}
