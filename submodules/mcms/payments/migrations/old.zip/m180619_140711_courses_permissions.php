<?php

use console\components\Migration;

class m180619_140711_courses_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('PaymentsPaymentsCourse', 'Курсы конвертации валют', 'PaymentsPaymentsController', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('PaymentsPaymentsCourse');
  }
}
