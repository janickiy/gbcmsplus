<?php

use console\components\Migration;

class m170315_111721_yandex_money_paysystem extends Migration
{
  public function up()
  {
    $this->insert('payment_systems_api', [
      'name' => 'Yandex.Money',
      'code' => 'yandex-money',
      'currency' => 'rub',
    ]);
  }

  public function down()
  {
    $this->delete('payment_systems_api', ['code' => 'yandex-money']);
  }
}
