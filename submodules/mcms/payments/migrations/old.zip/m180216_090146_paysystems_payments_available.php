<?php

use console\components\Migration;

class m180216_090146_paysystems_payments_available extends Migration
{
  const COLUMN = 'is_mgmp_payments_enabled';

  public function up()
  {
    $this->addColumn('wallets', self::COLUMN, $this->boolean()->defaultValue(true));
    $this->update('wallets', [self::COLUMN => 0], ['code' => 'webmoney']);
  }

  public function down()
  {
    $this->dropColumn('wallets', self::COLUMN);
  }
}
