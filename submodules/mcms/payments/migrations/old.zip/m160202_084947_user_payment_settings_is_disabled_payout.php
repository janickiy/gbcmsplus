<?php

use yii\db\Schema;
use console\components\Migration;

class m160202_084947_user_payment_settings_is_disabled_payout extends Migration
{
  const TABLE = 'user_payment_settings';
  public function up()
  {
    $this->addColumn(self::TABLE, 'is_auto_payout_disabled', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 1');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'is_auto_payout_disabled');
  }
}
