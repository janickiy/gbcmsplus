<?php

use console\components\Migration;

/**
 * Class m170721_063416_reseller_invoices
 */
class m170721_063416_reseller_invoices extends Migration
{
  use \rgk\utils\traits\PermissionTrait;


  /**
   *
   */
  public function up()
  {
    $this->createPermission('PaymentsResellerInvoicesController', 'Контроллер ResellerInvoices', 'PaymentsModule');
    $this->createPermission('PaymentsResellerInvoicesIndex', 'Просмотр инвойсов реселлера', 'PaymentsResellerInvoicesController', ['root', 'admin', 'reseller']);

    $this->addColumn('user_balance_invoices', 'file', $this->string(512)->after('type')->comment('имя файла к штрафу/компенсации (например экселька от оператора)'));

    $this->addColumn('user_balance_invoices', 'date', $this->date()->after('created_at')->comment('дата, за которую инвойс'));
    $this->createIndex('user_balance_invoices_date_user_index', 'user_balance_invoices', ['date', 'user_id']);
    $this->update('user_balance_invoices', [
      'date' => new \yii\db\Expression('FROM_UNIXTIME(created_at)')
    ]);

    $this->addColumn('user_balance_invoices', 'mgmp_id', $this->integer()->after('id')->comment('внутренний ID инвойса из MGMP'));
    $this->addColumn('user_balance_invoices', 'updated_at', $this->integer(10)->unsigned()->after('date')->comment('время обновления инвойса'));
    $this->update('user_balance_invoices', [
      'updated_at' => new \yii\db\Expression('created_at')
    ]);
  }

  /**
   *
   */
  public function down()
  {
    $this->dropColumn('user_balance_invoices', 'updated_at');
    $this->dropColumn('user_balance_invoices', 'mgmp_id');

    $this->dropIndex('user_balance_invoices_date_user_index', 'user_balance_invoices');
    $this->dropColumn('user_balance_invoices', 'date');
    $this->dropColumn('user_balance_invoices', 'file');

    $this->removePermission('PaymentsResellerInvoicesIndex');
    $this->removePermission('PaymentsResellerInvoicesController');
  }
}
