<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170209_130957_investor_wallet_update extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PaymentsCanViewAdditionalParameters', 'Показывать дополнительные параметры при редактировании настроек выплат', 'PaymentsPermissions', ['root', 'admin']);

    $this->assignRolesPermission('PaymentsUsersWalletModal', ['investor']);
    $this->assignRolesPermission('PromoPersonalProfitsUpdateModal', ['investor']);
    $this->assignRolesPermission('PaymentsUsersUpdateSettings', ['investor']);

    $this->revokeRolesPermission('PaymentsResellerSettings', ['reseller', 'manager']);
    $this->revokeRolesPermission('PaymentsCanChangeCurrency', ['investor']);


  }

  public function down()
  {
    $this->revokeRolesPermission('PaymentsUsersWalletModal', ['investor']);
    $this->revokeRolesPermission('PromoPersonalProfitsUpdateModal', ['investor']);
    $this->revokeRolesPermission('PaymentsUsersUpdateSettings', ['investor']);

    $this->assignRolesPermission('PaymentsResellerSettings', ['reseller', 'manager']);
    $this->assignRolesPermission('PaymentsCanChangeCurrency', ['investor']);

    $this->removePermission('PaymentsCanViewAdditionalParameters');
  }
}
