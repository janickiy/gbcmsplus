<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170303_131645_payment_systems_api_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PaymentsPaymentSystemsApiController', 'Контроллер PaymentSystemsApi', 'PaymentsModule');
    $this->createPermission('PaymentsPaymentSystemsApiList', 'Просмотр списка API платежных систем', 'PaymentsPaymentSystemsApiController', ['root', 'admin']);
  }

  public function down()
  {
    $this->removePermission('PaymentsPaymentSystemsApiList');
    $this->removePermission('PaymentsPaymentSystemsApiController');
  }
}
