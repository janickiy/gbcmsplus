<?php

use console\components\Migration;

/**
 * Class m170913_123803_ps_enable_disable
 */
class m170913_123803_ps_enable_disable extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  /**
   *
   */
  public function up()
  {
    $this->createPermission('PaymentsWalletEnable', 'Активировать платежную систему', 'PaymentsWalletController', ['root', 'admin', 'reseller']);
    $this->createPermission('PaymentsWalletDisable', 'Дективировать платежную систему', 'PaymentsWalletController', ['root', 'admin', 'reseller']);
  }

  /**
   */
  public function down()
  {
    $this->removePermission('PaymentsWalletEnable');
    $this->removePermission('PaymentsWalletDisable');
  }

}
