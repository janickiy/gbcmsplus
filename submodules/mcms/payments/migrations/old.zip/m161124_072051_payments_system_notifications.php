<?php

use console\components\Migration;
use mcms\notifications\models\Notification;

class m161124_072051_payments_system_notifications extends Migration
{
  public function up()
  {
    $this->db
      ->createCommand("UPDATE `notifications` SET `is_system` = 1 WHERE event IN(
                      'mcms\payments\components\events\RegularPaymentCreated',
                      'mcms\payments\components\events\PaymentStatusUpdated',
                      'mcms\payments\components\events\UserBalanceInvoiceMulct',
                      'mcms\payments\components\events\UserBalanceInvoiceCompensation',
                      'mcms\payments\components\events\EarlyPaymentAdminCreated')")
      ->execute()
    ;

  }

  public function down()
  {
    $this->db
      ->createCommand("UPDATE `notifications` SET `is_system` = 0 WHERE event IN(
                      'mcms\payments\components\events\RegularPaymentCreated',
                      'mcms\payments\components\events\PaymentStatusUpdated',
                      'mcms\payments\components\events\UserBalanceInvoiceMulct',
                      'mcms\payments\components\events\UserBalanceInvoiceCompensation',
                      'mcms\payments\components\events\EarlyPaymentAdminCreated')")
      ->execute()
    ;
  }
}
