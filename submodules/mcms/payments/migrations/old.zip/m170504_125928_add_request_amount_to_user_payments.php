<?php

use yii\db\Expression;
use console\components\Migration;

class m170504_125928_add_request_amount_to_user_payments extends Migration
{
  public function up()
  {
    $this->addColumn('user_payments', 'request_amount', 'DECIMAL(9,2) NULL DEFAULT NULL COMMENT \'Запрошенная сумма партнера с учетом конвертации валют\' AFTER amount ');
    $this->update('user_payments', [ 'request_amount' => new Expression('invoice_amount')]);
  }

  public function down()
  {
    $this->dropColumn('user_payments', 'request_amount');
  }
}
