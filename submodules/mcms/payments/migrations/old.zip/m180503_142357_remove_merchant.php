<?php

use console\components\Migration;

class m180503_142357_remove_merchant extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->removePermission('PaymentsMerchantSuccess');
    $this->removePermission('PaymentsMerchantFail');
    $this->removePermission('PaymentsMerchantResult');
    $this->removePermission('PaymentsMerchantController');
  }

  public function down()
  {
    $this->createPermission('PaymentsMerchantController', 'Контроллер Merchant', 'PaymentsModule');
    $this->createPermission('PaymentsMerchantSuccess', 'Получение сообщения об успехе', 'PaymentsMerchantController');
    $this->createPermission('PaymentsMerchantFail', 'Получение сообщения об ошибке', 'PaymentsMerchantController');
    $this->createPermission('PaymentsMerchantResult', 'Пополнение баланса', 'PaymentsMerchantController');
  }
}
