<?php

use console\components\Migration;

class m170228_143959_wallet_is_multiply extends Migration
{
  const USER_WALLETS = 'user_wallets';

  public function up()
  {
    $this->addColumn('wallets', 'is_multiple', $this->smallInteger(1)->unsigned()->notNull()->defaultValue(0));

    $this->createIndex(self::USER_WALLETS . '_user_id_index', self::USER_WALLETS, 'user_id');
    $this->dropIndex(self::USER_WALLETS . '_' . 'user_id_currency_wallet_type_uq', self::USER_WALLETS);
  }

  public function down()
  {
    $this->dropColumn('wallets', 'is_multiple');
    $this->dropIndex(self::USER_WALLETS . '_user_id_index', self::USER_WALLETS);
    $this->createIndex(self::USER_WALLETS . '_' . 'user_id_currency_wallet_type_uq', self::USER_WALLETS, ['user_id', 'currency', 'wallet_type'], true);
  }
}
