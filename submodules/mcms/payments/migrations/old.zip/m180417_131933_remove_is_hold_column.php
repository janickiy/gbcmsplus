<?php

use console\components\Migration;

class m180417_131933_remove_is_hold_column extends Migration
{
  const UUPDG_TABLE = 'user_unhold_profit_day_group';
  const UBI_TABLE = 'user_balance_invoices';
  const UBGD_TABLE = 'user_balances_grouped_by_day';

  public function up()
  {
    $sql = <<<SQL
    DROP TABLE IF EXISTS `temporary_ubgd`;
    CREATE TABLE IF NOT EXISTS temporary_ubgd AS (
        SELECT * FROM user_balances_grouped_by_day
      );
SQL;
    $this->db->createCommand($sql)->execute();

    // Удаляем строки с холдами
    $this->delete(self::UBI_TABLE, [
      'is_hold' => 1,
      'user_payment_id' => null
    ]);
    $this->delete(self::UBGD_TABLE, [
      'is_hold' => 1
    ]);

    // Удаляем переводы с холдов и на холды
    $this->delete(self::UBI_TABLE, [
      'type' => 8
    ]);

    $this->dropColumn(self::UBI_TABLE, 'is_hold');
    $this->dropPrimaryKey(
      'date_user_id_type_is_hold_pk',
      'user_balances_grouped_by_day'
    );
    $this->dropColumn(self::UBGD_TABLE, 'is_hold');
    $this->addPrimaryKey(
      'date_user_id_type_is_hold_pk',
      'user_balances_grouped_by_day',
      ['date', 'user_id', 'type']
    );
    $this->dropTable(self::UUPDG_TABLE);

    $sql = <<<SQL
INSERT INTO `user_balances_grouped_by_day`
        (`date`, `user_id`, `type`, `profit_rub`, `profit_usd`, `profit_eur`, `user_currency`)
SELECT `date`, `user_id`, `type`, SUM(`profit_rub`), SUM(`profit_usd`), SUM(`profit_eur`), `user_currency`
FROM temporary_ubgd GROUP BY date, user_id, type, user_currency ORDER BY NULL
ON DUPLICATE KEY UPDATE profit_rub = VALUES(profit_rub), profit_eur = VALUES(profit_eur), profit_usd = VALUES(profit_usd)
SQL;
    $this->db->createCommand($sql)->execute();

  }

  public function down()
  {
    $this->addColumn(self::UBI_TABLE, 'is_hold', 'TINYINT(1) UNSIGNED DEFAULT \'0\' NOT NULL');
    $this->addColumn(self::UBGD_TABLE, 'is_hold', 'TINYINT(1) UNSIGNED NOT NULL');

    $this->createTable(self::UUPDG_TABLE, [
      'user_id' => 'MEDIUMINT(5) unsigned NOT NULL',
      'landing_id' => 'mediumint(5) unsigned NOT NULL',
      'date' => 'date NOT NULL',
      'type' => 'TINYINT(1) NOT NULL',
      'sum_profit_rub' => 'DECIMAL(8,2) NOT NULL',
      'sum_profit_eur' => 'DECIMAL(8,2) NOT NULL',
      'sum_profit_usd' => 'DECIMAL(8,2) NOT NULL',
    ]);
    $this->addPrimaryKey('type_user_id_landing_id_date_pk', self::UUPDG_TABLE, ['type', 'user_id', 'landing_id', 'date']);
    $this->createIndex('date_user_id_index', self::UUPDG_TABLE, ['date', 'user_id']);
  }
}
