<?php

use console\components\Migration;

class m170403_111616_user_payments_error_info extends Migration
{
  public function up()
  {
    $this->addColumn('user_payments', 'error_info', $this->string(255)->notNull()->defaultValue(''));
    $this->update('user_payments', ['status' => 6], ['status' => 4]); // раньше статус 4 - это были отложенные выплаты. Теперь 4 - это ошибка выплаты. А отложенные = 6.
  }

  public function down()
  {
    $this->update('user_payments', ['status' => 4], ['status' => 6]);
    $this->dropColumn('user_payments', 'error_info');
  }
}
