<?php

use yii\db\Schema;
use console\components\Migration;

class m160226_142853_payments_permission_rules extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Reseller' => [
        ['view-payment', 'Can view partner payments', ['reseller'], [
          'PaymentsViewPaymentRule' => \mcms\payments\components\rbac\ViewPaymentRule::className()
        ]],
        ['auto-payout', 'Can auto payout to wallet', ['reseller'], [
          'PaymentsAutoPayoutRule' => \mcms\payments\components\rbac\AutoPayoutRule::className()
        ]],
      ],
      'Payments' => [
        ['auto-payout', 'Can auto payout to wallet', ['root', 'admin'], [
          'PaymentsAutoPayoutRule' => \mcms\payments\components\rbac\AutoPayoutRule::className()
        ]]
      ]
    ];
  }
}
