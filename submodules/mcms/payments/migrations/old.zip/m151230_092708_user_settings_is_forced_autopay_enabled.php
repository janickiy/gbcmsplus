<?php

use console\components\Migration;

class m151230_092708_user_settings_is_forced_autopay_enabled extends Migration
{

  public function up()
  {
    $this->addColumn('user_payment_settings', 'is_forced_autopay_enabled', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
  }

  public function down()
  {
    $this->dropColumn('user_payment_settings', 'is_forced_autopay_enabled');
  }
}