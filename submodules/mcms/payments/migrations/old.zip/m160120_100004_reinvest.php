<?php

use yii\db\Schema;
use console\components\Migration;

class m160120_100004_reinvest extends Migration
{
  const TABLE = 'user_payment_settings';
  public function safeUp()
  {
    $this->addColumn(self::TABLE, 'minimum_investor_balance', 'decimal(8,2)');
    $this->addColumn(self::TABLE, 'reinvest_transfer_amount', 'decimal(8,2)');
    $this->addColumn(self::TABLE, 'is_reinvest_disabled', 'TINYINT(1) NOT NULL DEFAULT 1');
    $this->createIndex(self::TABLE . '_user_id_is_reinvest_disabled_index', self::TABLE, ['user_id', 'is_reinvest_disabled']);
  }

  public function safeDown()
  {
    $this->dropIndex(self::TABLE . '_user_id_is_reinvest_disabled_index', self::TABLE);
    $this->dropColumn(self::TABLE, 'minimum_investor_balance');
    $this->dropColumn(self::TABLE, 'reinvest_transfer_amount');
    $this->dropColumn(self::TABLE, 'is_reinvest_disabled');
  }
}
