<?php

use console\components\Migration;

class m160811_124510_unhold_profits_add_type_column extends Migration
{
  const TABLE = 'user_unhold_profit_day_group';

  public function up()
  {
    $this->dropPrimaryKey('user_id_landing_id_date', self::TABLE);
    $this->addColumn(self::TABLE, 'type', 'tinyint(1) not null after date');
    $this->addPrimaryKey('type_user_id_landing_id_date_pk', self::TABLE, ['type', 'user_id', 'landing_id', 'date']);
    $this->createIndex('date_user_id_index', self::TABLE, ['date', 'user_id']);
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'type');
    $this->dropPrimaryKey('type_user_id_landing_id_date_pk', self::TABLE);
    $this->addPrimaryKey('user_id_landing_id_date', self::TABLE, ['user_id', 'landing_id', 'date']);
    $this->dropIndex('date_user_id_index', self::TABLE);
  }
}
