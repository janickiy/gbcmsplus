<?php

use console\components\Migration;
use yii\db\Query;
use yii\helpers\ArrayHelper;
use yii\helpers\Json;

class m161012_091647_refactor_wallets extends Migration
{
  /**
   * @return Query
   */
  private function getPaymentSettingsQuery()
  {
    return (new Query())->from('user_payment_settings')->where(
      [
        'or',
        ['currency' => 'rub', 'wallet_type' => '{"rub":"2"}'],
        ['currency' => 'usd', 'wallet_type' => '{"usd":"5"}'],
        ['currency' => 'eur', 'wallet_type' => '{"eur":"5"}']
      ]
    );
  }

  /**
   * @return Query
   */
  private function getPaymentsQuery()
  {
    return (new Query())->from('user_payments')->where(['wallet_type' => ['2', '5']]);
  }
  
  public function up()
  {
    foreach ($this->getPaymentSettingsQuery()->each() as $settings) {
      if (!$walletAccount = Json::decode($settings['wallet_account'])) {
        continue;
      }

      if ($settings['currency'] == 'rub' && $email = ArrayHelper::remove($walletAccount['rub'], 'email')) {
        $walletAccount['rub']['wallet'] = $email;
      }
      if ($settings['currency'] == 'usd' && $nameLastName = ArrayHelper::remove($walletAccount['usd'], 'nameLastName')) {
        $walletAccount['usd']['name'] = $nameLastName;
      }
      if ($settings['currency'] == 'eur' && $nameLastName = ArrayHelper::remove($walletAccount['eur'], 'nameLastName')) {
        $walletAccount['eur']['name'] = $nameLastName;
      }
      $this->update(
        'user_payment_settings',
        ['wallet_account' => Json::encode($walletAccount)],
        ['user_id' => $settings['user_id']]
      );
    }

    foreach ($this->getPaymentsQuery()->each() as $payment) {
      if (!$paymentInfo = Json::decode($payment['info'])) {
        continue;
      }

      if ($payment['currency'] == 'rub' && $email = ArrayHelper::remove($paymentInfo['recipient'], 'email')) {
        $paymentInfo['recipient']['wallet'] = $email;
      }
      if ($payment['currency'] == 'usd' && $nameLastName = ArrayHelper::remove($paymentInfo['recipient'], 'nameLastName')) {
        $paymentInfo['recipient']['name'] = $nameLastName;
      }
      if ($payment['currency'] == 'eur' && $nameLastName = ArrayHelper::remove($paymentInfo['recipient'], 'nameLastName')) {
        $paymentInfo['recipient']['name'] = $nameLastName;
      }
      $this->update('user_payments', ['info' => Json::encode($paymentInfo)], ['id' => $payment['id']]);
    }
  }

  public function down()
  {
    foreach ($this->getPaymentSettingsQuery()->each() as $settings) {
      if (!$walletAccount = Json::decode($settings['wallet_account'])) {
        continue;
      }

      if ($settings['currency'] == 'rub' && $wallet = ArrayHelper::remove($walletAccount['rub'], 'wallet')) {
        $walletAccount['rub']['email'] = $wallet;
      }
      if ($settings['currency'] == 'usd' && $name = ArrayHelper::remove($walletAccount['usd'], 'name')) {
        $walletAccount['usd']['nameLastName'] = $name;
      }
      if ($settings['currency'] == 'eur' && $name = ArrayHelper::remove($walletAccount['eur'], 'name')) {
        $walletAccount['eur']['nameLastName'] = $name;
      }
      $this->update(
        'user_payment_settings',
        ['wallet_account' => Json::encode($walletAccount)],
        ['user_id' => $settings['user_id']]
      );
    }

    foreach ($this->getPaymentsQuery()->each() as $payment) {
      if (!$paymentInfo = Json::decode($payment['info'])) {
        continue;
      }

      if ($payment['currency'] == 'rub' && $wallet = ArrayHelper::remove($paymentInfo['recipient'], 'wallet')) {
        $paymentInfo['recipient']['email'] = $wallet;
      }
      if ($payment['currency'] == 'usd' && $name = ArrayHelper::remove($paymentInfo['recipient'], 'name')) {
        $paymentInfo['recipient']['nameLastName'] = $name;
      }
      if ($payment['currency'] == 'eur' && $name = ArrayHelper::remove($paymentInfo['recipient'], 'name')) {
        $paymentInfo['recipient']['nameLastName'] = $name;
      }
      $this->update('user_payments', ['info' => Json::encode($paymentInfo)], ['id' => $payment['id']]);
    }
  }
}
