<?php

use console\components\Migration;

class m170303_115948_reseller_checkout_log_remove extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  const TABLE_R_P_LOG = '{{%reseller_checkout_log}}';
  const TABLE = '{{%reseller_checkout}}';

  public function up()
  {
    $this->dropTable(self::TABLE_R_P_LOG);
    $this->dropColumn(self::TABLE, 'is_closed');

    $this->removePermission('PaymentsResellerCheckoutEnable');
    $this->removePermission('PaymentsResellerCheckoutDisable');
  }

  public function down()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->addColumn(self::TABLE, 'is_closed', $this->smallInteger(1)->unsigned()->notNull()->defaultValue(0));

    $this->createTable(self::TABLE_R_P_LOG, [
      'id' => $this->primaryKey(5),
      'date' => $this->date(),
      'sum' => $this->decimal(8, 2)->unsigned(),
      'currency' => 'ENUM("rub", "usd", "eur")',
      'description' => $this->text()
    ], $tableOptions);

    $this->createPermission('PaymentsResellerCheckoutEnable', 'Активация рассчетного периода', 'PaymentsResellerCheckoutController');
    $this->createPermission('PaymentsResellerCheckoutDisable', 'Деактивация рассчетного периода', 'PaymentsResellerCheckoutController');

  }
}
