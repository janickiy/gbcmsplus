<?php

use rgk\settings\models\Setting;
use console\components\Migration;

class m180205_081356_remove_settings_exchanger_source extends Migration
{
  const SETTING = 'settings.payments.exchanger.source';

  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
  }

  public function up()
  {
    $this->settingsBuilder->removeSetting(self::SETTING);
  }

  public function down()
  {
    $title = ['ru' => 'Источник обменника', 'en' => 'Exchanger source'];
    $permissions = ['EditModuleSettingsPayments', 'PaymentsEditWmSettings'];
    $category = 'app.common.form_group_payments_webmoney';
    $validators = [["required"]];
    $this->settingsBuilder->createSetting($title, [], self::SETTING, $permissions, Setting::TYPE_LISTS, $category, 'wme', $validators);
  }
}
