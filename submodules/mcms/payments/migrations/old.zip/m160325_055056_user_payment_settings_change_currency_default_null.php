<?php

use console\components\Migration;

class m160325_055056_user_payment_settings_change_currency_default_null extends Migration
{
  const TABLE = 'user_payment_settings';
  public function up()
  {
    $this->alterColumn(self::TABLE, 'currency', 'varchar(3)');
  }

  public function down()
  {
    $this->alterColumn(self::TABLE, 'currency', 'varchar(3) NOT NULL');
  }
}
