<?php

use console\components\Migration;

class m151230_092210_user_settings_admin_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Users' => [
        ['CanChangeAdminSettings', 'Can change admin settings for other users such as forced autopay and disabling payments', ['root', 'admin']],
      ],
    ];
  }
}