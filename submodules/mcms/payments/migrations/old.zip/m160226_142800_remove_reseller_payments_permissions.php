<?php

use yii\db\Schema;
use console\components\Migration;

class m160226_142800_remove_reseller_payments_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;

    $this->removePermission('PaymentsResellerAutoPayout');
    $this->removePermission('PaymentsResellerViewPayment');
    $this->removePermission('PaymentsResellerAutoPayoutRule');
    $this->removePermission('PaymentsResellerViewPaymentRule');
  }
}
