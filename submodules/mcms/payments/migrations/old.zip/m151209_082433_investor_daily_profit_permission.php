<?php

use console\components\Migration;

class m151209_082433_investor_daily_profit_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Investor' => [
        ['daily-profit', 'Can view daily profit', ['investor']],
      ]
    ];
  }
}