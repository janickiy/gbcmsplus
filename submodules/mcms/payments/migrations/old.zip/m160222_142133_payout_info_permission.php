<?php

use yii\db\Schema;
use console\components\Migration;

class m160222_142133_payout_info_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Payments' => [
        ['payout-info', 'Can view payout info', ['root', 'admin', 'reseller']]
      ]
    ];
  }

}
