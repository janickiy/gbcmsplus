<?php

use console\components\Migration;

class m170317_153620_reseller_checkout_view_modal extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->removePermission('PaymentsResellerCheckoutUpdateModal');
    $this->createPermission('PaymentsResellerCheckoutViewModal', 'Просмотр детальной информации по выплате', 'PaymentsResellerCheckoutController');

  }

  public function down()
  {
    $this->createPermission('PaymentsResellerCheckoutUpdateModal', 'Редактирование записи в логе', 'PaymentsResellerCheckoutController');
    $this->removePermission('PaymentsResellerCheckoutViewModal');
  }
}
