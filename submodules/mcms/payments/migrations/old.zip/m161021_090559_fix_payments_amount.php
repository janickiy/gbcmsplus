<?php

use console\components\Migration;

class m161021_090559_fix_payments_amount extends Migration
{
  const USER_BALANCE_INVOICES = 'user_balance_invoices';
  const USER_PAYMENTS = 'user_payments';

  public function safeUp()
  {
    $this->alterColumn(self::USER_BALANCE_INVOICES, 'amount', 'DECIMAL(9,2)');
    $this->alterColumn(self::USER_PAYMENTS, 'amount', 'DECIMAL(9,2)');
    $this->alterColumn(self::USER_PAYMENTS, 'invoice_amount', 'DECIMAL(9,2)');
  }

  public function safeDown()
  {
    $this->alterColumn(self::USER_PAYMENTS, 'invoice_amount', 'DECIMAL(8,2)');
    $this->alterColumn(self::USER_PAYMENTS, 'amount', 'DECIMAL(8,2)');
    $this->alterColumn(self::USER_BALANCE_INVOICES, 'amount', 'DECIMAL(8,2)');
  }
}
