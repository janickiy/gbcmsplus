<?php

use console\components\Migration;

class m170310_124722_wallets_sender_api_id extends Migration
{
  public function up()
  {
    foreach (['rub', 'usd', 'eur'] as $currency) {
      $this->dropColumn('wallets', $currency . '_sender_api_code');
    }

    foreach (['rub', 'usd', 'eur'] as $currency) {
      $this->addColumn('wallets', $currency . '_sender_api_id', $this->smallInteger(3)->unsigned());
    }
  }

  public function down()
  {
    foreach (['rub', 'usd', 'eur'] as $currency) {
      $this->dropColumn('wallets', $currency . '_sender_api_id');
    }

    foreach (['rub', 'usd', 'eur'] as $currency) {
      $this->addColumn('wallets', $currency . '_sender_api_code', $this->string(32));
    }
  }
}
