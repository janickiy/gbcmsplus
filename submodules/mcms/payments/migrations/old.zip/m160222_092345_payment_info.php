<?php

use yii\db\Schema;
use console\components\Migration;

class m160222_092345_payment_info extends Migration
{
  const TABLE = 'user_payments';
  public function up()
  {
    $this->addColumn(self::TABLE, 'info', 'TEXT DEFAULT NULL');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'info');
  }
}
