<?php

use console\components\Migration;

class m180614_132331_ps_currencies extends Migration
{
  const TABLE = 'wallets';

  public function up()
  {
    $this->addColumn(self::TABLE, 'is_rub', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
    $this->addColumn(self::TABLE, 'is_usd', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
    $this->addColumn(self::TABLE, 'is_eur', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');

    $this->update(self::TABLE,
      ['is_rub' => 1],
      ['code' => [
        'webmoney',
        'card',
        'juridical-person',
        'private-person',
        'yandex-money',
        'qiwi',
      ]]
    );
    $this->update(self::TABLE,
      ['is_usd' => 1, 'is_eur' => 1],
      ['code' => [
        'epayments',
        'webmoney',
        'wireiban',
        'paxum',
        'paypal',
        'card',
      ]]
    );
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'is_rub');
    $this->dropColumn(self::TABLE, 'is_usd');
    $this->dropColumn(self::TABLE, 'is_eur');
  }
}
