<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170317_143014_process_payout_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PaymentsPaymentsProcessPayout', '', 'PaymentsPaymentsController', ['root', 'admin', 'reseller']);
    $this->createPermission('PaymentsPaymentsProcessPayoutModal', '', 'PaymentsPaymentsController', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('PaymentsPaymentsProcessPayout');
    $this->removePermission('PaymentsPaymentsProcessPayoutModal');
  }
}
