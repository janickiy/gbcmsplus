<?php

use console\components\Migration;

class m170830_123423_reseller_payments_refactoring extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->removePermission('PaymentsResellerIndex');
    $this->removePermission('PaymentsResellerSettings');
    $this->createPermission('PaymentsPaymentsResellerSettings', 'Установка настроек платежей', 'PaymentsPaymentsController', ['reseller']);
    $this->removePermission('PaymentsResellerInvoices');
    $this->removePermission('PaymentsResellerPartnerPayments');
    $this->assignRolesPermission('PaymentsPaymentsIndex', ['reseller']);
    $this->removePermission('PaymentsResellerDailyProfit');
    $this->movePermission('PaymentsAutoPayoutRule', 'PaymentsResellerAutoPayout', 'PaymentsPermissions');

    $this->assignRolesPermission('PaymentsAutoPayoutRule', ['reseller']); // слетел пермишен, т.к. ресу был назначен родительский пермишен.

    $this->removePermission('PaymentsResellerAutoPayout');
    $this->movePermission('PaymentsViewPaymentRule', 'PaymentsResellerViewPayment', 'PaymentsPaymentsView');
    $this->movePermission('PaymentsUpdatePaymentRule', 'PaymentsResellerUpdatePayment', 'PaymentsPaymentsUpdate');
    $this->removePermission('PaymentsResellerViewPayment');
    $this->assignRolesPermission('PaymentsPaymentsView', ['reseller']);
    $this->removePermission('PaymentsResellerCreatePayment');
    $this->removePermission('PaymentsResellerUpdatePayment');
    $this->assignRolesPermission('PaymentsPaymentsUpdate', ['reseller']);
    $this->assignRolesPermission('PaymentsPaymentsUserDetail', ['reseller']);
    $this->removePermission('PaymentsResellerUserDetail');
    $this->removePermission('PaymentsResellerFindUser');

    $this->removePermission('PaymentsResellerAddCompensation');
    $this->removePermission('PaymentsResellerAddPenalty');
    $this->createPermission('PaymentsPaymentsAddCompensation', 'Добавление компенсации реселлером', 'PaymentsPaymentsController', ['reseller']);
    $this->createPermission('PaymentsPaymentsAddPenalty', 'Добавление штрафа реселлером', 'PaymentsPaymentsController', ['reseller']);

    $this->removePermission('PaymentsResellerController');

  }

  public function down()
  {
    $this->createPermission('PaymentsResellerController', 'Контроллер Reseller', 'PaymentsModule');
    $this->removePermission('PaymentsPaymentsAddCompensation');
    $this->removePermission('PaymentsPaymentsAddPenalty');
    $this->createPermission('PaymentsResellerAddCompensation', 'Добавление компенсации реселлером', 'PaymentsPaymentsController', ['reseller']);
    $this->createPermission('PaymentsResellerAddPenalty', 'Добавление штрафа реселлером', 'PaymentsPaymentsController', ['reseller']);

    $this->createPermission('PaymentsResellerFindUser', 'Поиск партнеров реселлером', 'PaymentsResellerController', ['reseller']);
    $this->createPermission('PaymentsResellerUserDetail', 'Редактирование платежей реселлером', 'PaymentsResellerController', ['reseller']);
    $this->revokeRolesPermission('PaymentsPaymentsUserDetail', ['reseller']);
    $this->revokeRolesPermission('PaymentsPaymentsUpdate', ['reseller']);
    $this->createPermission('PaymentsResellerUpdatePayment', 'Редактирование платежей реселлером', 'PaymentsResellerController', ['reseller']);
    $this->movePermission('PaymentsUpdatePaymentRule', 'PaymentsPaymentsUpdate', 'PaymentsResellerUpdatePayment');
    $this->createPermission('PaymentsResellerCreatePayment', 'Создание платежа реселлером', 'PaymentsResellerController');
    $this->revokeRolesPermission('PaymentsPaymentsView', ['reseller']);
    $this->createPermission('PaymentsResellerViewPayment', 'Просмотр платежей партнера', 'PaymentsResellerController', ['reseller']);
    $this->movePermission('PaymentsViewPaymentRule', 'PaymentsPaymentsView', 'PaymentsResellerViewPayment');
    $this->createPermission('PaymentsResellerAutoPayout', 'Автоплатеж в кошелек', 'PaymentsResellerController', ['reseller', 'admin']);
    $this->movePermission('PaymentsAutoPayoutRule', 'PaymentsPermissions', 'PaymentsResellerAutoPayout');
    $this->createPermission('PaymentsResellerDailyProfit', 'Просмотр дневного дохода', 'PaymentsResellerController', ['reseller']);
    $this->revokeRolesPermission('PaymentsPaymentsIndex', ['reseller']);
    $this->createPermission('PaymentsResellerPartnerPayments', 'Просмотр платежей партнера', 'PaymentsResellerController', ['reseller']);
    $this->createPermission('PaymentsResellerInvoices', 'Просмотр баланса счетов', 'PaymentsResellerController', ['reseller']);
    $this->removePermission('PaymentsPaymentsResellerSettings');
    $this->createPermission('PaymentsResellerSettings', 'Установка настроек платежей', 'PaymentsResellerController', ['reseller']);
    $this->createPermission('PaymentsResellerIndex', 'Просмотр операций над балансом и платежей', 'PaymentsResellerController', ['reseller']);
  }
}
