<?php

use console\components\Migration;

class m170613_091055_user_payments_reseller_individual_percent extends Migration
{
  public function up()
  {
    $this->addColumn('user_payments', 'reseller_individual_percent', $this->decimal(5, 2)->after('reseller_paysystem_percent'));
  }

  public function down()
  {
    $this->dropColumn('user_payments', 'reseller_individual_percent');
  }
}
