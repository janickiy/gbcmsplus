<?php

use yii\db\Schema;
use console\components\Migration;

class m160301_115720_user_payment_settings_last_payment_generated extends Migration
{
  const TABLE = 'user_payment_settings';
  const COLUMN = 'last_generated_payment';

  public function up()
  {
    $this->addColumn(self::TABLE, self::COLUMN, 'date');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, self::COLUMN);
  }
}
