<?php

use console\components\Migration;

class m170731_165359_rename_mulct_penalty_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->renamePermission('PaymentsResellerAddMulct', 'PaymentsResellerAddPenalty');
    $this->renamePermission('PaymentsUsersAddMulct', 'PaymentsUsersAddPenalty');
  }

  public function down()
  {
    $this->renamePermission('PaymentsResellerAddPenalty', 'PaymentsResellerAddMulct');
    $this->renamePermission('PaymentsUsersAddPenalty', 'PaymentsUsersAddMulct');
  }
}
