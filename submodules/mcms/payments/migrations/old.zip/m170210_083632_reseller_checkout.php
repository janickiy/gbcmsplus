<?php

use console\components\Migration;

class m170210_083632_reseller_checkout extends Migration
{
  use \rgk\utils\traits\PermissionTrait;


  public function up()
  {
    $this->createPermission('PaymentsResellerCheckoutController', 'Контроллер ResellerCheckout', 'PaymentsModule', ['root', 'admin']);
    $this->createPermission('PaymentsResellerCheckoutIndex', 'Просмотр расчетов реселлера', 'PaymentsResellerCheckoutController');
    $this->createPermission('PaymentsResellerCheckoutEnable', 'Активация рассчетного периода', 'PaymentsResellerCheckoutController');
    $this->createPermission('PaymentsResellerCheckoutDisable', 'Деактивация рассчетного периода', 'PaymentsResellerCheckoutController');
    $this->createPermission('PaymentsResellerCheckoutCreate', 'Создание записи в логе', 'PaymentsResellerCheckoutController');
    $this->createPermission('PaymentsResellerCheckoutUpdateModal', 'Редактирование записи в логе', 'PaymentsResellerCheckoutController');
  }

  public function down()
  {
    $this->removePermission('PaymentsResellerCheckoutIndex');
    $this->removePermission('PaymentsResellerCheckoutController');
    $this->removePermission('PaymentsResellerCheckoutEnable');
    $this->removePermission('PaymentsResellerCheckoutDisable');
    $this->removePermission('PaymentsResellerCheckoutCreate');
    $this->removePermission('PaymentsResellerCheckoutUpdateModal');
  }
}
