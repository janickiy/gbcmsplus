<?php

use console\components\Migration;

class m170912_090002_paxum_percent_update extends Migration
{
  public function up()
  {
    $this->update('wallets', ['profit_percent' => '1.0'], ['code' => 'paxum']);

  }

  public function down()
  {
    echo 'Paxum profit_percent not changed, because params.php need be changed too';
  }
}
