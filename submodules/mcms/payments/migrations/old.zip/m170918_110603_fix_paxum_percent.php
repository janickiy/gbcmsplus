<?php

use console\components\Migration;

class m170918_110603_fix_paxum_percent extends Migration
{
  public function up()
  {
    $this->update('wallets', ['profit_percent' => -1.00], ['code' => 'paxum']);
  }

  public function down()
  {
    $this->update('wallets', ['profit_percent' => 1.00], ['code' => 'paxum']);
  }
}
