<?php

use console\components\Migration;

/**
 * Class m170728_084223_delay_permission
 */
class m170728_084223_delay_permission extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  /**
   *
   */
  public function up()
  {
    $this->createPermission('PaymentsPaymentsProcessDelay', 'Отложить выплату', 'PaymentsPaymentsController', ['root', 'admin', 'reseller']);
  }

  /**
   */
  public function down()
  {
    $this->removePermission('PaymentsPaymentsProcessDelay', 'Отложить выплату');
  }

}
