<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170426_103252_assing_permission_resellers_checkout extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->assignRolesPermission('PaymentsResellerCheckoutController', ['reseller']);
    $this->assignRolesPermission('PaymentsResellerSettings', ['reseller']);
  }

  public function down()
  {
    $this->revokeRolesPermission('PaymentsResellerCheckoutController', ['reseller']);
    $this->revokeRolesPermission('PaymentsResellerSettings', ['reseller']);
  }
}
