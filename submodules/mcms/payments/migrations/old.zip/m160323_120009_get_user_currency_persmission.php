<?php

use console\components\Migration;

class m160323_120009_get_user_currency_persmission extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  const PERMISSION = 'PaymentsUsersGetUserCurrency';

  public function up()
  {
    $this->createOrGetPermission(self::PERMISSION, 'Get user currency action');
    $this->assignRolesPermission(self::PERMISSION, ['admin', 'root', 'reseller']);
  }

  public function down()
  {
    $this->removePermission(self::PERMISSION);
  }

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
  }

}
