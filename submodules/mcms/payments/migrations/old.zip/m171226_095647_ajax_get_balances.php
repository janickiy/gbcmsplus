<?php

use console\components\Migration;

class m171226_095647_ajax_get_balances extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('PaymentsPaymentsGetBalances', 'Ajax получение балансов всех пользователей', 'PaymentsPaymentsController', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('PaymentsPaymentsGetBalances');
  }
}
