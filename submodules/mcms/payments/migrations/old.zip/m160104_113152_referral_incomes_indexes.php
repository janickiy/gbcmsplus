<?php

use console\components\Migration;

class m160104_113152_referral_incomes_indexes extends Migration
{
  const TABLE_NAME = 'referral_incomes';

  public $primaryKeyName = self::TABLE_NAME . '_date_user_id_referral_id_is_hold' . 'pk';
  public $userIdDateIndexName = self::TABLE_NAME . '_user_id_date' . '_index';
  public $userIdReferralIdIsHoldIndexName = self::TABLE_NAME . '_user_id_referral_id_is_hold' . '_index';

  public function up()
  {
    $this->alterColumn(self::TABLE_NAME, 'date', 'DATE NOT NULL');
    $this->addPrimaryKey($this->primaryKeyName, self::TABLE_NAME, [
      'date', 'user_id', 'referral_id', 'is_hold'
    ]);
    $this->createIndex($this->userIdDateIndexName, self::TABLE_NAME, [
      'user_id', 'date'
    ]);
    $this->createIndex($this->userIdReferralIdIsHoldIndexName, self::TABLE_NAME, [
      'user_id', 'referral_id', 'is_hold'
    ]);    
  }

  public function down()
  {
    $this->dropIndex($this->userIdReferralIdIsHoldIndexName, self::TABLE_NAME);
    $this->dropIndex($this->userIdDateIndexName, self::TABLE_NAME);
    $this->dropPrimaryKey($this->primaryKeyName, self::TABLE_NAME);
    $this->alterColumn(self::TABLE_NAME, 'date', 'DATE DEFAULT NULL');
  }
}