<?php

use console\components\Migration;

class m170310_124723_alfabank_paysystem extends Migration
{
  public function up()
  {
    $this->insert('payment_systems_api', [
      'name' => 'Alfabank rub',
      'code' => 'alfabank',
      'currency' => 'rub',
    ]);

    $this->insert('payment_systems_api', [
      'name' => 'Alfabank usd',
      'code' => 'alfabank',
      'currency' => 'usd',
    ]);

    $this->insert('payment_systems_api', [
      'name' => 'Alfabank eur',
      'code' => 'alfabank',
      'currency' => 'eur',
    ]);
  }

  public function down()
  {
    $this->delete('payment_systems_api', 'code = "alfabank"');
  }
}
