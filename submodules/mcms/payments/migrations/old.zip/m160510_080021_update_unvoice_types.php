<?php

use mcms\payments\models\UserBalanceInvoice;
use console\components\Migration;
use yii\helpers\ArrayHelper;

class m160510_080021_update_unvoice_types extends Migration
{
  public function up()
  {
    $userPaymentInvoices = (new \yii\db\Query())
      ->from(UserBalanceInvoice::tableName())
      ->where('user_payment_id IS NOT NULL')
      ->each();

    $invoices = [];

    foreach ($userPaymentInvoices as $userPaymentInvoice) {
      $userPaymentId = ArrayHelper::getValue($userPaymentInvoice, 'user_payment_id', 0);
      if ($userPaymentId == 0) continue;
      $userPaymentInvoiceType = ArrayHelper::getValue($userPaymentInvoice, 'type', 0);
      $userPaymentInvoiceId = ArrayHelper::getValue($userPaymentInvoice, 'id', 0);
      $invoices[$userPaymentId][$userPaymentInvoiceId] = $userPaymentInvoiceType;
    }

    foreach ($invoices as $userPaymentId => $invoice) {
      if (count($invoice) == 1) unset($invoices[$userPaymentId]);
      $rightType = current($invoice);

      UserBalanceInvoice::updateAll(['type' => $rightType], ['user_payment_id' => $userPaymentId]);
    }
  }

  public function down()
  {
    echo "m160510_080021_update_unvoice_types cannot be reverted.\n";
  }
}
