<?php

use console\components\Migration;

class m170210_084647_combine_wire_payments extends Migration
{
  public function up()
  {
    $this->db->createCommand('UPDATE user_payments SET wallet_type = 7 where wallet_type = 8')->execute();
    $this->db->createCommand('UPDATE user_wallets SET wallet_type = 7 where wallet_type = 8')->execute();
  }

  public function down()
  {
    echo "m170213_084229_combine_wire_payments cannot be reverted.\n";
  }
}
