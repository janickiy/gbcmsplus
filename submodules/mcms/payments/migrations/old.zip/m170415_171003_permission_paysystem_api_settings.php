<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170415_171003_permission_paysystem_api_settings extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->assignRolesPermission('PaymentsPaymentSystemsApiList', ['admin', 'reseller']);
    $this->assignRolesPermission('PaymentsPaymentSystemsApiUpdate', ['admin', 'reseller']);
  }

  public function down()
  {
    $this->revokeRolesPermission('PaymentsPaymentSystemsApiList', ['admin', 'reseller']);
    $this->revokeRolesPermission('PaymentsPaymentSystemsApiUpdate', ['admin', 'reseller']);
  }
}
