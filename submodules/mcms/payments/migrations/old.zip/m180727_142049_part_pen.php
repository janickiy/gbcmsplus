<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
*/
class m180727_142049_part_pen extends Migration
{
  use PermissionTrait;
  /**
  */
  public function up()
  {
    $this->assignRolesPermission('PaymentsUsersBalanceInvoice', ['reseller']);
  }

  /**
  */
  public function down()
  {
    $this->revokeRolesPermission('PaymentsUsersBalanceInvoice', ['reseller']);
  }
}
