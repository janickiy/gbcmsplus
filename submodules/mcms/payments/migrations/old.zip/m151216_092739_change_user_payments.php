<?php

use console\components\Migration;

class m151216_092739_change_user_payments extends Migration
{
  public function safeUp()
  {
    $this->execute('SET foreign_key_checks = 0;');
    $this->dropForeignKey('user_payments_payment_system_type_id_fk', 'user_payments');
    $this->dropColumn('user_payments', 'payment_system_type_id');

    $this->dropForeignKey('user_payment_settings_payment_system_type_id_fk', 'user_payment_settings');
    $this->dropColumn('user_payment_settings', 'payment_system_type_id');
    $this->execute('SET foreign_key_checks = 1;');

    $this->dropColumn('user_payment_settings', 'payment_system_account');

    $this->createIndex('user_payment_settings_wallet_type_index', 'user_payment_settings', 'wallet_type');
  }

  public function safeDown()
  {
    $this->addColumn('user_payment_settings', 'payment_system_type_id', 'TINYINT(1) UNSIGNED NOT NULL');
    $this->addColumn('user_payment_settings', 'payment_system_account', $this->string(255)->notNull());
    $this->addColumn('user_payments', 'payment_system_type_id', 'TINYINT(1) UNSIGNED NOT NULL');
    $this->addForeignKey(
      'user_payments_payment_system_type_id_fk',
      'user_payments',
      'payment_system_type_id',
      'payment_system_types',
      'id',
      'CASCADE',
      'CASCADE'
    );

    $this->dropIndex('user_payment_settings_wallet_type_index', 'user_payment_settings');
  }
}
