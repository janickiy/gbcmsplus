<?php

use console\components\Migration;

class m151229_100810_user_payment_settings_enable_autopay extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Users' => [
        ['CanEnableAutopay', 'Can enable autopay for other users', ['root', 'admin']],
      ],
    ];
  }
}