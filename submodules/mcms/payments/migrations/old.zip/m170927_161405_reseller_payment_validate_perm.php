<?php

use console\components\Migration;

class m170927_161405_reseller_payment_validate_perm extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->assignRolesPermission('PaymentsPaymentsValidate', ['reseller']);
  }

  public function down()
  {
    $this->revokeRolesPermission('PaymentsPaymentsValidate', ['reseller']);
  }
}
