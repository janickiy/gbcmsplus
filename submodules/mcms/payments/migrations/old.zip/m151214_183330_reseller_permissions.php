<?php

use console\components\Migration;

class m151214_183330_reseller_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Reseller' => [
        ['index', 'Can view balance operations and payment', ['reseller']],
      ]
    ];
  }
}
