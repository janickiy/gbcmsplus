<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170323_063211_delete_wallet_permissions extends Migration
{
  use PermissionTrait;

  const DELETE_WALLET_PERMISSION = 'PaymentsUsersDeleteWallet';

  public function up()
  {
    $this->createPermission(self::DELETE_WALLET_PERMISSION, 'Удаление кошелька', 'PaymentsUsersController', ['root', 'admin']);
  }

  public function down()
  {
    $this->removePermission(self::DELETE_WALLET_PERMISSION);
  }
}
