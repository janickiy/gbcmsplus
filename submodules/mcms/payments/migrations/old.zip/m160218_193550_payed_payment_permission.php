<?php

use yii\db\Schema;
use console\components\Migration;

class m160218_193550_payed_payment_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'Payments' => [
        ['editPayedPayments', 'Can edit payed payments', ['root']]
      ]
    ];
  }
}
