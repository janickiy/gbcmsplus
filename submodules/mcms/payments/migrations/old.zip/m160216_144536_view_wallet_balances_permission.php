<?php

use yii\db\Schema;
use console\components\Migration;

class m160216_144536_view_wallet_balances_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'Payments' => [
        ['viewSystemWalletBalances', 'Can view system wallet balances', ['root', 'admin']]
      ]
    ];
  }
}
