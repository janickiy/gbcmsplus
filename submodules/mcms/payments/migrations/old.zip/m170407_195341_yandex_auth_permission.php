<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170407_195341_yandex_auth_permission extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->assignRolesPermission('PaymentsPaymentSystemsAuthYandexMoney',  ['reseller']);
  }

  public function down()
  {
    $this->revokeRolesPermission('PaymentsPaymentSystemsAuthYandexMoney',  ['reseller']);
  }
}
