<?php

use console\components\Migration;

class m170524_080848_wallets_name_update extends Migration
{
  public function up()
  {
    $this->update('wallets', ['name' => serialize([
      'ru' => 'Wire Transfer',
      'en' => 'Wire Transfer',
    ])], ['code'=>'wireiban']);

    $this->update('wallets', ['name' => serialize([
      'ru' => 'ИП',
      'en' => 'Individual Entrepreneur',
    ])], ['code'=>'private-person']);

    $this->update('wallets', ['name' => serialize([
      'ru' => 'Юр. лицо',
      'en' => 'Local RU Company',
    ])], ['code'=>'juridical-person']);
  }

  public function down()
  {
    $this->update('wallets', ['name' => serialize([
      'ru' => 'WireIban',
      'en' => 'WireIban',
    ])], ['code'=>'wireiban']);


    $this->update('wallets', ['name' => serialize([
      'ru' => 'ИП',
      'en' => 'Private person',
    ])], ['code'=>'private-person']);

    $this->update('wallets', ['name' => serialize([
      'ru' => 'Юр. лицо',
      'en' => 'Juridical person',
    ])], ['code'=>'juridical-person']);

  }

}
