<?php

use mcms\payments\components\events\UserBalanceConvert;
use console\components\Migration;

class m180711_132848_event_user_balance_convert_update extends Migration
{
  const TABLE = 'notifications';

  public function up()
  {
    $header = serialize([
      'ru' => 'Баланс сконвертирован',
      'en' => 'Balance converted',
    ]);
    $template = serialize([
      'ru' => 'Баланс {transfer.amountFrom} {transfer.currencyFrom} сконвертирован в {transfer.amountTo} {transfer.currencyTo}.',
      'en' => 'Balance {transfer.amountFrom} {transfer.currencyFrom} converted in {transfer.amountTo} {transfer.currencyTo}.'
    ]);

    $this->update(self::TABLE, [
      'header' => $header,
      'template' => $template
    ], [
      'event' => UserBalanceConvert::className()
    ]);
  }

  public function down()
  {
    $header = serialize([
      'ru' => 'Баланс{transfer.hold} сконвертирован',
      'en' => 'Balance{transfer.hold} converted',
    ]);
    $template = serialize([
      'ru' => 'Баланс{transfer.hold} {transfer.amountFrom} {transfer.currencyFrom} сконвертирован в {transfer.amountTo} {transfer.currencyTo}.',
      'en' => 'Balance{transfer.hold} {transfer.amountFrom} {transfer.currencyFrom} converted in {transfer.amountTo} {transfer.currencyTo}.'
    ]);

    $this->update(self::TABLE, [
      'header' => $header,
      'template' => $template
    ], [
      'event' => UserBalanceConvert::className()
    ]);
  }
}
