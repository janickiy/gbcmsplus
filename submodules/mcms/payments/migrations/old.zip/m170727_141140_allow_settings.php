<?php

use console\components\Migration;

/**
 * Class m170727_141140_allow_settings
 */
class m170727_141140_allow_settings extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  /**
   *
   */
  public function up()
  {
    $this->assignRolesPermission('EditModuleSettingsPayments', ['reseller']);

    $this->createPermission('PaymentsSettings', 'Редактирование настроек модуля', 'PaymentsPermissions');
    $this->createPermission('PaymentsEditDelaySettings', 'Редактирование настроек отложенных выплат', 'PaymentsSettings', ['root' ,'admin', 'reseller']);
    $this->createPermission('PaymentsEditMainSettings', 'Редактирование главных настроек выплат', 'PaymentsSettings', ['root' ,'admin']);
    $this->createPermission('PaymentsEditMgmpSettings', 'Редактирование настроек MGMP', 'PaymentsSettings', ['root' ,'admin']);
    $this->createPermission('PaymentsEditWmSettings', 'Редактирование WM настроек', 'PaymentsSettings', ['root' ,'admin']);
  }

  /**
   *
   */
  public function down()
  {
    $this->revokeRolesPermission('EditModuleSettingsPayments', ['reseller']);

    $this->removePermission('PaymentsEditWmSettings');
    $this->removePermission('PaymentsEditDelaySettings');
    $this->removePermission('PaymentsEditMainSettings');
    $this->removePermission('PaymentsEditMgmpSettings');
    $this->removePermission('PaymentsSettings');
  }

}
