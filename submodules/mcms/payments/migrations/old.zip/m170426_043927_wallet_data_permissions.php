<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170426_043927_wallet_data_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission(
      'PaymentsPaymentsWalletData',
      'Данные о кошельке для конвертации',
      'PaymentsPaymentsController',
      ['root', 'admin']
    );
  }

  public function down()
  {
    $this->removePermission('PaymentsPaymentsWalletData');
  }
}
