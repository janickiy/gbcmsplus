<?php

use console\components\Migration;

class m170301_115107_wallet_limits extends Migration
{
  public function up()
  {
    foreach (['rub', 'usd', 'eur'] as $currency) {
      $this->addColumn('wallets', $currency . '_max_payout_sum', $this->decimal(8, 2)->unsigned()->comment('Разовый лимит на снятие'));
      $this->addColumn('wallets', $currency . '_payout_limit_daily', $this->decimal(10, 2)->unsigned()->comment('Дневной лимит на снятие'));
      $this->addColumn('wallets', $currency . '_payout_limit_monthly', $this->decimal(10, 2)->unsigned()->comment('Месячный лимит на снятие'));
    }
  }

  public function down()
  {
    foreach (['rub', 'usd', 'eur'] as $currency) {
      $this->dropColumn('wallets', $currency . '_max_payout_sum');
      $this->dropColumn('wallets', $currency . '_payout_limit_daily');
      $this->dropColumn('wallets', $currency . '_payout_limit_monthly');
    }
  }
}
