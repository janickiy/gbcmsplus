<?php

use console\components\Migration;

class m170507_193229_wallet_data_permission_remove extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->removePermission('PaymentsPaymentsWalletData');
  }

  public function down()
  {
  }
}
