<?php

use console\components\Migration;

class m160414_144846_clear_empty_payment_settings extends Migration
{
  public function up()
  {
    $this->execute('update user_payment_settings set wallet_type = NULL where wallet_type = "[]"');
    $this->execute('update user_payment_settings set wallet_account = NULL where wallet_account = "[]"');
  }

  public function down()
  {
    echo "m160414_144846_clear_empty_payment_settings cannot be reverted.\n";
  }
}
