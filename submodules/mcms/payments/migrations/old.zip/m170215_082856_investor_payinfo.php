<?php

use console\components\Migration;

class m170215_082856_investor_payinfo extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->assignRolesPermission('PaymentsWalletDetailView', ['investor']);
  }

  public function down()
  {
    $this->revokeRolesPermission('PaymentsWalletDetailView', ['investor']);
  }
}
