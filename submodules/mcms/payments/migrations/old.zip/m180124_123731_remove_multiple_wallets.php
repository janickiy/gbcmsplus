<?php

use console\components\Migration;

class m180124_123731_remove_multiple_wallets extends Migration
{
  const TABLE = 'wallets';

  public function up()
  {
    $this->dropColumn(self::TABLE, 'is_multiple');
  }

  public function down()
  {
    $this->addColumn(self::TABLE, 'is_multiple', 'SMALLINT(1) UNSIGNED DEFAULT 0 NOT NULL AFTER usd_min_payout_sum');
  }
}
