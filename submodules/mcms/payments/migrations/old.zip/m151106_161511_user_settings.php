<?php

use console\components\Migration;

class m151106_161511_user_settings extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable('user_payment_settings', [
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'payment_system_type_id' => 'TINYINT(1) UNSIGNED NOT NULL',
      'payment_system_account' => $this->string(255)->notNull(),
      'is_auto_payments' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'referral_percent' => 'TINYINT(3) UNSIGNED NOT NULL',
      'early_payment_percent' => 'DECIMAL(4,1) UNSIGNED NOT NULL',
      'currency' => $this->string(3)->notNull(),
    ], $tableOptions);

    $this->addForeignKey(
      'user_payment_settings_payment_system_type_id_fk',
      'user_payment_settings',
      'payment_system_type_id',
      'payment_system_types',
      'id',
      'CASCADE',
      'CASCADE'
    );
  }

  public function down()
  {
    $this->dropTable('user_payment_settings');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
