<?php

use console\components\Migration;

class m160307_102735_user_payments_type extends Migration
{
  const TABLE = 'user_payments';
  const FIELD = 'type';

  public function up()
  {
    $this->addColumn(self::TABLE, self::FIELD, 'TINYINT(2) UNSIGNED NOT NULL');
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, self::FIELD);
  }

}
