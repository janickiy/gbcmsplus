<?php

use console\components\Migration;

class m160424_202458_update_user_currency_if_null extends Migration
{
  public function up()
  {
    $this->db
      ->createCommand("UPDATE `user_payment_settings` SET `currency` = 'rub' WHERE currency IS NULL;")
      ->execute()
    ;
  }

  public function down()
  {

  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
