<?php

use console\components\Migration;

class m170512_144748_wallets_description extends Migration
{
  public function up()
  {
    $this->addColumn('wallets', 'info', $this->text()->after('name'));
  }

  public function down()
  {
    $this->dropColumn('wallets', 'info');
  }
}
