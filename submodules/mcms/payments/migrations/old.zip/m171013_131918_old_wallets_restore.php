<?php

use console\components\Migration;

/**
 * Раньше:
 * - кошелек мог быть только один
 * - кошелек хранился в настройках
 * - в выплату записывались данные кошелька
 * - при смене кошелька, данные оставались в выплате, но заменялись на новый в настройках
 *
 * Так вот мы перенесли кошельки, которые были прописаны в настройках на момент накатывания выплат, но не учли, что
 * до кошелька записанного в настройках могли быть использованы и другие кошельки.
 * Так вот эта миграция ищет выплаты для которых мы не обнаружили кошелек, создает кошелек с пустыми данными с пометкой "удален"
 * и привязывает к выплате, что бы не ломалась логика сайта
 */
class m171013_131918_old_wallets_restore extends Migration
{
  public function up()
  {
    $this->execute(<<<SQL
INSERT INTO user_wallets (user_id, currency, wallet_type, is_deleted)
  SELECT
    user_id,
    currency,
    wallet_type,
    1
  FROM user_payments up
  WHERE up.user_wallet_id IS NULL
  GROUP BY user_id, currency, wallet_type;

UPDATE user_payments up INNER JOIN user_wallets uw
    ON uw.user_id = up.user_id AND up.currency = uw.currency AND up.wallet_type = uw.wallet_type
SET up.user_wallet_id = uw.id
WHERE up.user_wallet_id IS NULL;
SQL
);
  }

  public function down()
  {

  }
}
