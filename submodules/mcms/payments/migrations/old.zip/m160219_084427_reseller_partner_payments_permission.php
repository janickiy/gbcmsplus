<?php

use yii\db\Schema;
use console\components\Migration;

class m160219_084427_reseller_partner_payments_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Reseller' => [
        ['partner-payments', 'Can view partner payments', ['reseller']],
        ['auto-payout', 'Can auto payout to wallet', ['reseller']],
        ['view-payment', 'Can view partner payments', ['reseller']],
      ]
    ];
  }
}
