<?php

use console\components\Migration;

class m170310_124721_webmoney_paysystem extends Migration
{
  public function up()
  {
    $this->addColumn('payment_systems_api', 'currency', 'CHAR(3) AFTER code');

    $this->insert('payment_systems_api', [
      'name' => 'Webmoney rub',
      'code' => 'webmoney',
      'currency' => 'rub',
    ]);

    $this->insert('payment_systems_api', [
      'name' => 'Webmoney usd',
      'code' => 'webmoney',
      'currency' => 'usd',
    ]);

    $this->insert('payment_systems_api', [
      'name' => 'Webmoney eur',
      'code' => 'webmoney',
      'currency' => 'eur',
    ]);
  }

  public function down()
  {
    $this->delete('payment_systems_api', 'code = "webmoney"');
    if (in_array('currency', $this->db->getTableSchema('payment_systems_api')->columnNames)) {
      $this->dropColumn('payment_systems_api', 'currency');
    }
  }
}
