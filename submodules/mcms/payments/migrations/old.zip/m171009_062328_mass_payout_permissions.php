<?php

use console\components\Migration;

class m171009_062328_mass_payout_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('PaymentsPaymentsMassPayout', 'Массовое выполнение выплат', 'PaymentsPaymentsController', ['root', 'admin']);
  }

  public function down()
  {
    $this->removePermission('PaymentsPaymentsMassPayout');
  }
}
