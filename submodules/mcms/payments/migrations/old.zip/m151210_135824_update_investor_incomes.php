<?php

use console\components\Migration;

class m151210_135824_update_investor_incomes extends Migration
{
  public function up()
  {
    $this->alterColumn('investor_incomes', 'status', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
  }

  public function down()
  {
    $this->alterColumn('investor_incomes', 'status', 'TINYINT(1) UNSIGNED NOT NULL');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
