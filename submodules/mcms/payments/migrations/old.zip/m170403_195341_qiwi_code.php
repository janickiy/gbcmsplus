<?php

use console\components\Migration;

class m170403_195341_qiwi_code extends Migration
{
  public function up()
  {
    $this->execute('UPDATE wallets SET code = "qiwi" WHERE id = 13');
  }
}
