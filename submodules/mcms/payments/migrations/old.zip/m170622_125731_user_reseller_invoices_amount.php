<?php

use console\components\Migration;

class m170622_125731_user_reseller_invoices_amount extends Migration
{
  public function up()
  {
    $this->alterColumn('user_investor_invoices', 'amount', $this->decimal(9,2)->notNull());
  }

  public function down()
  {
    $this->alterColumn('user_investor_invoices', 'amount', $this->decimal(8,2)->notNull());
  }
}
