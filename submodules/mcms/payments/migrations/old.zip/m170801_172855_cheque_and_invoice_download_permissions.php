<?php

use console\components\Migration;

class m170801_172855_cheque_and_invoice_download_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('PaymentsPaymentsDownloadCheque', 'Скачивание квитанции выплаты', 'PaymentsPaymentsController', ['root', 'admin', 'reseller', 'partner']);
    $this->createPermission('PaymentsPaymentsDownloadInvoice', 'Скачивание акта выплаты', 'PaymentsPaymentsController', ['root', 'admin', 'reseller', 'partner']);
  }

  public function down()
  {
    $this->removePermission('PaymentsPaymentsDownloadCheque');
    $this->removePermission('PaymentsPaymentsDownloadInvoice');
  }
}
