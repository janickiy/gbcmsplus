<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170303_131647_payment_systems_api_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PaymentsPaymentSystemsApiFileUpload', 'Загрузка файла', 'PaymentsPaymentSystemsApiController', ['root', 'admin']);
    $this->createPermission('PaymentsPaymentSystemsApiFileDelete', 'Удаление файла', 'PaymentsPaymentSystemsApiController', ['root', 'admin']);
  }

  public function down()
  {
    $this->removePermission('PaymentsPaymentSystemsApiFileUpload');
    $this->removePermission('PaymentsPaymentSystemsApiFileDelete');
  }
}
