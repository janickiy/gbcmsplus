<?php

use console\components\Migration;

/**
 * Class m170915_140536_alfa_del
 */
class m170915_140536_alfa_del extends Migration
{
  /**
   *
   */
  public function up()
  {
    $this->delete('payment_systems_api', 'code = "alfabank"');
  }

  /**
   */
  public function down()
  {
    $this->insert('payment_systems_api', [
      'name' => 'Alfabank rub',
      'code' => 'alfabank',
      'currency' => 'rub',
    ]);

    $this->insert('payment_systems_api', [
      'name' => 'Alfabank usd',
      'code' => 'alfabank',
      'currency' => 'usd',
    ]);

    $this->insert('payment_systems_api', [
      'name' => 'Alfabank eur',
      'code' => 'alfabank',
      'currency' => 'eur',
    ]);
  }

}
