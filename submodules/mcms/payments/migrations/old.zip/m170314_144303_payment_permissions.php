<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170314_144303_payment_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PaymentsPaymentSystemsAuthYandexMoney', 'Авторизация для  API Yandex Money', 'PaymentsPaymentSystemsAuthController', ['root', 'admin']);
  }

  public function down()
  {
    $this->removePermission('PaymentsPaymentSystemsAuthYandexMoney');
  }
}
