<?php

use console\components\Migration;

/**
 */
class m180117_075943_investor_invoices_remove extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  /**
   */
  public function up()
  {
    $this->removePermission('PaymentsUsersInvestorInvoice');
  }

  /**
   */
  public function down()
  {
    $this->createPermission('PaymentsUsersInvestorInvoice', 'Просмотр деталей счета инвестора', 'PaymentsUsersController', ['admin', 'root']);

  }
}
