<?php

use console\components\Migration;

class m170301_085122_reseller_checkout extends Migration
{
  const TABLE_R_P_FLAGS = '{{%reseller_checkout_closed}}';
  const TABLE = '{{%reseller_checkout}}';
  const TABLE_INVESTORS = '{{%reseller_checkout_investors}}';

  public function up()
  {
    $this->dropTable(self::TABLE_R_P_FLAGS);

    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::TABLE, [
      'week_start' => $this->date(),
      'rub' => $this->decimal(9, 2)->unsigned()->notNull()->defaultValue(0),
      'usd' => $this->decimal(8, 2)->unsigned()->notNull()->defaultValue(0),
      'eur' => $this->decimal(8, 2)->unsigned()->notNull()->defaultValue(0),
      'is_closed' => $this->smallInteger(1)->notNull()->unsigned()->defaultValue(0)
    ], $tableOptions);

    $this->addPrimaryKey('week_start_pk', self::TABLE, 'week_start');

    $this->createTable(self::TABLE_INVESTORS, [
      'week_start' => $this->date(),
      'investor_id' => $this->smallInteger(5)->unsigned()->notNull(),
      'sum' => $this->decimal(8, 2)->unsigned()->notNull()->defaultValue(0),
      'currency' => $this->string(3)->notNull(),
    ], $tableOptions);

    $this->addPrimaryKey('week_start_investor_pk', self::TABLE_INVESTORS, ['week_start', 'investor_id']);
  }

  public function down()
  {
    $this->dropTable(self::TABLE_INVESTORS);
    $this->dropTable(self::TABLE);
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::TABLE_R_P_FLAGS, [
      'range_start' => $this->string()->notNull()
    ], $tableOptions);
    $this->addPrimaryKey('range_start_pk', self::TABLE_R_P_FLAGS, 'range_start');
  }
}
