<?php

use console\components\Migration;

class m151214_211119_user_payment_add_field_created_by extends Migration
{
  public function safeUp()
  {
    $this->addColumn('user_payments', 'created_by', 'MEDIUMINT(5) UNSIGNED NOT NULL');
  }

  public function safeDown()
  {
    $this->dropColumn('user_payments', 'created_by');
  }
}