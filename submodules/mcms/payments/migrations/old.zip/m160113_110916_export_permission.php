<?php

use console\components\Migration;

class m160113_110916_export_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Payments' => [
        ['export', 'Can export payments', ['admin', 'root']],
      ],
    ];
  }
}
