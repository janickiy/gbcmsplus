<?php

use mcms\payments\components\rbac\UpdatePaymentRule;
use console\components\Migration;

class m160407_084456_reseller_create_payment_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Reseller' => [
        ['create-payment', 'Can reseller create payments', ['reseller']],
        ['update-payment', 'Can reseller update payments', ['reseller'], [
          'PaymentsUpdatePaymentRule' => UpdatePaymentRule::className(),
        ]],
        ['user-detail', 'Can reseller update payments', ['reseller']],
        ['add-compensation', 'Can reseller add compensation', ['reseller']],
        ['add-mulct', 'Can reseller add mulct', ['reseller']],
      ]
    ];
  }
}
