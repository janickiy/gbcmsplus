<?php

use console\components\Migration;

class m171005_063654_payment_percent extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->renameColumn('user_payment_settings', 'early_payment_percent', 'early_payment_percent_old');
    $this->addColumn(
      'user_payments',
      'early_payment_percent',
      $this->decimal(4, 2)->defaultValue(null)->after('rgk_processing_percent')
    );
    $this->addColumn(
      'user_payment_settings',
      'early_payment_percent',
      $this->decimal(4, 2)->defaultValue(null)->after('currency')
    );

    $this->createPermission('PaymentsCanRequestPaymentWithoutCreateCommission', 'Запрос выплаты без комиссии за создание', 'PaymentsPermissions', ['root', 'admin', 'reseller', 'investor', 'manager']);
    $this->createPermission('PaymentsCanChangePaymentCreatePercent', 'Изменение процента за создание выплаты', 'PaymentsPermissions', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->dropColumn('user_payments', 'early_payment_percent');
    $this->dropColumn('user_payment_settings', 'early_payment_percent');
    $this->renameColumn('user_payment_settings', 'early_payment_percent_old', 'early_payment_percent');

    $this->removePermission('PaymentsCanRequestPaymentWithoutCreateCommission');
    $this->removePermission('PaymentsCanChangePaymentCreatePercent');
  }
}
