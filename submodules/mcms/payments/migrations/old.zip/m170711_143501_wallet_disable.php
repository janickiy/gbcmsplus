<?php

use console\components\Migration;

class m170711_143501_wallet_disable extends Migration
{
  public function up()
  {
    $this->addColumn('wallets', 'is_disabled', $this->boolean()->defaultValue(false)->after('id'));
  }

  public function down()
  {
    $this->dropColumn('wallets', 'is_disabled');
  }
}
