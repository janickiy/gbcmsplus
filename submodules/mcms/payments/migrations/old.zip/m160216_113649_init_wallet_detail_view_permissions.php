<?php

use yii\db\Schema;
use console\components\Migration;

class m160216_113649_init_wallet_detail_view_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'Payments' => [
        ['walletDetailView', 'Display wallets additional info of users', ['root', 'admin', 'reseller']],
      ],
    ];
  }
}
