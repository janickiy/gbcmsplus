<?php

use console\components\Migration;

/**
 * Class m170727_084833_process_manual_permissions
 */
class m170727_084833_process_manual_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  /**
   *
   */
  public function up()
  {
    $this->createPermission('PaymentsPaymentsProcessManual', 'Выполнить выплату вручную', 'PaymentsPaymentsController', ['root', 'admin', 'reseller']);
  }

  /**
   *
   */
  public function down()
  {
    $this->removePermission('PaymentsPaymentsProcessManual');
  }
}
