<?php

use console\components\Migration;

class m151214_093939_add_setting_wallet extends Migration
{
  public function up()
  {
    $this->addColumn('user_payment_settings', 'wallet_type', 'TINYINT(1) UNSIGNED NOT NULL');
    $this->addColumn('user_payment_settings', 'wallet_account', $this->string());
  }

  public function down()
  {
    $this->dropColumn('user_payment_settings', 'wallet_type');
    $this->dropColumn('user_payment_settings', 'wallet_account');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
