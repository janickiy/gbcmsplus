<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170303_131646_payment_systems_api_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PaymentsPaymentSystemsApiUpdate', 'Редактирование API платежных систем', 'PaymentsPaymentSystemsApiController', ['root', 'admin']);
  }

  public function down()
  {
    $this->removePermission('PaymentsPaymentSystemsApiUpdate');
  }
}
