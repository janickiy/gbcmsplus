<?php

use yii\db\Schema;
use console\components\Migration;

class m160127_122639_investor_low_balance_notify_at extends Migration
{
  public function up()
  {
    $this->addColumn(
      'user_payment_settings',
      'is_low_balance_notification_disabled',
      'tinyint(1) UNSIGNED NOT NULL DEFAULT 1'
    );

    $this->addColumn(
      'user_payment_settings',
      'low_balance_notification_limit',
      'int(10) UNSIGNED NOT NULL DEFAULT 0'
    );

    $this->addColumn('user_payment_settings', 'low_balance_notified_at', 'int(10) UNSIGNED DEFAULT NULL');
  }

  public function down()
  {
    $this->dropColumn('user_payment_settings', 'low_balance_notified_at');
    $this->dropColumn('user_payment_settings', 'is_low_balance_notification_disabled');
    $this->dropColumn('user_payment_settings', 'low_balance_notification_limit');
  }
}
