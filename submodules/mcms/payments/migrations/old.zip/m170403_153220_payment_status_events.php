<?php

use console\components\Migration;
use yii\db\Query;

class m170403_153220_payment_status_events extends Migration
{
  public function up()
  {
    $ids = (new Query())->select('id')->from('notifications')->where(['event' => 'mcms\payments\components\events\PaymentStatusUpdated'])->column();

    if ($ids) {
      foreach ($ids as $id) {
        $this->addNotificationAuthItem($id);
      }
    }
  }

  public function down()
  {
    echo "m160630_091939_add_reseller cannot be reverted.\n";
  }

  private function addNotificationAuthItem($id)
  {
    return $this->getDb()
      ->createCommand('INSERT IGNORE INTO notifications_auth_item (auth_item_name, notification_id) VALUES(:item, :notification)', [
        ':item' => 'partner',
        ':notification' => $id,
      ])
      ->execute();
  }
}
