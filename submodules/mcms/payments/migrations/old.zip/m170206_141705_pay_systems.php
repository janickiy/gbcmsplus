<?php

use console\components\Migration;

class m170206_141705_pay_systems extends Migration
{
  const TABLE = 'wallets';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::TABLE, [
      'id' => $this->primaryKey(2),
      'name' => $this->string(512)->notNull(),
      'profit_percent' => $this->decimal(5, 2)->notNull()->defaultValue(0),
      'rub_min_payout_sum' => $this->decimal(8, 2)->unsigned()->notNull()->defaultValue(0),
      'eur_min_payout_sum' => $this->decimal(8, 2)->unsigned()->notNull()->defaultValue(0),
      'usd_min_payout_sum' => $this->decimal(8, 2)->unsigned()->notNull()->defaultValue(0),
    ], $tableOptions);

    $wallets = [
      [
        'id' => 1,
        'name' => serialize(['ru' => 'Webmoney', 'en' => 'Webmoney']),
        'profit_percent' => -3,
        'usd_min_payout_sum' =>  5,
        'eur_min_payout_sum' => 5,
        'rub_min_payout_sum' => 100,
      ],
      [
        'id' => 2,
        'name' => serialize(['ru' => 'Яндекс.Деньги', 'en' => 'Yandex.Money']),
        'profit_percent' => -1.5,
        'usd_min_payout_sum' =>  5,
        'eur_min_payout_sum' => 5,
        'rub_min_payout_sum' => 100,
      ],
      [
        'id' => 3,
        'name' => serialize(['ru' => 'Epayments', 'en' => 'Epayments']),
        'profit_percent' => 0,
        'usd_min_payout_sum' =>  5,
        'eur_min_payout_sum' => 5,
        'rub_min_payout_sum' => 100,
      ],
      [
        'id' => 5,
        'name' => serialize(['ru' => 'PayPal', 'en' => 'PayPal']),
        'profit_percent' => -3,
        'usd_min_payout_sum' =>  5,
        'eur_min_payout_sum' => 5,
        'rub_min_payout_sum' => 100,
      ],
      [
        'id' => 6,
        'name' => serialize(['ru' => 'Paxum', 'en' => 'Paxum']),
        'profit_percent' => 0,
        'usd_min_payout_sum' =>  5,
        'eur_min_payout_sum' => 5,
        'rub_min_payout_sum' => 100,
      ],
      [
        'id' => 7,
        'name' => serialize(['ru' => 'WireIban', 'en' => 'WireIban']),
        'profit_percent' => 0,
        'usd_min_payout_sum' =>  250,
        'eur_min_payout_sum' => 150,
        'rub_min_payout_sum' => 0,
      ],
    ];

    foreach ($wallets as $wallet) {
      $this->insert(self::TABLE, $wallet);
    }

  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }
}
