<?php

use mcms\payments\components\rbac\CanUseMultipleCurrenciesBalance;
use console\components\Migration;

class m160321_195307_multiple_currencies_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->authManager->add(new CanUseMultipleCurrenciesBalance());

    $this->createOrGetPermission(
      'PaymentsCanUseMultipleCurrenciesBalance',
      'Can have or view multiple currencies',
      'PaymentsCanUseMultipleCurrenciesBalance'
    );
    $this->assignRolesPermission('PaymentsCanUseMultipleCurrenciesBalance', ['root', 'admin', 'reseller']);
  }


  public function down()
  {
    $this->removePermission('PaymentsCanUseMultipleCurrenciesBalance');
  }
}
