<?php

use console\components\Migration;

class m170422_141914_payment_invoice_currency extends Migration
{
  public function up()
  {
    $this->addColumn('user_payments', 'invoice_currency', $this->string(3)->notNull()->defaultValue('')->after('amount'));
    $this->execute("UPDATE user_payments SET invoice_currency = currency");
  }

  public function down()
  {
    $this->dropColumn('user_payments', 'invoice_currency');
  }
}
