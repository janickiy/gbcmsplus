<?php

use console\components\Migration;

class m151218_113929_generate_payments extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Payments' => [
        ['generatePayments', 'Can generate payments', ['admin', 'root']],
      ]
    ];
  }


}
