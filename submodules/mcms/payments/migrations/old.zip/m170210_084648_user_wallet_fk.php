<?php

use console\components\Migration;

class m170210_084648_user_wallet_fk extends Migration
{
  const USER_WALLETS = 'user_wallets';
  const WALLETS = 'wallets';

  public function up()
  {
    $this->addForeignKey(self::USER_WALLETS . '_' . 'wallet_type_fk', self::USER_WALLETS, 'wallet_type', self::WALLETS, 'id', 'RESTRICT', 'RESTRICT');
  }

  public function down()
  {
    $this->dropForeignKey(self::USER_WALLETS . '_' . 'wallet_type_fk', self::USER_WALLETS);
  }
}
