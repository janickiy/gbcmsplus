<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m170208_124608_payments_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('PaymentsPaymentsDependentWallets', 'Получение кошельков пользователя', 'PaymentsPaymentsController', ['root', 'admin', 'reseller']);
    $this->createPermission('PaymentsUsersDeleteWalletFiles', 'Удаление файлов прицепленных к кошельку', 'PaymentsUsersController', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('PaymentsPaymentsDependentWallets');
    $this->removePermission('PaymentsUsersDeleteWalletFiles');
  }
}
