<?php

use console\components\Migration;

/**  */
class m180222_135257_check_wm extends Migration
{
  /**  */
  public function up()
  {
    $result = (new \yii\db\Query())->from('user_payments')->where([
      'processing_type' => 2,
      'wallet_type' => 1,
      'status' => 4,
    ])->count();

    if ($result > 0) {
      \yii\helpers\Console::prompt('На реселлерке есть выплаты на вебмане в зависшем статусе. Проверьте их, иначе есть риск что задублируются при повторной отправке. см. MCMS-1966');
    }
  }

  /**  */
  public function down()
  {
    return true;
  }
}
