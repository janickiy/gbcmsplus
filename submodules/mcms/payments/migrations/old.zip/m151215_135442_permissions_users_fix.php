<?php

use console\components\Migration;
use \mcms\common\traits\PermissionMigration;

class m151215_135442_permissions_users_fix extends Migration
{
  use PermissionMigration {
    PermissionMigration::up as traitUp;
    PermissionMigration::down as traitDown;
  }

  public $newPermissions = [
    'Users' => [
      ['index', 'Can view users list', ['admin', 'root']],
      ['view', 'Can view users payments', ['admin', 'root']],
      ['profit', 'Can view users profit statistics', ['admin', 'root']],
      ['updateSettings', 'Can update users profit settings', ['admin', 'root']],
      ['updatePartnerSettings', 'Can update users profit settings', ['admin', 'root', 'partner']],
      ['balanceInvoice', 'Can view partner invoice details', ['admin', 'root']],
      ['investorInvoice', 'Can view investor invoice details', ['admin', 'root']],
      ['balanceInvestorTransfer', 'Can transfer money between invoice and main balance', ['admin', 'root']],
    ],
    'Payments' => [
      ['userDetail', 'Can view user payment settings', ['admin', 'root']],
      ['validate', 'Can validate payment create/update form', ['admin', 'root']],
      ['view', 'Can view payment details', ['admin', 'root']],
    ],
  ];
  public $oldPermissions = [
    'User' => [
      ['index', 'Can view users list', ['admin', 'root']],
      ['view', 'Can view users payments', ['admin', 'root']],
      ['profit', 'Can view users profit statistics', ['admin', 'root']],
      ['updateSettings', 'Can update users profit settings', ['admin', 'root']],
      ['updatePartnerSettings', 'Can update users profit settings', ['admin', 'root', 'partner']],
      ['balanceInvoice', 'Can view partner invoice details', ['admin', 'root']],
      ['investorInvoice', 'Can view investor invoice details', ['admin', 'root']],
      ['balanceInvestorTransfer', 'Can transfer money between invoice and main balance', ['admin', 'root']],
    ],
  ];

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = $this->newPermissions;
  }

  public function up()
  {
    $this->permissions = $this->oldPermissions;
    $this->traitDown();
    $this->permissions = $this->newPermissions;
    $this->traitUp();
  }

  public function down()
  {
    $this->permissions = $this->newPermissions;
    $this->traitDown();
    $this->permissions = $this->oldPermissions;
    $this->traitUp();
  }
}