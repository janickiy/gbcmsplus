<?php

use yii\db\Schema;
use console\components\Migration;

class m160120_075559_user_payment_settings_wallet_clean extends Migration
{
  public function up()
  {
    $this->update('user_payment_settings', ['wallet_account' => '', 'wallet_type' => '']);
  }

  public function down()
  {

  }
}
