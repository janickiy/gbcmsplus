<?php

use console\components\Migration;

class m180207_114129_update_wire_wallet_name extends Migration
{
  public function up()
  {
    $this->update('wallets', ['name' => serialize([
      'ru' => 'Bank account transfer',
      'en' => 'Bank account transfer',
    ])], ['code'=>'wireiban']);
  }

  public function down()
  {
    $this->update('wallets', ['name' => serialize([
      'ru' => 'Wire Transfer',
      'en' => 'Wire Transfer',
    ])], ['code'=>'wireiban']);
  }

}
