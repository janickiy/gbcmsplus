<?php

use console\components\Migration;

class m171229_075944_user_change_currency_log extends Migration
{
  const TABLE = 'currency_log';
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::TABLE, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'user_id' => 'MEDIUMINT(5) NOT NULL',
      'currency' => $this->string(3)->notNull(),
      'created_at' => 'INT(10) UNSIGNED NOT NULL'
    ], $tableOptions);

    $this->createIndex(
      'user_currency_change_index',
      self::TABLE,
      ['user_id', 'created_at']
    );
  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }
}
