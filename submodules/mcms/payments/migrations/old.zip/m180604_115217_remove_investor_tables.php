<?php

use console\components\Migration;

class m180604_115217_remove_investor_tables extends Migration
{
  public function up()
  {
    $this->renameTable('user_investor_invoices', 'old_user_investor_invoices');
    $this->renameTable('investor_incomes', 'old_investor_incomes');
    $this->renameTable('invest_statistic_data_hour_group', 'old_invest_statistic_data_hour_group');
    $this->renameTable('invest_subscriptions_day_hour_group', 'old_invest_subscriptions_day_hour_group');
    $this->renameTable('invest_subscriptions_day_group', 'old_invest_subscriptions_day_group');
  }

  public function down()
  {
    $this->renameTable('old_user_investor_invoices', 'user_investor_invoices');
    $this->renameTable('old_investor_incomes', 'investor_incomes');
    $this->renameTable('old_invest_statistic_data_hour_group', 'invest_statistic_data_hour_group');
    $this->renameTable('old_invest_subscriptions_day_hour_group', 'invest_subscriptions_day_hour_group');
    $this->renameTable('old_invest_subscriptions_day_group', 'invest_subscriptions_day_group');
  }
}
