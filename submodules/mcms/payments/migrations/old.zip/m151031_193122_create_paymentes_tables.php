<?php

use console\components\Migration;

class m151031_193122_create_paymentes_tables extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable('wm_system_purses', [
      'id' => 'TINYINT(2) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'wmid' => $this->string(13)->notNull(),
      'certificate' => $this->string(255)->notNull(),
      'is_disabled' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0'
    ], $tableOptions);
    $this->createIndex('wm_system_purses_is_disabled_index', 'wm_system_purses', ['is_disabled']);

    $this->createTable('user_payments', [
      'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'payment_system_type_id' => 'TINYINT(1) UNSIGNED NOT NULL',
//      'user_balance_invoice_id' => 'INT(10) UNSIGNED NOT NULL',
      'currency' => $this->string(3)->notNull(),
      'amount' => 'DECIMAL(8,2) NOT NULL',
      'status' => 'TINYINT(1) NOT NULL',
      'description' => $this->string(255)->notNull(),
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED NOT NULL',
      'payed_at' => 'INT(10) UNSIGNED',
      'response' => 'TEXT COLLATE utf8_unicode_ci',
      'is_hold' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
    ], $tableOptions);
//    $this->addForeignKey(
//      'user_payments_user_balance_invoice_id_fk',
//      'user_payments',
//      'user_balance_invoice_id',
//      'user_balance_invoices',
//      'id',
//      'CASCADE',
//      'CASCADE'
//    );

    $this->createTable('user_balance_invoices', [
      'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'user_id' => 'MEDIUMINT(5) NOT NULL',
      'user_payment_id' => 'INT(10) UNSIGNED DEFAULT NULL',
      'currency' => $this->string(3)->notNull(),
      'amount' => 'DECIMAL(8,2) NOT NULL',
      'description' => $this->string(255),
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'type' => 'TINYINT(1) UNSIGNED NOT NULL',
      'is_hold' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0'
    ], $tableOptions);

    $this->addForeignKey(
      'user_balance_invoices_user_payment_id_fk',
      'user_balance_invoices',
      'user_payment_id',
      'user_payments',
      'id',
      'CASCADE',
      'CASCADE'
    );

    $this->createTable('payment_system_types', [
      'id' => 'TINYINT(1) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'label' => $this->string(255)->notNull(),
      'is_disabled' => 'TINYINT(1) UNSIGNED NOT NULL'
    ], $tableOptions);
    $this->createIndex('payment_system_types_is_disabled_index', 'payment_system_types', ['is_disabled']);

    $this->createTable('user_investor_invoices', [
      'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'user_id' => 'MEDIUMINT(5) NOT NULL',
      'currency' => $this->string(3)->notNull(),
      'amount' => 'DECIMAL(8,2) NOT NULL',
      'description' => $this->string(255),
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'type' => 'TINYINT(1) UNSIGNED NOT NULL'
    ], $tableOptions);
    $this->createTable('user_balances_grouped_by_day', [
      'date' => 'INT(10) UNSIGNED NOT NULL',
      'user_id' => 'MEDIUMINT(5) NOT NULL',
      'type' => 'TINYINT(1) UNSIGNED NOT NULL',
      'is_hold' => 'TINYINT(1) UNSIGNED NOT NULL',
      'profit_rub' => 'DECIMAL(8,2) NOT NULL',
      'profit_eur' => 'DECIMAL(8,2) NOT NULL',
      'profit_usd' => 'DECIMAL(8,2) NOT NULL',
    ], $tableOptions);
    $this->addPrimaryKey(
      'date_user_id_type_is_hold_pk',
      'user_balances_grouped_by_day',
      ['date', 'user_id', 'type', 'is_hold']
    );
    $this->createIndex(
      'user_balances_grouped_by_day_is_hold_index',
      'user_balances_grouped_by_day',
      'is_hold'
    );
    $this->createTable('investor_incomes', [
      'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'user_id' => 'MEDIUMINT(5) NOT NULL',
      'currency' => $this->string(3)->notNull(),
      'amount' => 'DECIMAL(8,2) NOT NULL',
      'description' => $this->string(255)->notNull(),
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'status' => 'TINYINT(1) UNSIGNED NOT NULL'
    ], $tableOptions);
    $this->addForeignKey(
      'user_payments_payment_system_type_id_fk',
      'user_payments',
      'payment_system_type_id',
      'payment_system_types',
      'id',
      'CASCADE',
      'CASCADE'
    );
  }

  public function down()
  {
    $this->dropForeignKey('user_payments_payment_system_type_id_fk', 'user_payments');
    $this->dropForeignKey('user_payments_user_balance_invoice_id_fk', 'user_payments');
    $this->dropTable('wm_system_purses');
    $this->dropTable('user_payments');
    $this->dropTable('user_balance_invoices');
    $this->dropTable('payment_system_types');
    $this->dropTable('user_investor_invoices');
    $this->dropTable('user_balances_grouped_by_day');
    $this->dropTable('investor_incomes');
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}