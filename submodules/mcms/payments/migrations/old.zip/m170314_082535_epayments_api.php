<?php

use console\components\Migration;

class m170314_082535_epayments_api extends Migration
{
  public function up()
  {
    $this->insert('payment_systems_api', [
      'name' => 'EPayments rub',
      'code' => 'epayments',
      'currency' => 'rub',
    ]);
    $this->insert('payment_systems_api', [
      'name' => 'EPayments usd',
      'code' => 'epayments',
      'currency' => 'usd',
    ]);
    $this->insert('payment_systems_api', [
      'name' => 'EPayments eur',
      'code' => 'epayments',
      'currency' => 'eur',
    ]);
  }

  public function down()
  {
    $this->delete('payment_systems_api', 'code = "epayments"');
  }
}
