<?php

use console\components\Migration;

class m170609_163025_get_balance extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('PaymentsPaymentSystemsApiGetBalance', 'Получение баланса платежной системы', 'PaymentsPaymentSystemsApiGetBalances');
  }

  public function down()
  {
    $this->removePermission('PaymentsPaymentSystemsApiGetBalance');
  }

}
