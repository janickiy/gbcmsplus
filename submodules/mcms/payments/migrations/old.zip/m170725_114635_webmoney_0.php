<?php

use console\components\Migration;

class m170725_114635_webmoney_0 extends Migration
{
  public function up()
  {
    $this->update('wallets', ['profit_percent' => 0], ['code' => 'webmoney']);
  }

  public function down()
  {
    $this->update('wallets', ['profit_percent' => -3], ['code' => 'webmoney']);
  }
}
