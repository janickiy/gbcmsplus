<?php

use yii\db\Schema;
use console\components\Migration;

class m160202_132926_exchanger_courses extends Migration
{

  const TABLE_NAME = 'exchanger_courses';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::TABLE_NAME, [
      'id' => 'INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'usd_rur' => 'DECIMAL(13,9) UNSIGNED NOT NULL DEFAULT 0',
      'rur_usd' => 'DECIMAL(13,9) UNSIGNED NOT NULL DEFAULT 0',
      'usd_eur' => 'DECIMAL(13,9) UNSIGNED NOT NULL DEFAULT 0',
      'eur_usd' => 'DECIMAL(13,9) UNSIGNED NOT NULL DEFAULT 0',
      'eur_rur' => 'DECIMAL(13,9) UNSIGNED NOT NULL DEFAULT 0',
      'rur_eur' => 'DECIMAL(13,9) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => 'INT(10) UNSIGNED NOT NULL DEFAULT 0'
    ], $tableOptions);

    $this->createIndex(self::TABLE_NAME . '_created_at_index', self::TABLE_NAME, 'created_at');
  }

  public function down()
  {
    $this->dropTable(self::TABLE_NAME);
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
