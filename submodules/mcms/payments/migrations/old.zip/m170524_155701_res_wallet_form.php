<?php

use console\components\Migration;

class m170524_155701_res_wallet_form extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->assignRolesPermission('PaymentsWalletIndex', ['reseller']);
    $this->assignRolesPermission('PaymentsWalletUpdateModal', ['reseller']);
    $this->createPermission(
      'PaymentsWalletEditAllFields',
      'Редактирование абсолютно всех полей ПС',
      'PaymentsWalletController',
      ['root', 'admin']
    );
  }

  public function down()
  {
    $this->revokeRolesPermission('PaymentsWalletIndex', ['reseller']);
    $this->revokeRolesPermission('PaymentsWalletUpdateModal', ['reseller']);
    $this->removePermission('PaymentsWalletEditAllFields');
  }
}
