<?php

use console\components\Migration;

class m151218_172507_user_payment_is_disabled_new_default_value extends Migration
{
  public function up()
  {
    $this->alterColumn('user_payment_settings', 'is_disabled', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0');
  }

  public function down()
  {
    $this->alterColumn('user_payment_settings', 'is_disabled', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 1');
  }
}