<?php

use console\components\Migration;

/**
 * Class m170721_145603_download_perm
 */
class m170721_145603_download_perm extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  /**
   *
   */
  public function up()
  {
    $this->createPermission('PaymentsResellerInvoicesDownloadFile', 'Просмотр файлов инвойсов реселлера', 'PaymentsResellerInvoicesController', ['root', 'admin', 'reseller']);
  }

  /**
   */
  public function down()
  {
    $this->removePermission('PaymentsResellerInvoicesDownloadFile');
  }
}
