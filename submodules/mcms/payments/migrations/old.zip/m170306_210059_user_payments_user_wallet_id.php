<?php

use console\components\Migration;
use yii\db\Query;

/**
 * Class m170306_210059_user_payments_user_wallet_id
 */
class m170306_210059_user_payments_user_wallet_id extends Migration
{
  const USER_PAYMENTS = 'user_payments';

  public function up()
  {
    $this->addColumn(self::USER_PAYMENTS, 'user_wallet_id', $this->integer(5));

    $query = (new Query)->from('user_payments')->select(['wallet_type', 'currency', 'user_id'], 'DISTINCT');

    foreach ($query->each() as $combination) {

      $userWallet = (new Query)->from('user_wallets')
        ->where(['wallet_type' => $combination['wallet_type'], 'currency' => $combination['currency'], 'user_id' => $combination['user_id']])
        ->one();
      if (!$userWallet) continue;

      (new Query)->createCommand()->update('user_payments', ['user_wallet_id' => $userWallet['id']],
        ['wallet_type' => $combination['wallet_type'], 'currency' => $combination['currency'], 'user_id' => $combination['user_id']])
        ->execute();
    }

   $this->addForeignKey(self::USER_PAYMENTS . '_' . 'user_wallet_id_fk', self::USER_PAYMENTS, 'user_wallet_id', 'user_wallets', 'id', 'CASCADE', 'CASCADE');

  }

  public function down()
  {
    $this->dropForeignKey(self::USER_PAYMENTS . '_' . 'user_wallet_id_fk', self::USER_PAYMENTS);
    $this->dropColumn(self::USER_PAYMENTS, 'user_wallet_id');
  }
}
