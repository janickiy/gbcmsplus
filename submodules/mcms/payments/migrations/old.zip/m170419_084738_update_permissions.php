<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170419_084738_update_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->revokeRolesPermission('PaymentsResellerPartnerPayments', ['manager']);
    $this->revokeRolesPermission('PaymentsResellerAddCompensation', ['manager']);
    $this->revokeRolesPermission('PaymentsResellerAddMulct', ['manager']);
    $this->revokeRolesPermission('PaymentsResellerCreatePayment', ['manager']);
    $this->revokeRolesPermission('PaymentsResellerViewPayment', ['manager']);

  }

  public function down()
  {
    $this->assignRolesPermission('PaymentsResellerPartnerPayments', ['manager']);
    $this->assignRolesPermission('PaymentsResellerAddCompensation', ['manager']);
    $this->assignRolesPermission('PaymentsResellerAddMulct', ['manager']);
    $this->assignRolesPermission('PaymentsResellerCreatePayment', ['manager']);
    $this->assignRolesPermission('PaymentsResellerViewPayment', ['manager']);

  }
}
