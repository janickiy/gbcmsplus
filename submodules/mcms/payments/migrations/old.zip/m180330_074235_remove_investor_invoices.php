<?php

use console\components\Migration;
use yii\db\Query;

class m180330_074235_remove_investor_invoices extends Migration
{
  const INVESTOR_ROLE = 'investor';

  public function up()
  {
    $investorIds = (new Query())
      ->select('u.id')
      ->from('users u')
      ->innerJoin('auth_assignment aa', 'u.id = aa.user_id AND aa.item_name = :item_name')
      ->addParams([':item_name' => self::INVESTOR_ROLE])
      ->column();

    $this->delete('user_balance_invoices', ['user_id' => $investorIds]);

  }
}
