<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

class m180620_152159_alternative_grid_permissions extends Migration
{
  const SETTINGS_ALTERNATIVE_PAYMENTS_GRID_VIEW = 'settings.alternative_payments_grid_view';

  use PermissionTrait;
  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
    $this->authManager = Yii::$app->authManager;
  }

  public function up()
  {
    $this->createPermission('PaymentsEditPaymentsGridSetting',
      'Редактирование настройки альтернативный грид выплат', 'PaymentsSettings', ['root', 'admin']);
    $this->settingsBuilder->setPermissions(self::SETTINGS_ALTERNATIVE_PAYMENTS_GRID_VIEW, ['PaymentsEditPaymentsGridSetting']);
  }

  public function down()
  {
    $this->settingsBuilder->setPermissions(self::SETTINGS_ALTERNATIVE_PAYMENTS_GRID_VIEW, ['EditModuleSettingsPayments']);
    $this->removePermission('PaymentsEditPaymentsGridSetting');
  }

}
