<?php

use mcms\payments\models\UserBalanceInvoice;
use console\components\Migration;

class m160407_080449_balance_invoice_created_by extends Migration
{
  const TABLE = 'user_balance_invoices';
  public function up()
  {
    $this->addColumn(self::TABLE, 'created_by', 'MEDIUMINT(5) UNSIGNED NOT NULL AFTER created_at');
    /** @var UserBalanceInvoice $invoice */
    foreach (UserBalanceInvoice::find()->each() as $invoice) {
      if (!$payment = $invoice->getUserPayment()->one()) {
        $created_by = 1;
      } else {
        $created_by = $payment->created_by;
      }
      $invoice->created_by = $created_by;
      $invoice->save(false);
    }
  }

  public function down()
  {
    $this->dropColumn(self::TABLE, 'created_by');
  }
}
