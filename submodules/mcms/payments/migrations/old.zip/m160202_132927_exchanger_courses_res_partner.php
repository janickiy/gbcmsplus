<?php

use console\components\Migration;

class m160202_132927_exchanger_courses_res_partner extends Migration
{
  const TABLE = 'exchanger_courses';

  private static $courses = [
    'usd_rur',
    'rur_usd',
    'usd_eur',
    'eur_usd',
    'eur_rur',
    'rur_eur',
  ];

  public function up()
  {
    foreach (self::$courses as $course) {
      $this->addColumn(self::TABLE,$course . '_partner', $this->decimal(13,9)->unsigned()->notNull()->defaultValue(0)->after($course));
      $this->addColumn(self::TABLE,$course . '_real', $this->decimal(13,9)->unsigned()->notNull()->defaultValue(0)->after($course));
    }
  }

  public function down()
  {
    foreach (self::$courses as $course) {
      $this->dropColumn(self::TABLE, $course . '_real');
      $this->dropColumn(self::TABLE, $course . '_partner');
    }
  }

}
