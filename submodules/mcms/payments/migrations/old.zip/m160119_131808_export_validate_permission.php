<?php

use yii\db\Schema;
use console\components\Migration;

class m160119_131808_export_validate_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Payments' => [
        ['export-validate', 'Can validate export payments', ['admin', 'root']],
      ],
    ];
  }
}
