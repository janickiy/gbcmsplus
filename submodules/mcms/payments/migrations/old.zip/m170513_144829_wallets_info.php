<?php

use console\components\Migration;

class m170513_144829_wallets_info extends Migration
{
  public function up()
  {
    $this->update('wallets', ['info' => NULL]);
    $this->update('wallets', ['info' => serialize([
      'ru' => '<p>1. Максимальная сумма одного перевода на кошелек (включая комиссии)</p>
<ul type="square">
<li>с анонимным статусом: 15 000 RUB</li>
<li>с именным или идентифицированным статусом: 60 000 RUB</li>
</ul>
<p>2. Макисмальная сумма переводов на один кошелек</p>
<ul type="square">
<li>в сутки: 300 000 RUB</li>
<li>в месяц: 600 000 RUB</li>
</ul>',
      'en' => '<p>1. The maximum amount per transfer (including fees)</p>
<ul type="square">
<li>to an anonymous user\'s wallet: 15 000 RUB</li>
<li>to a reviewed or identified user\'s wallet: 60 000 RUB</li>
</ul>
<p>2. The maximum amount for making transfers to a single wallet</p>
<ul type="square">
<li>per day: 300 000 RUB</li>
<li>per month: 600 000 RUB</li>
</ul>',
    ])], ['code' => 'yandex-money']);
    $this->update('wallets', ['info' => serialize([
      'ru' => '<p>1. Лимит остатка на балансе кошелька Qiwi:</p>
<ul type="square">
<li>с анонимным статусом: 15 000 RUB</li>
<li>со стандартным статусом: 60 000 RUB</li>
<li>с максимальным статусом: 600 000 RUB</li>
</ul>
<p>2. Лимит платежей на один кошелек в месяц:</p>
<ul type="square">
<li>с анонимным статусом: 40 000 RUB</li>
<li>со стандартным статусом: 60 000 RUB</li>
<li>с максимальным статусом: без ограничений</li>
</ul>
<p>*лимиты в других валютах эквивалентны рублевым</p>',
      'en' => '<p>1. Remaining balance limit on Qiwi wallets:</p>
<ul type="square">
<li>with anonymous status: 15 000 RUB</li>
<li>with standard status: 60 000 RUB</li>
<li>with maximum status: 600 000 RUB</li>
</ul>
<p>2. Monthly payment limits per wallet:</p>
<ul type="square">
<li>with anonymous status: 40 000 RUB</li>
<li>with standard status: 60 000 RUB</li>
<li>with maximum status: no limit</li>
</ul>
<p>*limits for other currencies are equal to the rouble equivalents shown above</p>',
    ])], ['code' => 'qiwi']);
  }

  public function down()
  {
    $this->update('wallets', ['info' => NULL]);
  }

}
