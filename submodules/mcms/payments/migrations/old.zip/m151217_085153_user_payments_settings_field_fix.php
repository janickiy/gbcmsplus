<?php

use console\components\Migration;

class m151217_085153_user_payments_settings_field_fix extends Migration
{
  public function up()
  {
    $this->alterColumn('user_payment_settings', 'wallet_type', 'TINYINT(1) UNSIGNED DEFAULT NULL');
  }

  public function down()
  {
    $this->alterColumn('user_payment_settings', 'wallet_type', 'TINYINT(1) UNSIGNED NOT NULL');
  }
}
