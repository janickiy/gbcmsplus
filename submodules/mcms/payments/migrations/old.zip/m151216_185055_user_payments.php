<?php

use console\components\Migration;

class m151216_185055_user_payments extends Migration
{
  public function up()
  {
    $this->addColumn('user_payments', 'wallet_type', 'TINYINT(1) UNSIGNED NOT NULL AFTER user_id');
    $this->createIndex('user_payments_wallet_type_index', 'user_payments', 'wallet_type');

  }

  public function down()
  {
    $this->dropColumn('user_payments', 'wallet_type');
  }
}
