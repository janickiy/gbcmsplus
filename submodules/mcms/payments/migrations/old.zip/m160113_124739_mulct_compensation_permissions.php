<?php

use console\components\Migration;

class m160113_124739_mulct_compensation_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Users' => [
        ['add-mulct', 'Can add mulct', ['admin', 'root']],
        ['add-compensation', 'Can add compensation', ['admin', 'root']],
      ]
    ];
  }


}
