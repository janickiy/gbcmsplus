<?php

use console\components\Migration;

/**
 * Class m170727_125953_act_file_src
 */
class m170727_125953_act_file_src extends Migration
{
  /**
   *
   */
  public function up()
  {
    $this->addColumn('user_payments', 'invoice_file', $this->string()->after('check_file_src'));
    $this->renameColumn('user_payments', 'check_file_src', 'cheque_file');

    $this->addColumn('wallets', 'is_invoice_file_required', $this->boolean()->defaultValue(false));
    $this->addColumn('wallets', 'is_invoice_file_show', $this->boolean()->defaultValue(false));
  }

  /**
   *
   */
  public function down()
  {
    $this->dropColumn('wallets', 'is_invoice_file_show');
    $this->dropColumn('wallets', 'is_invoice_file_required');

    $this->dropColumn('user_payments', 'invoice_file');
    $this->renameColumn('user_payments', 'cheque_file', 'check_file_src');
  }
}
