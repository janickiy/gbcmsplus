<?php

use console\components\Migration;

class m151217_054653_reseller_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Users' => [
        ['updatePartner', 'Can update user settings', ['partner', 'investor', 'reseller']],
        ['updatePartnerSettings', 'Can update user settings', ['partner', 'investor', 'reseller']],
      ],
      'Reseller' => [
        ['payments', 'Can view reseller payments', ['reseller']],
        ['settings', 'Can set settings payments', ['reseller']],
        ['daily-profit', 'Can view daily profit', ['reseller']],
      ],
    ];
  }
}
