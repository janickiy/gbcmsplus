<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170405_145026_payments_get_summary_action extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PaymentsPaymentsGetSummary', 'Сумма выплат и балансов', 'PaymentsPaymentsController', ['admin', 'root', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('PaymentsPaymentsGetSummary');
  }
}
