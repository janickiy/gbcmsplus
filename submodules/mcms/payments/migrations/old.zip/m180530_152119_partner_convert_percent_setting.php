<?php

use rgk\settings\models\Setting;
use console\components\Migration;

class m180530_152119_partner_convert_percent_setting extends Migration
{
  const SETTING = 'settings.payments.exchange_percent_';

  private static $courses = [
    'usd_rur',
    'rur_usd',
    'usd_eur',
    'eur_usd',
    'eur_rur',
    'rur_eur',
  ];

  /** @var \rgk\settings\components\SettingsBuilder $settingsBuilder */
  private $settingsBuilder;

  public function init()
  {
    parent::init();
    $this->settingsBuilder = Yii::$app->settingsBuilder;
  }

  public function up()
  {
    foreach (self::$courses as $order => $course) {
      $courseTitle = strtoupper(str_replace('_', '/', $course));
      $title = ['ru' => 'Процент комиссии при конвертации ' . $courseTitle, 'en' => 'Exchange percent commission ' . $courseTitle];
      $permissions = ['EditModuleSettingsPayments'];
      $category = 'app.common.form_group_payments_main';
      $validators = [['number', ['min' => 0, 'max' => 20]],['double']];
      $this->settingsBuilder->createSetting($title, [], self::SETTING . $course, $permissions, Setting::TYPE_FLOAT, $category, 2, $validators, $order);
    }
  }

  public function down()
  {
    foreach (self::$courses as $course) {
      $this->settingsBuilder->removeSetting(self::SETTING . $course);
    }
  }
}