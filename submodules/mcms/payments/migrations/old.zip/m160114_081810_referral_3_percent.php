<?php

use console\components\Migration;

class m160114_081810_referral_3_percent extends Migration
{
  public function up()
  {
    $this->update('user_payment_settings', ['referral_percent' => 3]);
  }

  public function down()
  {
    echo "m160114_081810_referral_3_percent cannot be reverted.\n";
  }
}
