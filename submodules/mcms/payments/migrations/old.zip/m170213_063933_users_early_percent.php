<?php

use mcms\common\module\settings\Float;
use mcms\common\module\settings\Repository;
use mcms\modmanager\models\Module;
use console\components\Migration;

class m170213_063933_users_early_percent extends Migration
{
  const MODULE = 'payments';
  const SETTING = 'settings.early_payment_percent';
  const NEW_PERCENT = 0.0;

  public function up()
  {
    // Убрать процент у текущих пользователей
    $this->execute("UPDATE user_payment_settings SET early_payment_percent = " . self::NEW_PERCENT);

    // Убрать процент из настроек модуля
    /** @var Module $payments */
    $payments = Module::findOne(['module_id' => self::MODULE]);
    /** @var Repository $promoRepo */
    $promoRepo = unserialize($payments->settings);
    // Если настроек нет, инициализируем
    if (!$promoRepo) {
      $promoRepo = (new Repository())->setModuleId(self::MODULE);
      $promoRepo->set((new Float())->setKey(self::SETTING));
    }
    // Установка параметра в настройки модуля
    $promoRepo->offsetSet(self::SETTING, self::NEW_PERCENT);
    $payments->settings = serialize($promoRepo);
    $payments->save();
  }

  public function down()
  {
    echo "m170213_063933_users_earcly_percent cannot be reverted.\n";
  }
}
