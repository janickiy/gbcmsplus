<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170510_132933_payments_find_users extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->createPermission('PaymentsResellerFindUser', 'Поиск партнеров реселлером', 'PaymentsResellerController', ['reseller']);
  }

  public function down()
  {
    $this->removePermission('PaymentsResellerFindUser');
  }
}
