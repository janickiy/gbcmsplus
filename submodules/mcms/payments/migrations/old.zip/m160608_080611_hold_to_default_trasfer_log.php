<?php

use console\components\Migration;

class m160608_080611_hold_to_default_trasfer_log extends Migration
{
  const TABLE = 'hold_balance_transfer_logs';
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::TABLE, [
      'landing_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'date' => 'DATE NOT NULL',
      'currency' => 'VARCHAR(3) NOT NULL',
      'amount' => 'DECIMAL(8,2) NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
    ], $tableOptions);
    $this->addPrimaryKey('landing_id_user_id_date_pk', self::TABLE, ['landing_id', 'user_id', 'date', 'currency']);
  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
