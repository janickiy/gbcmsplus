<?php

use console\components\Migration;

class m170315_212611_paypal_api extends Migration
{
  public function up()
  {
    foreach (['rub', 'usd', 'eur'] as $currency) {
      $this->insert('payment_systems_api', ['name' => 'PayPal ' . $currency, 'code' => 'paypal', 'currency' => $currency]);
    }
  }

  public function down()
  {
    $this->delete('payment_systems_api', ['code' => 'paypal']);
  }
}
