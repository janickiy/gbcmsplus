<?php

use console\components\Migration;

class m160304_120142_fill_user_payment_info extends Migration
{
  public function up()
  {
    return true;
  }

  public function down()
  {
    return true;
  }
}
