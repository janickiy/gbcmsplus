<?php

use console\components\Migration;

class m151123_120527_init_permissions extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'PaymentSystemTypes' => [
        ['index', 'Can lists all PaymentSystemType models', ['admin', 'root']],
        ['create', 'Can create a new PaymentSystemType model', ['admin', 'root']],
        ['update', 'Can updates an existing PaymentSystemType model', ['admin', 'root']],
        ['enable', 'Can enable an existing PaymentSystemType model', ['admin', 'root']],
        ['disable', 'Can disable an existing PaymentSystemType model', ['admin', 'root']],
      ],
      'User' => [
        ['index', 'Can view users list', ['admin', 'root']],
        ['view', 'Can view users payments', ['admin', 'root']],
        ['profit', 'Can view users profit statistics', ['admin', 'root']],
        ['updateSettings', 'Can update users profit settings', ['admin', 'root']],
        ['updatePartnerSettings', 'Can update users profit settings', ['admin', 'root', 'partner']],
        ['balanceInvoice', 'Can view partner invoice details', ['admin', 'root']],
        ['investorInvoice', 'Can view investor invoice details', ['admin', 'root']],
      ],
      'WmSystemPurses' => [
        ['index', 'Can view all WmSystemPurse models', ['admin', 'root']],
        ['create', 'Can create WmSystemPurse models', ['admin', 'root']],
        ['update', 'Can update WmSystemPurse models', ['admin', 'root']],
        ['enable', 'Can enable WmSystemPurse models', ['admin', 'root']],
        ['disable', 'Can disable WmSystemPurse models', ['admin', 'root']],
      ],
      'Payments' => [
        ['index', 'Can view all Payments models', ['admin', 'root']],
        ['create', 'Can create Payments models', ['admin', 'root']],
        ['update', 'Can update Payments models', ['admin', 'root']],
        ['findUser', 'Can view Users', ['admin', 'root']],
        ['userDetail', 'Can view Users', ['admin', 'root']],
      ]
    ];
  }
}
