<?php

use console\components\Migration;

class m160104_110414_table_referral_incomes extends Migration
{
  const TABLE_NAME = 'referral_incomes';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(self::TABLE_NAME, [
      'date' => 'DATE DEFAULT NULL',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'referral_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'is_hold' => 'TINYINT(1) UNSIGNED NOT NULL',
      'profit_rub' => 'DECIMAL(8,2) NOT NULL',
      'profit_eur' => 'DECIMAL(8,2) NOT NULL',
      'profit_usd' => 'DECIMAL(8,2) NOT NULL',
      'referral_percent' => 'MEDIUMINT(3) UNSIGNED NOT NULL',
    ], $tableOptions);
  }

  public function down()
  {
    $this->dropTable(self::TABLE_NAME);
  }
}