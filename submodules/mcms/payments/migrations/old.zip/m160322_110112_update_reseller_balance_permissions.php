<?php

use console\components\Migration;

class m160322_110112_update_reseller_balance_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
  }


  public function up()
  {
    $this->removePermission('PaymentsResellerPayments');
    $this->createOrGetPermission('PaymentsResellerInvoices', 'View reseller balance invoices');
    $this->assignRolesPermission('PaymentsResellerInvoices', ['reseller']);
  }

  public function down()
  {
    $this->removePermission('PaymentsResellerInvoices');
    $this->createOrGetPermission('PaymentsResellerPayments', 'View reseller balance payments');
    $this->assignRolesPermission('PaymentsResellerPayments', ['reseller']);
  }
}
