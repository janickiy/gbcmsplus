<?php

use mcms\notifications\models\Notification;
use console\components\Migration;
use yii\helpers\ArrayHelper;

class m170609_094550_event_payment_update extends Migration
{
    public function up()
    {
      $paymentsModule = Yii::$app->getModule('payments');
      $paymentsModuleEntity = Yii::$app->getModule('modmanager')
        ->api('moduleById', ['moduleId' => $paymentsModule->id])
        ->getResult();

      $this->createNotification([
        'module_id' => $paymentsModuleEntity->id,
        'event' => \mcms\payments\components\events\PaymentUpdated::className(),
        'type' => Notification::NOTIFICATION_TYPE_BROWSER,
        'header' => [
          'ru' => 'Выплата #{model.id} обновлена.',
          'en' => 'Payment #{model.id} updated.',
        ],
        'template' => [
          'ru' => 'Статус выплаты: {model.status}.',
          'en' => 'Payment status: {model.status}.'
        ],
        'use_owner' => false,
        'roles' => ['admin', 'root', 'reseller']
      ]);
    }

    public function down()
    {
      Notification::find()->andWhere(['event' => 'mcms\payments\components\events\PaymentUpdated'])->one()->delete();
    }



  /**
   * @see \m160306_181406_update_notifications::createNotification()
   * @param array $notification
   */
  private function createNotification(array $notification)
  {
    $model = new Notification;
    $model->module_id = ArrayHelper::getValue($notification, 'module_id');
    $model->event = ArrayHelper::getValue($notification, 'event');
    $model->notification_type = ArrayHelper::getValue($notification, 'type');
    $model->header = ArrayHelper::getValue($notification, 'header');
    $model->template = ArrayHelper::getValue($notification, 'template');
    $model->use_owner = ArrayHelper::getValue($notification, 'use_owner', false);

    if ($roles = ArrayHelper::getValue($notification, 'roles', [])) {
      $model->setRoles($roles);
    }

    $model->from = ArrayHelper::getValue($notification, 'from');

    $model->save(false);

  }
}
