<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170330_144825_clean_payments_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->removePermission('PaymentsUsersUpload');
    $this->removePermission('PaymentsUsersIndex');
    $this->removePermission('PaymentsUsersUploadWalletFiles');

    $this->removePermission('PaymentsResellerUpload');

    $this->removePermission('PaymentsResellerCheckoutGetPayments');

    $this->removePermission('PaymentsPaymentSystemTypesController');
    $this->removePermission('PaymentsPaymentSystemTypesCreate');
    $this->removePermission('PaymentsPaymentSystemTypesDisable');
    $this->removePermission('PaymentsPaymentSystemTypesEnable');
    $this->removePermission('PaymentsPaymentSystemTypesIndex');
    $this->removePermission('PaymentsPaymentSystemTypesUpdate');

    $this->removePermission('PaymentsPaymentsAutoPayout');
    $this->removePermission('PaymentsPaymentsFindUser');
    $this->removePermission('PaymentsPaymentsPayoutWm');

    $this->removePermission('PaymentsInvestorTransfer');
    $this->removePermission('PaymentsInvestorUpload');

  }

  public function down()
  {
    $this->createPermission('PaymentsUsersUpload', 'Загрузка аватара админом', 'PaymentsUsersController', ['admin', 'root']);
//    $this->createPermission('PaymentsUsersDeleteWallet', 'Удаление кошелька', 'PaymentsUsersController', ['admin', 'root']);
    $this->createPermission('PaymentsUsersIndex', 'Просмотр списка пользователей', 'PaymentsUsersController', ['admin', 'root']);
    $this->createPermission('PaymentsUsersUploadWalletFiles', 'Загрузка файлов для кошельков', 'PaymentsUsersController', ['admin', 'root', 'reseller']);

    $this->createPermission('PaymentsResellerUpload', 'Загрузка аватара реселлером', 'PaymentsResellerController', ['reseller']);

    $this->createPermission('PaymentsResellerCheckoutGetPayments', 'Получение кошельков пользователя', 'PaymentsResellerCheckoutController');

    $this->createPermission('PaymentsPaymentSystemTypesController', 'Контроллер PaymentSystemTypes', 'PaymentsModule');
    $this->createPermission('PaymentsPaymentSystemTypesCreate', 'Создание платежной системы', 'PaymentsPaymentSystemTypesController', ['admin', 'root']);
    $this->createPermission('PaymentsPaymentSystemTypesDisable', 'Выключение платежной системы', 'PaymentsPaymentSystemTypesController', ['admin', 'root']);
    $this->createPermission('PaymentsPaymentSystemTypesEnable', 'Включение платежной системы', 'PaymentsPaymentSystemTypesController', ['admin', 'root']);
    $this->createPermission('PaymentsPaymentSystemTypesIndex', 'Просмотр списка платежных систем', 'PaymentsPaymentSystemTypesController', ['admin', 'root']);
    $this->createPermission('PaymentsPaymentSystemTypesUpdate', 'Редактирование платежной системы', 'PaymentsPaymentSystemTypesController', ['admin', 'root']);

    $this->createPermission('PaymentsPaymentsAutoPayout', 'Автоплатеж в кошелек', 'PaymentsPaymentsController', ['admin', 'root']);
    $this->createPermission('PaymentsPaymentsFindUser', 'Просмотр пользователей', 'PaymentsPaymentsController', ['admin', 'root']);
    $this->createPermission('PaymentsPaymentsPayoutWm', 'Платеж на WM-кошелек', 'PaymentsPaymentsController', ['admin', 'root']);

    $this->createPermission('PaymentsInvestorTransfer', 'Просмотр формы перевода между счетами', 'PaymentsInvestorController', ['investor']);
    $this->createPermission('PaymentsInvestorUpload', 'Загрузка аватара инвестором', 'PaymentsInvestorController', ['investor']);
  }
}
