<?php

use console\components\Migration;

class m170830_085708_can_have_ballance_wallets_permissions extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->createPermission('CanUserHaveWallets', 'Возможность иметь кошельки', 'PaymentsPermissions', ['reseller', 'partner']);
    $this->createPermission('CanUserHaveBalance', 'Возможность иметь баланс', 'PaymentsPermissions', ['reseller', 'partner', 'investor']);
  }

  public function down()
  {
    $this->removePermission('CanUserHaveWallets');
    $this->removePermission('CanUserHaveBalance');
  }
}
