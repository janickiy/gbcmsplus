<?php

use console\components\Migration;

class m170504_134803_res_create_paym extends Migration
{

  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->revokeRolesPermission('PaymentsResellerCreatePayment', ['reseller']);
  }

  public function down()
  {
    $this->assignRolesPermission('PaymentsResellerCreatePayment', ['reseller']);
  }

}
