<?php

use console\components\Migration;

class m160419_145401_can_change_currency_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->getAuthManager();
  }


  public function up()
  {
    $changeCurrencyRuleObject = new \mcms\payments\components\rbac\ChangeCurrencyRule();
    $this->authManager->add($changeCurrencyRuleObject);
    $this->createOrGetPermission('PaymentsCanChangeCurrency', 'Can change currency', $changeCurrencyRuleObject->name);
    $this->assignRolesPermission('PaymentsCanChangeCurrency', ['root', 'admin', 'reseller', 'manager', 'investor', 'partner']);

    $changeWalletRuleObject = new \mcms\payments\components\rbac\ChangeWalletRule();
    $this->authManager->add($changeWalletRuleObject);
    $this->createOrGetPermission('PaymentsCanChangeWallet', 'Can change wallet', $changeWalletRuleObject->name);
    $this->assignRolesPermission('PaymentsCanChangeWallet', ['root', 'admin', 'reseller', 'manager', 'investor', 'partner']);

    $this->createOrGetPermission('PaymentsCanChangeWalletForce', 'Can change wallet force');
    $this->assignRolesPermission('PaymentsCanChangeWalletForce', ['root', 'admin', 'reseller', 'manager']);
  }

  public function down()
  {
    $changeCurrencyRuleObject = new \mcms\payments\components\rbac\ChangeCurrencyRule();
    $this->authManager->remove($changeCurrencyRuleObject);
    $changeWalletRuleObject = new \mcms\payments\components\rbac\ChangeWalletRule();
    $this->authManager->remove($changeWalletRuleObject);
    $this->removePermission('PaymentsCanChangeCurrency');
    $this->removePermission('PaymentsCanChangeWallet');
    $this->removePermission('PaymentsCanChangeWalletForce');
  }
}
