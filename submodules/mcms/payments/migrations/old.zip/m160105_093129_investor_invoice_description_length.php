<?php

use console\components\Migration;

class m160105_093129_investor_invoice_description_length extends Migration
{

  const TABLE = 'user_investor_invoices';

  public function up()
  {
    $this->alterColumn(self::TABLE, 'description', $this->text());
  }

  public function down()
  {
    $this->alterColumn(self::TABLE, 'description', $this->string());
  }

}
