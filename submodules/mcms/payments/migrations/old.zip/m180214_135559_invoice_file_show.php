<?php

use console\components\Migration;

class m180214_135559_invoice_file_show extends Migration
{
  public function up()
  {
    $this->update('wallets', ['is_invoice_file_show' => true], ['code' => ['wireiban', 'private-person', 'juridical-person']]);
  }

  public function down()
  {
    // Не меняем, чтобы не затереть настройки, выставленные вручную
    return true;
  }
}
