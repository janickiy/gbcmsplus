<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170403_173311_delete_wallet_permissions extends Migration
{
  use PermissionTrait;

  const DELETE_WALLET_PERMISSION = 'PaymentsUsersDeleteWallet';

  public function up()
  {
    $this->assignRolesPermission(self::DELETE_WALLET_PERMISSION, ['reseller']);
  }

  public function down()
  {
    $this->revokeRolesPermission(self::DELETE_WALLET_PERMISSION, ['reseller']);
  }
}
