<?php

use console\components\Migration;
use mcms\payments\Module;

class m160216_082056_fileupload extends Migration
{
  public function up()
  {
    $settings = Yii::$app->getModule('payments')->settings;
    $currentValue = $settings->getValueByKey('settings.payments.wm.kwm.file');

    if (!$currentValue) return true;

    $newValue = basename($currentValue);

    $settings->offsetSet('settings.payments.wm.kwm.file', $newValue);
  }

  public function down()
  {
    echo "m160216_082056_fileupload cannot be reverted.\n";

    return false;
  }
}
