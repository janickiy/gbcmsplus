<?php

use mcms\notifications\models\Notification;
use console\components\Migration;
use yii\helpers\ArrayHelper;

class m180607_080536_remove_payments_notifications extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->delete('notifications', "event LIKE '%RegularPaymentsGenerated'");
    $this->removePermission('PaymentsPaymentsGeneratePayments');
  }

  public function down()
  {
    //модуль выплаты
    $paymentsModule = Yii::$app->getModule('payments');
    $paymentsModuleId = Yii::$app->getModule('modmanager')
      ->api('moduleById', ['moduleId' => $paymentsModule->id])
      ->getResult();

    $this->createNotification([
      'module_id' => $paymentsModuleId->id,
      'event' => 'mcms\\payments\\components\\events\\RegularPaymentsGenerated',
      'type' => Notification::NOTIFICATION_TYPE_BROWSER,
      'header' => [
        'ru' => 'Выплата за период {component.dateFrom} - {component.dateTo}',
        'en' => 'Payment for the period {component.dateFrom} - {component.dateTo}',
      ],
      'template' => [
        'ru' => 'Кол-во: {component.count} шт.<br/>Общая сумма выплат: {component.amount.rub} руб, {component.amount.eur} евро, {component.amount.usd} долларов.',
        'en' => 'Qty:. {component.count} items <br/> Total Payments: {component.amount.rub} rubles, {component.amount.eur} euros, {component.amount.usd} dollars.'
      ],
      'roles' => ['admin', 'root', 'reseller'],
    ]);

    $this->createPermission('PaymentsPaymentsGeneratePayments', 'Генерирование платежей',
      'PaymentsPaymentsController', ['root', 'admin']);
  }

  private function createNotification(array $notification)
  {
    $model = new Notification();
    $model->module_id = ArrayHelper::getValue($notification, 'module_id');
    $model->event = ArrayHelper::getValue($notification, 'event');
    $model->notification_type = ArrayHelper::getValue($notification, 'type');
    $model->header = ArrayHelper::getValue($notification, 'header');
    $model->template = ArrayHelper::getValue($notification, 'template');
    $model->use_owner = ArrayHelper::getValue($notification, 'use_owner', false);

    if ($roles = ArrayHelper::getValue($notification, 'roles', [])) {
      $model->setRoles($roles);
    }

    $model->from = ArrayHelper::getValue($notification, 'from');

    $model->save(false);
  }

}
