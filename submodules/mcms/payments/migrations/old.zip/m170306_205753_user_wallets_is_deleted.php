<?php

use console\components\Migration;

class m170306_205753_user_wallets_is_deleted extends Migration
{
  const USER_WALLETS = 'user_wallets';

  public function up()
  {
    $this->addColumn(self::USER_WALLETS, 'is_deleted', $this->smallInteger(1)->unsigned()->notNull()->defaultValue(0));
    $this->createIndex(self::USER_WALLETS . '_is_deleted_index', self::USER_WALLETS, 'is_deleted');
  }

  public function down()
  {
    $this->dropColumn(self::USER_WALLETS, 'is_deleted');
  }
}
