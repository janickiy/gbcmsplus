<?php

use console\components\Migration;

class m170608_174655_user_payment_paysystem_percent extends Migration
{
  public function up()
  {
    $this->addColumn('user_payments', 'rgk_processing_percent', $this->decimal(5, 2)->defaultValue(null)->after('invoice_amount'));
    $this->addColumn('user_payments', 'rgk_paysystem_percent', $this->decimal(5, 2)->defaultValue(null)->after('invoice_amount'));
    $this->alterColumn('user_payments','reseller_paysystem_percent', $this->decimal(5, 2)->defaultValue(null)->after('invoice_amount'));
  }

  public function down()
  {
    $this->dropColumn('user_payments', 'rgk_processing_percent');
    $this->dropColumn('user_payments', 'rgk_paysystem_percent');
    $this->alterColumn('user_payments','reseller_paysystem_percent', $this->decimal(5, 2)->defaultValue(0)->after('invoice_amount'));
  }
}
