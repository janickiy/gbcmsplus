<?php

use yii\db\Schema;
use console\components\Migration;

class m160126_070918_payments_from_to_fields_change_autoincrement extends Migration
{
  public function up()
  {
    $this->addColumn('user_payments', 'from_date', 'DATE DEFAULT NULL');
    $this->addColumn('user_payments', 'to_date', 'DATE DEFAULT NULL');
    $this->execute('ALTER TABLE user_payments AUTO_INCREMENT=1000000');
  }

  public function down()
  {
    $this->dropColumn('user_payments', 'from_date');
    $this->dropColumn('user_payments', 'to_date');
    $this->execute('ALTER TABLE user_payments AUTO_INCREMENT=1');
  }
}
