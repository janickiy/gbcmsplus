<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
*/
class m180809_142041_remove_old_page extends Migration
{
  use PermissionTrait;
  /**
  */
  public function up()
  {
    $this->removePermission('PaymentsPaymentsCourse');
  }

  /**
  */
  public function down()
  {
    $this->createPermission('PaymentsPaymentsCourse', 'Курсы конвертации валют', 'PaymentsPaymentsController', ['root', 'admin', 'reseller']);
  }
}
