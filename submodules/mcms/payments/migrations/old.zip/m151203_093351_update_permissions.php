<?php

use console\components\Migration;

class m151203_093351_update_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'User' => [
        ['balanceInvestorTransfer', 'Can transfer money between invoice and main balance', ['admin', 'root']],
      ],
      'Investor' => [
        ['index', 'Can view own investor profile', ['investor']],
        ['settings', 'Can update own investor settings', ['investor']],
        ['require-early-payment', 'Can require early payment', ['investor']],
        ['transfer', 'Can view transfer form between invoice and main balance', ['investor']],
        ['balance-transfer', 'Can transfer money between invoice and main balance', ['investor']],
        ['main-balance-invoices', 'Can view invoices of main balance', ['investor']],
        ['investor-balance-invoices', 'Can view invoices of investor balance', ['investor']],
        ['to-up-investor-balance', 'Can to up investor balance', ['investor']],
        ['merchant', 'Can submit merchant form', ['investor']],
      ],
      'Merchant' => [
        ['result', 'can do something', ['guest']],
        ['success', 'can do something', ['guest']],
        ['fail', 'can do something', ['guest']],
      ]
    ];
  }


}
