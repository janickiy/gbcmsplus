<?php

use console\components\Migration;

class m170620_070024_autopayout_root extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->assignRolesPermission('PaymentsAutoPayoutRule', ['root']);
  }

  public function down()
  {
  }
}
