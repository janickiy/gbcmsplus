<?php

use console\components\Migration;

class m151213_140308_remove_system_wm extends Migration
{
  public function up()
  {
    $this->dropTable('wm_system_purses');
  }

  public function down()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable('wm_system_purses', [
      'id' => 'TINYINT(2) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'wmid' => $this->string(13)->notNull(),
      'certificate' => $this->string(255)->notNull(),
      'is_disabled' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0'
    ], $tableOptions);
    $this->createIndex('wm_system_purses_is_disabled_index', 'wm_system_purses', ['is_disabled']);
  }

  /*
  // Use safeUp/safeDown to run migration code within a transaction
  public function safeUp()
  {
  }

  public function safeDown()
  {
  }
  */
}
