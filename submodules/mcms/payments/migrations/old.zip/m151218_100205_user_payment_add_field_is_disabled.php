<?php

use console\components\Migration;

class m151218_100205_user_payment_add_field_is_disabled extends Migration
{
  public function safeUp()
  {
    $this->addColumn('user_payment_settings', 'is_disabled', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 1');
  }

  public function safeDown()
  {
    $this->dropColumn('user_payment_settings', 'is_disabled');
  }
}