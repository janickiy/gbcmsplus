<?php

use yii\db\Schema;
use console\components\Migration;

class m160127_203800_autopayment_migration extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Payments';
    $this->permissions = [
      'Payments' => [
        ['autoPayout', 'Can auto payout on wallet', ['admin', 'root']]
      ]
    ];
  }

}
