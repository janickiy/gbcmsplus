<?php

use yii\db\Schema;
use console\components\Migration;

class m160202_161754_wallet_account_expand extends Migration
{
  const TABLE = 'user_payment_settings';

  public function up()
  {
    $this->alterColumn(self::TABLE, 'wallet_account', 'text');
  }

  public function down()
  {
    $this->alterColumn(self::TABLE, 'wallet_account', 'varchar(255)');
  }
}
