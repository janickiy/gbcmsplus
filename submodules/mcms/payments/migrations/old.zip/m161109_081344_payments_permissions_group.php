<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

/**
 * Группировка прав модуля Payments
 */
class m161109_081344_payments_permissions_group extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('PaymentsModule');

    // Разрешения
    $this->createPermission('PaymentsPermissions', '', 'PaymentsModule');
    $this->addChildPermission('PaymentsPermissions', 'PaymentsCanChangeCurrency');
    $this->addChildPermission('PaymentsPermissions', 'PaymentsCanChangeWallet');
    $this->addChildPermission('PaymentsPermissions', 'PaymentsCanChangeWalletForce');
    $this->addChildPermission('PaymentsPermissions', 'PaymentsCanUseMultipleCurrenciesBalance');

    $this->addChildPermission('PaymentsPermissions', 'PaymentsViewSystemWalletBalances');
    $this->addChildPermission('PaymentsPermissions', 'PaymentsWalletDetailView');
    $this->addChildPermission('PaymentsPermissions', 'PaymentsEditPayedPayments');

    $this->addChildPermission('PaymentsPermissions', 'PaymentsUsersCanChangeAdminSettings');
    $this->addChildPermission('PaymentsPermissions', 'PaymentsUsersCanEnableAutopay');
    $this->addChildPermission('PaymentsPermissions', 'PaymentsUsersChangeReinvestSettings');
    $this->addChildPermission('PaymentsPermissions', 'PaymentsUsersDisableUserPayments');

    // Контроллеры
    $this->createPermission('PaymentsInvestorController', '', 'PaymentsModule');
    $this->addChildPermission('PaymentsInvestorController', 'PaymentsInvestorBalanceTransfer');
    $this->addChildPermission('PaymentsInvestorController', 'PaymentsInvestorDailyProfit');
    $this->addChildPermission('PaymentsInvestorController', 'PaymentsInvestorIndex');
    $this->addChildPermission('PaymentsInvestorController', 'PaymentsInvestorInvestorBalanceInvoices');
    $this->addChildPermission('PaymentsInvestorController', 'PaymentsInvestorMainBalanceInvoices');
    $this->addChildPermission('PaymentsInvestorController', 'PaymentsInvestorMerchant');
    $this->addChildPermission('PaymentsInvestorController', 'PaymentsInvestorProfile');
    $this->addChildPermission('PaymentsInvestorController', 'PaymentsInvestorRequireEarlyPayment');
    $this->addChildPermission('PaymentsInvestorController', 'PaymentsInvestorSettings');
    $this->addChildPermission('PaymentsInvestorController', 'PaymentsInvestorToUpInvestorBalance');
    $this->addChildPermission('PaymentsInvestorController', 'PaymentsInvestorTransfer');
    $this->addChildPermission('PaymentsInvestorController', 'PaymentsInvestorUpload');

    $this->createPermission('PaymentsMerchantController', '', 'PaymentsModule');
    $this->addChildPermission('PaymentsMerchantController', 'PaymentsMerchantFail');
    $this->addChildPermission('PaymentsMerchantController', 'PaymentsMerchantResult');
    $this->addChildPermission('PaymentsMerchantController', 'PaymentsMerchantSuccess');

    $this->createPermission('PaymentsPaymentsController', '', 'PaymentsModule');
    $this->addChildPermission('PaymentsPaymentsController', 'PaymentsPaymentsAutoPayout');
    $this->addChildPermission('PaymentsPaymentsController', 'PaymentsPaymentsCreate');
    $this->addChildPermission('PaymentsPaymentsController', 'PaymentsPaymentsExport');
    $this->addChildPermission('PaymentsPaymentsController', 'PaymentsPaymentsExportValidate');
    $this->addChildPermission('PaymentsPaymentsController', 'PaymentsPaymentsFindUser');
    $this->addChildPermission('PaymentsPaymentsController', 'PaymentsPaymentsGeneratePayments');
    $this->addChildPermission('PaymentsPaymentsController', 'PaymentsPaymentsIndex');
    $this->addChildPermission('PaymentsPaymentsController', 'PaymentsPaymentsPayoutInfo');
    $this->addChildPermission('PaymentsPaymentsController', 'PaymentsPaymentsPayoutWm');
    $this->addChildPermission('PaymentsPaymentsController', 'PaymentsPaymentsUpdate');
    $this->addChildPermission('PaymentsPaymentsController', 'PaymentsPaymentsUserDetail');
    $this->addChildPermission('PaymentsPaymentsController', 'PaymentsPaymentsValidate');
    $this->addChildPermission('PaymentsPaymentsController', 'PaymentsPaymentsView');

    $this->createPermission('PaymentsPaymentSystemTypesController', '', 'PaymentsModule');
    $this->addChildPermission('PaymentsPaymentSystemTypesController', 'PaymentsPaymentSystemTypesCreate');
    $this->addChildPermission('PaymentsPaymentSystemTypesController', 'PaymentsPaymentSystemTypesDisable');
    $this->addChildPermission('PaymentsPaymentSystemTypesController', 'PaymentsPaymentSystemTypesEnable');
    $this->addChildPermission('PaymentsPaymentSystemTypesController', 'PaymentsPaymentSystemTypesIndex');
    $this->addChildPermission('PaymentsPaymentSystemTypesController', 'PaymentsPaymentSystemTypesUpdate');

    $this->createPermission('PaymentsResellerController', '', 'PaymentsModule');
    $this->addChildPermission('PaymentsResellerController', 'PaymentsResellerAddCompensation');
    $this->addChildPermission('PaymentsResellerController', 'PaymentsResellerAddMulct');
    $this->addChildPermission('PaymentsResellerController', 'PaymentsResellerAutoPayout');
    $this->addChildPermission('PaymentsResellerController', 'PaymentsResellerCreatePayment');
    $this->addChildPermission('PaymentsResellerController', 'PaymentsResellerDailyProfit');
    $this->addChildPermission('PaymentsResellerController', 'PaymentsResellerIndex');
    $this->addChildPermission('PaymentsResellerController', 'PaymentsResellerInvoices');
    $this->addChildPermission('PaymentsResellerController', 'PaymentsResellerPartnerPayments');
    $this->addChildPermission('PaymentsResellerController', 'PaymentsResellerProfile');
    $this->addChildPermission('PaymentsResellerController', 'PaymentsResellerSettings');
    $this->addChildPermission('PaymentsResellerController', 'PaymentsResellerUpdatePayment');
    $this->addChildPermission('PaymentsResellerController', 'PaymentsResellerUpload');
    $this->addChildPermission('PaymentsResellerController', 'PaymentsResellerUserDetail');
    $this->addChildPermission('PaymentsResellerController', 'PaymentsResellerViewPayment');

    $this->createPermission('PaymentsUsersController', '', 'PaymentsModule');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersAddCompensation');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersAddMulct');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersBalanceInvestorTransfer');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersBalanceInvoice');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersDependentWallets');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersGetUserCurrency');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersIndex');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersInvestorInvoice');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersProfile');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersProfit');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersUpdate');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersUpdatePartner');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersUpdatePartnerSettings');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersUpdateSettings');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersUpload');
    $this->addChildPermission('PaymentsUsersController', 'PaymentsUsersView');

    // Удаление устаревших прав
    $this->removePermission('PaymentsWmSystemPursesCreate');
    $this->removePermission('PaymentsWmSystemPursesDisable');
    $this->removePermission('PaymentsWmSystemPursesEnable');
    $this->removePermission('PaymentsWmSystemPursesIndex');
    $this->removePermission('PaymentsWmSystemPursesUpdate');

    $this->removePermission('PaymentsUsersProfile');
    $this->removePermission('PaymentsResellerProfile');
    $this->removePermission('PaymentsInvestorProfile');
  }

  public function down()
  {
    $this->removePermission('PaymentsModule');
    $this->removePermission('PaymentsPermissions');

    // Контроллеры
    $this->removePermission('PaymentsInvestorController');
    $this->removePermission('PaymentsMerchantController');
    $this->removePermission('PaymentsPaymentsController');
    $this->removePermission('PaymentsPaymentSystemTypesController');
    $this->removePermission('PaymentsResellerController');
    $this->removePermission('PaymentsUsersController');

    // Восстановление устаревших прав
    $this->createPermission('PaymentsWmSystemPursesCreate', null, null, ['root', 'admin']);
    $this->createPermission('PaymentsWmSystemPursesDisable', null, null, ['root', 'admin']);
    $this->createPermission('PaymentsWmSystemPursesEnable', null, null, ['root', 'admin']);
    $this->createPermission('PaymentsWmSystemPursesIndex', null, null, ['root', 'admin']);
    $this->createPermission('PaymentsWmSystemPursesUpdate', null, null, ['root', 'admin']);

    $this->createPermission('PaymentsUsersProfile', null, null, ['root', 'admin']);
    $this->createPermission('PaymentsResellerProfile', null, null, ['manager', 'reseller']);
    $this->createPermission('PaymentsInvestorProfile', null, null, ['investor']);
  }
}
