<?php

use mcms\payments\Module;
use console\components\Migration;

class m171102_121801_reset_early_percent extends Migration
{
  public function up()
  {
    $settings = Yii::$app->getModule('payments')->settings;
    $settings->offsetSet(Module::SETTINGS_EARLY_PAYMENT_PERCENT, 0);
  }

  public function down()
  {
    echo 'Migration cant be reverted';
  }
}
