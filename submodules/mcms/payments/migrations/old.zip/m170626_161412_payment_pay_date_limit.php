<?php

use console\components\Migration;

/**
 * Class m170626_161412_payment_pay_date_limit
 */
class m170626_161412_payment_pay_date_limit extends Migration
{
  /**
   *
   */
  public function up()
  {
    $this->addColumn(
      'user_payments',
      'pay_period_end_date',
      $this
        ->integer(10)
        ->unsigned()
        ->defaultValue(null)
        ->after('is_hold')
        ->comment('Крайняя дата выполнения выплаты (или отложена до)')
    );
  }

  /**
   *
   */
  public function down()
  {
    $this->dropColumn('user_payments', 'pay_period_end_date');
  }
}
