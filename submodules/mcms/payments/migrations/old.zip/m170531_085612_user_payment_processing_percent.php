<?php

use console\components\Migration;

class m170531_085612_user_payment_processing_percent extends Migration
{
  public function up()
  {
    $this->addColumn('user_payments','reseller_paysystem_percent', $this->decimal(5,2)->defaultValue(0)->after('invoice_amount'));
  }

  public function down()
  {
    $this->dropColumn('user_payments', 'reseller_paysystem_percent');
  }

}
