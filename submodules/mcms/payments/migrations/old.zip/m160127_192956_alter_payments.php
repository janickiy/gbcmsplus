<?php

use yii\db\Schema;
use console\components\Migration;

class m160127_192956_alter_payments extends Migration
{
  const TABLE = 'user_payments';

  public function up()
  {
    try {
      $this->createIndex(self::TABLE . '_status_index', self::TABLE, 'status');
      $this->createIndex(self::TABLE . '_wallet_type_status_index', self::TABLE, ['wallet_type', 'status']);
    } catch (Exception $e) {
    }
  }

  public function down()
  {
    try {
      $this->dropIndex(self::TABLE . '_status_index', self::TABLE);
      $this->dropIndex(self::TABLE . '_wallet_type_status_index', self::TABLE);
    } catch (Exception $e) {
    }
  }
}
