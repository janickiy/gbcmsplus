<?php

use console\components\Migration;

class m170615_110259_remove_paypal_rub extends Migration
{
  public function up()
  {
    $this->delete('payment_systems_api', ['code' => 'paypal', 'currency' => 'rub']);
  }

  public function down()
  {
    echo "m170615_110259_remove_paypal_rub cannot be reverted.\n";
  }
}
