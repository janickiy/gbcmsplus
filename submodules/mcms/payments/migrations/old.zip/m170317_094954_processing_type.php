<?php

use console\components\Migration;

class m170317_094954_processing_type extends Migration
{
  public function up()
  {
    $this->addColumn('user_payments', 'processing_type', 'TINYINT(1) NOT NULL DEFAULT 0');

    $this->db->createCommand('UPDATE user_payments SET processing_type = 1')->execute();
  }

  public function down()
  {
    $this->dropColumn('user_payments', 'processing_type');
  }
}
