<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m170207_080149_pay_systems_crud extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('PaymentsWalletController', 'Контроллер Wallet', 'PaymentsModule', ['admin', 'root']);
    $this->createPermission('PaymentsWalletIndex', 'Просмотр справочника платежных систем', 'PaymentsWalletController');
    $this->createPermission('PaymentsWalletUpdateModal', 'Редактирование платежной системы', 'PaymentsWalletController');
  }

  public function down()
  {
    $this->removePermission('PaymentsWalletIndex');
    $this->removePermission('PaymentsWalletController');
    $this->removePermission('PaymentsWalletUpdateModal');
  }
}
