<?php

use console\components\Migration;

class m151212_081043_user_balances_grouped_by_day_bugfix extends Migration
{
    public function up()
    {
      $this->alterColumn('user_balances_grouped_by_day', 'date', 'DATE DEFAULT NULL');
    }

    public function down()
    {
      $this->alterColumn('user_balances_grouped_by_day', 'date', 'INT(10) UNSIGNED DEFAULT 0');
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
