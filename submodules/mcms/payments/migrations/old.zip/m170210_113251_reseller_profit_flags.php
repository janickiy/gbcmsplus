<?php

use console\components\Migration;

class m170210_113251_reseller_profit_flags extends Migration
{
  const TABLE_R_P_FLAGS = '{{%reseller_checkout_closed}}';
  const TABLE_R_P_LOG = '{{%reseller_checkout_log}}';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable(self::TABLE_R_P_FLAGS, [
      'range_start' => $this->string()->notNull()
    ], $tableOptions);
    $this->addPrimaryKey('range_start_pk', self::TABLE_R_P_FLAGS, 'range_start');

    $this->createTable(self::TABLE_R_P_LOG, [
      'id' => $this->primaryKey(5),
      'date' => $this->date(),
      'sum' => $this->decimal(8, 2)->unsigned(),
      'currency' => 'ENUM("rub", "usd", "eur")',
      'description' => $this->text()
    ], $tableOptions);

  }

  public function down()
  {
    $this->dropTable(self::TABLE_R_P_FLAGS);
    $this->dropTable(self::TABLE_R_P_LOG);
  }
}
