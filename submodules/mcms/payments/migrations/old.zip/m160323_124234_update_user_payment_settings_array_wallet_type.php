<?php

use mcms\payments\models\UserPaymentSetting;
use console\components\Migration;
use yii\db\Query;
use yii\helpers\ArrayHelper;

class m160323_124234_update_user_payment_settings_array_wallet_type extends Migration
{
  const RUB = 'rub';
  public function up()
  {
    $this->alterColumn(UserPaymentSetting::tableName(), 'wallet_type', 'VARCHAR(64)');

    $modelList = (new Query())
      ->from(UserPaymentSetting::tableName())
      ->where(['is not', 'wallet_type', NULL])
    ;

    foreach ($modelList->each() as $model) {

      $walletType = json_encode([$model['currency'] => $model['wallet_type']]);
      $walletAccount = json_encode([$model['currency'] => json_decode($model['wallet_account'])]);

      UserPaymentSetting::updateAll(
        ['wallet_type' => $walletType, 'wallet_account' => $walletAccount],
        ['user_id' => $model['user_id']]
      );
    }
  }

  public function down()
  {
    $modelList = (new Query())
      ->from(UserPaymentSetting::tableName())
      ->where(['is not', 'wallet_type', NULL])
    ;

    foreach ($modelList->each() as $model) {
      if (($walletType = json_decode($model['wallet_type'], true)) !== null) {
        $walletType = ArrayHelper::getValue($walletType, $model['currency']);
      }
      if (($walletAccount = json_decode($model['wallet_account'], true)) !== null) {
        $walletAccount = json_encode(ArrayHelper::getValue($walletAccount, $model['currency']));
      }

      UserPaymentSetting::updateAll(
        ['wallet_type' => $walletType, 'wallet_account' => $walletAccount],
        ['user_id' => $model['user_id']]
      );
    }

    UserPaymentSetting::updateAll(['currency' => self::RUB], 'currency = "" or currency is null');

    $this->alterColumn(UserPaymentSetting::tableName(), 'wallet_type', 'TINYINT(1) UNSIGNED');
  }
}
