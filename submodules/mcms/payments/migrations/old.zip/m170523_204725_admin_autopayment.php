<?php

use console\components\Migration;

class m170523_204725_admin_autopayment extends Migration
{
  use \rgk\utils\traits\PermissionTrait;

  public function up()
  {
    $this->assignRolesPermission('PaymentsResellerAutoPayout', ['admin']);
  }

  public function down()
  {
    $this->revokeRolesPermission('PaymentsResellerAutoPayout', ['admin']);
  }

}
