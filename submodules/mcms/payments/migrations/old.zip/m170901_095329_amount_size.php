<?php

use console\components\Migration;

class m170901_095329_amount_size extends Migration
{
  public function up()
  {
    $this->alterColumn('user_payments', 'amount', $this->decimal(12, 2));

    $this->alterColumn('user_payments', 'request_amount', $this->decimal(12, 2)->comment('Запрошенная сумма партнера с учетом конвертации валют'));

    $this->alterColumn('user_payments', 'invoice_amount', $this->decimal(12, 2));

    $this->alterColumn('credit_transactions', 'amount', $this->decimal(12, 2)->notNull());
    $this->alterColumn('credits', 'amount', $this->decimal(12, 2)->notNull()->comment('сумма кредита'));

    $this->alterColumn('user_balance_invoices', 'amount', $this->decimal(12, 2));
  }

  public function down()
  {
    $this->alterColumn('user_payments', 'amount', $this->decimal(9, 2));

    $this->alterColumn('user_payments', 'request_amount', $this->decimal(9, 2)->comment('Запрошенная сумма партнера с учетом конвертации валют'));

    $this->alterColumn('user_payments', 'invoice_amount', $this->decimal(9, 2));

    $this->alterColumn('credit_transactions', 'amount', $this->decimal(10, 2)->notNull());
    $this->alterColumn('credits', 'amount', $this->decimal(10, 2)->notNull()->comment('сумма кредита'));

    $this->alterColumn('user_balance_invoices', 'amount', $this->decimal(9, 2));
  }
}
