<?php

use admin\migrations\dbfix\SettingsTransferTrait;
use console\components\Migration;

class m160208_214717_new_settings extends Migration
{
  use SettingsTransferTrait;

  const SETTINGS_PROJECT_ID = 'settings.project_id';
  const SETTINGS_REFERRAL_PERCENT_PROFIT = 'settings.referral_percent_profit';
  const SETTINGS_EARLY_PAYMENT_PERCENT = 'settings.early_payment_percent';
  const SETTINGS_AUTOPAY_ENABLED_SUBSCRIPTION_COUNT = 'settings.subscription_count_autopay_enabled';
  const SETTINGS_CURRENCY = 'settings.currency';
  const SETTINGS_PAYMENTS_WM_INCOME_WMR = 'settings.payments.wmr.income.merchant';
  const SETTINGS_PAYMENTS_WM_INCOME_WME = 'settings.payments.wme.income.merchant';
  const SETTINGS_PAYMENTS_WM_INCOME_WMZ = 'settings.payments.wmz.income.merchant';
  const SETTINGS_PAYMENTS_WM_KEY = 'settings.payments.wm.key';
  const SETTINGS_PAYMENTS_WM_PAYOUT_WMID = 'settings.payments.wm.payout.wmid';
  const SETTINGS_PAYMENTS_WM_CAPITALLER_WMID = 'settings.payments.wm.capitaller.wmid';
  const SETTINGS_PAYMENTS_WM_PAYOUT_WMR = 'settings.payments.wm.payout.wmr';
  const SETTINGS_PAYMENTS_WM_PAYOUT_WME = 'settings.payments.wm.payout.wme';
  const SETTINGS_PAYMENTS_WM_PAYOUT_WMZ = 'settings.payments.wm.payout.wmz';
  const SETTINGS_PAYMENTS_WM_KWM_FILE = 'settings.payments.wm.kwm.file';
  const SETTINGS_PAYMENTS_WM_KWM_FILE_PASSWORD = 'settings.payments.wm.kwm.file.password';
  const SETTINGS_GENERATE_PAYMENTS_DAY = 'settings.generate.payments.day';
  const SETTINGS_MIN_PAYOUT_SUM_RUB = 'settings.min.payout.sum.rub';
  const SETTINGS_MIN_PAYOUT_SUM_EUR = 'settings.min.payout.sum.eur';
  const SETTINGS_MIN_PAYOUT_SUM_USD = 'settings.min.payout.sum.usd';
  const SETTINGS_WM_MIN_PAYOUT_SUM_RUB = 'settings.wm.min.payout.sum.rub';
  const SETTINGS_WM_MIN_PAYOUT_SUM_EUR = 'settings.wm.min.payout.sum.eur';
  const SETTINGS_WM_MIN_PAYOUT_SUM_USD = 'settings.wm.min.payout.sum.usd';
  const SETTINGS_EXCHANGER_SOURCE = 'settings.payments.exchanger.source';
  const SETTINGS_EXCHANGER_SOURCE_CRB = 'cbr';
  const SETTINGS_EXCHANGER_SOURCE_WME = 'wme';
  const SETTINGS_IS_GENERATE_REGULAR_PAYMENTS_RESELLERS = 'settings.payments.is.generate.regular.payments.resellers';
  const SETTINGS_NUMBER_OF_WEEKS = 'settings.number_of_weeks';
  const SETTINGS_LEFT_BORDER_DATE = 'settings.left_border_date';
  const PERMISSION_CAN_DISABLE_USER_PAYMENTS = 'PaymentsUsersDisableUserPayments';
  const PERMISSION_CAN_ENABLE_AUTOPAY = 'PaymentsUsersCanEnableAutopay';
  const PERMISSION_CAN_CHANGE_USER_ADMIN_SETTINGS = 'PaymentsUsersCanChangeAdminSettings';
  const PERMISSION_CAN_CHANGE_REINVEST_SETTINGS = 'PaymentsUsersChangeReinvestSettings';
  const PERMISSION_CAN_VIEW_SYSTEM_WALLET_BALANCES = 'PaymentsViewSystemWalletBalances';
  const PERMISSION_CAN_EDIT_PAYED_PAYMENTS = 'PaymentsEditPayedPayments';
  const PERMISSION_PAYMENTS_INVESTOR_SETTINGS = 'PaymentsInvestorSettings';
  const PERMISSION_PAYMENTS_RESELLER_SETTINGS = 'PaymentsResellerSettings';
  const PERMISSION_EDIT_MAIN_SETTINGS = 'PaymentsEditMainSettings';
  const PERMISSION_CAN_CHANGE_PAYMENT_EARLY_COMMISSION = 'PaymentsCanChangePaymentCreatePercent';
  const PERMISSION_EDIT_WM_SETTINGS = 'PaymentsEditWmSettings';
  const SETTINGS_ALTERNATIVE_PAYMENTS_GRID_VIEW = 'settings.alternative_payments_grid_view';
  const SETTINGS_MGMP_URL = 'settings.mgmp.url';
  const PERMISSION_EDIT_MGMP_SETTINGS = 'PaymentsEditMgmpSettings';
  const SETTINGS_MGMP_RESELLER_ID = 'settings.mgmp.reseller_id';
  const SETTINGS_MGMP_SECRET_KEY = 'settings.mgmp.secret_key';
  const SETTINGS_DELAY_LEVEL2 = 'settings.delay_level2';
  const SETTINGS_DELAY_LEVEL1 = 'settings.delay_level1';



  const MODULE_ID = 'payments';

  const SETTINGS_TABLE = 'rgk_settings';
  const PERMISSIONS_TABLE = 'rgk_settings_permissions';
  const OPTIONS_TABLE = 'rgk_settings_options';
  const VALUES_TABLE = 'rgk_settings_values';

  public function up()
  {
    $this->insertValues();
  }

  public function down()
  {

  }

  private function getRepository()
  {
    return (new admin\migrations\dbfix\Repository())
      ->set(
        (new admin\migrations\dbfix\Float())
          ->setName('payments.settings.referral_percent_profit')
          ->setValue(3)
          ->setKey(self::SETTINGS_REFERRAL_PERCENT_PROFIT)
          ->setPermissions([self::PERMISSION_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_registration', 'sort' => 3])
          ->setFormGroup(['name' => 'app.common.form_group_referals', 'sort' => 2])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\Float())
          ->setName('payments.settings.early_payment_percent')
          ->setHint('payments.settings.early_payment_percent_hint')
          ->setValue(0)
          ->setValidators([['required'], ['double', ['min' => 0, 'max' => 99]]])
          ->setKey(self::SETTINGS_EARLY_PAYMENT_PERCENT)
          ->setPermissions([self::PERMISSION_CAN_CHANGE_PAYMENT_EARLY_COMMISSION])
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\Integer())
          ->setName('payments.settings.autopay_enabled_subscription_count')
          ->setValue(1000)
          ->setKey(self::SETTINGS_AUTOPAY_ENABLED_SUBSCRIPTION_COUNT)
          ->setPermissions([self::PERMISSION_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setSort(2)
      )->set(
        (new admin\migrations\dbfix\Integer())
          ->setName('payments.settings.number_of_weeks')
          ->setValue(10)
          ->setKey(self::SETTINGS_NUMBER_OF_WEEKS)
          ->setPermissions([self::PERMISSION_EDIT_MAIN_SETTINGS])
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setSort(3)
      )->set(
        (new admin\migrations\dbfix\String())
          ->setName('payments.settings.left_border_date')
          ->setKey(self::SETTINGS_LEFT_BORDER_DATE)
          ->setPermissions([self::PERMISSION_EDIT_MAIN_SETTINGS])
          ->setHint('payments.settings.left_border_date_hint')
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setSort(4)
      )
      ->set(
        (new admin\migrations\dbfix\Lists())
          ->setName('payments.settings.generate_payments_day')
          ->setKey(self::SETTINGS_GENERATE_PAYMENTS_DAY)
          ->setPermissions([self::PERMISSION_EDIT_MAIN_SETTINGS])
          ->setOptions(array_map(function ($day) {
            return 'payments.settings.' . date('l', strtotime('next Monday +' . $day . 'days'));
          }, array_combine(range(1, 7), range(0, 6))))
          ->setValue(4)
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_payments', 'sort' => 2])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\Float())
          ->setName('payments.settings.min_payout_sum_rub')
          ->setValue(100)
          ->setPermissions([self::PERMISSION_EDIT_MAIN_SETTINGS])
          ->setKey(self::SETTINGS_MIN_PAYOUT_SUM_RUB)
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_payments', 'sort' => 2])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\Float())
          ->setName('payments.settings.min_payout_sum_eur')
          ->setPermissions([self::PERMISSION_EDIT_MAIN_SETTINGS])
          ->setValue(2)
          ->setKey(self::SETTINGS_MIN_PAYOUT_SUM_EUR)
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_payments', 'sort' => 2])
          ->setSort(4)
      )
      ->set(
        (new admin\migrations\dbfix\Float())
          ->setName('payments.settings.min_payout_sum_usd')
          ->setPermissions([self::PERMISSION_EDIT_MAIN_SETTINGS])
          ->setValue(2)
          ->setKey(self::SETTINGS_MIN_PAYOUT_SUM_USD)
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_payments', 'sort' => 2])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('payments.settings.is_generate_regular_payments_resellers')
          ->setPermissions([self::PERMISSION_EDIT_MAIN_SETTINGS])
          ->setValue(false)
          ->setKey(self::SETTINGS_IS_GENERATE_REGULAR_PAYMENTS_RESELLERS)
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_payments', 'sort' => 2])
          ->setSort(5)
      )
      ->set(
        (new  admin\migrations\dbfix\Integer())
          ->setName('payments.settings.payments_project_id')
          ->setKey(self::SETTINGS_PROJECT_ID)
          ->setPermissions([self::PERMISSION_EDIT_WM_SETTINGS])
          ->setValue(0)
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_webmoney', 'sort' => 3])
          ->setSort(1)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('payments.settings.payments_wm_payout_wmid')
          ->setKey(self::SETTINGS_PAYMENTS_WM_PAYOUT_WMID)
          ->setPermissions([self::PERMISSION_EDIT_WM_SETTINGS])
          ->setValidators([['string']])
          ->setValue('957043463339')
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_webmoney', 'sort' => 3])
          ->setSort(2)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('payments.settings.payments_wm_capitaller_wmid')
          ->setKey(self::SETTINGS_PAYMENTS_WM_CAPITALLER_WMID)
          ->setPermissions([self::PERMISSION_EDIT_WM_SETTINGS])
          ->setValidators([['string']])
          ->setValue('257413316011')
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_webmoney', 'sort' => 3])
          ->setSort(3)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('payments.settings.payments_wmr_income_merchant')
          ->setKey(self::SETTINGS_PAYMENTS_WM_INCOME_WMR)
          ->setPermissions([self::PERMISSION_EDIT_WM_SETTINGS])
          ->setValidators([['string']])
          ->setValue('R131121108887')
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_webmoney', 'sort' => 3])
          ->setSort(4)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('payments.settings.payments_wmz_income_merchant')
          ->setKey(self::SETTINGS_PAYMENTS_WM_INCOME_WMZ)
          ->setPermissions([self::PERMISSION_EDIT_WM_SETTINGS])
          ->setValidators([['string']])
          ->setValue('Z587435796145')
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_webmoney', 'sort' => 3])
          ->setSort(5)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('payments.settings.payments_wme_income_merchant')
          ->setKey(self::SETTINGS_PAYMENTS_WM_INCOME_WME)
          ->setPermissions([self::PERMISSION_EDIT_WM_SETTINGS])
          ->setValidators([['string']])
          ->setValue('E047261796367')
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_webmoney', 'sort' => 3])
          ->setSort(6)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('payments.settings.payments_wm_key')
          ->setKey(self::SETTINGS_PAYMENTS_WM_KEY)
          ->setPermissions([self::PERMISSION_EDIT_WM_SETTINGS])
          ->setValidators([['string']])
          ->setValue('EjKKh9x8W3EDkygWhwPaB7qFnPZ3uK')
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_webmoney', 'sort' => 3])
          ->setSort(7)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('payments.settings.payments_wm_payout_wmr')
          ->setKey(self::SETTINGS_PAYMENTS_WM_PAYOUT_WMR)
          ->setPermissions([self::PERMISSION_EDIT_WM_SETTINGS])
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_webmoney', 'sort' => 3])
          ->setSort(8)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('payments.settings.payments_wm_payout_wme')
          ->setKey(self::SETTINGS_PAYMENTS_WM_PAYOUT_WME)
          ->setPermissions([self::PERMISSION_EDIT_WM_SETTINGS])
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_webmoney', 'sort' => 3])
          ->setSort(9)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('payments.settings.payments_wm_payout_wmz')
          ->setKey(self::SETTINGS_PAYMENTS_WM_PAYOUT_WMZ)
          ->setPermissions([self::PERMISSION_EDIT_WM_SETTINGS])
          ->setValidators([['string']])
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_webmoney', 'sort' => 3])
          ->setSort(10)
      )
      ->set(
        (new admin\migrations\dbfix\FileUpload('payments'))
          ->setName('payments.settings.payments_wm_kwm_file')
          ->setKey(self::SETTINGS_PAYMENTS_WM_KWM_FILE)
          ->setPermissions([self::PERMISSION_EDIT_WM_SETTINGS])
          ->setUploadDir('@mcms/{moduleId}/upload/{attributeName}')
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_webmoney', 'sort' => 3])
          ->setSort(11)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('payments.settings.payments_wm_kwm_file_password')
          ->setKey(self::SETTINGS_PAYMENTS_WM_KWM_FILE_PASSWORD)
          ->setPermissions([self::PERMISSION_EDIT_WM_SETTINGS])
          ->setValidators([['string']])
          ->setValue('utCYPudvWpC1SCCohJHu')
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_webmoney', 'sort' => 3])
          ->setSort(12)
      )
      ->set(
        (new admin\migrations\dbfix\Lists())
          ->setName('payments.settings.exchanger_source')
          ->setPermissions([self::PERMISSION_EDIT_WM_SETTINGS])
          ->setKey(self::SETTINGS_EXCHANGER_SOURCE)
          ->setOptions([
            self::SETTINGS_EXCHANGER_SOURCE_CRB => 'payments.settings.CBR',
            self::SETTINGS_EXCHANGER_SOURCE_WME => 'payments.settings.WME',
          ])
          ->setValue(self::SETTINGS_EXCHANGER_SOURCE_WME)
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 9])
          ->setFormGroup(['name' => 'app.common.form_group_payments_webmoney', 'sort' => 3])
          ->setSort(13)
      )
      ->set(
        (new admin\migrations\dbfix\Boolean())
          ->setName('payments.settings.alternative_payments_grid_view')
          ->setValue(false)
          ->setKey(self::SETTINGS_ALTERNATIVE_PAYMENTS_GRID_VIEW)
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 99123])
          ->setFormGroup(['name' => 'app.common.form_group_payments_main', 'sort' => 1])
          ->setSort(5)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('payments.settings.mgmp_url')
          ->setKey(self::SETTINGS_MGMP_URL)
          ->setValidators([['string']])
          ->setPermissions([self::PERMISSION_EDIT_MGMP_SETTINGS])
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 99123])
          ->setFormGroup(['name' => 'payments.settings.mgmp', 'sort' => 3])
          ->setSort(14)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('payments.settings.mgmp_reseller_id')
          ->setKey(self::SETTINGS_MGMP_RESELLER_ID)
          ->setValidators([['string']])
          ->setPermissions([self::PERMISSION_EDIT_MGMP_SETTINGS])
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 99123])
          ->setFormGroup(['name' => 'payments.settings.mgmp', 'sort' => 3])
          ->setSort(15)
      )
      ->set(
        (new admin\migrations\dbfix\String())
          ->setName('payments.settings.mgmp_secret_key')
          ->setKey(self::SETTINGS_MGMP_SECRET_KEY)
          ->setValidators([['string']])
          ->setPermissions([self::PERMISSION_EDIT_MGMP_SETTINGS])
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 99123])
          ->setFormGroup(['name' => 'payments.settings.mgmp', 'sort' => 3])
          ->setSort(16)
      )
      ->set(
        (new admin\migrations\dbfix\Integer())
          ->setName('payments.settings.delay_level2')
          ->setKey(self::SETTINGS_DELAY_LEVEL2)
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 99123])
          ->setFormGroup(['name' => 'payments.settings.delay', 'sort' => 4])
          ->setValue(5)
          ->setSort(17)
      )
      ->set(
        (new admin\migrations\dbfix\Integer())
          ->setName('payments.settings.delay_level1')
          ->setKey(self::SETTINGS_DELAY_LEVEL1)
          ->setGroup(['name' => 'app.common.group_payments', 'sort' => 99123])
          ->setFormGroup(['name' => 'payments.settings.delay', 'sort' => 4])
          ->setValue(3)
          ->setSort(18)
      );
  }
}
