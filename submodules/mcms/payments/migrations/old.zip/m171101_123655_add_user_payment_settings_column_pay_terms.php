<?php

use console\components\Migration;

class m171101_123655_add_user_payment_settings_column_pay_terms extends Migration
{
  public function up()
  {
    $this->addColumn('user_payment_settings', 'pay_terms', 'TINYINT UNSIGNED');

    $this->db->createCommand('UPDATE user_payment_settings SET pay_terms=6')->execute();
  }

  public function down()
  {
    $this->dropColumn('user_payment_settings', 'pay_terms');
  }
}
