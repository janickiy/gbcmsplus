<?php

use console\components\Migration;

class m170720_064127_add_pdf_file_fields extends Migration
{
  public function up()
  {
    $this->addColumn('wallets', 'is_check_file_required', $this->boolean()->defaultValue(false));
    $this->addColumn('wallets', 'is_check_file_show', $this->boolean()->defaultValue(false));
    $this->addColumn('user_payments', 'check_file_src', $this->string());
  }

  public function down()
  {

    $this->dropColumn('user_payments', 'check_file_src');
    $this->dropColumn('wallets', 'is_check_file_show');
    $this->dropColumn('wallets', 'is_check_file_required');
  }
}
