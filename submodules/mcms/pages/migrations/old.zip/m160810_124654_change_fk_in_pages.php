<?php

use console\components\Migration;

class m160810_124654_change_fk_in_pages extends Migration
{
    const TABLE = 'pages';
    const CAT = 'page_categories';

    public function safeUp()
    {
        $this->dropForeignKey(self::TABLE . '_page_category_id_fk', self::TABLE);
        $this->addForeignKey(self::TABLE . '_page_category_id_fk', self::TABLE, 'page_category_id', self::CAT, 'id', 'CASCADE');
    }

    public function safeDown()
    {
        $this->dropForeignKey(self::TABLE . '_page_category_id_fk', self::TABLE);
        $this->addForeignKey(self::TABLE . '_page_category_id_fk', self::TABLE, 'page_category_id', self::CAT, 'id');
    }
}
