<?php

use console\components\Migration;

class m170124_121204_rename_module extends Migration
{
  public function up()
  {
    $this->update('modules',
      [ 'name' => 'pages.main.module_name', ],
      [ 'module_id' => 'pages', ]
    );
  }

  public function down()
  {
    $this->update('modules',
      [ 'name' => 'app.common.module_pages', ],
      [ 'module_id' => 'pages', ]
    );
  }
}
