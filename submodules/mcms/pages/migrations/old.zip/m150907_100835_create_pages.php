 <?php

use console\components\Migration;

class m150907_100835_create_pages extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable('{{%pages}}', [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => 'VARCHAR(500) NOT NULL',
      'text' => 'LONGTEXT DEFAULT NULL',
      'seo_title' => 'VARCHAR(500) DEFAULT NULL',
      'seo_keywords' => 'VARCHAR(500) DEFAULT NULL',
      'seo_description' => 'text DEFAULT NULL',
      'noindex' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_disabled' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED NOT NULL',
    ], $tableOptions);

    $this->createIndex('pages_is_disabled', 'pages', 'is_disabled');
  }

  public function down()
  {
    $this->dropTable('{{%pages}}');
  }
}
