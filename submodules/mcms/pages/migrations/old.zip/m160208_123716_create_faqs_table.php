<?php

use yii\db\Schema;
use console\components\Migration;

class m160208_123716_create_faqs_table extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable('faqs', [
      'id' => 'MEDIUMINT(7) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'question' => 'TEXT NOT NULL',
      'answer' => 'TEXT NOT NULL',
      'sort' => 'MEDIUMINT(5) NOT NULL',
      'visible' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'faq_category_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',

      'FOREIGN KEY (faq_category_id) REFERENCES faq_categories (id) ON DELETE CASCADE ON UPDATE CASCADE',
    ], $tableOptions);
    $this->createIndex('faqs_sort', 'faqs', 'sort');
    $this->createIndex('faqs_visible', 'faqs', 'visible');
  }

  public function down()
  {
    $this->dropTable('faqs');
  }
}
