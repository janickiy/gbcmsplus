<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m170117_123839_vote_statistic_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('PagesVoteStatisticController', 'Статистика опросов', 'PagesModule', ['admin', 'root', 'reseller']);
    $this->createPermission('PagesVoteStatisticIndex', 'Список статистика опросов', 'PagesVoteStatisticController', ['admin', 'root', 'reseller']);

  }

  public function down()
  {
    $this->removePermission('PagesVoteStatisticController');
    $this->removePermission('PagesVoteStatisticIndex');
  }
}
