<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m161129_091955_partner_cabinet_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('PagesPartnerCabinetStylesController', 'Контроллер PartnerCabinetStyles', 'PagesModule');
    $this->createPermission('PagesPartnerCabinetStylesIndex', 'Оформление партнерского кабинета', 'PagesPartnerCabinetStylesController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesPartnerCabinetStylesCreateStyle', 'Создание оформления', 'PagesPartnerCabinetStylesController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesPartnerCabinetStylesDeleteStyle', 'Удаление оформления', 'PagesPartnerCabinetStylesController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesPartnerCabinetStylesToggleStylePreview', 'Предпросмотр оформления', 'PagesPartnerCabinetStylesController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesPartnerCabinetStylesToggleStyleActivity', 'Управление активностью оформления', 'PagesPartnerCabinetStylesController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesCanUpdatePartnerCabinetStyle', 'Изменение оформления', 'PagesPartnerCabinetStylesController', ['root', 'admin', 'reseller']);

    $this->createPermission('PagesPartnerCabinetStylesCreateCategoryModal', 'Создание категории стилей в оформлении партнерского кабинета', 'PagesPartnerCabinetStylesController', ['root', 'admin']);
    $this->createPermission('PagesPartnerCabinetStylesUpdateCategoryModal', 'Редактирование категории стилей в оформлении партнерского кабинета', 'PagesPartnerCabinetStylesController', ['root', 'admin']);
    $this->createPermission('PagesPartnerCabinetStylesDeleteCategory', 'Удаление категории стилей в оформлении партнерского кабинета', 'PagesPartnerCabinetStylesController', ['root', 'admin']);

    $this->createPermission('PagesPartnerCabinetStylesCreateFieldModal', 'Создание поля из модалки', 'PagesPartnerCabinetStylesController', ['root', 'admin']);
    $this->createPermission('PagesPartnerCabinetStylesUpdateFieldModal', 'Обновление поля из модалки', 'PagesPartnerCabinetStylesController', ['root', 'admin']);
    $this->createPermission('PagesPartnerCabinetStylesDeleteField', 'Удаление поля', 'PagesPartnerCabinetStylesController', ['root', 'admin']);
  }

  public function down()
  {
    $this->removePermission('PagesPartnerCabinetStylesDeleteField');
    $this->removePermission('PagesPartnerCabinetStylesUpdateFieldModal');
    $this->removePermission('PagesPartnerCabinetStylesCreateFieldModal');
    $this->removePermission('PagesPartnerCabinetStylesController');
    $this->removePermission('PagesPartnerCabinetStylesIndex');
    $this->removePermission('PagesPartnerCabinetStylesCreateStyle');
    $this->removePermission('PagesPartnerCabinetStylesDeleteStyle');
    $this->removePermission('PagesPartnerCabinetStylesToggleStylePreview');
    $this->removePermission('PagesPartnerCabinetStylesToggleStyleActivity');
    $this->removePermission('PagesCanUpdatePartnerCabinetStyle');

    $this->removePermission('PagesPartnerCabinetStylesCreateCategoryModal');
    $this->removePermission('PagesPartnerCabinetStylesUpdateCategoryModal');
    $this->removePermission('PagesPartnerCabinetStylesDeleteCategory');
  }
}
