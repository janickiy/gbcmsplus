<?php

use console\components\Migration;

class m151225_124828_update_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();

    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Pages';
    $this->permissions = [
      'Pages' => [
        ['image-upload', 'Can upload image', ['admin', 'root']],
        ['images-get', 'Can get images', ['admin', 'root']],
      ],
    ];
  }
}
