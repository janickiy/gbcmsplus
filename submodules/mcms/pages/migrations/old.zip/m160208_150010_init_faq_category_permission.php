<?php

use yii\db\Schema;
use console\components\Migration;

class m160208_150010_init_faq_category_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'PagesFaqCategories' => [
        ['index', 'Display faq categories list', ['admin', 'root']],
        ['view', 'View faq category', ['admin', 'root']],
        ['create', 'Create faq category', ['admin', 'root']],
        ['update', 'Update faq category', ['admin', 'root']],
        ['delete', 'Remove faq category', ['admin', 'root']],
      ]
    ];
  }
}
