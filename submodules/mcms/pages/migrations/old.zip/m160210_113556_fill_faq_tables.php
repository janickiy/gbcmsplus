<?php

use mcms\pages\models\Faq;
use mcms\pages\models\FaqCategory;
use yii\db\Schema;
use console\components\Migration;

class m160210_113556_fill_faq_tables extends Migration
{
  public function up()
  {
    $domainName = Yii::$app->getModule('partners')->getFooterCopyright();
    $mainCategory = new FaqCategory();
    $mainCategory->name = ['ru' => 'Общие вопросы', 'en' => 'General issues'];
    $mainCategory->sort = 1;
    $mainCategory->visible = 1;
    $mainCategory->save();

    $techCategory = new FaqCategory();
    $techCategory->name = ['ru' => 'Технические вопросы', 'en' => 'Technical issues'];
    $techCategory->sort = 2;
    $techCategory->visible = 1;
    $techCategory->save();

    $financialCategory = new FaqCategory();
    $financialCategory->name = ['ru' => 'Финансовые вопросы', 'en' => 'Financial questions'];
    $financialCategory->sort = 3;
    $financialCategory->visible = 1;
    $financialCategory->save();

    $termsCategory = new FaqCategory();
    $termsCategory->name = ['ru' => 'Правила и соглашение партнерской программы', 'en' => 'Terms of the agreement and the partnership program'];
    $termsCategory->sort = 4;
    $termsCategory->visible = 1;
    $termsCategory->save();

    /* ******* */

    /* START main category */

    $faq = new Faq();
    $faq->question = ['ru' => "Что такое вапклик (wapclick)?", 'en' => "What is wapclick?"];
    $faq->answer = [
      'ru' => "Вапклик - это технология оплаты контента на сайте без ввода номера и кода подтверждения. Это легальный способ монетизации мобильного трафика, при котором абонент соглашается со стоимость и условиями подписки нажимая кнопку “ОК” или “Загрузить”.",
      'en' => "Wapclick - is a payment technology content on the site without entering a number and confirmation code. This is a legitimate way to monetize mobile traffic, in which the subscriber agrees with the terms of the subscription cost and pressing \"OK\" or \"Download.\""
    ];
    $faq->sort = 1;
    $faq->visible = 1;
    $faq->faq_category_id = $mainCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Как происходит подписка?", 'en' => "How is the subscription?"];
    $faq->answer = [
      'ru' => "Пользователь заходит на платник нужной тематики, с мобильного телефона или смартфона. Выбирает интересующий его контент и нажимает кнопку “ОК”, тем самым соглашаясь со стоимостью и правилами подписки. После успешной подписки пользователь получает ссылку для скачивания контента.",
      'en' => "The user enters the desired paysite theme, mobile phone or smartphone. Selects the interest of its content, and clicks \"OK\", thus agreeing with the value and the subscription rules. After successful subscription the user receives a link to a content download."
    ];
    $faq->sort = 2;
    $faq->visible = 1;
    $faq->faq_category_id = $mainCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "В чем преимущества вапклик?", 'en' => "What are the advantages wapclick?"];
    $faq->answer = [
      'ru' => "Вапклик имеет множество преимуществ, среди которых хотелось бы выделить:<br>
- Абсолютно легальная схема работы, полностью согласованная с ОСС.<br>
- Отличный конверт, т.к пользователю не требуется вводить номер телефона либо скачивать мидлет для активации подписки.<br>
- Хороший доход на длинной дистанции. В отличии от смс подписка будет нести доход в течении нескольких месяцев.<br>
- Отсутствие фрода и штрафов со стороны операторов, при соблюдении правил работы.",
      'en' => "Wapclick has many advantages, among which we would like to highlight:<br>
- Absolutely legal scheme of work, fully compatible with the OSS.<br>
- Excellent envelope, because the user does not need to enter a phone number or to download the MIDlet to activate the subscription.<br>
- A good income in the long run. Unlike SMS subscription will incur income for several months.<br>
- Absence of fraud and fines from the operators in compliance with work rules."
    ];
    $faq->sort = 3;
    $faq->visible = 1;
    $faq->faq_category_id = $mainCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Что такое платники?", 'en' => "What is a paysite?"];
    $faq->answer = [
      'ru' => "Платник - это целевая страница (согласованная с ОСС), на которую попадает пользователь с вашего сайта либо рекламной сети. На платнике содержится информация об услуге и тип контента который получит пользователь после подписки.",
      'en' => "Paysites - a landing page (compatible with the OSS), on which the user gets to your website or ad network. On paysites contains information about the service and the type of content that a user will receive after the subscription."
    ];
    $faq->sort = 4;
    $faq->visible = 1;
    $faq->faq_category_id = $mainCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Какой платник выбрать?", 'en' => "Which paysite to choose?"];
    $faq->answer = [
      'ru' => "Обязательно нужно использовать платники подходящие по тематике под ваш трафик. Так например, если у вас музыкальный портал то необходимо использовать музыкальный платник. Операторы категорически запрещают использовать для adult трафика платники других тематик.",
      'en' => "Be sure to use paysite suitable topics for your traffic. For example, if you have a music portal it is necessary to use the music paysite. Operators categorically prohibit the use of adult paysite traffic of other topics."
    ];
    $faq->sort = 5;
    $faq->visible = 1;
    $faq->faq_category_id = $mainCategory->id;
    $faq->save();

    /* END main category */


    /* START tech category */

    $faq = new Faq();
    $faq->question = ['ru' => "Какие операторы принимаются?", 'en' => "What operators are accepted?"];
    $faq->answer = [
      'ru' => "На данный момент ПП принимает большую тройку ОСС по России (МТС, Билайн, Мегафон), а так же Францию и Азербайджан. При этом мы постоянно работаем над увеличением зоны покрытия, и по мере согласования новых стран, будем сообщать об этом в новостях.",
      'en' => "At present PP takes big three OSS in Russia (MTS, Beeline, Megafon), as well as France and Azerbaijan. At the same time we are constantly working to increase the coverage area, and as the approval of new countries will report about it in the news."
    ];
    $faq->sort = 1;
    $faq->visible = 1;
    $faq->faq_category_id = $techCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Какие категории трафика принимает ПП?", 'en' => "What are the categories of traffic takes PP?"];
    $faq->answer = [
      'ru' => "Партнерская программа принимает все согласованные категории трафика кроме:<br>
- траффика добытого с помощью вредоносных и троянских программ, а так же с помощью подмены выдачи<br>
- подмены лицензионного контента: skype/viber/whatsapp/opera итд<br>
- спама в любой форме, включая sms и email рассылку<br>
- трафика с ресурсов содержащих: детскую порнографию, информацию о любых наркотиках, экстремистские либо другие запрещенные к публикации материалы.<br>
- траффика с взломанных сайтов и шеллов",
      'en' => "Affiliate program accepts all agreed except for traffic category:<br>
- Traffic produced via malware and Trojans, as well as with the help of the substitution of issue<br>
- Substitution of licensed content: skype / viber / whatsapp / opera etc.<br>
- Any form of spam, including sms and email newsletter<br>
- Traffic resources containing: child pornography, information on any drugs, extremist or other prohibited materials for publication.<br>
- Traffic to compromised Web sites and shells"
    ];
    $faq->sort = 2;
    $faq->visible = 1;
    $faq->faq_category_id = $techCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Какие платформы поддерживает вапклик?", 'en' => "Which platforms supports waplick?"];
    $faq->answer = [
      'ru' => "В отличии от мидлетов – вапклик поддерживает практически все мобильные устройства, начиная от кнопочных телефонов, заканчивая современными смартфонами и Iphone.",
      'en' => "Unlike MIDlet - wapclick supports virtually every mobile device, from the push-button phones to modern smartphones and Iphone."
    ];
    $faq->sort = 3;
    $faq->visible = 1;
    $faq->faq_category_id = $techCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Для чего нужна парковка и регистрация доменов?", 'en' => "What is the parking and domain name registration?"];
    $faq->answer = [
      'ru' => "Парковка и регистрация доменов позволяет вам использовать свои домены для работы с партнерской программой. Это позволяет увеличить конверт, за счет снижения рисков бана системных доменов антивирусами, и других форс-мажорных обстоятельствах. Рекомендуем переодически следить за припарковаными доменами на бан АВ.",
      'en' => "Parking and domain registration allows you to use your domain to work with the affiliate program. This makes it possible to increase the envelope, by reducing the risk of systemic ban domains antivirus, and other force majeure. We recommend periodically monitor the parked domains to ban AB."
    ];
    $faq->sort = 4;
    $faq->visible = 1;
    $faq->faq_category_id = $techCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Зачем нужно указывать источники трафика?", 'en' => "Why do we need to specify the sources of traffic?"];
    $faq->answer = [
      'ru' => "Согласно требованиям ОСС – все источники трафика должны проходить обязательную модерацию. Как правило модерация занимает не более 5 часов в рабочее время.",
      'en' => "According to the requirements of the OSS - all traffic sources must undergo mandatory moderation. Typically approval takes less than 5 hours of working time."
    ];
    $faq->sort = 5;
    $faq->visible = 1;
    $faq->faq_category_id = $techCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Как настроить слив трафика со своего сайта?", 'en' => "How to set drain traffic from your site?"];
    $faq->answer = [
      'ru' => "Вы можете настроить слив траффика со своего сайта используя .htaccess код либо javascript скрипт. В данном случае все принимаемые операторы будут автоматически перенаправляться на заданные платники партнерской программы.",
      'en' => "You can adjust the drain traffic from the site using .htaccess code or javascript script. In this case, all operators will be taken automatically redirected to the specified paysite affiliate program."
    ];
    $faq->sort = 6;
    $faq->visible = 1;
    $faq->faq_category_id = $techCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Для чего нужны субаккаунты?", 'en' => "What are the subaccounts?"];
    $faq->answer = [
      'ru' => "Субаккаунты служат для разделения статистики и анализа трафика. Вы можете настроить слив с разных разделов сайта по разным субаккаунтам, и отслежить конверсию по каждому отдельно взятому разделу.",
      'en' => "Subaccounts serve to separate statistics and traffic analysis. You can customize the sink with different sections of the site for different subaccounts, and monitored by the conversion of each individual section."
    ];
    $faq->sort = 7;
    $faq->visible = 1;
    $faq->faq_category_id = $techCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Как отследить конверсии для максимального конверта?", 'en' => "How to track conversions for the maximum of the envelope?"];
    $faq->answer = [
      'ru' => "Для максимально эффективного анализа трафика и площадок советуем воспользоваться инструментом “пингбек”, который позволяет интегрировать статистику в вашем трекере по каждому переходу.",
      'en' => "To maximize the traffic analysis sites and recommend you to use our \"pingbek\" which allows you to integrate this information on your tracker at each transition."
    ];
    $faq->sort = 8;
    $faq->visible = 1;
    $faq->faq_category_id = $techCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Для чего нужен трафикбек?", 'en' => "What is the trafficback?"];
    $faq->answer = [
      'ru' => "Трафикбек нужен для возврата не принимаемого траффика. Чтобы трафик не терялся вы можете перенаправить его в другие партнерские программы, либо сделать возврат на свой сайт.",
      'en' => "Trafficback not need to return the received traffic. To traffic is not lost, you can redirect it to other affiliate programs or make refund to your site."
    ];
    $faq->sort = 9;
    $faq->visible = 1;
    $faq->faq_category_id = $techCategory->id;
    $faq->save();

    /* END tech category */


    /* START financial category */

    $faq = new Faq();
    $faq->question = ['ru' => "Какой доход приносит подписка?", 'en' => "Which brings subscription revenue?"];
    $faq->answer = [
      'ru' => "В среднем подписка в долгосрочной перспективе приносит от 40 до 150 рублей в зависимости от тарификации и оператора.",
      'en' => "The average subscription in the long run brings from 40 to 150 rubles depending on the operator and tariff."
    ];
    $faq->sort = 1;
    $faq->visible = 1;
    $faq->faq_category_id = $financialCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Когда происходят выплаты?", 'en' => "When the payment occur?"];
    $faq->answer = [
      'ru' => "Выплаты производятся каждую среду за предыдущую расчетную неделю.",
      'en' => "Payments are made every Wednesday for the previous week calculated."
    ];
    $faq->sort = 2;
    $faq->visible = 1;
    $faq->faq_category_id = $financialCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Какой размер партнерских отчислений?", 'en' => "What is the size of partner contributions?"];
    $faq->answer = [
      'ru' => "По умолчанию размер партнерских отчислений составляет 85%, но может варьироваться в индивидуальном порядке, для каждого партнера.",
      'en' => "The default size of partner contributions is 85%, but may vary on an individual basis for each partner."
    ];
    $faq->sort = 3;
    $faq->visible = 1;
    $faq->faq_category_id = $financialCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Какую стоимость использовать на лендинге?", 'en' => "What is the cost to use the Landing?"];
    $faq->answer = [
      'ru' => "В ПП есть 2 вида тарификации, с ежедневными и единоразовыми списаниями. При ежедневных списаниях стоимость для пользователя варьируется от 20 до 30 рублей. Хороший конверт показывают обе тарификации. При единоразовых списаниях есть возможность устанавливать произвольную цену от 50 до 500 рублей. В зависимости от качества трафика оптимальная цена для единоразового ребила будет 150-250 рублей.",
      'en' => "The PP has 2 types of charging, with daily and one-time write-offs. When the daily cost of write-offs for the user ranging from 20 to 30 rubles. Good envelope shows two charging. When one-time write-offs have the ability to set an arbitrary price from 50 to 500 rubles. Depending on the quality of traffic to the optimal price for a one-time rebila is 150-250 rubles."
    ];
    $faq->sort = 4;
    $faq->visible = 1;
    $faq->faq_category_id = $financialCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Что такое кредитование подписок?", 'en' => "What is a credit subscriptions?"];
    $faq->answer = [
      'ru' => "Кредитование это авансовый платеж за новые подписки, с фиксированной ставкой. Более подробно о кредитовании можно прочитать в профильном разделе.",
      'en' => "Credit is an advance payment for new subscriptions, fixed rate. More information about lending can be found in the profile section."
    ];
    $faq->sort = 5;
    $faq->visible = 1;
    $faq->faq_category_id = $financialCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Как работает авто выкуп подписок?", 'en' => "How does the purchase of cars subscriptions?"];
    $faq->answer = [
      'ru' => "Автоматический выкуп подписок позволяет после первого ребила получить фиксированную выплату за подписку. Преимущества автовыкупа в том, что не нужно ждать определенный период для окупаемости, а можно сразу работать в +.",
      'en' => "Automatic redemption subscriptions allowing the first rebila receive a fixed payment for a subscription. Benefits autorepayment that do not need to wait for a certain period of payback, and you can immediately work. +"
    ];
    $faq->sort = 6;
    $faq->visible = 1;
    $faq->faq_category_id = $financialCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Для чего нужна страховка выплат?", 'en' => "What is the insurance payments?"];
    $faq->answer = [
      'ru' => "Страховка выплат позволяет застраховать подписки от возможных проблем со стороны ОСС и КП.",
      'en' => "Insurance payments allows to insure the subscription of possible problems from the OSS and CS."
    ];
    $faq->sort = 7;
    $faq->visible = 1;
    $faq->faq_category_id = $financialCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Можно ли заказать досрочные выплаты?", 'en' => "Is it possible to order the early payment?"];
    $faq->answer = [
      'ru' => "Да такая функция есть в партнерской программе. Вы можете заказать досрочные выплаты, не дожидаясь расчетного периода. Досрочные выплаты можно заказать в любой день.",
      'en' => "Yes, such a function is in the affiliate program. You can order an early payment, without waiting for the settlement period. Early payments are available on any given day."
    ];
    $faq->sort = 8;
    $faq->visible = 1;
    $faq->faq_category_id = $financialCategory->id;
    $faq->save();

    /* END financial category */


    /* START terms category */

    $faq = new Faq();
    $faq->question = ['ru' => "Общие положения:", 'en' => "General Provisions:"];
    $faq->answer = [
      'ru' => "<ul><li>Соглашение регламентирует условия, и порядок предоставления услуг партнерской программой партнеру.</li>
<li>Стороны признают настоящее соглашение имеющим юридическую силу, и равнозначным договору заключенном в письменной форме.</li>
<li>Партнерская программа вправе изменить или дополнить условия данного соглашения в одностороннем порядке, но обязана уведомить об этом партнеров.</li>
<li>Начиная работу с партнерской программой партнер принимает и акцептирует данное соглашение а так же соглашается с обработкой персональных данных.</li></ul>",
      'en' => "<ul><li>The agreement regulates the conditions and procedure for granting services affiliate partner program.</li>
<li>The Parties recognize this agreement legally binding and equivalent to the contract concluded in writing.</li>
<li>Affiliates have the right to change or supplement the terms of the agreement unilaterally, but is obliged to notify partners.</li>
<li>Starting work with the affiliate program partner receives and accepts this agreement as well as agree to the processing of personal data.</li></ul>"
    ];
    $faq->sort = 1;
    $faq->visible = 1;
    $faq->faq_category_id = $termsCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Права и обязанности сторон:", 'en' => "Rights and Obligations of the parties:"];
    $faq->answer = [
      'ru' => "
<ul>
  <li>
  Партнер обязуется:
    <ul>
      <li>Ознакомиться с данным соглашением.</li>
      <li>
        Указывать достоверные реквизиты, а именно:<br>
        - контактную информацию и email<br>
        - платежные реквизиты
      </li>
      <li>Запрещено создавать топики на форумах, закрытого и открытого типа, без согласования с администрацией.</li>
      <li>Оперативно (в течении 2х рабочих дней) реагировать на изменения в партнерской программе, касающиеся логики и правил работы и публикуемые в новостях. При необходимости вносить соответствующие правки.</li>
      <li>Привлекать рефералов только законными методами.</li>
      <li>
      При любых проблемах, включая:<br>
      - недоступность партнерской программы или лэндингов<br>
      - задержку поступления средств после публикации новости о выплатах<br>
      немедленно информировать техническую поддержку.
      </li>
      <li>
        Использовать только законные методы привлечения трафика. Категорически запрещено:<br>
        - использовать траффик добытый с помощью вредоносных и троянских программ, а так же с помощью подмены выдачи<br>
        - осуществлять подписку вводя пользователя в заблуждение, или с помощью выманивания у последнего номера телефона и кода для активации подписки<br>
        - использовать спам в любой форме, включая sms и email рассылку<br>
        - использовать трафик с ресурсов содержащих: детскую порнографию, информацию о любых наркотиках, экстремистские либо другие запрещенные к публикации материалы.<br>
        - выдавать платники под видом лицензионного контента: skype/viber/whatsapp/opera и т.д.<br>
        - вводить пользователей в заблуждение используя в рекламе фразы и их производственные: бесплатно, халява, даром, а так же упоминание о детской порнографии, зоофилии, и .т.д.<br>
        - использовать траффик с взломанных сайтов и шеллов<br>
        - использовать в работе накрутку и фрод
      </li>
    </ul>
  </li>
  <li>
  Партнерская программа обязуется:
    <ul>
      <li>Сохранять конфиденциальность партнеров, за исключением случаев нарушения правил партнерской программы.</li>
      <li>Своевременно осуществлять плановые и досрочные выплаты согласно установленным срокам.</li>
      <li>Оказывать партнеру услуги по конвертации мобильного траффика на лэндингах согласованных с ОСС.</li>
      <li>Осуществлять техническую поддержку партнеров, связанную с использованием партнерской программы.</li>
      <li>Своевременно информировать партнеров обо всех изменениях и нововведениях, посредством новостей.</li>
    </ul>
  </li>
</ul>",
      'en' => "
<ul>
  <li>
  Partner shall:
    <ul>
      <li>To view this agreement.</li>
      <li>
        Pointing accuracy of the details, namely:<br>
        - Contact information and email<br>
        - Payment details
      </li>
      <li>It is forbidden to create topics on the forums, closed and open, without the consent of the administration.</li>
      <li>Promptly (within 2 business days) to respond to the changes in the affiliate program on the logic and rules of operation, and published in the news. If necessary, make the appropriate changes.</li>
      <li>Attract referrals only by legal means.</li>
      <li>
        If you experience problems, including:<br>
        - Lack of access to the affiliate program or Landing<br>
        - Delay in inflows after the publication of news about payments<br>
        immediately inform the technical support.
      </li>
      <li>
        Use only legitimate methods to attract traffic. Absolutely forbidden:<br>
        - Use the traffic produced by a malware and Trojans, as well as with the help of the substitution of issue<br>
        - To subscribe to mislead users or by defrauding the latter telephone number and a code to activate your subscription<br>
        - Use spam in any form, including sms and email newsletter<br>
        - Use traffic from resources containing: child pornography, information on any drugs, extremist or other prohibited materials for publication.<br>
        - Paysite issue under the guise of licensed content: skype / viber / whatsapp / opera etc.<br>
        - Mislead users by using the phrase in advertising and production: free, freebies, for free, as well as references to child pornography, bestiality, and .t.d.<br>
        - Use traffic from hacked websites and shells<br>
        - To use the cheat and fraud
      </li>
    </ul>
  </li>
  <li>
  Affiliate program shall:
    <ul>
      <li>Maintain the confidentiality of the partners, with the exception of cases of violation of the rules of the affiliate program.</li>
      <li>In a timely manner to carry out scheduled and early payment in accordance with established deadlines.</li>
      <li>Assist the partner services in converting traffic to mobile Landing agreed with OSS.</li>
      <li>Provide technical support to partners associated with the use of affiliate programs.</li>
      <li>Timely inform partners about all the changes and innovations through the news.</li>
    </ul>
  </li>
</ul>
"
    ];
    $faq->sort = 2;
    $faq->visible = 1;
    $faq->faq_category_id = $termsCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Ограничения ответственности:", 'en' => "Limitations of Liability:"];
    $faq->answer = [
      'ru' => "<ul><li>Партнерская программа не несет ответственности за любые проблемы связанные с нарушением партнером правил партнерской программы.</li>
<li>Партнерская программа не несет ответственности за финансовые убытки связанные с неправильным использованием, либо нарушением правил партнерской программы партнером.</li>
<li>Партнерская программа не несет ответственности за любые проблемы возникшие по вине третьих лиц.</li></ul>",
      'en' => "<ul><li>Affiliate program is not responsible for any problems related to the violation of the rules of the affiliate program partner.</li>
<li>Affiliates shall not be liable for financial damages resulting from misuse or violation of the rules of the affiliate program partner.</li>
<li>Affiliate program is not responsible for any problems caused by the fault of third parties.</li></ul>"
    ];
    $faq->sort = 3;
    $faq->visible = 1;
    $faq->faq_category_id = $termsCategory->id;
    $faq->save();

    $faq = new Faq();
    $faq->question = ['ru' => "Партнерская программа имеет право:", 'en' => "Affiliate program is entitled:"];
    $faq->answer = [
      'ru' => "<ul><li>Приостанавливать работу партнерской программы для проведения плановых работ, обновления программного обеспечения и модернизации оборудования.</li>
<li>Выставлять партнеру штрафы выставленные ОСС либо КП в полном объеме, в случае если причиной данного штрафа было нарушение правил партнерской программы партнером.</li>
<li>В случае нарушения правил партнерской программы со стороны партнера – заблокировать аккаунт, с частичной или полной блокировкой средств на счету партнера.</li></ul>",
      'en' => "<ul><li>Pauses the affiliate program for planned works, software updates and hardware upgrades.</li>
<li>Expose partner penalties exposed OSS or manual in its entirety, if the reason for this penalty was a violation of the rules of the affiliate program partner.</li>
<li>In case of violation of the rules of the affiliate program from a partner - to block the account, with partial or complete blocking of funds in the account partner.</li></ul>"
    ];
    $faq->sort = 4;
    $faq->visible = 1;
    $faq->faq_category_id = $termsCategory->id;
    $faq->save();

    /* END terms category */
  }

  public function down()
  {
    $this->truncateTable('faqs');
    $this->execute("SET foreign_key_checks = 0;");
    $this->truncateTable('faq_categories');
    $this->execute("SET foreign_key_checks = 1;");
  }
}
