<?php

use console\components\Migration;

class m161226_101222_partner_cabinet_result_link extends Migration
{
  public function up()
  {
    $this->db->createCommand('
    INSERT IGNORE INTO partner_cabinet_style_fields (code, name, css_selector, css_prop, sort_css, default_value, sort, category_id, created_by, updated_by, created_at, updated_at) VALUES (\'result_link\', \'a:2:{s:2:"ru";s:63:"Создание ссылки: блок "Ваша ссылка"";s:2:"en";s:32:"Link creation: block "Your link"";}\', \'.result_url .result_url-box .result_url-input\', \'background-color\', 110, \'#3089C5\', 110, 2, 1, 1, 1482746395, 1482746395);
    ')->execute();
  }

  public function down()
  {
    $this->db->createCommand('DELETE FROM partner_cabinet_style_fields WHERE code="result_link"')->execute();
  }
}
