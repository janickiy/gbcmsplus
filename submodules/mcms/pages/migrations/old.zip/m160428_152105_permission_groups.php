<?php

use console\components\Migration;

class m160428_152105_permission_groups extends Migration
{
  /** @var  \yii\rbac\ManagerInterface */
  private $authManager;
  private $groupPermission = [
    'name' =>  'PagesModule',
    'description' => 'Module Pages',
  ]
  ;
  private $groupPermissionControllers = [
    'PagesCategoriesController' => [
      'description' => 'Pages Categories Controller',
      'permissions' => [
        'PagesCategoriesCreate',
        'PagesCategoriesDelete',
        'PagesCategoriesIndex',
        'PagesCategoriesPropDelete',
        'PagesCategoriesPropEntityDelete',
        'PagesCategoriesPropEntityModal',
        'PagesCategoriesPropModal',
      ]
    ],
    'PagesFaqCategoriesController' => [
      'description' => 'Pages Faq Categories Controller',
      'permissions' => [
        'PagesFaqCategoriesCreate',
        'PagesFaqCategoriesDelete',
        'PagesFaqCategoriesIndex',
        'PagesFaqCategoriesUpdate',
        'PagesFaqCategoriesView',
        'PagesFaqCreate',
        'PagesFaqDelete',
        'PagesFaqGetSortDropDownArray',
        'PagesFaqIndex',
        'PagesFaqUpdate',
        'PagesFaqView',
      ]
    ],
    'PagesController' => [
      'description' => 'Pages Controller',
      'permissions' => [
        'PagesPagesCreate',
        'PagesPagesDelete',
        'PagesPagesDisable',
        'PagesPagesEnable',
        'PagesPagesFileDelete',
        'PagesPagesImagesGet',
        'PagesPagesImageUpload',
        'PagesPagesIndex',
        'PagesPagesUpdate',
        'PagesPagesView',
        'PagesPagesViewText',
      ]
    ],

  ];

  public function init()
  {
    parent::init();
    $this->authManager = \Yii::$app->authManager;
  }

  public function up()
  {
    foreach ($this->groupPermissionControllers as $controllerName => $controllerData) {
      $controllerPermission = $this->createOrGetPermission($controllerName, $controllerData['description']);
      foreach($controllerData['permissions'] as $childPermissionName) {
        $childPermission = $this->authManager->getPermission($childPermissionName);
        if ($childPermission && !$this->authManager->hasChild($controllerPermission, $childPermission)) {
          $this->authManager->addChild($controllerPermission, $childPermission);
        }
      }
      $groupPermission = $this->createOrGetPermission($this->groupPermission['name'], $this->groupPermission['description']);
      $this->authManager->addChild($groupPermission, $controllerPermission);
    }
  }

  public function down()
  {
    $permission = $this->authManager->getPermission($this->groupPermission);
    $this->authManager->remove($permission);
    foreach ($this->groupPermissionControllers as $controllerName => $controllerData) {
      $controllerPermission = $this->authManager->getPermission($controllerName);
      $this->authManager->remove($controllerPermission);
    }
  }

  public function createOrGetPermission($permissionName, $permissionDescription)
  {
    $permission = $this->authManager->getPermission($permissionName);
    if (!$permission) {
      $permission = $this->authManager->createPermission($permissionName);
      $permission->description = $permissionDescription;
      $this->authManager->add($permission);
    }
    return $permission;
  }
}
