<?php

use console\components\Migration;

class m161129_093420_style_fields extends Migration
{

  const TABLE = 'partner_cabinet_style_fields';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(static::TABLE, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'code' => $this->string(255)->notNull(),
      'name' => $this->string(512)->notNull() . ' COMMENT \'мультиланг\'',
      'css_selector' => $this->string(255)->notNull() . ' COMMENT \'например .head > span\'',
      'css_prop' => $this->string(128)->notNull() . ' COMMENT \'например background-color\'',
      'sort_css' => $this->smallInteger()->unsigned()->notNull()->defaultValue(100) . ' COMMENT \'позиция в css файле\'',
      'default_value' => $this->text(),
      'sort' => $this->smallInteger()->unsigned()->notNull()->defaultValue(100),
      'category_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',

      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'updated_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED NOT NULL'
    ], $tableOptions);

    $this->createIndex(self::TABLE . '_code_unique', self::TABLE, 'code', true);
    $this->addForeignKey(
      self::TABLE . '_category_id_fk',
      self::TABLE,
      'category_id',
      'partner_cabinet_style_categories',
      'id',
      'CASCADE',
      'CASCADE'
    );

  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }
}
