<?php

use console\components\Migration;

class m151217_140439_reseller_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration {
    up as traitUp;
    down as traitDown;
  }

  /**
   * @inheritDoc
   */
  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Pages';
    $this->permissions = [
      'Pages' => [
        ['index', 'Display pages list', ['admin', 'root']],
        ['view', 'View page', ['admin', 'root']],
        ['update', 'Update page', ['admin', 'root']],
        ['enable', 'Enable page', ['admin', 'root']],
        ['disable', 'Disable page', ['admin', 'root']],
        ['fileDelete', 'Delete file', ['admin', 'root']],
      ],
    ];
  }

  public function up()
  {
    $this->permissions = [
      'Pages' => [
        ['index', 'Display pages list', ['admin', 'root', 'reseller']],
        ['view', 'View page', ['admin', 'root', 'reseller']],
        ['update', 'Update page', ['admin', 'root', 'reseller']],
        ['enable', 'Enable page', ['admin', 'root', 'reseller']],
        ['disable', 'Disable page', ['admin', 'root', 'reseller']],
        ['fileDelete', 'Delete file', ['admin', 'root', 'reseller']],
      ],
    ];
    $this->traitUp();
  }

  public function down()
  {
    $this->traitDown();
    $this->traitUp();
  }
}
