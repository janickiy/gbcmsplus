<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;
use yii\rbac\Role;

/**
*/
class m181106_092153_infoblocks_revoke extends Migration
{
  use PermissionTrait;
  /**
  */
  public function up()
  {
    $revokePermissions = [
      "'PagesCategoriesPropModal'",
      "'PagesCategoriesPropEntityModal'",
      "'PagesCategoriesPropEntityDelete'",
      "'PagesCategoriesPropDelete'",
      "'PagesCategoriesIndex'",
      "'PagesCategoriesDelete'",
      "'PagesCategoriesCreate'",
      "'PagesCategoriesController'",
      "'PagesPagesView'",
      "'PagesPagesUpdate'",
      "'PagesPagesIndex'",
      "'PagesPagesImageUpload'",
      "'PagesPagesImagesGet'",
      "'PagesPagesFileDelete'",
      "'PagesPagesEnable'",
      "'PagesPagesDisable'",
      "'PagesPagesDelete'",
      "'PagesPagesCreate'",
      "'PagesController'",
    ];

    $revokePermissionsStr = implode(',', $revokePermissions);

    // сделал не через $this->revokeRolesPermission() чтобы затронуть
    // всякие супер-менеджеры и другие роли, которых мы не поддерживаем в коде
    $this->execute("
      DELETE aic FROM auth_item_child aic
        INNER JOIN auth_item a ON aic.parent = a.name AND a.type = :typeRole
      WHERE aic.child IN ($revokePermissionsStr)
    ", [
      ':typeRole' => Role::TYPE_ROLE
    ]);
  }

  /**
  */
  public function down()
  {
    echo "m181106_092153_infoblocks_revoke cannot be reverted.\n";

    return true;
  }


}
