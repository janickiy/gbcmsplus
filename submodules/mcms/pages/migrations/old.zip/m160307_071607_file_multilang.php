<?php

use console\components\Migration;
use mcms\pages\models\PageProp;
use mcms\pages\models\CategoryProp;
use mcms\common\multilang\widgets\input\FileInputWidget;

class m160307_071607_file_multilang extends Migration
{

  private $pagesProps = [];

  /**
   * Ранее для каждого файла создавалась модель PageProp. Теперь все файлы одного свойства у
   * страницы хранятся в одной модели в поле multilang_values.
   * Пример: ['ru' => ['file1.png', 'file2.png', 'file3.png'], 'en' => [...]]
   *
   * @return bool
   * @throws \yii\base\Exception
   */
  public function safeUp()
  {
    $categoryProps = CategoryProp::find()->where(['type' => CategoryProp::TYPE_FILE])->all();

    foreach($categoryProps as $categoryProp) {

      $this->pagesProps = [];

      /** @var CategoryProp $categoryProp */
      $pagesProps = $categoryProp->getPageProps()->all();

      foreach ($pagesProps as $pageProp) {
        if (!isset($this->pagesProps[$pageProp->page_id])) {
          $this->pagesProps[$pageProp->page_id] = new PageProp([
            'page_category_prop_id' => $categoryProp->id,
            'page_id' => $pageProp->page_id,
            'multilang_value' => []
          ]);
        }

        $multilang = $this->pagesProps[$pageProp->page_id]->multilang_value;

        foreach (FileInputWidget::getLanguages() as $lang) {
          $multilang[$lang][] = $pageProp->value;
        }

        $this->pagesProps[$pageProp->page_id]->multilang_value = $multilang;

        $pageProp->delete();
      }

      // сохраняем накопившиеся модели
      foreach ($this->pagesProps as $newPageProp) {
        if (!$newPageProp->save()) throw new \yii\base\Exception('New prop save error ' . json_encode($newPageProp));
      }
    }

  }

  public function safeDown()
  {
    echo 'migrate down is unsupported';
  }
}
