<?php

use console\components\Migration;

class m170117_091837_votes_structure extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable('{{%votes}}', [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => 'VARCHAR(500) NOT NULL',
      'description' => 'TEXT NOT NULL',
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_multiple' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED NOT NULL',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'updated_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
    ], $tableOptions);

    $this->addForeignKey('vote_created_fk', '{{%votes}}', 'created_by', '{{%users}}', 'id', 'CASCADE');
    $this->addForeignKey('vote_updated_fk', '{{%votes}}', 'updated_by', '{{%users}}', 'id', 'CASCADE');

    $this->createTable('{{%vote_variants}}', [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'vote_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'name' => 'TEXT NOT NULL',
      'is_text' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_text_required' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'sort' => 'SMALLINT(5) UNSIGNED NOT NULL DEFAULT 100',
    ], $tableOptions);

    $this->addForeignKey('vote_variants_fk', '{{%vote_variants}}', 'vote_id', '{{%votes}}', 'id', 'CASCADE');

    $this->createTable('{{%vote_results}}', [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'variant_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'text' => 'TEXT DEFAULT NULL',
    ], $tableOptions);

    $this->addForeignKey('vote_results_fk', '{{%vote_results}}', 'variant_id', '{{%vote_variants}}', 'id', 'CASCADE');
    $this->addForeignKey('vote_results_users_fk', '{{%vote_results}}', 'user_id', '{{%users}}', 'id', 'CASCADE');
  }

  public function down()
  {
    $this->dropTable('{{%vote_results}}');
    $this->dropTable('{{%vote_variants}}');
    $this->dropTable('{{%votes}}');
  }
}
