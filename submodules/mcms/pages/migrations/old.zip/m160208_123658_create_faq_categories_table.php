<?php

use yii\db\Schema;
use console\components\Migration;

class m160208_123658_create_faq_categories_table extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable('faq_categories', [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => 'TEXT NOT NULL',
      'sort' => 'TINYINT(4) NOT NULL',
      'visible' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0'
    ], $tableOptions);
    $this->createIndex('faq_categories_sort', 'faq_categories', 'sort');
    $this->createIndex('faq_categories_visible', 'faq_categories', 'visible');
  }

  public function down()
  {
    $this->dropTable('faq_categories');
  }
}
