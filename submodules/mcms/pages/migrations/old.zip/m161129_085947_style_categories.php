<?php

use console\components\Migration;

class m161129_085947_style_categories extends Migration
{
  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }
    $this->createTable('{{%partner_cabinet_style_categories}}', [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'code' => $this->string(255)->notNull(),
      'name' => $this->string(512)->notNull(),
      'sort' => $this->smallInteger()->unsigned()->notNull()->defaultValue(100),
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'updated_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED NOT NULL'
    ], $tableOptions);

    $this->createIndex('partner_cabinet_style_categories_code_index', '{{%partner_cabinet_style_categories}}', 'code', true);
  }

  public function down()
  {
    $this->dropTable('{{%partner_cabinet_style_categories}}');
  }
}
