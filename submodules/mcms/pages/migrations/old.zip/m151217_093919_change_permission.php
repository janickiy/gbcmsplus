<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m151217_093919_change_permission extends Migration
{
  use PermissionMigration {
    up as traitUp;
    down as traitDown;
  }

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'Pages' => [
        ['index', 'Display pages list', ['admin', 'root']],
        ['view', 'View page', ['admin', 'root']],
        ['create', 'Create page', ['admin', 'root']],
        ['update', 'Update page', ['admin', 'root']],
        ['delete', 'Remove page', ['admin', 'root']],
        ['enable', 'Enable page', ['admin', 'root']],
        ['disable', 'Disable page', ['admin', 'root']],
        ['fileDelete', 'Delete file', ['admin', 'root']],
      ]
    ];
  }

  public function up()
  {
    $this->traitDown();

    $this->moduleName = 'Pages';
    $this->traitUp();
  }

  public function down()
  {
    $this->moduleName = 'Pages';
    $this->traitDown();

    $this->moduleName = '';
    $this->traitUp();
  }
}
