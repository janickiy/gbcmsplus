<?php

use console\components\Migration;
use rgk\utils\traits\PermissionTrait;

/**
*/
class m181106_085446_votes_destroyer extends Migration
{
  use PermissionTrait;
  /**
  */
  public function up()
  {
    $this->removePermission('PartnersVotesController');
    $this->removePermission('PartnersVotesVote');

    $this->removePermission('PagesVoteStatisticController');
    $this->removePermission('PagesVoteStatisticIndex');

    $this->removePermission('PagesVoteController');
    $this->removePermission('PagesVoteIndex');
    $this->removePermission('PagesVoteCreate');
    $this->removePermission('PagesVoteUpdate');
    $this->removePermission('PagesVoteDelete');
    $this->removePermission('PagesVoteEnable');
    $this->removePermission('PagesVoteDisable');
    $this->removePermission('PagesVoteStatistic');
    $this->removePermission('PagesVoteCreateOption');
    $this->removePermission('PagesVoteUpdateOption');
    $this->removePermission('PagesVoteDeleteOption');

    $this->dropTable('{{%vote_results}}');
    $this->dropTable('{{%vote_variants}}');
    $this->dropTable('{{%votes}}');
  }

  /**
  */
  public function down()
  {
    $this->createPermission('PartnersVotesController', 'Контроллер Votes', 'PartnersModule');
    $this->createPermission('PartnersVotesVote', 'Отдать голос', 'PartnersVotesController', ['partner']);

    $this->createPermission('PagesVoteStatisticController', 'Статистика опросов', 'PagesModule', ['admin', 'root', 'reseller']);
    $this->createPermission('PagesVoteStatisticIndex', 'Список статистика опросов', 'PagesVoteStatisticController', ['admin', 'root', 'reseller']);

    $this->createPermission('PagesVoteController', 'Контроллер Vote', 'PagesModule');

    $this->createPermission('PagesVoteIndex', 'Просмотр списка голосований', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteCreate', 'Создание голосования', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteUpdate', 'Редактирование голосования', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteDelete', 'Удаление голосования', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteEnable', 'Активация голосования', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteDisable', 'Деактивация голосования', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteStatistic', 'Статистика голосования', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteCreateOption', 'Создание варианта', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteUpdateOption', 'Редактирование варианта', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteDeleteOption', 'Удаление варианта', 'PagesVoteController', ['root', 'admin', 'reseller']);

    $this->createTable('{{%votes}}', [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'name' => 'VARCHAR(500) NOT NULL',
      'description' => 'TEXT NOT NULL',
      'status' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_multiple' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED NOT NULL',
      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'updated_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
    ]);

    $this->addForeignKey('vote_created_fk', '{{%votes}}', 'created_by', '{{%users}}', 'id', 'CASCADE');
    $this->addForeignKey('vote_updated_fk', '{{%votes}}', 'updated_by', '{{%users}}', 'id', 'CASCADE');

    $this->createTable('{{%vote_variants}}', [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'vote_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'name' => 'TEXT NOT NULL',
      'is_text' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'is_text_required' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0',
      'sort' => 'SMALLINT(5) UNSIGNED NOT NULL DEFAULT 100',
    ]);

    $this->addForeignKey('vote_variants_fk', '{{%vote_variants}}', 'vote_id', '{{%votes}}', 'id', 'CASCADE');

    $this->createTable('{{%vote_results}}', [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'user_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'variant_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'text' => 'TEXT DEFAULT NULL',
    ]);

    $this->addForeignKey('vote_results_fk', '{{%vote_results}}', 'variant_id', '{{%vote_variants}}', 'id', 'CASCADE');
    $this->addForeignKey('vote_results_users_fk', '{{%vote_results}}', 'user_id', '{{%users}}', 'id', 'CASCADE');
  }
}
