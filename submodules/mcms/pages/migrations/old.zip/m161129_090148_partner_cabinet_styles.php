<?php

use console\components\Migration;

/**
 *
 */
class m161129_090148_partner_cabinet_styles extends Migration
{
  const TABLE = 'partner_cabinet_styles';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(static::TABLE, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',

      'name' => $this->string(128)->notNull(),
      'status' => $this->smallInteger(1)->notNull()->defaultValue(0),

      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'updated_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',

      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED NOT NULL'
    ], $tableOptions);

    $this->insert(static::TABLE, ['name' => 'Пример оформления']);
  }

  public function down()
  {
    $this->dropTable(static::TABLE);
  }
}
