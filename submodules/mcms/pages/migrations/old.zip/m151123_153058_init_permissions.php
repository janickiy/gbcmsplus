<?php

use console\components\Migration;

class m151123_153058_init_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'Pages' => [
        ['index', 'Display pages list', ['admin', 'root']],
        ['view', 'View page', ['admin', 'root']],
        ['create', 'Create page', ['admin', 'root']],
        ['update', 'Update page', ['admin', 'root']],
        ['delete', 'Remove page', ['admin', 'root']],
        ['enable', 'Enable page', ['admin', 'root']],
        ['disable', 'Disable page', ['admin', 'root']],
        ['fileDelete', 'Delete file', ['admin', 'root']],
      ]
    ];
  }


}
