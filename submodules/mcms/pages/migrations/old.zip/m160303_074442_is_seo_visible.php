<?php

use console\components\Migration;

class m160303_074442_is_seo_visible extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  const TABLE = 'page_categories';
  const COLUMN_SEO = 'is_seo_visible';
  const COLUMN_URL = 'is_url_visible';
  const COLUMN_INDEX = 'is_index_visible';

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    parent::init();
  }

  public function up()
  {
    $this->addColumn(self::TABLE, self::COLUMN_SEO, 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0 AFTER name');
    $this->addColumn(self::TABLE, self::COLUMN_URL, 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0 AFTER name');
    $this->addColumn(self::TABLE, self::COLUMN_INDEX, 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0 AFTER name');

    $this->revokeRolesPermission('PagesCategoriesPropEntityModal', ['reseller']);
    $this->revokeRolesPermission('PagesCategoriesCreate', ['reseller']);
    $this->revokeRolesPermission('PagesCategoriesIndex', ['reseller']);
    $this->revokeRolesPermission('PagesCategoriesPropModal', ['reseller']);
  }

  public function down()
  {
    $this->assignRolesPermission('PagesCategoriesPropEntityModal', ['reseller']);
    $this->assignRolesPermission('PagesCategoriesCreate', ['reseller']);
    $this->assignRolesPermission('PagesCategoriesIndex', ['reseller']);
    $this->assignRolesPermission('PagesCategoriesPropModal', ['reseller']);


    $this->dropColumn(self::TABLE, self::COLUMN_INDEX);
    $this->dropColumn(self::TABLE, self::COLUMN_URL);
    $this->dropColumn(self::TABLE, self::COLUMN_SEO);
  }

}
