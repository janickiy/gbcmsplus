<?php

use rgk\utils\traits\PermissionTrait;
use console\components\Migration;

class m170815_141805_remove_permissions extends Migration
{
  use PermissionTrait;

  public function up()
  {
    $this->removePermission('PagesPagesViewText');
  }

  public function down()
  {
    $this->createPermission('PagesPagesViewText', 'Просмотр текста элемента инфоблока', 'PagesController', ['root', 'admin', 'reseller']);
  }
}
