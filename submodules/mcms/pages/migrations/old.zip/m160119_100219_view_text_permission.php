<?php

use console\components\Migration;

class m160119_100219_view_text_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();

    $this->authManager = Yii::$app->authManager;
    $this->moduleName = 'Pages';
    $this->permissions = [
      'Pages' => [
        ['view-text', 'Can view page text', ['admin', 'root']],
      ],
    ];
  }
}
