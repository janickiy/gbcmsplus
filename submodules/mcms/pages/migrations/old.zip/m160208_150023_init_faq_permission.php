<?php

use yii\db\Schema;
use console\components\Migration;

class m160208_150023_init_faq_permission extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'PagesFaq' => [
        ['index', 'Display faq list', ['admin', 'root']],
        ['view', 'View faq', ['admin', 'root']],
        ['create', 'Create faq', ['admin', 'root']],
        ['update', 'Update faq', ['admin', 'root']],
        ['delete', 'Remove faq', ['admin', 'root']],
        ['getSortDropDownArray', 'Get sort drop down in faq form', ['admin', 'root']],
      ]
    ];
  }
}
