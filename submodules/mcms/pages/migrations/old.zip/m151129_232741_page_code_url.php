<?php

use console\components\Migration;

class m151129_232741_page_code_url extends Migration
{
    public function up()
    {
        $this->addColumn('pages', 'url', 'varchar(255) DEFAULT NULL AFTER seo_description');
        $this->addColumn('pages', 'code', 'varchar(255) DEFAULT NULL AFTER url');

        $this->createIndex('pages_url_uk','pages','url',true);
        $this->createIndex('pages_code_uk','pages','code',true);
    }

    public function down()
    {
        $this->dropColumn('pages','url');
        $this->dropColumn('pages','code');
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
