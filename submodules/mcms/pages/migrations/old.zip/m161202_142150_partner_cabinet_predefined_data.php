<?php

use console\components\Migration;

class m161202_142150_partner_cabinet_predefined_data extends Migration
{
  public function up()
  {
    $this->db->createCommand('
      INSERT IGNORE INTO partner_cabinet_styles (id, name, status, created_by, updated_by, created_at, updated_at) VALUES (1, "Пример оформления", 0, 0, 2, 0, 1480688386);
    ')->execute();

    $this->db->createCommand('
      INSERT IGNORE INTO partner_cabinet_style_categories (id, code, name, sort, created_by, updated_by, created_at, updated_at) VALUES (1, \'head\', \'a:2:{s:2:"ru";s:4:"Head";s:2:"en";s:4:"Head";}\', 1, 1, 1, 1480600000, 1480600000);
      INSERT IGNORE INTO partner_cabinet_style_categories (id, code, name, sort, created_by, updated_by, created_at, updated_at) VALUES (2, \'body\', \'a:2:{s:2:"ru";s:4:"Body";s:2:"en";s:4:"Body";}\', 2, 1, 1, 1480601568, 1480601568);
    ')->execute();

    $this->db->createCommand('
      INSERT IGNORE INTO partner_cabinet_style_fields (code, name, css_selector, css_prop, sort_css, default_value, sort, category_id, created_by, updated_by, created_at, updated_at) VALUES (\'navy_background_color\', \'a:2:{s:2:"ru";s:31:"Панель навигации";s:2:"en";s:28:"Navy panel: background color";}\', \'.navbar.navbar-default\', \'background-color\', 2, \'default\', 1, 1, 1, 2, 1480600127, 1480683034);
      INSERT IGNORE INTO partner_cabinet_style_fields (code, name, css_selector, css_prop, sort_css, default_value, sort, category_id, created_by, updated_by, created_at, updated_at) VALUES (\'statistic_table_data_period_check_background_color\', \'a:2:{s:2:"ru";s:107:"Таблица статистики: выделенный элемент периода - цвет фона";s:2:"en";s:107:"Таблица статистики: выделенный элемент периода - цвет фона";}\', \'.btn-group_custom label.btn.active:active, .btn-group_custom label.btn.active.active, .open > .btn-group_custom label.btn.active.dropdown-toggle\', \'background-color\', 104, \'#fff99c\', 4, 2, 1, 2, 1480601105, 1480607387);
      INSERT IGNORE INTO partner_cabinet_style_fields (code, name, css_selector, css_prop, sort_css, default_value, sort, category_id, created_by, updated_by, created_at, updated_at) VALUES (\'navy_notify_header_top_background_color\', \'a:2:{s:2:"ru";s:55:"Панель навигации: нотификация";s:2:"en";s:29:"Navy notofy: background color";}\', \'.notify-header_top:not(.active)\', \'background-color\', 3, \'#2d2d2d\', 3, 1, 2, 2, 1480603477, 1480683026);
      INSERT IGNORE INTO partner_cabinet_style_fields (code, name, css_selector, css_prop, sort_css, default_value, sort, category_id, created_by, updated_by, created_at, updated_at) VALUES (\'navy_usermenu_background_color\', \'a:2:{s:2:"ru";s:66:"Панель навигации: меню пользователя";s:2:"en";s:4:"Menu";}\', \'.navbar-nav > li.dropdown\', \'background-color\', 5, \'#2C2C2C\', 5, 1, 2, 2, 1480603950, 1480683091);
      INSERT IGNORE INTO partner_cabinet_style_fields (code, name, css_selector, css_prop, sort_css, default_value, sort, category_id, created_by, updated_by, created_at, updated_at) VALUES (\'navy_usermenu_clicked_background_color\', \'a:2:{s:2:"ru";s:103:"Панель навигации: меню пользователя в нажатом состоянии";s:2:"en";s:10:"Menu: push";}\', \'.navbar-default .navbar-nav > .open, .navbar-default .navbar-nav > .open:hover, .navbar-default .navbar-nav > .open:focus\', \'background-color\', 6, \'#262626\', 6, 1, 2, 2, 1480604004, 1480683082);
      INSERT IGNORE INTO partner_cabinet_style_fields (code, name, css_selector, css_prop, sort_css, default_value, sort, category_id, created_by, updated_by, created_at, updated_at) VALUES (\'navy_usermenu_dropdown_background_color\', \'a:2:{s:2:"ru";s:102:"Панель навигации: меню пользователя - выпадающий список";s:2:"en";s:14:"Menu: dropdown";}\', \'.navbar-nav .dropdown-menu\', \'background-color\', 7, \'#2C2C2C\', 7, 1, 2, 2, 1480604096, 1480683140);
      INSERT IGNORE INTO partner_cabinet_style_fields (code, name, css_selector, css_prop, sort_css, default_value, sort, category_id, created_by, updated_by, created_at, updated_at) VALUES (\'head_background_color\', \'a:2:{s:2:"ru";s:17:"Фон шапки";s:2:"en";s:15:"Head background";}\', \'body.cerulean .category, body.cerulean .result_url\', \'background-color\', 8, \'#2F97DE\', 8, 1, 2, 2, 1480604487, 1480681549);
      INSERT IGNORE INTO partner_cabinet_style_fields (code, name, css_selector, css_prop, sort_css, default_value, sort, category_id, created_by, updated_by, created_at, updated_at) VALUES (\'statistic_table_footer_background_color\', \'a:2:{s:2:"ru";s:64:"Таблица статистики: подвал таблицы";s:2:"en";s:34:"Statistic table: footer background";}\', \'.table > tfoot\', \'background-color\', 109, \'#EAFAED\', 109, 2, 2, 2, 1480604706, 1480683202);
      INSERT IGNORE INTO partner_cabinet_style_fields (code, name, css_selector, css_prop, sort_css, default_value, sort, category_id, created_by, updated_by, created_at, updated_at) VALUES (\'statistic_table_data_period_check_border_color\', \'a:2:{s:2:"ru";s:113:"Таблица статистики: выделенный элемент периода - цвет границы";s:2:"en";s:113:"Таблица статистики: выделенный элемент периода - цвет границы";}\', \'.btn-group_custom label.btn.active:active, .btn-group_custom label.btn.active.active, .open > .btn-group_custom label.btn.active.dropdown-toggle\', \'border-color\', 105, \'#dce831\', 105, 2, 2, 2, 1480607431, 1480607489);
    ')->execute();

  }

  public function down()
  {
    $this->db->createCommand()->truncateTable('partner_cabinet_style_fields');
    $this->db->createCommand()->truncateTable('partner_cabinet_style_categories');
    $this->db->createCommand()->truncateTable('partner_cabinet_styles');
  }
}
