<?php

use console\components\Migration;

class m180405_082429_faq_update extends Migration
{
  // TRICKY: Кроме как по вопросу искать не по чему, поэтому, если вопрос меняли из админки, он не отредактируется
  public function up()
  {
    $question = serialize(['ru' => "Для чего нужна парковка и регистрация доменов?", 'en' => "What is the parking and domain name registration?"]);
    $questionId = $this->db->createCommand('SELECT id FROM faqs WHERE question=:question', ['question' => $question])->queryScalar();

    $newQuestion = serialize(['ru' => "Для чего нужна парковка доменов?", 'en' => "What is the parking?"]);
    $newAnswer = serialize([
      'ru' => "Парковка доменов позволяет вам использовать свои домены для работы с партнерской программой. Это позволяет увеличить конверт, за счет снижения рисков бана системных доменов антивирусами, и других форс-мажорных обстоятельствах. Рекомендуем переодически следить за припарковаными доменами на бан АВ.",
      'en' => "Parking allows you to use your domain to work with the affiliate program. This makes it possible to increase the envelope, by reducing the risk of systemic ban domains antivirus, and other force majeure. We recommend periodically monitor the parked domains to ban AB."
    ]);

    $this->update('faqs', ['question' => $newQuestion, 'answer' => $newAnswer], ['id' => $questionId]);
  }

  public function down()
  {
    $question = serialize(['ru' => "Для чего нужна парковка доменов?", 'en' => "What is the parking?"]);
    $questionId = $this->db->createCommand('SELECT id FROM faqs WHERE question=:question', ['question' => $question])->queryScalar();

    $newQuestion = serialize(['ru' => "Для чего нужна парковка и регистрация доменов?", 'en' => "What is the parking and domain name registration?"]);
    $newAnswer = serialize([
      'ru' => "Парковка и регистрация доменов позволяет вам использовать свои домены для работы с партнерской программой. Это позволяет увеличить конверт, за счет снижения рисков бана системных доменов антивирусами, и других форс-мажорных обстоятельствах. Рекомендуем переодически следить за припарковаными доменами на бан АВ.",
      'en' => "Parking and domain registration allows you to use your domain to work with the affiliate program. This makes it possible to increase the envelope, by reducing the risk of systemic ban domains antivirus, and other force majeure. We recommend periodically monitor the parked domains to ban AB."
    ]);

    $this->update('faqs', ['question' => $newQuestion, 'answer' => $newAnswer], ['id' => $questionId]);
  }
}
