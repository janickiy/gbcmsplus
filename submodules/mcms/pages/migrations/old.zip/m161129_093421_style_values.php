<?php

use console\components\Migration;

class m161129_093421_style_values extends Migration
{

  const TABLE = 'partner_cabinet_style_values';

  public function up()
  {
    $tableOptions = null;
    if ($this->db->driverName === 'mysql') {
      // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
      $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
    }

    $this->createTable(static::TABLE, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'style_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL COMMENT "связь к таблице partner_cabinet_styles"',
      'field_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL COMMENT "связь к таблице partner_cabinet_style_fields"',
      'value' => $this->text() . ' COMMENT \'значение css свойства\'',

      'created_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'updated_by' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED NOT NULL'
    ], $tableOptions);

    $this->addForeignKey(
      self::TABLE . '_field_id_fk',
      self::TABLE,
      'field_id',
      'partner_cabinet_style_fields',
      'id',
      'CASCADE',
      'CASCADE'
    );

    $this->addForeignKey(
      self::TABLE . '_style_id_fk',
      self::TABLE,
      'style_id',
      'partner_cabinet_styles',
      'id',
      'CASCADE',
      'CASCADE'
    );

  }

  public function down()
  {
    $this->dropTable(self::TABLE);
  }
}
