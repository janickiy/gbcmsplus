<?php

use console\components\Migration;

class m151109_093457_add_field_images extends Migration
{
    public function up()
    {
        $this->addColumn('pages', 'images', 'text DEFAULT NULL');
    }

    public function down()
    {
        $this->dropColumn('pages', 'images');
    }

}
