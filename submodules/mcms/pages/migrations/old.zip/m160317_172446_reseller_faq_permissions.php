<?php

use console\components\Migration;

class m160317_172446_reseller_faq_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'PagesFaq' => [
        ['index', 'Display faq list', ['reseller']],
        ['view', 'View faq', ['reseller']],
        ['create', 'Create faq', ['reseller']],
        ['update', 'Update faq', ['reseller']],
        ['delete', 'Remove faq', ['reseller']],
        ['getSortDropDownArray', 'Get sort drop down in faq form', ['reseller']],
      ]
    ];
  }
}
