<?php

use console\components\Migration;

class m160302_151045_reseller_rights extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    parent::init();
  }

  public function up()
  {
    $this->assignRolesPermission('PagesCategoriesPropEntityModal', ['reseller']);
    $this->assignRolesPermission('PagesPagesCreate', ['reseller']);
    $this->assignRolesPermission('PagesPagesImagesGet', ['reseller']);
    $this->assignRolesPermission('PagesPagesImageUpload', ['reseller']);
    $this->assignRolesPermission('PagesPagesViewText', ['reseller']);
  }

  public function down()
  {
    $this->revokeRolesPermission('PagesCategoriesPropEntityModal', ['reseller']);
    $this->revokeRolesPermission('PagesPagesCreate', ['reseller']);
    $this->revokeRolesPermission('PagesPagesImagesGet', ['reseller']);
    $this->revokeRolesPermission('PagesPagesImageUpload', ['reseller']);
    $this->revokeRolesPermission('PagesPagesViewText', ['reseller']);
  }

}
