<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m170117_121350_votes_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('PagesVoteController', 'Контроллер Vote', 'PagesModule');

    $this->createPermission('PagesVoteIndex', 'Просмотр списка голосований', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteCreate', 'Создание голосования', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteUpdate', 'Редактирование голосования', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteDelete', 'Удаление голосования', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteEnable', 'Активация голосования', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteDisable', 'Деактивация голосования', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteStatistic', 'Статистика голосования', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteCreateOption', 'Создание варианта', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteUpdateOption', 'Редактирование варианта', 'PagesVoteController', ['root', 'admin', 'reseller']);
    $this->createPermission('PagesVoteDeleteOption', 'Удаление варианта', 'PagesVoteController', ['root', 'admin', 'reseller']);
  }

  public function down()
  {
    $this->removePermission('PagesVoteController');
    $this->removePermission('PagesVoteIndex');
    $this->removePermission('PagesVoteCreate');
    $this->removePermission('PagesVoteUpdate');
    $this->removePermission('PagesVoteDelete');
    $this->removePermission('PagesVoteEnable');
    $this->removePermission('PagesVoteDisable');
    $this->removePermission('PagesVoteStatistic');
    $this->removePermission('PagesVoteCreateOption');
    $this->removePermission('PagesVoteUpdateOption');
    $this->removePermission('PagesVoteDeleteOption');
  }
}
