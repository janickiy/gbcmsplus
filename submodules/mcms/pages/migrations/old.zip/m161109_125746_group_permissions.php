<?php

use mcms\common\traits\PermissionMigration;
use console\components\Migration;

class m161109_125746_group_permissions extends Migration
{
  use PermissionMigration;

  public function up()
  {
    $this->createPermission('PagesFaqController', null, 'PagesModule');

    $this->removeChildPermission('PagesFaqCategoriesController', 'PagesFaqCreate');
    $this->addChildPermission('PagesFaqController', 'PagesFaqCreate');

    $this->removeChildPermission('PagesFaqCategoriesController', 'PagesFaqDelete');
    $this->addChildPermission('PagesFaqController', 'PagesFaqDelete');

    $this->removeChildPermission('PagesFaqCategoriesController', 'PagesFaqGetSortDropDownArray');
    $this->addChildPermission('PagesFaqController', 'PagesFaqGetSortDropDownArray');

    $this->removeChildPermission('PagesFaqCategoriesController', 'PagesFaqIndex');
    $this->addChildPermission('PagesFaqController', 'PagesFaqIndex');

    $this->removeChildPermission('PagesFaqCategoriesController', 'PagesFaqUpdate');
    $this->addChildPermission('PagesFaqController', 'PagesFaqUpdate');

    $this->removeChildPermission('PagesFaqCategoriesController', 'PagesFaqView');
    $this->addChildPermission('PagesFaqController', 'PagesFaqView');
  }

  public function down()
  {
    $this->removePermission('PagesFaqController');
    $this->addChildPermission('PagesFaqCategoriesController', 'PagesFaqCreate');
    $this->addChildPermission('PagesFaqCategoriesController', 'PagesFaqDelete');
    $this->addChildPermission('PagesFaqCategoriesController', 'PagesFaqGetSortDropDownArray');
    $this->addChildPermission('PagesFaqCategoriesController', 'PagesFaqIndex');
    $this->addChildPermission('PagesFaqCategoriesController', 'PagesFaqUpdate');
    $this->addChildPermission('PagesFaqCategoriesController', 'PagesFaqView');
  }
}
