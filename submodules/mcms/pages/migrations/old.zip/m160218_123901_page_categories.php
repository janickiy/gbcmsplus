<?php

use yii\db\Schema;
use console\components\Migration;

class m160218_123901_page_categories extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  const CAT = 'page_categories';
  const PROP = 'page_category_props';
  const ENTITY = 'page_category_prop_entities';
  const PAGES = 'pages';
  const PAGE_PROPS = 'page_props';

  public function init()
  {
    $this->authManager = Yii::$app->authManager;
    parent::init();
  }


  public function up()
  {

    /** КАТЕГОРИИ */
    $this->createTable(self::CAT, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'code' => $this->string()->notNull(),
      'name' => $this->string()->notNull(),
      'created_at' => 'INT(10) UNSIGNED NOT NULL',
      'updated_at' => 'INT(10) UNSIGNED NOT NULL'
    ]);

    /** уникальность кода */
    $this->createIndex(self::CAT . '_code_uq', self::CAT, 'code', true);


    /** СВОЙСТВА КАТЕГОРИЙ */
    $this->createTable(self::PROP, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'type' => 'TINYINT(1) NOT NULL',
      'code' => $this->string()->notNull(),
      'name' => $this->string()->notNull(),
      'page_category_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'is_multivalue' => 'TINYINT(1) UNSIGNED NOT NULL'
    ]);
    $this->createIndex(self::PROP . '_type_index', self::PROP, 'type');
    $this->createIndex(self::PROP . '_code_uq', self::PROP, ['page_category_id', 'code'], true);
    $this->addForeignKey(self::PROP . '_page_category_id_fk', self::PROP, 'page_category_id', self::CAT, 'id', 'CASCADE');


    /** СПРАВОЧНИКИ СВОЙСТВ */
    $this->createTable(self::ENTITY, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'code' => $this->string()->notNull(),
      'label' => $this->string()->notNull(),
      'page_category_prop_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
    ]);
    $this->createIndex(self::ENTITY . '_code_uq', self::ENTITY, ['page_category_prop_id', 'code'], true);
    $this->addForeignKey(self::ENTITY . '_page_category_prop_id_fk', self::ENTITY, 'page_category_prop_id', self::PROP, 'id', 'CASCADE');


    $this->createOrGetPermission('PagesCategoriesIndex', 'View categories list');
    $this->assignRolesPermission('PagesCategoriesIndex', ['root']);

    $this->createOrGetPermission('PagesCategoriesCreate', 'Create page category');
    $this->assignRolesPermission('PagesCategoriesCreate', ['root']);

    $this->createOrGetPermission('PagesCategoriesPropModal', 'Create/update page category property');
    $this->assignRolesPermission('PagesCategoriesPropModal', ['root']);

    $this->createOrGetPermission('PagesCategoriesPropEntityModal', 'Create/update category property entity');
    $this->assignRolesPermission('PagesCategoriesPropEntityModal', ['root']);

    $this->createOrGetPermission('PagesCategoriesPropEntityDelete', 'Delete category property entity');
    $this->assignRolesPermission('PagesCategoriesPropEntityDelete', ['root']);

    $this->createOrGetPermission('PagesCategoriesPropDelete', 'Delete category property');
    $this->assignRolesPermission('PagesCategoriesPropDelete', ['root']);

    $this->createOrGetPermission('PagesCategoriesDelete', 'Delete category property');
    $this->assignRolesPermission('PagesCategoriesDelete', ['root']);


    $findCat = \mcms\pages\models\Category::findOne(1);
    if (!$findCat) {
      $this->insert(self::CAT, [
        'id' => 1,
        'code' => 'common',
        'name' => serialize(['ru' => 'Общее', 'en' => 'Common']),
        'created_at' => time(),
        'updated_at' => time()
      ]);
    }


    $this->addColumn(self::PAGES, 'page_category_id', 'MEDIUMINT(5) UNSIGNED NOT NULL');
    $this->update(self::PAGES, ['page_category_id' => 1]);
    $this->addForeignKey(self::PAGES . '_page_category_id_fk', self::PAGES, 'page_category_id', self::CAT, 'id');

    $this->createTable(self::PAGE_PROPS, [
      'id' => 'MEDIUMINT(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
      'page_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'page_category_prop_id' => 'MEDIUMINT(5) UNSIGNED NOT NULL',
      'entity_id' => 'MEDIUMINT(5) UNSIGNED',
      'multilang_value' => $this->text(),
      'value' => $this->text()
    ]);
    $this->addForeignKey(self::PAGE_PROPS . '_page_id_fk', self::PAGE_PROPS, 'page_id', self::PAGES, 'id', 'CASCADE');
    $this->addForeignKey(self::PAGE_PROPS . '_page_category_prop_id_fk', self::PAGE_PROPS, 'page_category_prop_id', self::PROP, 'id', 'CASCADE');
    $this->addForeignKey(self::PAGE_PROPS . '_entity_id_fk', self::PAGE_PROPS, 'entity_id', self::ENTITY, 'id', 'CASCADE');

    $this->dropIndex('pages_code_uk', self::PAGES);
    $this->createIndex(self::PAGES . '_code_uq', self::PAGES, ['page_category_id', 'code'], true);

    $this->dropIndex('pages_url_uk', self::PAGES);
    $this->addColumn(self::PAGES, 'sort', 'MEDIUMINT(3) UNSIGNED NOT NULL DEFAULT 100');
  }

  public function down()
  {
    $this->dropForeignKey(self::PAGES . '_page_category_id_fk', self::PAGES);
    $this->dropColumn(self::PAGES, 'page_category_id');
    $this->dropTable(self::PAGE_PROPS);
    $this->dropForeignKey(self::ENTITY . '_page_category_prop_id_fk' , self::ENTITY);
    $this->dropTable(self::ENTITY);
    $this->dropTable(self::PROP);
    $this->dropTable(self::CAT);
  }

}
