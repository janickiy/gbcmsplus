<?php

use console\components\Migration;

class m160317_173313_reseller_faq_categories_permissions extends Migration
{
  use \mcms\common\traits\PermissionMigration;

  public function init()
  {
    parent::init();
    $this->authManager = Yii::$app->authManager;
    $this->permissions = [
      'PagesFaqCategories' => [
        ['index', 'Display faq categories list', ['reseller']],
        ['view', 'View faq category', ['reseller']],
        ['create', 'Create faq category', ['reseller']],
        ['update', 'Update faq category', ['reseller']],
        ['delete', 'Remove faq category', ['reseller']],
      ]
    ];
  }
}
