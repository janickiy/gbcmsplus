<?php

use console\components\Migration;

class m161221_132032_remove_view_faq_category extends Migration
{

  use \mcms\common\traits\PermissionMigration;

  public function up()
  {
    $this->removePermission('PagesFaqCategoriesView');
  }

  public function down()
  {
    $this->createPermission('PagesFaqCategoriesView', 'Просмотр FAQ категории', 'PagesFaqCategoriesController', ['root', 'reseller', 'admin']);
  }
}
